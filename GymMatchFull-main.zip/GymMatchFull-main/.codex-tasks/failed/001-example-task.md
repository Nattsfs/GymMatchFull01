# Task 001 - Exemplo

## Objetivo
Esta e uma task de exemplo para testar o runner.

## Contexto
Use esta task apenas para validar se o fluxo pending -> running -> done/failed esta funcionando.

## Regras
- Nao altere funcionalidades importantes do projeto.
- Apenas leia a estrutura do projeto e gere um breve relatorio no terminal.

## Criterios de aceite
- [ ] O Codex executou a task.
- [ ] O script aguardou a execucao terminar.
- [ ] O arquivo foi movido para done ou failed.
- [ ] O state.json foi atualizado.
