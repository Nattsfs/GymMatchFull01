# Task 033 - Integrar login administrativo com API

## Objetivo
Conectar a tela de login do painel administrativo à API, armazenar sessão/token de forma segura e proteger rotas internas.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript, preferencialmente Next.js.
- Backend já possui login com JWT.
- Backend já possui autorização por role.
- Usuários possuem role `STUDENT` e `ADMIN`.
- Tela visual de login admin já existe.
- Apenas administradores podem acessar o painel.

Esta task deve implementar autenticação do painel admin contra a API.

## Escopo da task
- Integrar formulário de login do admin com endpoint de login da API.
- Enviar e-mail e senha para a API.
- Receber access token e dados do usuário.
- Validar que o usuário autenticado possui role `ADMIN`.
- Bloquear login no painel para usuário `STUDENT`.
- Armazenar token/sessão de forma segura conforme o padrão do projeto.
- Criar mecanismo de logout.
- Criar proteção de rotas internas.
- Redirecionar usuário autenticado para área interna inicial.
- Redirecionar usuário não autenticado para login.
- Exibir mensagens de erro amigáveis.
- Criar testes básicos de renderização/fluxo, se houver setup disponível.


## Fora de escopo
- Não implementar recuperação de senha.
- Não implementar refresh token no frontend, salvo se já existir padrão simples.
- Não criar dashboard real.
- Não criar tela de usuários.
- Não criar tela de denúncias.
- Não implementar permissões avançadas.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.
- Não implementar cadastro de administrador.

## Arquivos prováveis
- `admin/src/app/login/page.tsx`
- `admin/src/app/(protected)/layout.tsx`
- `admin/src/app/dashboard/page.tsx`
- `admin/src/lib/api-client.ts`
- `admin/src/lib/auth.ts`
- `admin/src/hooks/use-auth.ts`
- `admin/src/components/`
- `admin/src/middleware.ts`, se usar Next.js middleware
- `admin/.env.example`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas role `ADMIN` pode acessar o painel.
- Usuário `STUDENT` deve ser bloqueado mesmo com credenciais válidas.
- Token inválido deve redirecionar para login.
- Não armazene secrets no código.
- Use variável de ambiente para URL da API.
- Não implemente recuperação de senha nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Tela de login envia credenciais para a API.
- [ ] Admin válido consegue acessar área interna.
- [ ] Aluno com credenciais válidas não consegue acessar o painel.
- [ ] Token inválido é tratado.
- [ ] Usuário sem sessão é redirecionado para login.
- [ ] Rotas internas são protegidas.
- [ ] Existe logout.
- [ ] Erros de login são exibidos de forma amigável.
- [ ] Recuperação de senha não foi implementada.
- [ ] Dashboard real não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar

