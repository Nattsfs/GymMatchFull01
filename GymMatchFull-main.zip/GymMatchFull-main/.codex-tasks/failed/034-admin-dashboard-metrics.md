# Task 034 - Criar dashboard administrativo inicial

## Objetivo
Criar dashboard administrativo inicial com cards de métricas reais vindas da API.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Autenticação e autorização admin já existem.
- Painel administrativo já possui login integrado.
- Matches, denúncias e usuários já existem no backend.

O administrador precisa visualizar indicadores principais do sistema em uma tela inicial.

## Escopo da task
- Criar endpoint administrativo de métricas no backend, se ainda não existir.
- Proteger endpoint com JWT e role `ADMIN`.
- Retornar métricas básicas:
  - total de usuários;
  - usuários ativos;
  - total de matches;
  - total de denúncias;
  - assinaturas premium, se existir estrutura de planos;
  - se planos ainda não existirem, retornar 0 ou omitir campo com decisão documentada.
- Criar tela de dashboard no admin.
- Exibir cards com as métricas.
- Criar estado de loading.
- Criar estado de erro.
- Usar client de API existente.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar gráficos avançados.
- Não implementar exportação de relatórios.
- Não implementar filtros avançados.
- Não implementar analytics detalhado.
- Não criar tela de usuários.
- Não criar tela de denúncias.
- Não implementar sistema de assinaturas.
- Não criar dados fake se a API real estiver disponível.

## Arquivos prováveis
- `backend/src/admin/metrics/`
- `backend/src/admin/metrics/admin-metrics.controller.ts`
- `backend/src/admin/metrics/admin-metrics.service.ts`
- `admin/src/app/dashboard/page.tsx`
- `admin/src/components/dashboard/`
- `admin/src/lib/api-client.ts`
- `admin/src/types/metrics.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Métricas administrativas devem exigir role `ADMIN`.
- Usuário `STUDENT` não pode acessar métricas.
- Cards devem usar dados reais da API.
- Não implemente gráficos avançados nesta task.
- Não exponha dados sensíveis.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint admin de métricas, se ainda não existia.
- [ ] Endpoint de métricas exige role `ADMIN`.
- [ ] Aluno é bloqueado no endpoint de métricas.
- [ ] Dashboard carrega métricas reais da API.
- [ ] Dashboard exibe cards de usuários totais.
- [ ] Dashboard exibe cards de usuários ativos.
- [ ] Dashboard exibe cards de matches.
- [ ] Dashboard exibe cards de denúncias.
- [ ] Dashboard trata loading.
- [ ] Dashboard trata erro.
- [ ] Gráficos avançados não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar

