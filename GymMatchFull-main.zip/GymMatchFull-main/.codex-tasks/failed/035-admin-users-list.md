# Task 035 - Criar tela administrativa de usuários

## Objetivo
Criar tela administrativa para listar usuários, aplicar filtros básicos e abrir detalhes de um usuário.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Login administrativo já existe.
- Roles `STUDENT` e `ADMIN` já existem.
- Usuários são vinculados a academia/unidade.
- Endpoints de academias e unidades já existem.

Administradores precisam visualizar e filtrar usuários para operação e moderação.

## Escopo da task
- Criar endpoint administrativo de listagem de usuários, se ainda não existir.
- Proteger endpoint com role `ADMIN`.
- Implementar filtros:
  - academia;
  - unidade;
  - status;
  - busca por nome/e-mail, se fizer sentido.
- Implementar paginação.
- Criar tela admin de usuários.
- Exibir tabela/lista com:
  - nome;
  - e-mail;
  - role;
  - status;
  - academia/unidade;
  - data de criação.
- Permitir abrir detalhe básico do usuário.
- Criar estados de loading e erro.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar suspensão.
- Não implementar banimento.
- Não implementar edição de usuário.
- Não implementar exclusão.
- Não implementar exportação.
- Não implementar auditoria.
- Não criar gráficos.
- Não criar gestão avançada de permissões.

## Arquivos prováveis
- `backend/src/users/admin-users.controller.ts`
- `backend/src/users/users.service.ts`
- `backend/src/users/dto/list-users-query.dto.ts`
- `admin/src/app/users/page.tsx`
- `admin/src/components/users/`
- `admin/src/lib/api-client.ts`
- `admin/src/types/users.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Endpoints administrativos devem exigir role `ADMIN`.
- Usuário `STUDENT` não pode listar usuários.
- A listagem não deve expor `passwordHash`, refresh token ou dados sensíveis desnecessários.
- Use paginação.
- Não implemente suspensão ou banimento nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Admin consegue listar usuários.
- [ ] Usuário `STUDENT` é bloqueado no endpoint.
- [ ] Usuário sem token é bloqueado.
- [ ] Listagem possui paginação.
- [ ] Listagem permite filtro por academia, se dados existirem.
- [ ] Listagem permite filtro por unidade, se dados existirem.
- [ ] Listagem permite filtro por status.
- [ ] Tela admin exibe tabela/lista de usuários.
- [ ] Tela admin possui estados de loading e erro.
- [ ] Detalhe básico do usuário pode ser aberto.
- [ ] Dados sensíveis não são expostos.
- [ ] Suspensão e banimento não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
