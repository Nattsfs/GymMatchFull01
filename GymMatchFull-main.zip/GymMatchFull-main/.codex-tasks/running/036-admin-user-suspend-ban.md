# Task 036 - Implementar suspensão e banimento pelo admin

## Objetivo
Permitir que administradores suspendam ou banam usuários, registrando motivo e auditoria quando possível.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Autenticação JWT e role `ADMIN` já existem.
- Tela administrativa de usuários já existe.
- Usuários possuem status como `ACTIVE`, `SUSPENDED`, `BANNED` ou equivalentes.
- Logs de auditoria podem existir ou ainda não existir.

Administradores precisam punir usuários problemáticos.

## Escopo da task
- Criar endpoints administrativos para suspender e banir usuários, se ainda não existirem.
- Proteger endpoints com role `ADMIN`.
- Receber motivo da ação.
- Atualizar status do usuário:
  - suspensão: `SUSPENDED`;
  - banimento: `BANNED`.
- Registrar motivo da ação, se o modelo permitir.
- Criar log de auditoria se módulo existir.
- Se audit logs ainda não existirem, criar ponto centralizado simples ou documentar pendência.
- Atualizar tela administrativa de usuários para permitir ações:
  - suspender;
  - banir.
- Exibir confirmação antes da ação.
- Atualizar lista/detalhe após ação.
- Criar ou atualizar testes.
## Fora de escopo
- Não implementar fluxo de recurso/apelação.
- Não implementar expiração automática de suspensão.
- Não implementar reativação de usuário, salvo se já existir padrão simples.
- Não implementar exclusão física.
- Não implementar notificações ao usuário punido.
- Não implementar auditoria completa se ainda não existir base.
- Não alterar login além de respeitar status já existente.

## Arquivos prováveis
- `backend/src/users/admin-users.controller.ts`
- `backend/src/users/users.service.ts`
- `backend/src/users/dto/admin-user-action.dto.ts`
- `backend/src/audit-logs/`, se existir
- `admin/src/app/users/page.tsx`
- `admin/src/components/users/`
- `admin/src/lib/api-client.ts`
- `admin/src/types/users.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas admin pode suspender ou banir.
- Aluno não pode executar ações administrativas.
- Suspensão e banimento não devem excluir fisicamente o usuário.
- Usuário punido deve perder acesso ou ficar limitado conforme regras já existentes de login/status.
- Ação deve registrar motivo.
- Ação deve gerar log se auditoria existir.
- Não implemente recurso/apelação nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Admin consegue suspender usuário.
- [ ] Admin consegue banir usuário.
- [ ] Usuário `STUDENT` é bloqueado nos endpoints.
- [ ] Usuário sem token é bloqueado.
- [ ] Motivo da ação é validado.
- [ ] Status do usuário é atualizado corretamente.
- [ ] Usuário suspenso/banido perde acesso ou fica limitado conforme regra existente.
- [ ] Ação gera auditoria se módulo existir.
- [ ] Tela admin permite suspender e banir.
- [ ] Tela admin atualiza status após ação.
- [ ] Exclusão física não foi implementada.
- [ ] Fluxo de recurso/apelação não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
