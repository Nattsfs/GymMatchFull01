# Task 055 - Implementar desfazer match para premium

## Objetivo
Permitir que usuário premium encerre/desfaça um match ativo.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Modelo de matches já existe.
- Endpoint de listagem de matches já existe.
- Chat/conversa já existe.
- Modelo/service de planos já existe.
- Desfazer match é recurso premium.

Esta task implementa o recurso premium de desfazer match. :contentReference[oaicite:3]{index=3}

## Escopo da task
- Criar endpoint autenticado para desfazer match.
- Exemplo de rota: `POST /matches/:matchId/unmatch`.
- Permitir apenas usuários `STUDENT`.
- Validar que o usuário autenticado participa do match.
- Validar que o usuário é premium.
- Bloquear usuários grátis.
- Atualizar status do match para `UNMATCHED` ou equivalente.
- Tornar conversa vinculada inacessível para uso comum, conforme regra do projeto.
- Preservar histórico de mensagens no banco para moderação.
- Não apagar conversa fisicamente.
- Criar ou atualizar testes.

## Fora de escopo
- Não apagar conversa.
- Não apagar mensagens.
