# Task 044 - Criar telas mobile de perfil

## Objetivo
Implementar telas mobile para criação e edição do perfil do aluno.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoints para criação e edição de perfil.
- Aluno já consegue se cadastrar e autenticar.
- O perfil contém objetivo, interesses, gênero, orientação sexual, horários, modalidades e divisão de treino.
Esta task implementa os formulários mobile de perfil previstos na fase 09. :contentReference[oaicite:4]{index=4}

## Escopo da task
- Criar tela de criação de perfil.
- Criar tela de edição de perfil, se o padrão de navegação permitir.
- Criar formulário com campos:
 - data de nascimento;
 - gênero;
 - orientação sexual;
 - visibilidade da orientação sexual;
 - interesses;
 - objetivo no app;
 - objetivo de treino;
 - nível de treino;
 - horários disponíveis;
 - visibilidade dos horários;
 - modalidades preferidas;
- divisão de treino;
 - bio, se existir no backend.
- Validar campos obrigatórios.
- Chamar API para criar perfil.
- Chamar API para editar perfil.
- Tratar loading e erro da API.
- Exibir feedback de sucesso.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar upload de foto.
- Não implementar descoberta.
- Não implementar matches.
- Não implementar chat.
- Não implementar alteração de CPF, e-mail, telefone ou idade manual.
- Não implementar tela de perfil público.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.

 ## Arquivos prováveis
- `mobile/src/screens/profile/CreateProfileScreen.tsx`
- `mobile/src/screens/profile/EditProfileScreen.tsx`
- `mobile/src/profile/`
- `mobile/src/components/forms/`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/profile.ts`
- `mobile/src/navigation/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Trate orientação sexual como dado sensível.
- Permita controlar visibilidade de orientação sexual.
- Permita controlar visibilidade dos horários.
- Não permita alterar CPF, e-mail ou telefone por este fluxo.
- Não implemente upload de foto nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe tela mobile de criação de perfil.
- [ ] Existe tela mobile de edição de perfil, se aplicável.
- [ ] Formulário possui campos principais do perfil.
- [ ] Campos obrigatórios são validados.
- [ ] Criação de perfil chama API corretamente.
- [ ] Edição de perfil chama API corretamente.
- [ ] Erros da API são exibidos.
- [ ] Sucesso é sinalizado ao usuário.
- [ ] Upload de foto não foi implementado.
- [ ] Descoberta não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.


Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
