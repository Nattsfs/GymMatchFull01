# Task 051 - Criar fluxo mobile de denúncia e bloqueio

## Objetivo
Implementar ações mobile para denunciar e bloquear usuários a partir de perfis e conversas.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoints de denúncia de usuário.
- Backend possui endpoint de denúncia de mensagem.
- Backend possui endpoint de bloqueio.
- Tela de descoberta, perfil público e chat podem existir.
- O aluno precisa conseguir denunciar e bloquear usuários.
Esta task implementa o fluxo mobile de denúncia e bloqueio previsto na fase 09. :contentReference[oaicite:11]{index=11}

## Escopo da task
- Adicionar ação de bloquear usuário em locais relevantes:
  - perfil/card;
  - tela de chat, se existir.
- Adicionar ação de denunciar usuário.
- Criar formulário/modal de denúncia com:
  - motivo;
  - descrição opcional.
- Permitir denúncia de mensagem no chat, se a tela de chat já suporta selecionar mensagem.
- Chamar endpoints da API.
- Exibir feedback de sucesso.
- Tratar erro de denúncia duplicada.
- Tratar erro de bloqueio duplicado.
- Após bloqueio, remover usuário da descoberta ou sair da conversa, conforme contexto.
- Criar ou atualizar testes possíveis.
## Fora de escopo
- Não implementar painel administrativo.
- Não implementar análise de denúncia.
- Não implementar suspensão/banimento no mobile.
- Não implementar moderação com IA.
- Não implementar notificações.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.

## Arquivos prováveis
- `mobile/src/reports/`
- `mobile/src/blocks/`
- `mobile/src/components/reports/ReportModal.tsx`
- `mobile/src/screens/discovery/DiscoveryScreen.tsx`
- `mobile/src/screens/chat/ChatScreen.tsx`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/reports.ts`
- `mobile/src/types/blocks.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Motivo da denúncia deve ser obrigatório.
- Descrição deve ser opcional.
- Erros da API devem ser exibidos de forma amigável.
- Após bloquear, usuário não deve continuar aparecendo no contexto atual.
- Não implemente painel administrativo nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Usuário consegue abrir formulário de denúncia.
- [ ] Usuário consegue denunciar outro usuário.
- [ ] Usuário consegue bloquear outro usuário.
- [ ] Motivo de denúncia é obrigatório.
- [ ] Descrição é opcional.
- [ ] Erro de denúncia duplicada é tratado.
- [ ] Erro de bloqueio duplicado é tratado.
- [ ] Após bloqueio, usuário é removido do contexto atual.
- [ ] Denúncia de mensagem funciona se o chat permitir selecionar mensagem.
- [ ] Painel administrativo não foi implementado.
- [ ] Moderação administrativa não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
