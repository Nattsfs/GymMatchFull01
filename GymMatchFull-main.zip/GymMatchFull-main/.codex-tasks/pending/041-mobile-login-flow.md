# Task 041 - Criar fluxo mobile de login

## Objetivo
Implementar a tela de login no app mobile, integrada à API, com armazenamento seguro de token e navegação pós-login.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em React Native com Expo e TypeScript.
- Backend já possui endpoint de login com JWT.
- App mobile já possui navegação base e client HTTP.
- Alunos precisam acessar o app com e-mail e senha.

Esta task corresponde ao fluxo mobile de login previsto no plano da fase 09. :contentReference[oaicite:1]{index=1}

## Escopo da task
- Criar tela de login mobile.
- Criar formulário com:
 - e-mail;
 - senha.
- Validar campos obrigatórios.
- Validar formato básico de e-mail.
- Enviar credenciais para a API.
- Tratar loading.
- Tratar erro visual de credenciais inválidas.
- Armazenar access token de forma segura.
- Se a API retornar refresh token, armazená-lo de forma segura também.
- Criar contexto/hook de autenticação, se ainda não existir.
- Navegar para área autenticada após login válido.
- Impedir acesso à área autenticada sem token.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar cadastro.
- Não implementar recuperação de senha.
- Não implementar refresh automático complexo.
- Não implementar biometria.
- Não implementar login social.
- Não implementar perfil.
- Não implementar QR Code.
- Não implementar telas de descoberta.
- Não alterar backend.

## Arquivos prováveis
- `mobile/src/screens/LoginScreen.tsx`
- `mobile/src/auth/`
- `mobile/src/auth/AuthProvider.tsx`
- `mobile/src/auth/useAuth.ts`
- `mobile/src/navigation/`
- `mobile/src/lib/api-client.ts`
- `mobile/src/storage/secure-storage.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Token deve ser armazenado de forma segura.
- Não salve token em local inseguro se houver alternativa segura no Expo.
- Não coloque secrets no código.
- Exiba erro amigável para login inválido.
- Não implemente cadastro nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.


## Critérios de aceite
- [ ] Existe tela mobile de login.
- [ ] Login chama a API.
- [ ] Login válido armazena token com segurança.
- [ ] Login válido navega para área autenticada.
- [ ] Senha inválida mostra erro visual.
- [ ] Loading é exibido durante requisição.
- [ ] Área autenticada exige token.
- [ ] Cadastro não foi implementado.
- [ ] Recuperação de senha não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
