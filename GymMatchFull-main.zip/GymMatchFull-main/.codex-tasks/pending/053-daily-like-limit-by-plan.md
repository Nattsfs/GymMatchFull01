# Task 053 - Aplicar limite diário de curtidas por plano

## Objetivo
Bloquear curtidas quando o usuário atingir o limite diário do seu plano.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Endpoint de curtir perfil já existe.
- Modelo de curtidas já existe.
- Modelo ou service de planos já existe.
- Plano grátis deve ter limite diário de curtidas.
- Plano premium deve ter limite maior ou ilimitado.
Esta task aplica limites diários de curtidas conforme definido na fase de planos. :contentReference[oaicite:1]{index=1}

## Escopo da task
- Atualizar fluxo de curtir perfil.
- Consultar plano do usuário antes de registrar curtida.
- Contabilizar curtidas realizadas no dia atual.
- Comparar quantidade de curtidas do dia com limite do plano.
- Bloquear curtida quando o limite for atingido.
- Retornar erro claro e amigável para limite atingido.
- Permitir limite maior ou ilimitado para usuário premium.
- Centralizar regra de contagem/limite.
- Criar ou atualizar testes.

## Fora de escopo
- Não criar tela de upgrade.
- Não implementar Stripe.
- Não implementar sistema de pagamento.
- Não implementar desfazer curtida.
- Não alterar descoberta de perfis.
- Não alterar criação de match além do necessário para respeitar o limite.
- Não criar notificações.

## Arquivos prováveis
- `backend/src/likes/likes.service.ts`
- `backend/src/likes/likes.controller.ts`
- `backend/src/plans/plans.service.ts`
- `backend/src/plans/`
- `backend/src/likes/likes.service.spec.ts`
- `backend/src/plans/plans.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- O limite deve considerar curtidas do dia atual.
- Use timezone/intervalo de data de forma consistente com o backend.
- Plano grátis deve respeitar limite diário.
- Premium deve ter limite maior ou ilimitado conforme service de planos.
- A regra de limite deve ficar centralizada.
- Não implemente Stripe nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Curtida abaixo do limite diário é registrada.
- [ ] Curtida ao atingir limite diário do plano grátis é bloqueada.
- [ ] Usuário premium tem limite maior ou ilimitado.
- [ ] Erro de limite atingido é claro.
- [ ] Contagem considera apenas curtidas do período diário definido.
- [ ] Regra de limite está centralizada.
- [ ] Fluxo de curtida continua validando perfil elegível.
- [ ] Stripe não foi implementado.
- [ ] Tela de upgrade não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
