````md
# Task 065 - Padronizar tratamento de erros da API

## Objetivo
Criar um padrão consistente, claro e seguro para respostas de erro da API.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- API HTTP já existe.
- O sistema possui autenticação, cadastro, perfis, descoberta, chat e rotas administrativas.
- A API precisa retornar erros consistentes sem vazar stack trace.

Esta task inicia a fase de observabilidade, qualidade e deploy. :contentReference[oaicite:4]{index=4}
## Escopo da task
- Criar padrão de resposta de erro da API.
- Implementar filtro/middleware global de erros.
- Padronizar erros de:
  - validação;
  - autenticação;
  - autorização;
  - recurso não encontrado;
  - conflito;
  - erro inesperado.
- Criar códigos padronizados de erro.
- Garantir mensagens seguras.
- Evitar stack trace em produção.
- Manter stack trace apenas em desenvolvimento, se o padrão do projeto permitir.
- Atualizar testes de erro principais.

Formato sugerido:
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Dados inválidos.",
    "details": [],
    "timestamp": "2026-01-01T00:00:00.000Z",
    "path": "/example"
  }
}
````
## Fora de escopo

* Não integrar observabilidade externa.
* Não configurar Sentry, Datadog ou similares.
* Não alterar regras de negócio.
* Não refatorar todos os controllers sem necessidade.
* Não alterar frontend.
* Não implementar logs estruturados nesta task, salvo mínimo necessário.

## Arquivos prováveis

* `backend/src/common/errors/`
* `backend/src/common/filters/`
* `backend/src/common/middlewares/`
* `backend/src/main.ts`
* `backend/src/app.ts`
* `backend/src/common/errors/error-codes.ts`
* `backend/src/common/errors/api-error.ts`
* `backend/src/common/filters/http-exception.filter.ts`
* `backend/test/`
* O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias

* Siga o padrão atual do projeto.
* Não faça refatorações grandes fora do escopo da task.
* Não altere comportamento existente sem necessidade.
* Não remova código funcional.
* Use TypeScript.
* Use validações e padrões já existentes no projeto.
* Mantenha nomes consistentes com o domínio do projeto.
* Erros devem ser consistentes.
* Erros não devem vazar stack trace em produção.
* Erros não devem vazar dados sensíveis.
* Não integre observabilidade externa nesta task.
* Ao finalizar, explique brevemente os arquivos alterados.
* Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite

* [ ] Existe padrão de resposta de erro.
* [ ] Existe filtro/middleware global de erro.
* [ ] Erro de validação segue padrão.
* [ ] Erro de autenticação segue padrão.
* [ ] Erro de autorização segue padrão.
* [ ] Erro de recurso não encontrado segue padrão.
* [ ] Erro inesperado segue padrão seguro.
* [ ] Stack trace não aparece em produção.
* [ ] Dados sensíveis não aparecem em erros.
* [ ] Observabilidade externa não foi implementada.
* [ ] O código segue o padrão atual do projeto.
* [ ] Não há erros de TypeScript.
* [ ] As validações do projeto continuam passando.
* [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex

Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.
Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:

* arquivos criados
* arquivos alterados
* decisões tomadas
* como testar
