```md
# Task 068 - Preparar deploy do backend na Render

## Objetivo
Preparar o backend para deploy na Render, com scripts, variáveis, migrations e health check documentados.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- API possui rota `/health`.
- O backend precisa ser hospedado para apresentação do TCC.
- Deploy manual no painel da Render será feito fora do código.
Esta task prepara o backend para deploy conforme a fase 13. :contentReference[oaicite:7]{index=7}

## Escopo da task
- Revisar scripts de build/start do backend.
- Garantir script de produção.
- Garantir script para migrations em deploy.
- Garantir que `/health` funciona para health check.
- Atualizar `.env.example` com variáveis necessárias.
- Criar documentação de deploy na Render.
- Documentar:
  - build command;
  - start command;
  - variáveis de ambiente;
  - configuração de banco;
  - execução de migrations;
  - health check.
- Validar build local, se possível.
## Fora de escopo
- Não fazer deploy manual.
- Não criar conta Render.
- Não configurar banco real de produção.
- Não colocar secrets reais.
- Não alterar regras de negócio.
- Não configurar CI/CD completo.
- Não configurar domínio customizado.

## Arquivos prováveis
- `backend/package.json`
- `backend/prisma/`
- `backend/src/health/`
- `.env.example`
- `README.md`
- `docs/deploy/backend-render.md`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Não coloque secrets reais no repositório.
- Deploy manual fora do código não deve ser realizado.
- Documentação deve ser clara para apresentação do TCC.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite

- [ ] Backend possui script de build.
- [ ] Backend possui script de start produção.
- [ ] Migrations estão documentadas para deploy.
- [ ] `/health` está documentado como health check.
- [ ] `.env.example` está atualizado.
- [ ] Documentação de deploy na Render existe.
- [ ] Build local passa, se possível.
- [ ] Nenhum secret real foi adicionado.
- [ ] Deploy manual não foi feito.
- [ ] CI/CD completo não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
