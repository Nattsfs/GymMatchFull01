# Task 059 - Criar comunicados administrativos

## Objetivo
Criar backend para administradores enviarem comunicados importantes aos alunos.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação e autorização por role já existem.
- Modelo de notificações internas já existe.
- Admin pode enviar comunicados importantes aos alunos.
- Alunos podem visualizar comunicados/notificações.

Esta task cria comunicados administrativos conforme fase 11. :contentReference[oaicite:7]{index=7}

## Escopo da task
- Criar modelo/tabela de comunicado, se necessário.
- Criar módulo `announcements`.
- Criar endpoint admin para criar comunicado.
- Proteger endpoint com role `ADMIN`.
- Permitir definir:
  - título;
  - conteúdo;
  - público-alvo simples.
- Público-alvo mínimo:
  - todos os alunos;
  - alunos de uma academia/unidade, se simples e já disponível.
- Criar notificação interna para alunos elegíveis.
- Criar endpoint para aluno listar comunicados recebidos, se fizer sentido.
- Criar ou atualizar testes.

## Fora de escopo
- Não criar tela web.
- Não criar push notification.
- Não criar e-mail.
- Não implementar segmentação avançada.
- Não implementar agendamento de comunicados.
- Não implementar anexos.
- Não implementar edição visual avançada.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/announcements/announcements.module.ts`
- `backend/src/announcements/announcements.controller.ts`
- `backend/src/announcements/announcements.service.ts`
- `backend/src/announcements/dto/`
- `backend/src/notifications/`
- `backend/src/users/`
- `backend/src/announcements/announcements.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas admin pode criar comunicado.
- Aluno não pode acessar endpoint admin.
- Comunicados devem gerar notificações internas para alunos elegíveis.
- Não implemente push notification nesta task.
- Não implemente tela web nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Admin consegue criar comunicado.
- [ ] Aluno é bloqueado no endpoint admin.
- [ ] Comunicado possui título e conteúdo.
- [ ] Comunicado pode ser direcionado para todos os alunos ou alvo simples definido.
- [ ] Alunos elegíveis recebem/visualizam comunicado.
- [ ] Notificação interna é criada para comunicado, se aplicável.
- [ ] Push notification não foi implementado.
- [ ] E-mail não foi implementado.
- [ ] Tela web não foi implementada.
- [ ] Segmentação avançada não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
