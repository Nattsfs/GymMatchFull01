# Task 050 - Integrar chat mobile com WebSocket

## Objetivo
Atualizar a tela mobile de chat para receber novas mensagens em tempo real via WebSocket autenticado.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui WebSocket autenticado para novas mensagens.
- Tela mobile de chat já existe.
- Login mobile já armazena token.
- O chat deve atualizar automaticamente quando nova mensagem chegar.

Esta task implementa a integração mobile com WebSocket prevista na fase 09. :contentReference[oaicite:10]{index=10}

## Escopo da task
- Criar client WebSocket no app mobile.
- Autenticar conexão usando token armazenado.
- Conectar ao WebSocket ao entrar na tela de chat ou área autenticada.
- Ouvir evento de nova mensagem.
- Atualizar lista de mensagens em tempo real.
- Evitar duplicar mensagens já existentes.
- Tratar token inválido.
- Tratar erro de conexão.
- Implementar reconexão básica, se simples.
- Encerrar listeners ao sair da tela.
- Criar ou atualizar testes possíveis.
## Fora de escopo
- Não implementar push notification.
- Não implementar indicador de digitando.
- Não implementar confirmação de leitura.
- Não implementar presença online.
- Não implementar envio de áudio ou imagem.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.

## Arquivos prováveis
- `mobile/src/chat/websocket-client.ts`
- `mobile/src/screens/chat/ChatScreen.tsx`
- `mobile/src/chat/`
- `mobile/src/auth/`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/chat.ts`
- `mobile/.env.example`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- WebSocket deve usar token autenticado.
- Token inválido deve ser tratado.
- Nova mensagem não deve duplicar na lista.
- Listeners devem ser limpos ao sair da tela.
- Não implemente push notification nesta task.
- Não implemente typing/read receipts nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] App conecta ao WebSocket com token.
- [ ] Token inválido é tratado.
- [ ] Nova mensagem aparece em tempo real.
- [ ] Mensagens não são duplicadas.
- [ ] Erro de conexão é tratado.
- [ ] Reconexão básica existe ou decisão foi documentada.
- [ ] Listeners são removidos ao sair da tela.
- [ ] Push notification não foi implementado.
- [ ] Indicador de digitando não foi implementado.
- [ ] Confirmação de leitura não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
