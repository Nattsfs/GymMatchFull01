```md
# Task 070 - Preparar build do app mobile

## Objetivo
Preparar a configuração de build do app mobile para apresentação e futura publicação.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Login mobile já existe.
- O app mobile será apresentado no TCC e futuramente poderá ser publicado.
- Publicação real na Play Store/App Store não será feita nesta task.

Esta task prepara build mobile conforme fase 13. :contentReference[oaicite:9]{index=9}

## Escopo da task
- Revisar configuração do app mobile.
- Configurar nome do app.
- Configurar ícone/splash placeholder, se já houver assets.
- Configurar ambiente de API.
- Criar ou atualizar `mobile/.env.example`.
- Criar configuração EAS, se o projeto usar Expo EAS.
- Documentar comandos de build.
- Documentar como configurar ambiente local e de apresentação.
- Validar configuração local, se possível.

## Fora de escopo
- Não publicar na Play Store.
- Não publicar na App Store.
- Não configurar conta Apple/Google.
- Não criar assets finais de marca.
- Não implementar novas telas.
- Não alterar backend.
- Não configurar push notifications.
## Arquivos prováveis
- `mobile/app.json`
- `mobile/app.config.ts`
- `mobile/eas.json`
- `mobile/package.json`
- `mobile/.env.example`
- `README.md`
- `docs/deploy/mobile-build.md`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Não coloque secrets reais no repositório.
- Não publique o app.
- Documentação deve ser clara para apresentação do TCC.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] App mobile possui configuração de nome.
- [ ] App mobile possui configuração de API por ambiente.
- [ ] `mobile/.env.example` existe ou está atualizado.
- [ ] Configuração EAS existe, se aplicável.
- [ ] Instruções de build estão documentadas.
- [ ] Nenhum secret real foi adicionado.
- [ ] Publicação real não foi feita.
- [ ] Novas telas não foram implementadas.
- [ ] Push notification não foi configurado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.
Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
