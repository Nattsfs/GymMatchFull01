# Task 057 - Criar modelo de notificações internas

## Objetivo
Modelar notificações internas para avisar usuários sobre eventos importantes dentro do sistema.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários já existem.
- Matches, chat e denúncias já existem ou serão integrados depois.
- O sistema precisa notificar novos matches, mensagens e eventos importantes.

Esta task inicia a fase de notificações, comunicados e suporte. :contentReference[oaicite:5]{index=5}

## Escopo da task
- Criar modelo/tabela de notificações internas.
- Criar migration correspondente.
- Criar módulo `notifications`.
- A notificação deve ter:
  - usuário destinatário;
  - tipo;
  - título;
  - conteúdo;
  - status lida/não lida;
  - timestamps.
- Criar enums para tipo/status, se fizer sentido.
- Criar service/repository para:
  - criar notificação;
  - listar notificações do usuário;
  - marcar notificação como lida.
- Criar endpoints básicos para o usuário:
  - listar minhas notificações;
  - marcar uma notificação como lida.
- Criar testes básicos.

## Fora de escopo
- Não implementar push notification.
- Não implementar e-mail.
- Não integrar ainda com match e chat.
- Não criar tela mobile.
- Não criar painel admin.
- Não implementar notificações em tempo real.
- Não implementar preferências avançadas de notificação.
## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/notifications/notifications.module.ts`
- `backend/src/notifications/notifications.controller.ts`
- `backend/src/notifications/notifications.service.ts`
- `backend/src/notifications/notifications.repository.ts`
- `backend/src/notifications/dto/`
- `backend/src/notifications/notifications.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Usuário só pode listar as próprias notificações.
- Usuário só pode marcar as próprias notificações como lidas.
- Não implemente push notification nesta task.
- Não implemente e-mail nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe modelo/tabela de notificações.
- [ ] Existe migration para notificações.
- [ ] Notificação pertence a um usuário.
- [ ] Notificação possui tipo.
- [ ] Notificação possui título e conteúdo.
- [ ] Notificação possui status de lida/não lida.
- [ ] Usuário consegue listar suas notificações.
- [ ] Usuário consegue marcar sua notificação como lida.
- [ ] Usuário não consegue acessar notificação de outro usuário.
- [ ] Push notification não foi implementado.
- [ ] E-mail não foi implementado.
- [ ] Integração com match/chat não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.
Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
