
```md
# Task 061 - Criar logs de auditoria

## Objetivo
Criar modelo e serviço de auditoria para registrar ações administrativas e sensíveis do sistema.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Autorização por role `ADMIN` já implementada.
- Existem ações administrativas e sensíveis, como suspensão, banimento, acesso a conversa denunciada e alteração de status de denúncia.
- Ações críticas precisam gerar logs com ator, ação e contexto.

Esta task inicia a fase de relatórios, métricas e auditoria. :contentReference[oaicite:0]{index=0}

## Escopo da task
- Criar modelo/tabela `AuditLog`.
- Criar migration correspondente.
- Criar módulo `audit-logs`.
- Criar service centralizado para registrar logs.
- O log deve registrar:
  - ator da ação;
  - tipo da ação;
  - entidade afetada;
  - ID da entidade afetada;
  - contexto em JSON ou estrutura equivalente;
  - IP/user-agent, se disponível de forma simples;
  - timestamp.
- Criar enum ou constantes para ações auditáveis.
- Integrar auditoria inicialmente com ações administrativas já existentes, se possível:
  - suspensão de usuário;
  - banimento de usuário;
  - acesso a conversa denunciada.
- Criar testes para criação de logs.

## Fora de escopo
- Não criar tela de logs.
- Não criar exportação de logs.
- Não criar busca avançada de auditoria.
- Não implementar retenção automática de logs.
- Não implementar integração com serviço externo.
- Não criar observabilidade externa.
- Não registrar dados sensíveis desnecessários.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/audit-logs/audit-logs.module.ts`
- `backend/src/audit-logs/audit-logs.service.ts`
- `backend/src/audit-logs/audit-logs.repository.ts`
- `backend/src/audit-logs/audit-log-actions.ts`
- `backend/src/audit-logs/audit-logs.service.spec.ts`
- `backend/src/users/`
- `backend/src/reports/`
- `backend/src/chat/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Ações críticas devem gerar logs com ator, ação e contexto.
- Não registre senha, tokens, CPF completo ou dados sensíveis desnecessários.
- O serviço de auditoria deve ser reutilizável.
- Não implemente tela de logs nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe modelo/tabela `AuditLog`.
- [ ] Existe migration de auditoria.
- [ ] Existe service para registrar auditoria.
- [ ] Log registra ator da ação.
- [ ] Log registra ação executada.
- [ ] Log registra entidade afetada.
- [ ] Log registra contexto seguro.
- [ ] Suspensão de usuário gera log, se endpoint já existir.
- [ ] Banimento de usuário gera log, se endpoint já existir.
- [ ] Acesso a conversa denunciada gera log, se endpoint já existir.
- [ ] Dados sensíveis desnecessários não são registrados.
- [ ] Tela de logs não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
```
