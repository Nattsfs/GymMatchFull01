# Task 058 - Gerar notificações para match e mensagens

## Objetivo
Integrar notificações internas aos fluxos de novo match e nova mensagem.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Modelo de notificações internas já existe.
- Match automático por curtida mútua já existe.
- Envio de mensagem de texto já existe.
- Usuários devem ser avisados sobre novos matches e mensagens.
Esta task integra notificações internas aos fluxos de match e chat. :contentReference[oaicite:6]{index=6}

## Escopo da task
- Ao criar novo match, gerar notificação para ambos os usuários ou conforme regra definida.
- Ao receber nova mensagem, gerar notificação para o destinatário.
- Não notificar o remetente da própria mensagem.
- Criar payload simples de notificação.
- Usar service de notificações.
- Garantir que falha ao criar notificação não quebre fluxo principal, se essa for a estratégia do projeto.
- Criar testes para match e mensagem.

## Fora de escopo
- Não implementar push notification.
- Não implementar e-mail.
- Não implementar WebSocket de notificações.
- Não criar tela mobile de notificações.
- Não criar preferências de notificação.
- Não alterar fluxo de chat além da geração da notificação.
## Arquivos prováveis
- `backend/src/notifications/notifications.service.ts`
- `backend/src/matches/matches.service.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/notifications/notifications.service.spec.ts`
- `backend/src/matches/matches.service.spec.ts`
- `backend/src/chat/chat.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Novo match deve gerar notificação.
- Nova mensagem deve gerar notificação para destinatário.
- Remetente não deve receber notificação da própria mensagem.
- Não implemente push notification nesta task.
- Não implemente e-mail nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Novo match gera notificação interna.
- [ ] Nova mensagem gera notificação interna para destinatário.
- [ ] Remetente não recebe notificação da própria mensagem.
- [ ] Notificação contém título e conteúdo úteis.
- [ ] Fluxo de match continua funcionando.
- [ ] Fluxo de envio de mensagem continua funcionando.
- [ ] Push notification não foi implementado.
- [ ] E-mail não foi implementado.
- [ ] WebSocket de notificações não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
