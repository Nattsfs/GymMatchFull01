# Task 048 - Criar tela mobile de matches

## Objetivo
Implementar a tela mobile que lista os matches ativos do aluno autenticado.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoint de listagem de matches do aluno.
- Fluxo de descoberta, curtir e recusar já existe.
- O aluno precisa ver pessoas com quem deu match e acessar futuramente o chat.

Esta task implementa a listagem mobile de matches prevista na fase 09. :contentReference[oaicite:8]{index=8}

## Escopo da task
- Criar tela de matches.
- Buscar matches ativos da API.
- Exibir dados públicos do outro usuário.
- Exibir foto, nome e resumo do perfil.
- Exibir estado vazio quando não houver matches.
- Exibir loading e erro.
- Criar ação visual para abrir chat futuramente.
- Integrar rota/navegação para tela de chat, mesmo que chat ainda não esteja implementado.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar tela de chat.
- Não implementar envio de mensagens.
- Não implementar WebSocket.
- Não implementar desfazer match.
- Não implementar notificações.
- Não alterar backend.

## Arquivos prováveis
- `mobile/src/screens/matches/MatchesScreen.tsx`
- `mobile/src/matches/`
- `mobile/src/components/matches/MatchCard.tsx`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/matches.ts`
- `mobile/src/navigation/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Exiba apenas dados públicos retornados pela API.
- Não exiba CPF, telefone ou e-mail.
- Não implemente chat nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe tela mobile de matches.
- [ ] Tela busca matches ativos da API.
- [ ] Tela exibe dados públicos do outro usuário.
- [ ] Tela trata lista vazia.
- [ ] Tela trata loading.
- [ ] Tela trata erro da API.
- [ ] Existe ação visual para abrir chat futuramente.
- [ ] Chat não foi implementado.
- [ ] Dados sensíveis não são exibidos.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
