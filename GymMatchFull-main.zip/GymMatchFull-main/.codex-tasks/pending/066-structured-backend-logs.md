```md
# Task 066 - Adicionar logs estruturados

## Objetivo
Configurar logs estruturados no backend para rastrear requests, erros e eventos importantes sem expor dados sensíveis.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- API HTTP já existe.
- Tratamento padronizado de erros já existe.
- Ações importantes e erros precisam ser rastreáveis.
- Integração com serviço externo não será feita nesta task.
Esta task adiciona logs estruturados ao backend. :contentReference[oaicite:5]{index=5}

## Escopo da task
- Criar logger centralizado.
- Configurar níveis de log por ambiente.
- Registrar requests importantes.
- Registrar erros de forma estruturada.
- Evitar logs de senha, tokens, CPF completo, refresh token ou dados sensíveis.
- Adicionar middleware/interceptor de request logging, se fizer sentido.
- Usar `LOG_LEVEL` do ambiente, se já existir.
- Atualizar `.env.example`, se necessário.
- Criar testes ou validação manual.

## Fora de escopo
- Não integrar serviço externo.
- Não configurar Sentry, Datadog, New Relic ou similares.
- Não criar dashboard de logs.
- Não implementar tracing distribuído.
- Não alterar regras de negócio.
- Não logar payloads sensíveis completos.
## Arquivos prováveis
- `backend/src/logger/`
- `backend/src/common/logger/`
- `backend/src/common/middlewares/request-logger.middleware.ts`
- `backend/src/main.ts`
- `backend/src/config/`
- `.env.example`
- `backend/src/logger/logger.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Logs devem ser estruturados.
- Logs não devem expor senha, token, CPF completo ou dados sensíveis.
- Logger deve ser centralizado.
- Não integre serviço externo nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe logger centralizado.
- [ ] Logs possuem estrutura consistente.
- [ ] Erros são registrados.
- [ ] Requests importantes são registrados.
- [ ] Nível de log é configurável.
- [ ] Dados sensíveis não são logados.
- [ ] Integração externa de logs não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
