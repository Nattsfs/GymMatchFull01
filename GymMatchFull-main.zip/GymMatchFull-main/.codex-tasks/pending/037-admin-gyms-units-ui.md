# Task 037 - Criar tela administrativa de academias e unidades

## Objetivo
Criar interface no painel administrativo para listar, criar, editar e desativar academias e unidades usando os endpoints existentes.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Login administrativo já existe.
- Endpoints administrativos de academias já existem.
- Endpoints administrativos de unidades já existem.
- Apenas administradores podem gerenciar academias e unidades.

O painel admin precisa permitir gestão operacional de academias e unidades.

## Escopo da task
- Criar tela de academias no admin.
- Listar academias com paginação ou padrão existente.
- Criar formulário para cadastrar academia.
- Criar formulário para editar academia.
- Permitir ativar/desativar academia.
- Criar tela ou seção de unidades.
- Listar unidades com filtro por academia.
- Criar formulário para cadastrar unidade.
- Criar formulário para editar unidade.
- Permitir ativar/desativar unidade.
- Usar endpoints existentes da API.
- Exibir loading, erro e feedback de sucesso.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar gestão visual de QR Code.
- Não gerar imagem de QR Code.
- Não implementar leitura de QR Code.
- Não criar relatórios.
- Não criar métricas.
- Não alterar regras de backend, salvo ajustes mínimos necessários.
- Não implementar exclusão física.
- Não implementar múltiplos níveis de permissão.

## Arquivos prováveis
- `admin/src/app/gyms/page.tsx`
- `admin/src/app/gym-units/page.tsx`
- `admin/src/components/gyms/`
- `admin/src/components/gym-units/`
- `admin/src/lib/api-client.ts`
- `admin/src/types/gyms.ts`
- `admin/src/types/gym-units.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Use endpoints administrativos já existentes.
- Rotas da interface devem continuar protegidas por login admin.
- Não implemente QR Code visual nesta task.
- Não implemente exclusão física.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Admin consegue listar academias.
- [ ] Admin consegue criar academia.
- [ ] Admin consegue editar academia.
- [ ] Admin consegue ativar/desativar academia.
- [ ] Admin consegue listar unidades.
- [ ] Admin consegue filtrar unidades por academia.
- [ ] Admin consegue criar unidade.
- [ ] Admin consegue editar unidade.
- [ ] Admin consegue ativar/desativar unidade.
- [ ] Telas possuem loading e erro.
- [ ] Telas usam endpoints existentes.
- [ ] Gestão visual de QR Code não foi implementada.
- [ ] Exclusão física não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
