# Task 040 - Configurar projeto mobile

## Objetivo
Criar a base do app mobile dos alunos, com navegação inicial, tema base, tela inicial e cliente HTTP.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Monorepo com TypeScript.
- App mobile dentro de `mobile/`.
- Backend/API já existe.
- Alunos usarão o app mobile.
- Painel administrativo web é separado.
- O app mobile deve ser focado nos fluxos dos alunos: login, cadastro via QR Code, perfil, descoberta, matches e chat.

Esta task corresponde à fase mobile descrita no plano do projeto. :contentReference[oaicite:0]{index=0}

## Escopo da task
- Configurar o projeto mobile dentro de `mobile/`.
- Usar Expo com React Native e TypeScript, se ainda não houver stack mobile definida.
- Criar estrutura inicial de pastas.
- Configurar navegação base.
- Criar tela inicial.
- Criar tema base.
- Criar client HTTP para chamadas à API.
- Criar configuração de variável de ambiente para URL da API.
- Garantir que o app inicia localmente.
- Adicionar scripts necessários ao `mobile/package.json`.
- Atualizar README ou documentação com instruções para rodar o app mobile.

## Fora de escopo
- Não implementar fluxo completo de login.
- Não implementar cadastro.
- Não implementar leitura de QR Code.
- Não implementar criação de perfil.
- Não implementar descoberta.
- Não implementar matches.
- Não implementar chat.
- Não implementar notificações push.
- Não publicar na Play Store ou App Store.

## Arquivos prováveis
- `mobile/package.json`
- `mobile/app.json`
- `mobile/src/`
- `mobile/src/navigation/`
- `mobile/src/screens/`
- `mobile/src/screens/HomeScreen.tsx`
- `mobile/src/lib/api-client.ts`
- `mobile/src/theme/`
- `mobile/.env.example`
- `README.md`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.


## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- O app deve iniciar localmente.
- Use variável de ambiente para URL da API.
- Não coloque secrets no código.
- Não implemente fluxos completos de autenticação nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.


## Critérios de aceite
- [ ] Projeto mobile existe dentro de `mobile/`.
- [ ] App mobile inicia localmente.
- [ ] Navegação base está configurada.
- [ ] Existe tela inicial.
- [ ] Existe tema base.
- [ ] Existe client HTTP inicial.
- [ ] Existe configuração para URL da API.
- [ ] Scripts de desenvolvimento/build/lint estão configurados, conforme possível.
- [ ] README ou documentação explica como rodar o mobile.
- [ ] Login completo não foi implementado.
- [ ] Cadastro não foi implementado.
- [ ] QR Code não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
