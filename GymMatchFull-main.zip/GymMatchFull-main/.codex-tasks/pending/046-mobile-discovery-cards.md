# Task 046 - Criar tela mobile de descoberta

## Objetivo
Criar interface mobile de descoberta para exibir perfis elegíveis em formato de cards, com botões de curtir e recusar.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoint de descoberta de perfis.
- Perfil e upload de foto já existem.
- Curtir e recusar serão integrados na próxima task.
Esta task implementa a tela visual de descoberta prevista na fase 09. :contentReference[oaicite:6]{index=6}

## Escopo da task
- Criar tela de descoberta.
- Buscar perfis da API.
- Exibir perfis em cards.
- Mostrar dados públicos do perfil:
  - nome;
  - foto;
  - idade, se disponível;
  - objetivo;
  - nível;
  - modalidades;
  - bio, se disponível.
- Respeitar dados retornados pelo backend, sem tentar acessar dados privados.
- Criar botões visuais de curtir e recusar.
- Tratar lista vazia.
- Tratar loading.
- Tratar erro da API.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não integrar chamada real de curtir.
- Não integrar chamada real de recusar.
- Não implementar animações avançadas de swipe.
- Não implementar match.
- Não implementar chat.
- Não implementar filtros avançados.
- Não alterar backend.
## Arquivos prováveis
- `mobile/src/screens/discovery/DiscoveryScreen.tsx`
- `mobile/src/discovery/`
- `mobile/src/components/discovery/ProfileCard.tsx`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/profile.ts`
- `mobile/src/navigation/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Exiba apenas dados públicos retornados pela API.
- Não tente exibir CPF, telefone ou e-mail.
- Não implemente swipe avançado nesta task.
- Não integre curtir/recusar nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe tela mobile de descoberta.
- [ ] Tela busca perfis da API.
- [ ] Tela exibe cards de perfis.
- [ ] Tela possui botões visuais de curtir e recusar.
- [ ] Lista vazia é tratada.
- [ ] Loading é tratado.
- [ ] Erro da API é tratado.
- [ ] Dados sensíveis não são exibidos.
- [ ] Animações avançadas de swipe não foram implementadas.
- [ ] Integração real de curtir/recusar não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.
Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
