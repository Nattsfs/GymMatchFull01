# Task 060 - Criar fluxo básico de suporte

## Objetivo
Criar fluxo básico de tickets de suporte para alunos entrarem em contato e administradores responderem/fecharem solicitações.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação e autorização por role já existem.
- Usuários precisam ter opção de contato com suporte.
- Admins precisam visualizar, responder e fechar tickets.

Esta task cria o fluxo básico de suporte descrito na fase 11. :contentReference[oaicite:8]{index=8}

## Escopo da task
- Criar modelo/tabela de ticket de suporte.
- Criar modelo/tabela de respostas do ticket, se fizer sentido.
- Criar módulo `support`.
- Aluno autenticado pode abrir ticket.
- Aluno pode listar seus próprios tickets.
- Aluno pode ver detalhe do próprio ticket.
- Admin pode listar tickets.
- Admin pode responder ticket.
- Admin pode fechar ticket.
- Criar status de ticket, por exemplo:
  - `OPEN`
  - `IN_PROGRESS`
  - `CLOSED`
- Criar validações de título/mensagem.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar chat em tempo real com suporte.
- Não implementar anexos.
- Não implementar SLA.
- Não implementar notificações por e-mail.
- Não criar tela mobile.
- Não criar tela admin web.
- Não implementar avaliação de atendimento.
- Não implementar atribuição avançada para atendentes.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/support/support.module.ts`
- `backend/src/support/support.controller.ts`
- `backend/src/support/admin-support.controller.ts`
- `backend/src/support/support.service.ts`
- `backend/src/support/dto/`
- `backend/src/support/support.service.spec.ts`
- `backend/src/support/support.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Aluno só pode ver os próprios tickets.
- Admin pode ver tickets administrativos.
- Admin pode responder e fechar ticket.
- Ticket fechado não deve receber novas respostas do aluno, salvo se o projeto decidir permitir reabertura.
- Não implemente chat em tempo real nesta task.
- Não implemente anexos nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe modelo/tabela de ticket de suporte.
- [ ] Aluno autenticado consegue abrir ticket.
- [ ] Aluno consegue listar os próprios tickets.
- [ ] Aluno consegue ver detalhe do próprio ticket.
- [ ] Aluno não consegue ver ticket de outro usuário.
- [ ] Admin consegue listar tickets.
- [ ] Admin consegue responder ticket.
- [ ] Admin consegue fechar ticket.
- [ ] Status do ticket é atualizado corretamente.
- [ ] Mensagem/título são validados.
- [ ] Chat em tempo real com suporte não foi implementado.
- [ ] Anexos não foram implementados.
- [ ] Tela mobile/web não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
