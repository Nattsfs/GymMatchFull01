# Task 039 - Visualizar conversa denunciada com acesso restrito

## Objetivo
Permitir que administradores visualizem mensagens relacionadas a uma denúncia, com acesso restrito e registro de auditoria.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Autenticação JWT e role `ADMIN` já existem.
- Chat, conversas e mensagens já existem.
- Denúncias já existem.
- Tela administrativa de denúncias já existe.
- Admin pode acessar conversa apenas quando necessário para moderação.
Esta task deve permitir visualização restrita de conversa vinculada à denúncia. Não deve permitir acesso livre a qualquer conversa do sistema.

## Escopo da task
- Criar endpoint administrativo para obter mensagens relacionadas a uma denúncia, se ainda não existir.
- Proteger endpoint com role `ADMIN`.
- Validar que a denúncia existe.
- Validar que a denúncia está vinculada a uma mensagem ou conversa.
- Permitir retorno apenas do contexto necessário para moderação.
- Registrar log de auditoria do acesso, se módulo de auditoria existir.
- Se audit logs ainda não existirem, criar ponto centralizado simples ou documentar pendência.
- Atualizar tela de detalhe da denúncia no admin para exibir contexto da conversa.
- Exibir mensagens com:
  - remetente;
  - tipo;
  - conteúdo ou referência segura;
  - data;
  - status da mensagem.
- Exibir mensagens apagadas se forem relevantes para moderação, conforme regra do projeto.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não criar acesso livre a todas as conversas.
- Não criar tela global de conversas.
- Não permitir admin pesquisar qualquer chat sem denúncia.
- Não implementar moderação com IA.
- Não implementar resposta do admin na conversa.
- Não implementar exclusão de mensagens pelo admin.
- Não implementar download irrestrito de mídia.
- Não implementar auditoria completa se ainda não houver base.

## Arquivos prováveis
- `backend/src/chat/admin-chat.controller.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/reports/reports.service.ts`
- `backend/src/audit-logs/`, se existir
- `admin/src/app/reports/[id]/page.tsx`
- `admin/src/components/reports/ReportedConversation.tsx`
- `admin/src/lib/api-client.ts`
- `admin/src/types/reports.ts`
- `admin/src/types/chat.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas admin pode acessar contexto de conversa denunciada.
- O acesso deve exigir denúncia vinculada.
- Admin não deve ter endpoint livre para visualizar qualquer conversa.
- Acesso deve gerar auditoria se o módulo existir.
- Retornar apenas dados mínimos necessários para moderação.
- Não expor dados sensíveis desnecessários.
- Não implementar resposta do admin na conversa.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint admin para visualizar contexto de conversa vinculada à denúncia.
- [ ] Endpoint exige role `ADMIN`.
- [ ] Usuário `STUDENT` é bloqueado.
- [ ] Denúncia inexistente retorna erro adequado.
- [ ] Denúncia sem vínculo com mensagem/conversa não permite acesso indevido.
- [ ] Admin consegue visualizar mensagens relacionadas à denúncia.
- [ ] Admin não consegue acessar conversa não denunciada por esse fluxo.
- [ ] Acesso gera log de auditoria se módulo existir.
- [ ] Tela de detalhe da denúncia exibe contexto da conversa.
- [ ] Dados retornados são mínimos e seguros.
- [ ] Acesso livre a todas as conversas não foi implementado.
- [ ] Tela global de conversas não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
