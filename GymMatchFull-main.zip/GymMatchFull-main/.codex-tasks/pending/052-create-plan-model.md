# Task 052 - Criar modelo de planos

## Objetivo
Modelar os planos do sistema, incluindo plano grátis, plano premium e limites de uso.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários já existem.
- Curtidas, matches e chat já existem.
- O sistema terá plano grátis e plano premium.
- O plano premium permitirá recursos extras, como mais curtidas, mais matches, desfazer curtida, desfazer match e envio de imagem no chat.
Esta task inicia a fase de planos premium e pagamentos descrita no plano do projeto. :contentReference[oaicite:0]{index=0}

## Escopo da task
- Criar modelagem de planos no banco ou enums, conforme padrão do projeto.
- Criar suporte a plano grátis padrão.
- Criar suporte a plano premium.
- Criar limites consultáveis por plano, como:
  - curtidas diárias;
  - matches ativos;
  - envio de imagem no chat;
  - desfazer curtida;
  - desfazer match.
- Criar estrutura inicial de módulo `plans`, se ainda não existir.
- Criar estrutura inicial de `subscriptions`, se fizer sentido.
- Associar usuário ao plano atual.
- Garantir que novos usuários tenham plano grátis por padrão.
- Criar service para consultar plano e permissões do usuário.
- Criar testes básicos.

## Fora de escopo
- Não integrar Stripe.
- Não criar checkout.
- Não criar webhook.
- Não implementar pagamento real.
- Não criar tela de upgrade.
- Não alterar regras de curtida nesta task.
- Não alterar regras de match nesta task.
- Não alterar chat nesta task.
- Não implementar cobrança, nota fiscal ou regras fiscais.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/plans/plans.module.ts`
- `backend/src/plans/plans.service.ts`
- `backend/src/plans/plans.repository.ts`
- `backend/src/subscriptions/`
- `backend/src/users/`
- `backend/src/plans/plans.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Todo usuário deve ter um plano consultável.
- Usuário novo deve ser tratado como plano grátis por padrão.
- Limites e recursos do plano devem ficar centralizados.
- Não implemente Stripe nesta task.
- Não coloque secrets no código.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe modelagem de plano ou enum de plano.
- [ ] Existe representação de plano grátis.
- [ ] Existe representação de plano premium.
- [ ] Usuário possui plano consultável.
- [ ] Usuário novo é tratado como plano grátis por padrão.
- [ ] Limites de curtidas são consultáveis.
- [ ] Limites de matches ativos são consultáveis.
- [ ] Permissão de envio de imagem no chat é consultável.
- [ ] Permissão de desfazer curtida é consultável.
- [ ] Permissão de desfazer match é consultável.
- [ ] Stripe não foi implementado.
- [ ] Pagamento real não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
