# Task 056 - Preparar integração Stripe em modo teste

## Objetivo
Criar a base de integração com Stripe em modo teste para ativação do plano premium.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.
Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Modelo/service de planos já existe.
- O plano premium terá pagamento real usando Stripe em ambiente de teste.
- Variáveis de ambiente do Stripe devem vir do `.env`.

Esta task prepara checkout e webhook básico em modo teste. :contentReference[oaicite:4]{index=4}

## Escopo da task
- Criar módulo `payments` ou `stripe`.
- Configurar Stripe usando variáveis de ambiente.
- Adicionar variáveis ao `.env.example`, se ainda não existirem:
  - `STRIPE_SECRET_KEY`
  - `STRIPE_WEBHOOK_SECRET`
  - `STRIPE_PRICE_ID_PREMIUM`
- Criar endpoint autenticado para iniciar checkout premium.
- Criar checkout session em modo teste.
- Criar endpoint de webhook Stripe.
- Validar assinatura do webhook.
- Tratar evento básico de pagamento/assinatura concluída.
- Atualizar assinatura/plano do usuário para premium após evento válido.
- Criar testes/mocks para checkout e webhook.
- Documentar como testar localmente.

## Fora de escopo
- Não configurar produção real.
- Não tratar regras fiscais.
- Não implementar nota fiscal.
- Não implementar cancelamento completo de assinatura.
- Não implementar portal do cliente.
- Não implementar reembolso.
- Não criar tela mobile de pagamento.
- Não criar tela admin de assinaturas.
- Não colocar chaves reais no repositório.
## Arquivos prováveis
- `backend/src/payments/payments.module.ts`
- `backend/src/payments/payments.controller.ts`
- `backend/src/payments/payments.service.ts`
- `backend/src/payments/stripe.service.ts`
- `backend/src/subscriptions/`
- `backend/src/plans/`
- `backend/src/config/`
- `.env.example`
- `README.md`
- `backend/src/payments/payments.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Use Stripe apenas em modo teste/configurável.
- Não hardcode secrets.
- Não coloque chaves reais no código.
- Webhook deve validar assinatura.
- Usuário só vira premium após evento Stripe válido.
- Não implemente produção real ou regras fiscais nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe módulo de pagamentos/Stripe.
- [ ] Variáveis Stripe estão no `.env.example` sem valores reais.
- [ ] Usuário autenticado consegue iniciar checkout premium.
- [ ] Checkout session é criada usando price id configurado.
- [ ] Existe endpoint de webhook.
- [ ] Webhook valida assinatura.
- [ ] Evento válido atualiza plano/assinatura para premium.
- [ ] Webhook inválido é rejeitado.
- [ ] Chaves reais não foram adicionadas.
- [ ] Produção real não foi configurada.
- [ ] Regras fiscais não foram implementadas.
- [ ] Tela de pagamento não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
