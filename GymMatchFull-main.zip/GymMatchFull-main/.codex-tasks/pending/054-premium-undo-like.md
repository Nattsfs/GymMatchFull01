# Task 054 - Implementar desfazer curtida para premium

## Objetivo
Permitir que usuário premium remova uma curtida feita anteriormente.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Modelo de curtidas já existe.
- Endpoint de curtir perfil já existe.
- Modelo/service de planos já existe.
- Desfazer curtida é recurso premium.

Esta task implementa o recurso premium de desfazer curtida. :contentReference[oaicite:2]{index=2}

## Escopo da task
- Criar endpoint autenticado para desfazer curtida.
- Exemplo de rota: `DELETE /likes/:likedUserId`.
- Permitir apenas usuários `STUDENT`.
- Validar que o usuário autenticado é premium.
- Bloquear usuários grátis.
- Validar que a curtida existe.
- Remover a curtida ou marcar como desfeita, conforme padrão do projeto.
- Se houver match criado por essa curtida, tomar decisão conservadora:
  - não desfazer match nesta task;
  - ou impedir desfazer curtida quando já gerou match;
  - documentar decisão.
- Criar ou atualizar testes.

## Fora de escopo
- Não criar interface mobile.
- Não implementar desfazer match.
- Não implementar reembolso.
- Não implementar Stripe.
- Não alterar sistema de assinatura.
- Não apagar conversa.
- Não implementar histórico avançado de ações.

## Arquivos prováveis
- `backend/src/likes/likes.controller.ts`
- `backend/src/likes/likes.service.ts`
- `backend/src/plans/plans.service.ts`
- `backend/src/matches/`, se for necessário verificar match
- `backend/src/likes/likes.service.spec.ts`
- `backend/src/likes/likes.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas usuário premium pode desfazer curtida.
- Usuário grátis deve ser bloqueado.
- Usuário só pode desfazer a própria curtida.
- Curtida inexistente deve retornar erro adequado.
- Não implemente interface mobile nesta task.
- Não implemente desfazer match nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint para desfazer curtida.
- [ ] Usuário premium consegue desfazer a própria curtida.
- [ ] Usuário grátis é bloqueado.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário não consegue desfazer curtida de outro usuário.
- [ ] Curtida inexistente retorna erro adequado.
- [ ] Decisão sobre curtida que já gerou match foi documentada.
- [ ] Interface mobile não foi implementada.
- [ ] Desfazer match não foi implementado.
- [ ] Stripe não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
