# Task 047 - Integrar curtir e recusar no mobile

## Objetivo
Conectar os botões da tela de descoberta aos endpoints de curtir e recusar perfil.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Tela de descoberta já existe.
- Backend possui endpoint de curtir perfil.
- Backend possui endpoint de recusar perfil.
- Backend cria match automaticamente em curtida mútua.
- A tela deve remover o card atual após curtir ou recusar.
Esta task implementa a integração mobile de curtidas e recusas prevista na fase 09. :contentReference[oaicite:7]{index=7}

## Escopo da task
- Conectar botão de curtir ao endpoint da API.
- Conectar botão de recusar ao endpoint da API.
- Remover card da tela após ação bem-sucedida.
- Tratar loading por ação.
- Tratar erro da API.
- Mostrar feedback quando uma curtida gerar match.
- Tratar limite de curtidas, se a API retornar esse erro.
- Manter lista de descoberta atualizada.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar chat após match.
- Não implementar tela de matches.
- Não implementar animações avançadas.
- Não implementar desfazer curtida.
- Não implementar desfazer match.
- Não alterar backend.

## Arquivos prováveis
- `mobile/src/screens/discovery/DiscoveryScreen.tsx`
- `mobile/src/discovery/`
- `mobile/src/components/discovery/ProfileCard.tsx`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/likes.ts`
- `mobile/src/types/rejections.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Após curtir ou recusar, o perfil deve sair da tela atual.
- Se a curtida gerar match, mostrar feedback claro.
- Tratar erro de limite de curtidas de forma amigável.
- Não implementar chat nesta task.
- Não alterar backend.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Botão curtir chama API corretamente.
- [ ] Botão recusar chama API corretamente.
- [ ] Card é removido após curtir.
- [ ] Card é removido após recusar.
- [ ] Feedback de match é mostrado quando API indicar match.
- [ ] Erro de limite de curtidas é tratado visualmente.
- [ ] Loading da ação é tratado.
- [ ] Erro geral da API é tratado.
- [ ] Chat após match não foi implementado.
- [ ] Tela de matches não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
