# Task 045 - Implementar upload de foto no mobile

## Objetivo
Permitir que o aluno selecione, visualize e envie uma foto de perfil pelo app mobile.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoint de upload de foto de perfil.
- Telas de perfil mobile já existem.
- Perfil sem foto não pode dar match futuramente.

Esta task implementa upload de foto no app mobile conforme previsto na fase 09. :contentReference[oaicite:5]{index=5}

## Escopo da task
- Permitir selecionar imagem da galeria.
- Solicitar permissões necessárias.
- Tratar permissão negada.
- Exibir pré-visualização da imagem.
- Enviar imagem para API usando endpoint existente.
- Tratar loading.
- Tratar erro de arquivo inválido ou upload falho.
- Atualizar foto exibida no perfil após sucesso.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar edição avançada de imagem.
- Não implementar crop.
- Não implementar filtros.
- Não implementar compressão avançada.
- Não implementar múltiplas fotos.
- Não implementar upload de imagem no chat.
- Não alterar backend, salvo ajuste mínimo necessário e justificado
## Arquivos prováveis
- `mobile/src/screens/profile/ProfilePhotoScreen.tsx`
- `mobile/src/screens/profile/EditProfileScreen.tsx`
- `mobile/src/profile/`
- `mobile/src/media/`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/profile.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Trate permissão negada.
- Exiba pré-visualização antes ou depois do envio.
- Use endpoint existente da API.
- Não implemente edição avançada de imagem.
- Não coloque secrets no código.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Aluno consegue selecionar imagem.
- [ ] Permissão negada é tratada.
- [ ] Imagem selecionada é pré-visualizada.
- [ ] Upload chama API corretamente.
- [ ] Upload válido atualiza foto no perfil.
- [ ] Erro de upload é exibido.
- [ ] Arquivo inválido é tratado, se a API retornar erro.
- [ ] Edição avançada de imagem não foi implementada.
- [ ] Upload de imagem no chat não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
