```md
# Task 067 - Criar testes e2e dos fluxos principais

## Objetivo
Criar testes end-to-end para cobrir os fluxos críticos do backend e demonstrar estabilidade do MVP.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação, perfis, curtidas, matches, chat, denúncias e admin já existem.
- O TCC precisa demonstrar estabilidade dos principais fluxos.

Esta task cria testes e2e dos fluxos principais conforme a fase 13. :contentReference[oaicite:6]{index=6}
## Escopo da task
- Criar estrutura de testes e2e, se ainda não existir.
- Criar factories/fixtures para dados básicos.
- Criar testes e2e para:
  - cadastro;
  - login;
  - criação de perfil;
  - curtida;
  - match por curtida mútua;
  - envio de mensagem;
  - denúncia;
  - ação administrativa básica.
- Garantir isolamento dos testes.
- Documentar como rodar os testes e2e.
- Ajustar scripts de test:e2e, se necessário.


## Fora de escopo
- Não criar testes visuais mobile.
- Não criar testes visuais web.
- Não criar testes de carga.
- Não criar mocks complexos de serviços externos além do necessário.
- Não implementar novas funcionalidades de negócio.
- Não refatorar grandes partes do sistema.

## Arquivos prováveis
- `backend/test/e2e/`
- `backend/test/factories/`
- `backend/test/fixtures/`
- `backend/test/setup-e2e.ts`
- `backend/package.json`
- `README.md`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Testes e2e devem ser claros e reproduzíveis.
- Testes não devem depender de dados reais.
- Testes não devem usar secrets reais.
- Não implemente novas funcionalidades nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe estrutura de testes e2e.
- [ ] Existe teste e2e de cadastro.
- [ ] Existe teste e2e de login.
- [ ] Existe teste e2e de perfil.
- [ ] Existe teste e2e de curtida.
- [ ] Existe teste e2e de match.
- [ ] Existe teste e2e de chat.
- [ ] Existe teste e2e de denúncia.
- [ ] Existe teste e2e de ação admin.
- [ ] Existe script para rodar testes e2e.
- [ ] Testes não usam dados reais.
- [ ] Testes não usam secrets reais.
- [ ] Testes visuais mobile/web não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.
Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
