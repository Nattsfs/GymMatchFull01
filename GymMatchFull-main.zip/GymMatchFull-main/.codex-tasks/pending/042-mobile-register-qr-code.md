# Task 042 - Criar leitura de QR Code no cadastro mobile

## Objetivo
Implementar a primeira etapa do cadastro mobile: leitura ou entrada manual do token do QR Code da academia/unidade.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoint público de validação do token de QR Code da unidade.
- Cadastro do aluno começa com QR Code da academia/unidade.
- O app deve validar o token e guardar a unidade selecionada para o fluxo de cadastro.
Esta task corresponde à leitura/validação do QR Code prevista para o cadastro mobile. :contentReference[oaicite:2]{index=2}

## Escopo da task
- Criar tela de cadastro inicial por QR Code.
- Permitir leitura de QR Code usando câmera, se a stack atual suportar.
- Permitir entrada manual do token como fallback.
- Solicitar permissão de câmera.
- Tratar permissão negada.
- Validar token na API.
- Exibir academia/unidade retornada pela API.
- Guardar token e dados públicos da unidade no estado do fluxo de cadastro.
- Exibir erro para QR Code inválido.
- Criar ou atualizar testes possíveis.


## Fora de escopo
- Não implementar cadastro completo.
- Não criar conta de usuário.
- Não implementar verificação de SMS/e-mail.
- Não implementar perfil.
- Não implementar login.
- Não implementar geração de QR Code.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.

## Arquivos prováveis
- `mobile/src/screens/register/QrCodeScreen.tsx`
- `mobile/src/register/`
- `mobile/src/qr-code/`
- `mobile/src/navigation/`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/gym-unit.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Trate permissão de câmera negada.
- Permita entrada manual do token como fallback.
- Não crie conta de usuário nesta task.
- Não coloque secrets no código.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.


## Critérios de aceite
- [ ] Existe tela de leitura/entrada de QR Code.
- [ ] App solicita permissão de câmera, se usar câmera.
- [ ] Permissão negada é tratada.
- [ ] Token válido é validado na API.
- [ ] Token válido mostra academia/unidade.
- [ ] Token inválido mostra erro.
- [ ] Token e unidade selecionada ficam disponíveis para próxima etapa do cadastro.
- [ ] Cadastro completo não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
