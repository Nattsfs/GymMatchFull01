```md
# Task 064 - Criar tela de relatórios no painel admin

## Objetivo
Criar tela no painel administrativo para selecionar filtros e baixar relatórios em Excel.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Login administrativo já existe.
- Endpoint de exportação Excel já existe.
- Admin precisa baixar relatórios pela interface.
Esta task cria a tela web de relatórios prevista na fase 12. :contentReference[oaicite:3]{index=3}

## Escopo da task
- Criar tela de relatórios no painel admin.
- Permitir selecionar tipo de relatório:
  - usuários;
  - matches;
  - denúncias;
  - resumo geral.
- Permitir aplicar filtros simples:
  - período;
  - status;
  - academia/unidade, se já houver dados/endpoints.
- Chamar endpoint de exportação.
- Baixar arquivo Excel retornado pela API.
- Exibir loading durante geração.
- Exibir erro da API.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não criar editor visual de relatórios.
- Não criar gráficos.
- Não criar agendamento.
- Não enviar relatório por e-mail.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.
- Não implementar BI avançado.

## Arquivos prováveis
- `admin/src/app/reports/export/page.tsx`
- `admin/src/components/reports/ReportExportForm.tsx`
- `admin/src/lib/api-client.ts`
- `admin/src/types/reports.ts`
- `admin/src/types/gyms.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Rotas devem estar protegidas pelo login admin.
- O download deve usar o endpoint real da API.
- Trate loading e erro.
- Não implemente editor visual de relatórios.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe tela admin de exportação de relatórios.
- [ ] Admin consegue selecionar tipo de relatório.
- [ ] Admin consegue aplicar filtros disponíveis.
- [ ] Admin consegue baixar Excel.
- [ ] Loading é exibido.
- [ ] Erro da API é exibido.
- [ ] Rota está protegida pelo login admin.
- [ ] Editor visual de relatórios não foi implementado.
- [ ] Gráficos não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
