# Task 049 - Criar tela mobile de chat

## Objetivo
Implementar tela mobile de conversa com listagem de mensagens e envio de texto.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoints para listar mensagens e enviar mensagem de texto.
- Tela de matches já existe.
- Usuários com match ativo podem conversar.

Esta task implementa a tela mobile de chat básico prevista na fase 09. :contentReference[oaicite:9]{index=9}
## Escopo da task
- Criar tela de chat.
- Receber ID da conversa ou match pela navegação.
- Buscar mensagens da conversa na API.
- Exibir mensagens em ordem adequada.
- Diferenciar mensagens enviadas pelo usuário autenticado e pelo outro usuário.
- Criar campo de texto para nova mensagem.
- Enviar mensagem de texto pela API.
- Atualizar conversa após envio.
- Tratar loading, erro e estado vazio.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar áudio.
- Não implementar imagem.
- Não implementar WebSocket.
- Não implementar push notification.
- Não implementar exclusão de mensagem.
- Não implementar denúncia/bloqueio na tela de chat.
- Não alterar backend.

## Arquivos prováveis
- `mobile/src/screens/chat/ChatScreen.tsx`
- `mobile/src/chat/`
- `mobile/src/components/chat/MessageBubble.tsx`
- `mobile/src/components/chat/MessageInput.tsx`
- `mobile/src/lib/api-client.ts`
- `mobile/src/types/chat.ts`
- `mobile/src/navigation/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Usuário só deve visualizar conversa acessível pela API.
- Mensagem vazia não deve ser enviada.
- Trate erro de conversa sem permissão.
- Não implemente WebSocket nesta task.
- Não implemente áudio ou imagem nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe tela mobile de chat.
- [ ] Tela lista mensagens da conversa.
- [ ] Tela envia mensagem de texto.
- [ ] Mensagem enviada aparece na conversa.
- [ ] Mensagem vazia não é enviada.
- [ ] Loading é tratado.
- [ ] Erro de rede é tratado.
- [ ] Erro de conversa sem permissão é tratado.
- [ ] WebSocket não foi implementado.

- [ ] Áudio e imagem não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
