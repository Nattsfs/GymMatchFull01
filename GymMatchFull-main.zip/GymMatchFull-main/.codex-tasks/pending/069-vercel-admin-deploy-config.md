```md
# Task 069 - Preparar deploy do painel admin na Vercel

## Objetivo
Preparar o painel administrativo web para deploy na Vercel, com variáveis, build e documentação.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Preferencialmente Next.js.
- Login administrativo já existe.
- O painel administrativo precisa ser hospedado para apresentação.
- Deploy manual no painel da Vercel será feito fora do código.

Esta task prepara o painel admin para deploy conforme fase 13. :contentReference[oaicite:8]{index=8}

## Escopo da task
- Revisar scripts do app admin.
- Garantir que o admin possui build local.
- Configurar uso de variável de ambiente para API URL.
- Criar ou atualizar `admin/.env.example`.
- Documentar deploy na Vercel.
- Documentar:
  - install command;
  - build command;
  - output/framework;
  - variáveis de ambiente;
  - URL da API;
  - cuidados com autenticação.
- Validar build local, se possível.

## Fora de escopo
- Não fazer deploy manual.
- Não criar conta Vercel.
- Não configurar domínio customizado.
- Não colocar secrets reais.
- Não alterar backend.
- Não implementar novas telas.
- Não configurar CI/CD completo.
## Arquivos prováveis
- `admin/package.json`
- `admin/.env.example`
- `admin/next.config.js` ou equivalente
- `README.md`
- `docs/deploy/admin-vercel.md`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Não coloque secrets reais no repositório.
- Deploy manual fora do código não deve ser realizado.
- Documentação deve ser clara para apresentação do TCC.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Admin possui script de build.
- [ ] Admin usa variável de ambiente para API URL.
- [ ] `admin/.env.example` existe ou está atualizado.
- [ ] Documentação de deploy na Vercel existe.
- [ ] Build local passa, se possível.
- [ ] Nenhum secret real foi adicionado.
- [ ] Deploy manual não foi feito.
- [ ] CI/CD completo não foi implementado.
- [ ] Nenhuma tela nova foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
