# Task 043 - Criar fluxo mobile de cadastro básico

## Objetivo
Implementar o fluxo mobile de cadastro básico do aluno após validação do QR Code da unidade.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- App mobile em Expo/React Native com TypeScript.
- Backend possui endpoint de cadastro associado ao token do QR Code.
- Tela de leitura/validação de QR Code já existe.
- O aluno deve criar conta vinculada à unidade escaneada.

Esta task implementa o cadastro básico mobile previsto após a validação do QR Code. :contentReference[oaicite:3]{index=3}

## Escopo da task
- Criar telas/formulário de cadastro básico.
- Coletar:
 - nome;
 - e-mail;
 - CPF;
 - telefone;
 - senha;
 - confirmação de senha, se fizer sentido.
- Usar token do QR Code validado anteriormente.
- Validar campos no app.
- Validar e-mail básico.
- Validar senha mínima conforme backend.
- Validar confirmação de senha, se existir.
- Chamar endpoint de cadastro da API.
- Tratar loading.
- Tratar erros da API:
 - CPF duplicado;
 - e-mail duplicado;
 - telefone duplicado;
 - QR Code inválido;
 - senha fraca.
- Navegar para login ou área autenticada, conforme padrão definido.
- Criar ou atualizar testes possíveis.
## Fora de escopo
- Não implementar verificação real de SMS.
- Não implementar verificação real de e-mail.
- Não implementar criação de perfil completo.
- Não implementar upload de foto.
- Não implementar login automático se o backend não retornar tokens.
- Não implementar recuperação de senha.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.

## Arquivos prováveis
- `mobile/src/screens/register/RegisterScreen.tsx`
- `mobile/src/screens/register/`
- `mobile/src/register/`
- `mobile/src/forms/`
- `mobile/src/lib/api-client.ts`
- `mobile/src/navigation/`
- `mobile/src/types/auth.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Cadastro deve usar o token da unidade validada.
- Não confie em gymId/gymUnitId informados manualmente no app.
- Exiba erros amigáveis.
- Não implemente verificação real de SMS/e-mail nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe fluxo mobile de cadastro básico.
- [ ] Cadastro usa token do QR Code validado.
- [ ] Formulário valida campos obrigatórios.
- [ ] Formulário valida e-mail inválido.
- [ ] Formulário valida senha fraca.
- [ ] Cadastro válido chama API e cria aluno vinculado à unidade.
- [ ] Erro de CPF duplicado é tratado visualmente.
- [ ] Erro de e-mail duplicado é tratado visualmente.
- [ ] Erro de QR inválido é tratado visualmente.
- [ ] Verificação real de SMS/e-mail não foi implementada.
- [ ] Criação de perfil completo não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.


## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
