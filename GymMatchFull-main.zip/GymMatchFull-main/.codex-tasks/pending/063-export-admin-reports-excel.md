```md
# Task 063 - Implementar exportação de relatórios em Excel

## Objetivo
Criar endpoint administrativo para exportar relatórios em Excel com dados administrativos do sistema.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Autorização por role `ADMIN` já implementada.
- Métricas administrativas já existem.
- Admin poderá baixar relatórios automaticamente.
Esta task implementa exportação Excel prevista na fase 12. :contentReference[oaicite:2]{index=2}

## Escopo da task
- Criar módulo ou service de exportação de relatórios.
- Criar endpoint admin para exportar Excel.
- Exemplo de rota: `GET /admin/reports/export`.
- Proteger endpoint com role `ADMIN`.
- Suportar tipos de relatório:
  - usuários;
  - matches;
  - denúncias;
  - resumo geral.
- Permitir filtros simples, se já existirem:
  - período;
  - status;
  - academia/unidade, quando aplicável.
- Gerar arquivo `.xlsx` válido.
- Definir nome de arquivo coerente.
- Configurar content-type e headers de download.
- Criar testes para exportação válida e acesso bloqueado.
## Fora de escopo
- Não criar gráficos dentro da planilha.
- Não criar editor visual de relatórios.
- Não criar tela admin.
- Não implementar agendamento de relatórios.
- Não implementar envio por e-mail.
- Não exportar dados sensíveis desnecessários.
- Não criar BI avançado.

## Arquivos prováveis
- `backend/src/reports-export/reports-export.module.ts`
- `backend/src/reports-export/reports-export.controller.ts`
- `backend/src/reports-export/reports-export.service.ts`
- `backend/src/reports-export/dto/export-report-query.dto.ts`
- `backend/src/admin/metrics/`
- `backend/src/users/`
- `backend/src/matches/`
- `backend/src/reports/`
- `backend/package.json`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Endpoint deve exigir role `ADMIN`.
- Usuário `STUDENT` deve ser bloqueado.
- Gerar arquivo Excel válido.
- Não exportar senha, `passwordHash`, tokens ou dados sensíveis desnecessários.
- Não implementar gráficos dentro da planilha.
- Se adicionar biblioteca de Excel, justificar no resumo final.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint admin para exportar relatório em Excel.
- [ ] Endpoint exige JWT válido.
- [ ] Endpoint exige role `ADMIN`.
- [ ] Usuário `STUDENT` é bloqueado.
- [ ] Admin consegue baixar arquivo `.xlsx` válido.
- [ ] Exportação de usuários funciona.
- [ ] Exportação de matches funciona.
- [ ] Exportação de denúncias funciona.
- [ ] Exportação de resumo geral funciona.
- [ ] Filtros simples são aplicados, se implementados.
- [ ] Senhas, hashes e tokens não são exportados.
- [ ] Gráficos dentro da planilha não foram implementados.
- [ ] Tela admin não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
