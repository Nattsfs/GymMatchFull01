```md
# Task 062 - Criar métricas administrativas no backend

## Objetivo
Criar endpoints administrativos de métricas para alimentar o dashboard do painel admin.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Autorização por role `ADMIN` já implementada.
- Usuários, matches e denúncias já existem.
- O dashboard administrativo precisa exibir indicadores do sistema.
Esta task cria métricas administrativas no backend, conforme previsto na fase 12. :contentReference[oaicite:1]{index=1}

## Escopo da task
- Criar módulo ou controller de métricas administrativas.
- Criar endpoint protegido por role `ADMIN`.
- Exemplo de rota: `GET /admin/metrics`.
- Retornar métricas:
  - usuários totais;
  - usuários ativos;
  - matches totais;
  - matches ativos;
  - denúncias totais;
  - denúncias abertas;
  - horários mais procurados;
  - idade média;
  - faixas etárias.
- Garantir que usuário `STUDENT` não acessa.
- Garantir que usuário sem token não acessa.
- Criar testes para métricas vazias e com dados
## Fora de escopo
- Não implementar exportação Excel.
- Não criar gráficos.
- Não criar tela admin.
- Não implementar cache.
- Não implementar analytics avançado.
- Não expor dados pessoais individuais.
- Não criar relatórios customizados.

## Arquivos prováveis
- `backend/src/admin/metrics/admin-metrics.module.ts`
- `backend/src/admin/metrics/admin-metrics.controller.ts`
- `backend/src/admin/metrics/admin-metrics.service.ts`
- `backend/src/admin/metrics/dto/`
- `backend/src/users/`
- `backend/src/matches/`
- `backend/src/reports/`
- `backend/src/profiles/`
- `backend/src/admin/metrics/admin-metrics.service.spec.ts`
- `backend/src/admin/metrics/admin-metrics.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Endpoint de métricas deve exigir role `ADMIN`.
- Usuário `STUDENT` deve ser bloqueado.
- Métricas devem ser agregadas.
- Não retorne CPF, telefone, e-mail ou dados pessoais desnecessários.
- Não implemente exportação Excel nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint administrativo de métricas.
- [ ] Endpoint exige JWT válido.
- [ ] Endpoint exige role `ADMIN`.
- [ ] Usuário `STUDENT` é bloqueado.
- [ ] Métricas vazias retornam valores coerentes.
- [ ] Métricas com dados retornam contagens corretas.
- [ ] Retorna usuários totais e ativos.
- [ ] Retorna matches totais e ativos.
- [ ] Retorna denúncias totais e abertas.
- [ ] Retorna horários mais procurados, se dados existirem.
- [ ] Retorna idade média/faixas, se dados existirem.
- [ ] Exportação Excel não foi implementada.
- [ ] Dados pessoais desnecessários não são expostos.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
