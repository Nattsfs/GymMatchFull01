# Task 038 - Criar tela administrativa de denúncias

## Objetivo
Criar interface administrativa para listar, filtrar, visualizar detalhes e alterar status de denúncias.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Admin web em TypeScript.
- Backend/API em TypeScript.
- Login administrativo já existe.
- Endpoints administrativos de denúncias já existem.
- Usuários podem denunciar usuários e mensagens.
- Administradores analisam denúncias e podem tomar ações.

Esta task cria a interface web para gestão de denúncias, sem implementar visualização completa de conversa denunciada.

## Escopo da task
- Criar tela de denúncias no admin.
- Listar denúncias com paginação.
- Permitir filtros:
  - status;
  - urgência;
  - tipo;
  - motivo.
- Abrir detalhe da denúncia.
- Exibir dados mínimos:
  - denunciante;
  - denunciado;
  - tipo;
  - motivo;
  - descrição;
  - status;
  - urgência;
  - datas.
- Permitir alterar status da denúncia.
- Permitir marcar/desmarcar urgência, se endpoint existir.
- Permitir executar ações administrativas já disponíveis, se endpoints existirem:
  - suspender usuário denunciado;
  - banir usuário denunciado.
- Exibir loading, erro e feedback de sucesso.
- Criar ou atualizar testes possíveis.

## Fora de escopo
- Não implementar visualização completa de conversa denunciada.
- Não implementar acesso livre a conversas.
- Não criar moderação com IA.
- Não implementar notificações avançadas.
- Não criar recurso/apelação.
- Não alterar backend, salvo ajuste mínimo necessário e justificado.
- Não implementar auditoria visual completa.

## Arquivos prováveis
- `admin/src/app/reports/page.tsx`
- `admin/src/app/reports/[id]/page.tsx`
- `admin/src/components/reports/`
- `admin/src/lib/api-client.ts`
- `admin/src/types/reports.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Rotas da interface devem continuar protegidas por login admin.
- Use endpoints administrativos já existentes.
- Não exponha dados sensíveis além do necessário para moderação.
- Não implemente visualização completa de conversa denunciada nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Admin consegue listar denúncias.
- [ ] Admin consegue filtrar denúncias por status.
- [ ] Admin consegue filtrar denúncias por urgência.
- [ ] Admin consegue abrir detalhe de denúncia.
- [ ] Admin consegue alterar status da denúncia.
- [ ] Admin consegue marcar/desmarcar urgência, se endpoint existir.
- [ ] Admin consegue executar ações já disponíveis, como suspender/banir denunciado.
- [ ] Tela possui loading e erro.
- [ ] Tela usa endpoints existentes.
- [ ] Visualização completa de conversa denunciada não foi implementada.
- [ ] Acesso livre a conversas não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
