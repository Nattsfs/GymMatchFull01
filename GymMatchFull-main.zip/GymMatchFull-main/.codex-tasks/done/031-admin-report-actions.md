# Task 031 - Criar ações administrativas em denúncias

## Objetivo
Implementar endpoints administrativos para que administradores possam listar, analisar e tomar ações em denúncias.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Autorização por role já implementada.
- Usuários possuem role `STUDENT` e `ADMIN`.
- Modelo de denúncias já existe.
- Endpoints de denúncia de usuário e mensagem já existem.
- Administradores podem suspender ou banir usuários denunciados.
- Logs de auditoria podem existir ou ainda não existir.

Esta task cria apenas endpoints administrativos de backend. A tela web será implementada depois.

## Escopo da task
- Criar endpoints administrativos para denúncias.
- Proteger todos os endpoints com JWT e role `ADMIN`.
- Implementar listagem paginada de denúncias.
- Implementar filtros, se simples:
 - status;
 - urgência;
 - tipo;
 - motivo.
- Implementar endpoint de detalhe da denúncia.
- Implementar alteração de status da denúncia.
- Implementar marcação/desmarcação de urgência.
- Implementar ação para suspender usuário denunciado.
- Implementar ação para banir usuário denunciado.
- Registrar auditoria da ação, se módulo de audit logs já existir.
- Se módulo de audit logs não existir, criar integração mínima ou deixar ponto centralizado documentado, sem implementar sistema completo de auditoria.
- Criar ou atualizar testes.

Sugestão de rotas:
- `GET /admin/reports`
- `GET /admin/reports/:id`
- `PATCH /admin/reports/:id/status`
- `PATCH /admin/reports/:id/urgency`
- `POST /admin/reports/:id/suspend-reported-user`
- `POST /admin/reports/:id/ban-reported-user`

## Fora de escopo
- Não criar tela web.
- Não implementar painel administrativo frontend.
- Não implementar visualização completa de conversas denunciadas, salvo dados mínimos já relacionados à denúncia.
- Não implementar recurso/apelação do usuário punido.
- Não implementar moderação com IA.
- Não implementar notificações avançadas.
- Não implementar auditoria completa se ainda não existir módulo próprio.
- Não implementar exclusão física de usuários.

## Arquivos prováveis
- `backend/src/reports/admin-reports.controller.ts`
- `backend/src/reports/reports.controller.ts`
- `backend/src/reports/reports.service.ts`
- `backend/src/reports/dto/list-reports-query.dto.ts`
- `backend/src/reports/dto/update-report-status.dto.ts`
- `backend/src/reports/dto/update-report-urgency.dto.ts`
- `backend/src/users/users.service.ts`
- `backend/src/audit-logs/`, se existir
- `backend/src/auth/guards/`
- `backend/src/auth/decorators/`
- `backend/src/reports/reports.service.spec.ts`
- `backend/src/reports/admin-reports.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Todos os endpoints administrativos devem exigir role `ADMIN`.
- Usuário `STUDENT` não pode acessar endpoints administrativos de denúncias.
- Alteração de status deve validar status permitido.
- Suspensão deve alterar status do usuário denunciado para `SUSPENDED` ou equivalente.
- Banimento deve alterar status do usuário denunciado para `BANNED` ou equivalente.
- Não fazer exclusão física de usuário.
- Ações administrativas devem gerar auditoria se o projeto já tiver suporte.
- Não criar tela web nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Admin consegue listar denúncias com paginação.
- [ ] Admin consegue filtrar denúncias por status, se implementado.
- [ ] Admin consegue visualizar detalhe de denúncia.
- [ ] Admin consegue alterar status da denúncia.
- [ ] Admin consegue marcar ou desmarcar denúncia como urgente.
- [ ] Admin consegue suspender usuário denunciado.
- [ ] Admin consegue banir usuário denunciado.
- [ ] Usuário `STUDENT` é bloqueado em todos os endpoints administrativos.
- [ ] Usuário sem token é bloqueado.
- [ ] Status inválido de denúncia é rejeitado.
- [ ] Suspensão não faz exclusão física.
- [ ] Banimento não faz exclusão física.
- [ ] Auditoria é criada se o módulo existir, ou decisão foi documentada.
- [ ] Tela web não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar

