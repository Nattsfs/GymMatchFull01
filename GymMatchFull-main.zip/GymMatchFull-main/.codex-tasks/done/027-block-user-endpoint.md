# Task 027 - Criar endpoint de bloquear usuário

## Objetivo
Implementar endpoint para que um aluno autenticado consiga bloquear outro usuário, impedindo novas interações entre eles.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Modelo de bloqueios já existe.
- Matches e chat já existem.
- Descoberta de perfis já existe.
- O aluno deve poder bloquear outro usuário para impedir contato, mensagens futuras e aparição na descoberta.
Quando um bloqueio é criado, a relação entre os usuários deve ser interrompida para fins de interação.

## Escopo da task
- Criar endpoint autenticado para bloquear usuário.
- Exemplo de rota: `POST /blocks`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Receber o ID do usuário a ser bloqueado.
- Validar que o usuário bloqueado existe.
- Impedir bloquear a si mesmo.
- Impedir bloqueio duplicado.
- Registrar o bloqueio.
- Tornar match existente entre os usuários inacessível, encerrado ou com status apropriado.
- Impedir mensagens futuras entre os usuários bloqueados.
- Atualizar descoberta para não retornar usuários bloqueados pelo aluno autenticado.
- Atualizar descoberta para não retornar usuários que bloquearam o aluno autenticado.
- Criar ou atualizar testes.
## Fora de escopo
- Não implementar denúncia automática.
- Não implementar desbloqueio.
- Não implementar tela mobile.
- Não implementar painel administrativo.
- Não implementar notificações.
- Não implementar auditoria avançada.
- Não implementar moderação completa.

## Arquivos prováveis
- `backend/src/blocks/blocks.controller.ts`
- `backend/src/blocks/blocks.service.ts`
- `backend/src/blocks/dto/create-block.dto.ts`
- `backend/src/matches/matches.service.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/discovery/discovery.service.ts`
- `backend/src/blocks/blocks.service.spec.ts`
- `backend/src/blocks/blocks.controller.spec.ts`
- `backend/src/discovery/discovery.service.spec.ts`
- `backend/src/chat/chat.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas alunos podem bloquear usuários por este endpoint.
- Usuário não pode bloquear a si mesmo.
- Bloqueio duplicado deve ser impedido.
- Usuário bloqueado não deve aparecer na descoberta.
- Usuário que bloqueou o aluno também não deve aparecer na descoberta.
- Após bloqueio, mensagens futuras entre os usuários devem ser bloqueadas.
- Após bloqueio, match existente deve ficar inacessível, encerrado ou com status apropriado.
- Não implemente denúncia automática nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para bloquear usuário.
- [ ] Aluno autenticado consegue bloquear outro usuário válido.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado.
- [ ] Usuário não consegue bloquear a si mesmo.
- [ ] Bloqueio duplicado é impedido.
- [ ] Usuário bloqueado não aparece mais na descoberta.
- [ ] Usuário que bloqueou o aluno também não aparece mais na descoberta.
- [ ] Mensagens futuras entre os usuários bloqueados são impedidas.
- [ ] Match existente entre os usuários fica inacessível, encerrado ou com status apropriado.
- [ ] Denúncia automática não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
