# Task 016 - Criar endpoint de listagem de matches do aluno

## Objetivo
Implementar endpoint para que o aluno autenticado consiga visualizar seus matches ativos.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Modelo de matches já existe.
- Match automático por curtida mútua já existe.
- Serializer público de perfil já existe.

O aluno precisa visualizar os matches para acessar futuramente o chat.

## Escopo da task
- Criar endpoint autenticado para listar matches do aluno.
- Exemplo de rota: `GET /matches/me`.
- Permitir apenas usuários com role `STUDENT`.
- Retornar apenas matches do usuário autenticado.
- Retornar apenas matches ativos por padrão.
- Não retornar matches expirados, desfeitos, bloqueados ou deletados.
- Para cada match, retornar:
 - id do match;
 - status;
 - data de criação;
 - dados públicos do outro usuário;
 - dados públicos do perfil do outro usuário.
- Usar serializer público de perfil.
- Não expor dados sensíveis.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar chat.
- Não criar conversa.
- Não implementar notificações.
- Não implementar desfazer match.
- Não implementar expiração automática.
- Não implementar paginação avançada, salvo se o projeto já tiver padrão simples.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/src/matches/matches.controller.ts`
- `backend/src/matches/matches.service.ts`
- `backend/src/matches/dto/`
- `backend/src/profiles/serializers/`
- `backend/src/matches/matches.service.spec.ts`
- `backend/src/matches/matches.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Fora de escopo
- Não implementar chat.
- Não criar conversa.
- Não implementar notificações.
- Não implementar desfazer match.
- Não implementar expiração automática.
- Não implementar paginação avançada, salvo se o projeto já tiver padrão simples.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/src/matches/matches.controller.ts`
- `backend/src/matches/matches.service.ts`
- `backend/src/matches/dto/`
- `backend/src/profiles/serializers/`
- `backend/src/matches/matches.service.spec.ts`
- `backend/src/matches/matches.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Usuário só pode ver os próprios matches.
- Apenas matches ativos devem aparecer por padrão.
- O outro usuário deve ser retornado com visualização pública segura.
- Não retorne CPF, telefone, e-mail, senha, `passwordHash` ou refresh token.
- Não implemente chat nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para listar matches do aluno.
- [ ] Aluno autenticado vê seus próprios matches ativos.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado.
- [ ] Usuário não vê matches de outro usuário.
- [ ] Match expirado não aparece por padrão.
- [ ] Match desfeito/inativo não aparece por padrão.
- [ ] Match bloqueado não aparece por padrão.
- [ ] Dados do outro usuário usam visualização pública segura.
- [ ] A resposta não expõe dados sensíveis.
- [ ] Chat não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
