# Task 006 - Criar endpoint de descoberta de perfis elegíveis

## Objetivo
Implementar o endpoint de descoberta para listar perfis elegíveis da mesma academia/unidade do aluno autenticado.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Usuários possuem role `STUDENT` ou `ADMIN`.
- Alunos já são vinculados a uma academia/unidade no cadastro via QR Code.
- Perfil do aluno já existe.
- Visualização pública segura de perfil já foi criada.
- Apenas perfis completos, ativos, com foto e da mesma academia/unidade devem aparecer na descoberta.
A descoberta será usada futuramente pelo app mobile para mostrar cards de perfis para o aluno curtir ou recusar.

## Escopo da task
- Criar módulo ou estrutura de `discovery`, se ainda não existir.
- Criar endpoint autenticado para descoberta de perfis.
- Exemplo de rota: `GET /discovery/profiles`.
- Permitir acesso apenas para usuário autenticado com role `STUDENT`.
- Buscar o usuário autenticado e sua academia/unidade.
- Retornar apenas perfis:
  - de usuários com role `STUDENT`;
  - de usuários ativos;
  - de usuários não deletados;
  - com perfil completo;
  - com foto de perfil;
  - da mesma academia/unidade do usuário autenticado;
  - diferentes do próprio usuário autenticado.
- Usar o serializer/DTO público de perfil criado anteriormente.
- Não retornar dados sensíveis.
- Criar testes para os cenários principais.

## Fora de escopo
- Não implementar curtidas.
- Não implementar recusas.
- Não implementar match.
- Não implementar algoritmo avançado de recomendação.
- Não implementar filtros por objetivo de uso nesta task.
- Não implementar filtros de bloqueio nesta task, salvo se já existirem estruturas prontas.
- Não implementar paginação avançada nesta task.
- Não criar tela mobile.
- Não criar painel administrativo.

## Arquivos prováveis
- `backend/src/discovery/discovery.module.ts`
- `backend/src/discovery/discovery.controller.ts`
- `backend/src/discovery/discovery.service.ts`
- `backend/src/discovery/dto/`
- `backend/src/profiles/`
- `backend/src/users/`
- `backend/src/auth/guards/`
- `backend/src/auth/decorators/`
- `backend/src/profiles/serializers/`
- `backend/src/discovery/discovery.service.spec.ts`
- `backend/src/discovery/discovery.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas usuários `STUDENT` podem usar descoberta.

- O próprio usuário autenticado nunca deve aparecer.
- Usuários de outra academia/unidade não devem aparecer.
- Usuários inativos, deletados ou incompletos não devem aparecer.
- Perfis sem foto não devem aparecer.
- Use o serializer público de perfil.
- Não retorne CPF, telefone, e-mail, senha, `passwordHash` ou refresh token.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para descoberta de perfis.
- [ ] Aluno autenticado consegue listar perfis elegíveis.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado.
- [ ] O próprio usuário não aparece na descoberta.
- [ ] Usuário de outra unidade não aparece.
- [ ] Usuário de outra academia não aparece.
- [ ] Usuário incompleto não aparece.
- [ ] Usuário sem foto não aparece.
- [ ] Usuário inativo/deletado não aparece.
- [ ] A resposta usa visualização pública segura.
- [ ] A resposta não expõe dados sensíveis.
- [ ] Curtidas, recusas e match não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
