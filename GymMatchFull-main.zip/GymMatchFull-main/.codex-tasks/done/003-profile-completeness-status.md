# Task 003 - Implementar status de perfil completo

## Objetivo
Implementar a regra que determina se o perfil do aluno está completo ou incompleto.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Modelo de usuário já existe.
- Modelo de perfil do aluno já existe.
- Criação e edição de perfil já existem.
- Futuramente apenas perfis completos poderão aparecer em descoberta, dar match e interagir normalmente.
A regra de perfil completo será usada nas próximas fases do sistema.

## Escopo da task
- Implementar regra centralizada para determinar se um perfil está completo.
- Atualizar o campo `isComplete`, se ele existir no modelo.
- Se o campo ainda não existir, avaliar se deve ser criado via migration pequena e focada.
- Considerar como requisitos mínimos para perfil completo:
  - usuário ativo;
  - usuário com role `STUDENT`;
  - perfil existente;
  - campos obrigatórios preenchidos;
  - idade válida ou `birthDate` válido;
  - gênero preenchido;
  - objetivo do app preenchido;
  - objetivo de treino preenchido;
  - nível de treino preenchido;
  - horários disponíveis preenchidos;
  - modalidades preferidas preenchidas;
  - divisão de treino preenchida;
  - foto de perfil existente ou campo equivalente preparado para foto.
- Como o upload de foto será implementado na próxima task, preparar a regra para considerar foto obrigatória quando o campo estiver disponível.
- Se ainda não existir campo de foto no User/Profile, criar uma abordagem conservadora:
  - adicionar campo simples como `profilePhotoUrl` ou `profilePhotoKey` no perfil, se fizer sentido;
  - ou deixar a função preparada para verificar esse campo quando ele existir, documentando a decisão.
- Recalcular `isComplete` após criação de perfil.
- Recalcular `isComplete` após edição de perfil.
- Criar testes para perfis completos e incompletos.

## Fora de escopo
- Não implementar descoberta de perfis
- Não implementar match.
- Não implementar curtidas.
- Não implementar upload de foto de perfil completo, apenas preparar/verificar campo se necessário.
- Não implementar storage.
- Não implementar telas mobile.
- Não criar endpoint público de descoberta.
- Não alterar regras de autenticação.
- Não alterar dados sensíveis do usuário.

## Arquivos prováveis
- `backend/src/profiles/profiles.service.ts`
- `backend/src/profiles/profile-completeness.service.ts`
- `backend/src/profiles/utils/`
- `backend/src/profiles/profiles.service.spec.ts`
- `backend/prisma/schema.prisma`, se precisar de campo/migration
- `backend/prisma/migrations/`, se precisar de migration
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Centralize a regra de completude do perfil em um único lugar.
- Não duplique a regra em controller, service e DTO.
- `isComplete` deve refletir corretamente os dados atuais do perfil.
- Perfil sem foto deve ser considerado incompleto quando o campo de foto existir.
- Perfil com campo obrigatório ausente deve ser considerado incompleto.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe regra centralizada para calcular se o perfil está completo.
- [ ] Perfil com todos os campos mínimos preenchidos é marcado como completo.
- [ ] Perfil sem campo obrigatório é marcado como incompleto.
- [ ] Perfil sem foto é marcado como incompleto quando o campo de foto existir.
- [ ] `isComplete` é atualizado após criação do perfil.
- [ ] `isComplete` é atualizado após edição do perfil.
- [ ] A regra não implementa descoberta de perfis.
- [ ] A regra não implementa match.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
