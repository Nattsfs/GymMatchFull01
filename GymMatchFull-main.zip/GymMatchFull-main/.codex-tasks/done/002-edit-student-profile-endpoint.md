# Task 002 - Criar endpoint de edição de perfil do aluno

## Objetivo
Implementar o endpoint para que um aluno autenticado consiga editar os campos permitidos do próprio perfil.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Role `STUDENT` e `ADMIN` já existem.
- Endpoint de criação de perfil do aluno já foi implementado.
- O perfil pertence ao usuário autenticado.
- Alguns dados sensíveis do usuário não podem ser alterados por este fluxo.
O aluno pode editar informações do perfil usadas em descoberta e match, mas não pode alterar CPF, telefone, e-mail ou idade diretamente por este endpoint.

## Escopo da task
- Criar endpoint autenticado para editar o perfil do aluno.
- Exemplo de rota: `PATCH /profiles/me`.
- Permitir edição apenas pelo próprio aluno autenticado.
- Permitir editar:
  - interesses;
  - objetivo do app;
  - objetivo de treino;
  - nível de treino;
  - horários disponíveis;
  - modalidades preferidas;
  - divisão de treino;
  - bio;
  - visibilidade da orientação sexual;
  - visibilidade dos horários.
- Validar campos enviados.
- Atualizar apenas campos permitidos.
- Impedir alteração direta de:
  - CPF;
  - telefone;
  - e-mail;
  - idade;
  - `birthDate`, se o projeto considerar data de nascimento como sensível nesta fase.
- Impedir usuário editar perfil de outro usuário.
- Retornar perfil atualizado de forma segura.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar fluxo seguro para alteração de e-mail.
- Não implementar fluxo seguro para alteração de telefone.
- Não implementar alteração de CPF.
- Não implementar upload de foto.
- Não implementar descoberta de perfis.
- Não implementar visualização pública de perfil.
- Não implementar match.
- Não implementar painel administrativo.
- Não criar telas mobile.
- Não alterar cadastro de usuário.

## Arquivos prováveis
- `backend/src/profiles/profiles.controller.ts`
- `backend/src/profiles/profiles.service.ts`
- `backend/src/profiles/dto/update-student-profile.dto.ts`
- `backend/src/profiles/profiles.service.spec.ts`
- `backend/src/profiles/profiles.controller.spec.ts`
- `backend/src/auth/decorators/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas o dono do perfil pode editar o próprio perfil.
- Usuário `ADMIN` não deve usar este endpoint para editar perfil de aluno.
- Não permita alteração de CPF, telefone, e-mail, senha ou `passwordHash`.
- Não permita alteração de idade diretamente.
- Trate orientação sexual como dado sensível.
- Respeite campos de visibilidade.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint autenticado para editar o próprio perfil.
- [ ] Aluno autenticado consegue editar campos permitidos.
- [ ] Campos não enviados permanecem inalterados.
- [ ] CPF não pode ser alterado por este endpoint.
- [ ] Telefone não pode ser alterado por este endpoint.
- [ ] E-mail não pode ser alterado por este endpoint.
- [ ] Idade não pode ser alterada diretamente por este endpoint.
- [ ] Usuário não consegue editar perfil de outro usuário.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário sem perfil recebe erro adequado.
- [ ] A resposta não expõe dados sensíveis.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
