# Task 012 - Criar modelo de recusas

## Objetivo
Criar a modelagem de recusas no banco de dados, permitindo registrar quando um aluno recusa outro perfil.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários e perfis já existem.
- Descoberta de perfis já existe.
- Modelo de curtidas já existe.
A recusa representa uma ação unilateral: usuário A recusou usuário B. Usuários recusados não devem aparecer novamente para quem recusou.

## Escopo da task
- Criar modelo/tabela de recusas/rejeições no banco.
- Criar migration correspondente.
- Criar estrutura inicial do módulo `rejections`, se ainda não existir.
- A tabela deve registrar:
 - usuário que recusou;
 - usuário recusado;
 - data da recusa;
 - campos de auditoria, se o projeto já usa esse padrão.
- Criar constraint para impedir recusa duplicada entre o mesmo par de usuários.
- Criar índices úteis para descoberta futura.
- Criar service/repository básico para criar e buscar recusas.
- Criar testes básicos.
## Fora de escopo
- Não criar endpoint de recusar perfil.
- Não alterar descoberta nesta task.
- Não implementar desfazer recusa.
- Não implementar match.
- Não implementar curtidas.
- Não criar tela mobile.
- Não implementar notificações.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/rejections/rejections.module.ts`
- `backend/src/rejections/rejections.service.ts`
- `backend/src/rejections/rejections.repository.ts`
- `backend/src/rejections/rejections.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Um usuário não pode recusar a mesma pessoa duas vezes.
- Um usuário não pode recusar a si mesmo.
- Não implemente desfazer recusa nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe modelo/tabela de recusas.
- [ ] Existe migration para recusas.
- [ ] A recusa registra usuário que recusou e usuário recusado.
- [ ] A recusa possui timestamp de criação.
- [ ] Existe constraint de unicidade para impedir recusa duplicada.
- [ ] Existe índice para consultas por usuário que recusou.
- [ ] Existe índice para consultas por usuário recusado.
- [ ] Usuário não consegue recusar a si mesmo via service/repository.
- [ ] Endpoint público de recusa não foi implementado.
- [ ] Desfazer recusa não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
