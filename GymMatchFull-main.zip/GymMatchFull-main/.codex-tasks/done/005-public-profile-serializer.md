# Task 005 - Criar visualização pública segura de perfil

## Objetivo
Criar uma representação pública e segura do perfil do aluno, omitindo dados sensíveis e respeitando configurações de visibilidade.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Modelo User já existe.
- Modelo de perfil do aluno já existe.
- Criação, edição, completude e foto de perfil já foram implementadas ou preparadas.
- Futuramente a descoberta de perfis usará essa visualização pública.
O sistema lida com dados sensíveis, como CPF, telefone, e-mail, orientação sexual e horários disponíveis. A visualização pública não deve expor dados privados.

## Escopo da task
- Criar serializer, mapper ou DTO público para perfil do aluno.
- A visualização pública deve omitir:
  - CPF;
  - telefone;
  - e-mail;
  - senha;
  - `passwordHash`;
  - refresh token;
  - dados internos de auditoria sensíveis;
  - `deletedAt`;
  - campos administrativos.
- Respeitar `showSexualOrientation`:
  - se falso, não retornar orientação sexual;
  - se verdadeiro, retornar conforme regra do projeto.
- Respeitar `showAvailablePeriods`:
  - se falso, não retornar horários disponíveis;
  - se verdadeiro, retornar horários.
- Retornar apenas dados úteis para descoberta/match, por exemplo:
  - id público do usuário;
  - nome;
  - foto;
  - idade, se permitido;
  - gênero;
  - objetivo do app;
  - objetivo de treino;
  - nível de treino;
  - modalidades preferidas;
  - divisão de treino;
  - bio;
  - academia/unidade pública, se necessário.
- Criar função reutilizável, por exemplo:
  - `toPublicProfile()`
  - `mapToPublicProfileDto()`
  - `PublicStudentProfileDto`
- Usar essa representação em endpoint existente de perfil, se houver um endpoint seguro para visualizar o próprio perfil ou perfil por id.
- Se ainda não existir endpoint público, não criar descoberta. Apenas criar serializer e testes.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar endpoint de descoberta.
- Não implementar listagem de perfis.
- Não implementar match.
- Não implementar curtidas.
- Não implementar filtros.
- Não implementar painel administrativo.
- Não criar tela mobile.
- Não alterar regras de cadastro.
- Não alterar autenticação.
- Não expor dados sensíveis para facilitar testes.

## Arquivos prováveis
- `backend/src/profiles/dto/public-student-profile.dto.ts`
- `backend/src/profiles/serializers/public-profile.serializer.ts`
- `backend/src/profiles/profiles.service.ts`
- `backend/src/profiles/profiles.controller.ts`, se houver endpoint existente para usar o serializer
- `backend/src/profiles/profiles.service.spec.ts`
- `backend/src/profiles/serializers/public-profile.serializer.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Trate orientação sexual como dado sensível.
- Nunca retorne CPF, telefone, e-mail, senha ou `passwordHash` na visualização pública.
- Respeite campos de visibilidade.
- A visualização pública deve ser reutilizável pela futura descoberta de perfis.
- Não implemente descoberta nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe DTO/serializer público de perfil.
- [ ] Visualização pública não retorna CPF.
- [ ] Visualização pública não retorna telefone.
- [ ] Visualização pública não retorna e-mail.
- [ ] Visualização pública não retorna senha ou `passwordHash`.
- [ ] Visualização pública respeita `showSexualOrientation`.
- [ ] Visualização pública respeita `showAvailablePeriods`.
- [ ] Orientação sexual é ocultada quando configurada como oculta.
- [ ] Horários disponíveis são ocultados quando configurados como ocultos.
- [ ] Dados úteis e seguros do perfil são retornados.
- [ ] A implementação é reutilizável pela futura descoberta.
- [ ] Endpoint de descoberta não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
