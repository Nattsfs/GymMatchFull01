# Task 028 - Criar modelo de denúncias

## Objetivo
Criar a modelagem de denúncias no banco de dados para registrar denúncias de perfis, mensagens ou conversas.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários já existem.
- Bloqueios já existem.
- Chat e mensagens podem já existir.
- Administradores futuramente poderão analisar denúncias e tomar decisões.
A denúncia representa uma ação de moderação iniciada por um usuário contra outro usuário, perfil, mensagem ou conversa.

## Escopo da task
- Criar modelo/tabela de denúncias no banco.
- Criar migration correspondente.
- Criar estrutura inicial do módulo `reports`, se ainda não existir.
- A denúncia deve registrar:
 - denunciante;
 - denunciado;
 - tipo da denúncia;
 - motivo;
 - descrição opcional;
 - status;
 - urgência;
 - contexto opcional, como mensagem ou conversa;
 - timestamps;
 - campos de auditoria, se o projeto já usa esse padrão.
- Criar enums para tipo, motivo e status da denúncia.
- Criar service/repository básico para criar e buscar denúncias.
- Criar testes básicos.
Tipos sugeridos:
- `USER`
- `PROFILE`
- `MESSAGE`
- `CONVERSATION`

Motivos sugeridos:
- `HARASSMENT`
- `FAKE_PROFILE`
- `OFFENSIVE_LANGUAGE`
- `SPAM`
- `INAPPROPRIATE_BEHAVIOR`
- `RACISM`
- `OTHER`

Status sugeridos:
- `OPEN`
- `IN_REVIEW`
- `RESOLVED`
- `REJECTED`
## Fora de escopo
- Não criar endpoint de denúncia.
- Não implementar análise administrativa.
- Não implementar tela administrativa.
- Não implementar bloqueio automático.
- Não implementar suspensão ou banimento.
- Não implementar notificações.
- Não implementar auditoria avançada.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/reports/reports.module.ts`
- `backend/src/reports/reports.service.ts`
- `backend/src/reports/reports.repository.ts`
- `backend/src/reports/reports.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Denúncia deve registrar denunciante e denunciado.
- Denúncia deve registrar tipo, motivo, status e urgência.
- Status inicial deve ser `OPEN` ou equivalente.
- Urgência deve ter valor padrão.
- Não implemente endpoints nesta task.
- Não implemente ações administrativas nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe modelo/tabela de denúncias.
- [ ] Existe migration para denúncias.
- [ ] Denúncia registra denunciante e denunciado.
- [ ] Denúncia possui tipo.
- [ ] Denúncia possui motivo.
- [ ] Denúncia possui status.
- [ ] Denúncia possui indicador de urgência.
- [ ] Denúncia pode referenciar mensagem ou conversa, se aplicável ao schema atual.
- [ ] Status inicial é definido.
- [ ] Motivo inválido é rejeitado via validação/service, se aplicável.
- [ ] Endpoint de denúncia não foi implementado.
- [ ] Tela administrativa não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
