# Task 007 - Aplicar filtros de status e bloqueio na descoberta

## Objetivo
Refinar a descoberta de perfis para excluir usuários bloqueados, usuários que bloquearam o aluno atual e usuários indisponíveis por status.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Endpoint de descoberta de perfis elegíveis já existe.
- Usuários possuem status como `ACTIVE`, `SUSPENDED`, `BANNED`, `DELETED` ou equivalentes.
- Perfis completos e seguros já são retornados pela descoberta.
- A funcionalidade completa de bloqueio pode ainda não existir, mas a descoberta deve estar preparada para respeitar bloqueios quando o modelo/tabela existir.

A regra de negócio é: usuários bloqueados ou indisponíveis nunca devem aparecer na descoberta.

## Escopo da task
- Atualizar o endpoint/serviço de descoberta para excluir usuários indisponíveis.
- Garantir que a descoberta exclua:
  - usuários suspensos;
  - usuários banidos;
  - usuários com status deletado;
  - usuários com `deletedAt` preenchido;
  - perfis com `deletedAt` preenchido.
- Se já existir entidade/tabela de bloqueios:
  - excluir usuários bloqueados pelo aluno autenticado;
  - excluir usuários que bloquearam o aluno autenticado.
- Se ainda não existir entidade/tabela de bloqueios:
  - preparar a estrutura de filtro de forma conservadora;
  - não criar funcionalidade completa de bloqueio;
  - documentar no resumo final que o filtro real de bloqueio será ativado quando o módulo de bloqueios existir.
- Manter uso do serializer público de perfil.
- Criar ou atualizar testes.

## Fora de escopo
- Não criar funcionalidade completa de bloqueio.
- Não criar endpoint para bloquear usuário.
- Não criar endpoint para desbloquear usuário.
- Não implementar denúncia.
- Não implementar match.
- Não implementar curtidas ou recusas.
- Não implementar algoritmo avançado.
- Não criar tela mobile.
- Não criar painel administrativo.
## Arquivos prováveis
- `backend/src/discovery/discovery.service.ts`
- `backend/src/discovery/discovery.controller.ts`
- `backend/src/discovery/dto/`
- `backend/src/blocks/`, se já existir
- `backend/src/users/`
- `backend/src/profiles/`
- `backend/src/discovery/discovery.service.spec.ts`
- `backend/src/discovery/discovery.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Usuários suspensos, banidos e deletados nunca devem aparecer.
- Usuários com soft delete nunca devem aparecer.
- Perfis com soft delete nunca devem aparecer.
- Se bloqueios já existirem, respeite bloqueios nos dois sentidos.
- Não implemente endpoints de bloqueio nesta task.
- Não retorne dados sensíveis.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Descoberta não retorna usuários suspensos.
- [ ] Descoberta não retorna usuários banidos.
- [ ] Descoberta não retorna usuários deletados.
- [ ] Descoberta não retorna usuários com `deletedAt`.
- [ ] Descoberta não retorna perfis com `deletedAt`.
- [ ] Se o modelo de bloqueio existir, usuários bloqueados pelo aluno autenticado não aparecem.
- [ ] Se o modelo de bloqueio existir, usuários que bloquearam o aluno autenticado não aparecem.
- [ ] A descoberta continua retornando perfis válidos.
- [ ] A resposta continua usando visualização pública segura.
- [ ] A resposta não expõe dados sensíveis.
- [ ] Funcionalidade completa de bloqueio não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
