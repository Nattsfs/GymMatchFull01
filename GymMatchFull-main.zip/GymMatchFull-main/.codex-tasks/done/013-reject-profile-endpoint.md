# Task 013 - Criar endpoint de recusar perfil

## Objetivo
Implementar o endpoint para que um aluno autenticado possa recusar o perfil de outro aluno e impedir que ele apareça novamente na descoberta.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Descoberta de perfis já existe.
- Modelo de recusas já existe.
A recusa deve registrar que o aluno autenticado não tem interesse em outro perfil. Após a recusa, esse perfil não deve aparecer novamente para esse aluno na descoberta.

## Escopo da task
- Criar endpoint autenticado para recusar perfil.
- Exemplo de rota: `POST /rejections`.
- Receber o ID do usuário/perfil recusado.
- Permitir apenas usuários com role `STUDENT`.
- Validar que o usuário recusado existe.
- Impedir recusar a si mesmo.
- Impedir recusa duplicada.
- Registrar a recusa.
- Atualizar a descoberta para não retornar perfis recusados pelo usuário autenticado.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar desfazer recusa.
- Não implementar match.
- Não implementar curtidas.
- Não implementar notificações.
- Não criar tela mobile.
- Não implementar algoritmo avançado de descoberta.
- Não implementar bloqueios.
- Não implementar denúncias.
## Arquivos prováveis
- `backend/src/rejections/rejections.controller.ts`
- `backend/src/rejections/rejections.service.ts`
- `backend/src/rejections/dto/create-rejection.dto.ts`
- `backend/src/discovery/discovery.service.ts`
- `backend/src/users/`
- `backend/src/profiles/`
- `backend/src/rejections/rejections.service.spec.ts`
- `backend/src/rejections/rejections.controller.spec.ts`
- `backend/src/discovery/discovery.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas alunos podem recusar perfis.
- Usuário não pode recusar a si mesmo.
- Usuário não pode recusar a mesma pessoa duas vezes.
- Perfil recusado não deve aparecer novamente na descoberta para quem recusou.
- Não implemente desfazer recusa nesta task.
- Não retorne dados sensíveis.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para recusar perfil.
- [ ] Aluno autenticado consegue registrar recusa válida.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado.
- [ ] Recusar a si mesmo é bloqueado.
- [ ] Recusa duplicada é bloqueada.
- [ ] Recusar usuário inexistente retorna erro adequado.
- [ ] Perfil recusado deixa de aparecer na descoberta para quem recusou.
- [ ] A descoberta continua retornando outros perfis elegíveis.
- [ ] Desfazer recusa não foi implementado.
- [ ] Match não foi implementado nesta task.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.
Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
