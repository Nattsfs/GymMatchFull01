# Task 001 - Criar endpoint de criação de perfil do aluno

## Objetivo
Implementar o endpoint para que um aluno autenticado consiga criar seu perfil após o cadastro.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.
Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação com JWT já implementada.
- Autorização por role já implementada.
- Usuários possuem role `STUDENT` ou `ADMIN`.
- O modelo de perfil do aluno já foi criado na task T03.01.
- O aluno já é vinculado a uma academia/unidade pelo QR Code no cadastro.

O perfil do aluno deve conter informações usadas futuramente para descoberta, match e apresentação pública.

Arquivos relacionados prováveis:
- `backend/src/profiles/`
- `backend/src/profiles/profiles.controller.ts`
- `backend/src/profiles/profiles.service.ts`
- `backend/src/profiles/dto/`
- `backend/src/auth/guards/`
- `backend/src/auth/decorators/`
- `backend/prisma/schema.prisma`
## Escopo da task
- Criar endpoint autenticado para criação de perfil do aluno.
- Exemplo de rota: `POST /profiles/me`.
- Permitir criação apenas para usuário autenticado com role `STUDENT`.
- Impedir criação de perfil para usuário `ADMIN`.
- Validar campos obrigatórios do perfil.
- Validar idade mínima de 18 anos com base em `birthDate`.
- Validar enums como gênero, orientação sexual, objetivo do app, nível de treino, períodos disponíveis, modalidades e divisão de treino.
- Validar campos de visibilidade:
  - `showSexualOrientation`
  - `showAvailablePeriods`
- Impedir criação de perfil duplicado para o mesmo usuário.
- Criar perfil vinculado ao usuário autenticado.
- Retornar o perfil criado sem dados sensíveis do usuário.
- Manter controller simples e regras no service.
- Criar ou atualizar testes da criação de perfil.
## Fora de escopo
- Não implementar edição de perfil.
- Não implementar upload de foto.
- Não implementar descoberta de perfis.
- Não implementar visualização pública de perfil.
- Não alterar cadastro de usuário.
- Não alterar login ou autenticação.
- Não criar telas mobile.
- Não criar painel administrativo.
- Não implementar match, curtidas ou recusas.

## Arquivos prováveis
- `backend/src/profiles/profiles.controller.ts`
- `backend/src/profiles/profiles.service.ts`
- `backend/src/profiles/dto/create-student-profile.dto.ts`
- `backend/src/profiles/profiles.module.ts`
- `backend/src/profiles/profiles.service.spec.ts`
- `backend/src/profiles/profiles.controller.spec.ts`
- `backend/src/common/validators/`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.


## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas usuários `STUDENT` podem criar perfil de aluno.
- Um usuário só pode ter um perfil.
- Usuário `ADMIN` não pode criar perfil de aluno neste endpoint.
- A idade mínima é 18 anos.
- Trate orientação sexual como dado sensível.
- Não retorne CPF, telefone, senha, `passwordHash` ou dados privados do usuário.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.


## Critérios de aceite
- [ ] Existe endpoint autenticado para criar perfil do aluno.
- [ ] Aluno autenticado consegue criar perfil válido.
- [ ] Usuário sem token não consegue criar perfil.
- [ ] Usuário `ADMIN` não consegue criar perfil de aluno.
- [ ] Usuário menor de 18 anos é rejeitado.
- [ ] Campos obrigatórios ausentes são rejeitados.
- [ ] Valores inválidos de enum são rejeitados.
- [ ] Perfil duplicado para o mesmo usuário é rejeitado.
- [ ] O perfil criado pertence ao usuário autenticado.
- [ ] A resposta não expõe dados sensíveis.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
