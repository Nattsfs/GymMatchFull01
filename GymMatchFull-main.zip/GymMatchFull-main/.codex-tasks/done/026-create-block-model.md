# Task 026 - Criar modelo de bloqueio

## Objetivo
Criar a modelagem de bloqueios no banco de dados, permitindo registrar quando um usuário bloqueia outro usuário.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários já existem.
- Usuários possuem role `STUDENT` e `ADMIN`.
- Descoberta, matches e chat podem já existir.
- Usuários bloqueados não devem aparecer na descoberta, não devem manter contato ativo e não devem conseguir trocar mensagens.

O bloqueio representa uma ação unilateral: usuário A bloqueou usuário B.

## Escopo da task
- Criar modelo/tabela de bloqueios no banco.
- Criar migration correspondente.
- Criar estrutura inicial do módulo `blocks`, se ainda não existir.
- A tabela deve registrar:
 - usuário que bloqueou;
 - usuário bloqueado;
 - motivo opcional;
 - timestamps;
 - campos de auditoria, se o projeto já usa esse padrão.
- Criar constraint para impedir bloqueio duplicado entre o mesmo par de usuários.
- Criar índices úteis para consultas futuras.
- Criar service/repository básico para:
 - criar bloqueio;
 - verificar se existe bloqueio entre dois usuários;
 - listar usuários bloqueados por um usuário, se fizer sentido.
- Criar testes básicos.

## Fora de escopo
- Não criar endpoint público de bloqueio.
- Não alterar descoberta nesta task.
- Não alterar chat nesta task.
- Não alterar matches nesta task.
- Não implementar denúncias.
- Não implementar desbloqueio.
- Não criar tela mobile.
- Não criar painel administrativo.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/blocks/blocks.module.ts`
- `backend/src/blocks/blocks.service.ts`
- `backend/src/blocks/blocks.repository.ts`
- `backend/src/blocks/blocks.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Um usuário não pode bloquear a si mesmo.
- Um usuário não pode bloquear a mesma pessoa duas vezes.
- O bloqueio deve ser unilateral.
- Não implemente endpoint de bloqueio nesta task.
- Não implemente denúncia nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe modelo/tabela de bloqueios.
- [ ] Existe migration para bloqueios.
- [ ] Bloqueio registra bloqueador e bloqueado.
- [ ] Bloqueio possui motivo opcional.
- [ ] Bloqueio possui timestamp de criação.
- [ ] Existe constraint para impedir bloqueio duplicado.
- [ ] Existe índice para consultas por usuário bloqueador.
- [ ] Existe índice para consultas por usuário bloqueado.
- [ ] Usuário não consegue bloquear a si mesmo via service/repository.
- [ ] Endpoint público de bloqueio não foi implementado.
- [ ] Denúncias não foram implementadas.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
