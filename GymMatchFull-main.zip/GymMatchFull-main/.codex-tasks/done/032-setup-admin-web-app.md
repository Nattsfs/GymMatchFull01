# Task 032 - Configurar projeto web administrativo

## Objetivo
Criar a base do painel administrativo web, com estrutura inicial, layout base, rotas iniciais e tela de login.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Monorepo com TypeScript.
- Backend/API já existe.
- App web administrativo ficará dentro de `admin/`.
- O painel administrativo é separado do app mobile.
- Apenas administradores poderão acessar áreas internas.
- Login com JWT já existe no backend.
- A integração completa do login será feita na próxima task.
O objetivo desta task é preparar a base visual e estrutural do app admin, sem implementar telas de gestão ou dashboard completo.

## Escopo da task
- Configurar o app web administrativo dentro de `admin/`.
- Usar a stack definida no projeto, preferencialmente Next.js com TypeScript, se ainda não houver stack web configurada.
- Criar estrutura básica de pastas.
- Criar layout base do painel.
- Criar rotas iniciais.
- Criar tela de login visual.
- Criar formulário de login com campos:
  - e-mail;
  - senha.
- Validar campos obrigatórios no formulário.
- Criar client/base para futuras chamadas de API, sem integrar login real ainda se isso ficar para a próxima task.
- Garantir que o app admin rode localmente.
- Adicionar scripts necessários ao `admin/package.json`.
- Atualizar README ou documentação com instruções para rodar o admin.

## Fora de escopo
- Não integrar login com API nesta task.
- Não proteger rotas internas ainda, salvo estrutura visual mínima.
- Não criar dashboard real.
- Não criar tela de usuários.
- Não criar tela de academias.
- Não criar tela de unidades.
- Não criar tela de denúncias.
- Não implementar métricas.
- Não implementar suspensão ou banimento.
- Não alterar backend.
- Não implementar recuperação de senha.

## Arquivos prováveis
- `admin/package.json`
- `admin/tsconfig.json`
- `admin/src/`
- `admin/src/app/`
- `admin/src/app/layout.tsx`
- `admin/src/app/page.tsx`
- `admin/src/app/login/page.tsx`
- `admin/src/components/`
- `admin/src/lib/api-client.ts`

- `admin/src/styles/`
- `README.md`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- O painel deve ser simples e funcional para MVP.
- A tela de login deve existir, mas não precisa autenticar de verdade nesta task.
- Não crie dashboard ou telas de gestão nesta task.
- Não coloque secrets no código.
- Use variáveis de ambiente para URL da API, se necessário.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] O projeto web admin existe dentro de `admin/`.
- [ ] O painel web sobe localmente.
- [ ] Existe layout base.
- [ ] Existe rota de login.
- [ ] Existe tela de login visual.
- [ ] Formulário de login valida e-mail e senha obrigatórios.
- [ ] Existe estrutura inicial para client de API.
- [ ] Scripts de desenvolvimento/build/lint estão configurados para o admin.
- [ ] README ou documentação explica como rodar o admin.
- [ ] Dashboard real não foi implementado.
- [ ] Telas de gestão não foram implementadas.
- [ ] Integração real de login não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
