# Task 015 - Criar match automaticamente em curtida mútua

## Objetivo
Integrar curtidas e matches para que uma curtida mútua crie automaticamente um match ativo entre os dois alunos.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Endpoint de curtir perfil já existe.
- Modelo de curtidas já existe.
- Modelo de matches já existe.

Regra de negócio: quando o aluno A curte o aluno B, e o aluno B já curtiu o aluno A, o sistema deve criar um match entre eles.
## Escopo da task
- Atualizar o fluxo de curtir perfil.
- Após registrar uma curtida, verificar se existe curtida inversa.
- Se existir curtida inversa, criar match entre os usuários.
- Não criar match duplicado se ele já existir.
- Garantir que a criação de curtida e match seja segura contra inconsistências.
- Se possível, usar transação do ORM.
- Retornar na resposta da curtida se houve match.
- Criar testes para curtida simples e curtida mútua.

## Fora de escopo
- Não implementar chat.
- Não criar conversa automaticamente.
- Não implementar notificações.
- Não implementar listagem de matches.
- Não implementar limite de matches do plano grátis nesta task.
- Não implementar desfazer match.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/src/likes/likes.service.ts`
- `backend/src/likes/likes.controller.ts`
- `backend/src/matches/matches.service.ts`
- `backend/src/matches/matches.repository.ts`
- `backend/src/likes/likes.service.spec.ts`
- `backend/src/matches/matches.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Curtida simples não deve criar match.
- Curtida mútua deve criar match.
- Match duplicado deve ser impedido.
- Não crie match se algum usuário estiver inativo, banido, suspenso ou deletado.
- Não crie match se algum perfil estiver incompleto.
- Use transação se o padrão do projeto permitir.
- Não implemente chat nesta task.
- Não implemente notificações nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Curtida sem curtida inversa não cria match.
- [ ] Curtida com curtida inversa cria match ativo.
- [ ] Match criado representa corretamente os dois usuários.
- [ ] Match duplicado é impedido.
- [ ] Resposta do endpoint de curtida indica quando houve match.
- [ ] Não cria match com usuário inativo/suspenso/banido/deletado.
- [ ] Não cria match com perfil incompleto.
- [ ] A operação usa transação ou estratégia segura contra inconsistências.
- [ ] Chat não foi implementado.
- [ ] Notificações não foram implementadas.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
