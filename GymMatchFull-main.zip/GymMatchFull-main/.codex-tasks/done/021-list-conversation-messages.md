# Task 021 - Listar mensagens da conversa

## Objetivo
Implementar endpoint paginado para listar o histórico de mensagens de uma conversa.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Conversas e mensagens já existem.
- Envio de mensagem de texto já existe.
- Apenas participantes do match podem acessar a conversa.

O aluno precisa visualizar o histórico do chat com paginação e ordenação previsível.
## Escopo da task
- Criar endpoint autenticado para listar mensagens de uma conversa.
- Exemplo de rota: `GET /chat/conversations/:conversationId/messages`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Validar que a conversa existe.
- Validar que o usuário autenticado participa do match vinculado à conversa.
- Retornar mensagens paginadas.
- Implementar query params:
 - `page`;
 - `limit`.
- Definir limite padrão.
- Definir limite máximo.
- Ordenar mensagens de forma previsível, preferencialmente por `createdAt`.
- Retornar dados do remetente de forma segura.
- Não retornar mensagens deletadas para usuário comum, se já existir campo de deleção.
- Retornar metadados de paginação.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar WebSocket.
- Não implementar envio de áudio.
- Não implementar envio de imagem.
- Não implementar exclusão lógica de mensagem.
- Não implementar busca textual.
- Não implementar notificações.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/src/chat/chat.controller.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/chat/dto/list-messages-query.dto.ts`
- `backend/src/messages/`, se existir módulo separado
- `backend/src/common/pagination/`, se existir padrão comum
- `backend/src/chat/chat.service.spec.ts`
- `backend/src/chat/chat.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas participantes da conversa podem listar mensagens.
- Usuário fora do match não pode listar mensagens.
- A listagem deve ser paginada.
- A ordenação deve ser estável.
- Não retorne dados sensíveis dos usuários.
- Não implemente WebSocket nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para listar mensagens da conversa.
- [ ] Participante do match consegue listar mensagens.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado, salvo se o projeto já tiver regra admin específica.
- [ ] Usuário fora da conversa é bloqueado.
- [ ] Listagem é paginada.
- [ ] `limit` possui valor máximo.
- [ ] Mensagens são retornadas em ordem previsível.
- [ ] Dados do remetente são seguros.
- [ ] Mensagens deletadas não aparecem para usuário comum, se essa regra já existir.
- [ ] WebSocket não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
