# Task 029 - Criar endpoint de denúncia de usuário

## Objetivo
Implementar endpoint para que um aluno autenticado consiga denunciar outro usuário e bloqueá-lo automaticamente.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Modelo de bloqueios já existe.
- Endpoint de bloqueio já existe.
- Modelo de denúncias já existe.
- Usuários podem denunciar perfis por assédio, perfil falso, spam, racismo ou outros motivos.

Regra de negócio: ao denunciar um usuário, o denunciado deve ser bloqueado automaticamente para o denunciante.
## Escopo da task
- Criar endpoint autenticado para denunciar usuário/perfil.
- Exemplo de rota: `POST /reports/users`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Receber:
 - ID do usuário denunciado;
 - motivo;
 - descrição opcional.
- Validar que o usuário denunciado existe.
- Impedir denúncia contra si mesmo.
- Validar motivo da denúncia.
- Registrar denúncia com tipo `USER` ou `PROFILE`, conforme padrão do projeto.
- Criar bloqueio automático do denunciado para o denunciante.
- Impedir denúncia duplicada do mesmo contexto.
- Retornar resposta segura.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar painel administrativo de análise.
- Não implementar suspensão automática.
- Não implementar banimento automático.
- Não implementar denúncia de mensagem.
- Não implementar denúncia de conversa.
- Não implementar notificações administrativas, salvo se já houver mecanismo simples.
- Não criar tela mobile.
- Não criar tela admin.

## Arquivos prováveis
- `backend/src/reports/reports.controller.ts`
- `backend/src/reports/reports.service.ts`
- `backend/src/reports/dto/create-user-report.dto.ts`
- `backend/src/blocks/blocks.service.ts`
- `backend/src/users/users.service.ts`
- `backend/src/reports/reports.service.spec.ts`
- `backend/src/reports/reports.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas alunos podem denunciar usuários por este endpoint.
- Usuário não pode denunciar a si mesmo.
- Motivo de denúncia deve ser validado.
- Denúncia duplicada do mesmo contexto deve ser impedida.
- Denúncia deve criar bloqueio automático.
- Bloqueio automático não deve duplicar bloqueio existente.
- Não implemente suspensão ou banimento automático.
- Não implemente análise administrativa nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para denunciar usuário.
- [ ] Aluno autenticado consegue denunciar outro usuário válido.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado, salvo se o padrão do projeto permitir outra regra.
- [ ] Usuário não consegue denunciar a si mesmo.
- [ ] Motivo inválido é rejeitado.
- [ ] Denúncia duplicada do mesmo contexto é impedida.
- [ ] Denúncia cria registro no banco.
- [ ] Denúncia cria bloqueio automático do denunciado para o denunciante.
- [ ] Bloqueio automático não duplica bloqueio já existente.
- [ ] Suspensão automática não foi implementada.
- [ ] Banimento automático não foi implementado.
- [ ] Painel administrativo não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
