# Task 004 - Implementar upload de foto de perfil

## Objetivo
Permitir que o aluno autenticado envie uma foto de perfil válida e que essa foto seja associada ao seu perfil.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Perfil do aluno já existe.
- Regra de perfil completo já existe ou está preparada.
- Perfis sem foto não poderão dar match futuramente.
- Storage definitivo em produção ainda não será configurado nesta task.
A task deve implementar o endpoint e abstração mínima de storage para permitir evolução futura.

## Escopo da task
- Criar endpoint autenticado para upload de foto de perfil.
- Exemplo de rota: `POST /profiles/me/photo`.
- Permitir upload apenas para usuário autenticado com role `STUDENT`.
- Validar que o usuário possui perfil.
- Aceitar apenas imagens em formatos seguros, por exemplo:
  - JPG;
  - JPEG;
  - PNG;
  - WEBP, se o projeto quiser suportar.
- Validar tamanho máximo do arquivo.
- Rejeitar arquivos grandes demais.
- Rejeitar tipos inválidos.
- Criar abstração simples de storage.
- Para esta fase, usar implementação local/dev ou mock segura.
- Salvar no banco a URL, path ou chave da foto.
- Atualizar o perfil com o campo da foto.
- Recalcular `isComplete` após upload da foto, se a regra existir.
- Retornar dados seguros da foto/perfil atualizado.
- Criar ou atualizar testes.

## Fora de escopo
- Não configurar storage definitivo de produção.
- Não integrar S3, Cloudinary, Supabase Storage ou outro provider real, salvo se já existir no projeto.
- Não implementar upload de imagens no chat.
- Não implementar edição/corte avançado de imagem.
- Não criar tela mobile de upload.
- Não implementar CDN.
- Não implementar múltiplas fotos.
- Não implementar descoberta de perfis.
- Não implementar match.
## Arquivos prováveis
- `backend/src/profiles/profiles.controller.ts`
- `backend/src/profiles/profiles.service.ts`
- `backend/src/media/`
- `backend/src/storage/`
- `backend/src/storage/storage.service.ts`
- `backend/src/storage/local-storage.service.ts`
- `backend/prisma/schema.prisma`, se precisar adicionar campo de foto
- `backend/prisma/migrations/`, se precisar de migration
- `backend/src/profiles/profiles.service.spec.ts`
- `backend/src/profiles/profiles.controller.spec.ts`
- `.env.example`, se precisar de variável de storage local
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas usuário autenticado `STUDENT` pode enviar foto para o próprio perfil.
- Não permita upload sem autenticação.
- Não permita upload para perfil inexistente.
- Valide tipo de arquivo.
- Valide tamanho do arquivo.
- Não aceite arquivos executáveis.
- Não salve arquivos sensíveis no repositório.
- Não exponha paths internos desnecessários.
- Recalcule completude do perfil após upload, se aplicável.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.


## Critérios de aceite
- [ ] Existe endpoint autenticado para upload de foto de perfil.
- [ ] Aluno autenticado consegue enviar foto válida.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário sem perfil recebe erro adequado.
- [ ] Arquivo grande demais é rejeitado.
- [ ] Tipo inválido é rejeitado.
- [ ] Foto fica associada ao perfil do aluno.
- [ ] O perfil passa a ter referência da foto salva.
- [ ] `isComplete` é recalculado após upload, se aplicável.
- [ ] Storage definitivo de produção não foi implementado.
- [ ] Upload de imagem no chat não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar

