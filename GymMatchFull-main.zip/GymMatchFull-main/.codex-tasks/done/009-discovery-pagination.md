# Task 009 - Implementar paginação na descoberta

## Objetivo
Adicionar paginação ao endpoint de descoberta de perfis para tornar a listagem eficiente, previsível e segura.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Endpoint de descoberta de perfis já existe.
- A descoberta já filtra perfis elegíveis, ativos, completos, com foto e da mesma academia/unidade.
- A descoberta já pode considerar objetivo de uso do app.
A listagem precisa ser paginada para evitar respostas grandes e melhorar desempenho.

## Escopo da task
- Adicionar paginação ao endpoint de descoberta.
- Pode usar paginação por `page` e `limit` ou cursor.
- Escolha a opção mais consistente com o padrão atual do projeto.
- Se não houver padrão existente, usar `page` e `limit` por simplicidade.
- Criar DTO/schema para query params, se ainda não existir.
- Validar:
  - `page` mínimo 1;
  - `limit` mínimo 1;
  - `limit` máximo seguro, por exemplo 50.
- Definir limite padrão, por exemplo 10 ou 20.
- Garantir ordenação estável.
- Sugestão de ordenação:
  - perfis compatíveis primeiro, se a task anterior implementou ordenação por objetivo;
  - depois `createdAt desc` ou outro critério estável.
- Retornar metadados de paginação.
- Exemplo de resposta:
  - `data`;
  - `pagination.page`;
  - `pagination.limit`;
  - `pagination.total`;
  - `pagination.totalPages`.
- Manter uso do serializer público.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar cache.
- Não implementar recomendação avançada.
- Não implementar cursor complexo se o projeto ainda não usa esse padrão.
- Não implementar curtidas.
- Não implementar recusas.
- Não implementar match.
- Não criar tela mobile.
- Não alterar modelo de perfil sem necessidade.
- Não implementar filtros manuais avançados.
## Arquivos prováveis
- `backend/src/discovery/discovery.controller.ts`
- `backend/src/discovery/discovery.service.ts`
- `backend/src/discovery/dto/list-discovery-query.dto.ts`
- `backend/src/common/dto/pagination.dto.ts`, se já existir padrão comum
- `backend/src/common/pagination/`, se já existir
- `backend/src/discovery/discovery.service.spec.ts`
- `backend/src/discovery/discovery.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.


## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- A paginação deve ter limite máximo.
- A ordenação deve ser estável.
- A resposta deve manter visualização pública segura.
- Não retorne dados sensíveis.
- Não implemente cache ou recomendação avançada.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Endpoint de descoberta aceita parâmetros de paginação.
- [ ] `page` inválido é rejeitado ou normalizado conforme padrão do projeto.
- [ ] `limit` inválido é rejeitado ou normalizado conforme padrão do projeto.
- [ ] `limit` excessivo é limitado ou rejeitado.
- [ ] A resposta retorna metadados de paginação.
- [ ] A primeira página retorna dados corretos.
- [ ] A próxima página retorna dados corretos.
- [ ] A ordenação é estável.
- [ ] A descoberta continua aplicando todos os filtros de elegibilidade.
- [ ] A resposta não expõe dados sensíveis.
- [ ] Cache não foi implementado.
- [ ] Recomendação avançada não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
