# Task 018 - Criar modelos de conversa e mensagens

## Objetivo
Modelar conversas e mensagens no banco de dados para permitir chat entre usuários que deram match.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários, perfis e matches já existem.
- Match representa a relação entre dois alunos.
- O chat só deve existir após match.
- WebSocket, áudio, imagem e upload de mídia serão implementados em tasks futuras.

Após um match, os usuários poderão conversar. Para isso, precisamos criar os modelos de conversa e mensagens.
## Escopo da task
- Criar modelo/tabela de conversa.
- Criar modelo/tabela de mensagens.
- Criar migration correspondente.
- Criar estrutura inicial dos módulos `chat` e/ou `messages`, conforme padrão do projeto.
- A conversa deve estar vinculada a um match.
- Cada match deve ter no máximo uma conversa.
- Mensagens devem pertencer a uma conversa.
- Mensagens devem ter remetente.
- Mensagens devem ter tipo.
- Mensagens devem ter conteúdo textual ou referência futura para mídia.
- Mensagens devem ter status.
- Criar enums necessários para tipo e status de mensagem.
- Criar service/repository básico para:
 - criar conversa;
 - buscar conversa por match;
 - criar mensagem;
 - buscar mensagem por id.
- Criar testes básicos de modelagem e regras.
Sugestões de tipos de mensagem:
- `TEXT`
- `AUDIO`
- `IMAGE`

Sugestões de status de mensagem:
- `SENT`
- `DELETED`
- `MODERATION_HIDDEN`

## Fora de escopo
- Não criar WebSocket.
- Não criar endpoint de envio de mensagens.
- Não criar endpoint de listagem de mensagens.
- Não implementar upload de mídia.
- Não implementar envio de áudio.
- Não implementar envio de imagem.
- Não implementar exclusão lógica de mensagem.
- Não criar chat no mobile.
- Não criar notificações.
## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/chat/chat.module.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/chat/chat.repository.ts`
- `backend/src/messages/`, se o projeto separar mensagens em módulo próprio
- `backend/src/chat/chat.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.


## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Uma conversa deve pertencer a um match.
- Cada match deve ter no máximo uma conversa.
- Uma mensagem deve pertencer a uma conversa.
- Uma mensagem deve ter remetente.
- Uma mensagem não deve existir sem conversa.
- Não implemente envio de mensagens via endpoint nesta task.
- Não implemente WebSocket nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe modelo/tabela de conversa.
- [ ] Existe modelo/tabela de mensagem.
- [ ] Existe migration para conversa e mensagens.
- [ ] Conversa pertence a um match.
- [ ] Cada match tem no máximo uma conversa.
- [ ] Mensagem pertence a uma conversa.
- [ ] Mensagem possui remetente.
- [ ] Mensagem possui tipo.
- [ ] Mensagem possui status.
- [ ] Não é possível criar mensagem sem conversa via service/repository.
- [ ] Não foi implementado WebSocket.
- [ ] Não foi implementado endpoint de envio de mensagem.
- [ ] Não foi implementado upload de mídia.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
