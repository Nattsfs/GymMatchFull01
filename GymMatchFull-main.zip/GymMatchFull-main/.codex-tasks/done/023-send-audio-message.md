# Task 023 - Implementar envio de áudio no chat

## Objetivo
Permitir que usuários com match ativo enviem mensagens do tipo áudio em uma conversa.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Conversas e mensagens já existem.
- Envio de mensagem de texto já existe.
- Upload de foto de perfil já existe ou existe abstração de storage/media.
- Storage definitivo de produção pode ainda não estar configurado.

O chat deve permitir áudio, mas sem implementar player mobile ou transcrição nesta task.

## Escopo da task
- Criar endpoint autenticado para envio de mensagem de áudio.
- Exemplo de rota: `POST /chat/conversations/:conversationId/audio`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Validar que a conversa existe.
- Validar que o usuário autenticado participa do match.
- Validar que o match está ativo.
- Validar arquivo de áudio:
 - tipo permitido;
 - tamanho máximo;
 - presença obrigatória.
- Usar abstraction de storage/media existente, se houver.
- Se não houver, criar implementação mínima coerente com a já usada em foto de perfil.
- Salvar referência do arquivo na mensagem.
- Criar mensagem do tipo `AUDIO`.
- Retornar mensagem criada de forma segura.
- Criar ou atualizar testes.

Tipos de áudio sugeridos:
- `audio/mpeg`
- `audio/mp4`
- `audio/wav`
- `audio/webm`
- `audio/ogg`

## Fora de escopo
- Não implementar player mobile.
- Não implementar transcrição.
- Não implementar upload de imagem no chat.
- Não implementar WebSocket.
- Não implementar push notification.
- Não configurar storage definitivo de produção.
- Não criar tela mobile.
- Não implementar compressão de áudio.
## Arquivos prováveis
- `backend/src/chat/chat.controller.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/media/`
- `backend/src/storage/`
- `backend/src/messages/`, se existir módulo separado
- `backend/src/chat/chat.service.spec.ts`
- `backend/src/chat/chat.controller.spec.ts`
- `.env.example`, se precisar de configuração local de storage
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas participantes do match podem enviar áudio.
- Match deve estar ativo.
- Arquivo de áudio deve ser validado por tipo e tamanho.
- Não aceite arquivos executáveis.
- Não salve arquivos sensíveis no repositório.
- Não implemente player mobile.
- Não implemente WebSocket nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint autenticado para envio de áudio.
- [ ] Participante do match consegue enviar áudio válido.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário fora do match é bloqueado.
- [ ] Match inativo/expirado é bloqueado.
- [ ] Arquivo ausente é rejeitado.
- [ ] Tipo inválido é rejeitado.
- [ ] Arquivo grande demais é rejeitado.
- [ ] Mensagem criada tem tipo `AUDIO`.
- [ ] Referência do arquivo é salva corretamente.
- [ ] Player mobile não foi implementado.
- [ ] WebSocket não foi implementado.
- [ ] Storage definitivo de produção não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
