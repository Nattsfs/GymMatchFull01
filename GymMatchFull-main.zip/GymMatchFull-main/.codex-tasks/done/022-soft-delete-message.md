# Task 022 - Implementar exclusão lógica de mensagem

## Objetivo
Permitir que o usuário apague uma mensagem para a visualização comum, preservando o histórico no banco para futura moderação.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Conversas e mensagens já existem.
- Envio e listagem de mensagens já existem.
- O histórico precisa ser preservado para moderação futura.

A exclusão de mensagem deve ser lógica. O conteúdo não deve ser removido fisicamente do banco nesta task.
## Escopo da task
- Criar endpoint autenticado para apagar logicamente uma mensagem.
- Exemplo de rota: `DELETE /chat/messages/:messageId`.
- Permitir que o usuário apague apenas mensagens que ele enviou.
- Validar que a mensagem existe.
- Validar que o usuário autenticado é o remetente.
- Marcar a mensagem como deletada para visualização comum.
- Preservar conteúdo original no banco.
- Atualizar listagem de mensagens para não exibir normalmente mensagens deletadas, ou exibir placeholder seguro conforme padrão escolhido.
- Criar campos necessários, se ainda não existirem:
 - `deletedAt`;
 - `deletedById`;
 - ou status `DELETED`.
- Não fazer exclusão física.
- Criar ou atualizar testes.
## Fora de escopo
- Não implementar exclusão física.
- Não implementar moderação administrativa completa.
- Não implementar tela admin para ver mensagem apagada.
- Não implementar denúncia.
- Não implementar WebSocket.
- Não implementar áudio ou imagem.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/prisma/schema.prisma`, se precisar de campo/migration
- `backend/prisma/migrations/`, se precisar de migration
- `backend/src/chat/chat.controller.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/messages/`, se existir módulo separado
- `backend/src/chat/chat.service.spec.ts`
- `backend/src/chat/chat.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.


## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Usuário só pode apagar a própria mensagem.
- Mensagem apagada não deve aparecer normalmente na listagem comum.
- Conteúdo original deve permanecer no banco.
- Não faça exclusão física.
- Não implemente moderação admin nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint autenticado para exclusão lógica de mensagem.
- [ ] Remetente consegue apagar a própria mensagem.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário não consegue apagar mensagem de outro remetente.
- [ ] Mensagem inexistente retorna erro adequado.
- [ ] Mensagem apagada não aparece normalmente para usuário comum.
- [ ] Conteúdo original permanece persistido no banco.
- [ ] Exclusão física não foi implementada.
- [ ] Moderação administrativa não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
