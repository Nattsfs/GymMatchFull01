# Task 008 - Aplicar filtro por objetivo de uso na descoberta

## Objetivo
Melhorar a descoberta de perfis considerando o objetivo de uso informado pelo aluno no perfil.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- Endpoint de descoberta de perfis já existe.
- O perfil do aluno possui campo de objetivo de uso do app, como:
  - parceiro de treino;
  - amizade;
  - objetivos parecidos;
  - relacionamento.
- A descoberta já deve listar apenas perfis elegíveis, ativos, completos, com foto e da mesma academia/unidade.

O objetivo desta task é aplicar uma regra simples de compatibilidade por objetivo de uso, sem criar algoritmo avançado de recomendação.

## Escopo da task
- Atualizar a descoberta para considerar o objetivo de uso do aluno autenticado.
- Criar regra simples e documentada para compatibilidade de objetivos.
- Possíveis estratégias aceitáveis:
  - filtrar apenas perfis que tenham pelo menos um objetivo em comum;
  - ou ordenar primeiro perfis com objetivo em comum e depois outros elegíveis.
- Preferir a estratégia mais conservadora para MVP.
- Se o modelo permitir múltiplos objetivos, considerar interseção entre listas.
- Se o modelo permitir apenas um objetivo, comparar igualdade ou compatibilidade direta.
- Para objetivo de relacionamento, respeitar as regras de privacidade já existentes.
- Não expor orientação sexual se o perfil marcou como oculta.
- Atualizar DTO/query da descoberta apenas se necessário.
- Criar ou atualizar testes.
## Fora de escopo
- Não implementar algoritmo avançado de recomendação.
- Não implementar score complexo de compatibilidade.
- Não implementar machine learning.
- Não implementar geolocalização.
- Não implementar filtros manuais avançados.
- Não implementar curtidas.
- Não implementar recusas.
- Não implementar match.
- Não criar tela mobile.
- Não alterar o modelo de perfil sem necessidade.

## Arquivos prováveis
- `backend/src/discovery/discovery.service.ts`
- `backend/src/discovery/dto/`
- `backend/src/profiles/`
- `backend/src/profiles/serializers/`
- `backend/src/discovery/discovery.service.spec.ts`
- `backend/src/discovery/discovery.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- A descoberta deve considerar o objetivo de uso do app.
- A regra deve ser simples, previsível e documentada no resumo final.
- Não implemente recomendação avançada.
- Não exponha dados sensíveis.
- Respeite o serializer público de perfil.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] A descoberta considera o objetivo de uso do aluno autenticado.
- [ ] Perfis com objetivo compatível aparecem primeiro ou são filtrados conforme regra definida.
- [ ] A regra escolhida está clara no código ou no resumo final.
- [ ] A descoberta continua respeitando academia/unidade.
- [ ] A descoberta continua excluindo o próprio usuário.
- [ ] A descoberta continua excluindo perfis incompletos.
- [ ] A descoberta continua excluindo usuários indisponíveis.
- [ ] A resposta não expõe dados sensíveis.
- [ ] Algoritmo avançado de recomendação não foi implementado.
- [ ] Curtidas, recusas e match não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
