# Task 025 - Implementar WebSocket para novas mensagens

## Objetivo
Criar WebSocket autenticado para notificar participantes da conversa quando uma nova mensagem for enviada.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Chat com conversas e mensagens já existe.
- Endpoint de envio de mensagem de texto já existe.
- Áudio e imagem podem existir, mas esta task deve emitir evento de nova mensagem independentemente do tipo.
- Push notification mobile não será implementado nesta task.

O chat deve funcionar em tempo real. Quando uma mensagem for enviada, o outro participante conectado deve receber evento.

## Escopo da task
- Criar gateway WebSocket ou estrutura equivalente conforme framework do backend.
- Autenticar conexão WebSocket usando JWT.
- Rejeitar conexão sem token.
- Rejeitar conexão com token inválido.
- Associar conexão ao usuário autenticado.
- Criar estratégia de salas/canais por conversa ou por usuário.
- Emitir evento de nova mensagem quando mensagem for criada.
- Garantir que apenas participantes da conversa recebam evento.
- Integrar emissão com o fluxo existente de envio de mensagem.
- Criar eventos com payload seguro.
- Criar testes possíveis para autenticação e emissão, conforme suporte da stack.

Sugestão de evento:
- `message.created`
Payload seguro sugerido:
- id da mensagem;
- id da conversa;
- id do remetente;
- tipo;
- conteúdo ou referência segura;
- createdAt.

## Fora de escopo
- Não implementar push notification mobile.
- Não implementar app mobile.
- Não implementar indicador de digitando.
- Não implementar confirmação de leitura.
- Não implementar presença online.
- Não implementar reconexão avançada no cliente.
- Não implementar notificações por e-mail.
- Não criar painel administrativo.
## Arquivos prováveis
- `backend/src/chat/chat.gateway.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/chat/chat.module.ts`
- `backend/src/auth/`
- `backend/src/websocket/`, se o projeto usar módulo separado
- `backend/src/chat/chat.gateway.spec.ts`
- `backend/src/chat/chat.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- WebSocket deve exigir autenticação.
- Conexão sem token deve ser rejeitada.
- Token inválido deve ser rejeitado.
- Evento de nova mensagem deve ser enviado apenas para participantes da conversa.
- Payload do evento não deve expor dados sensíveis.
- Não implemente push notification nesta task.
- Não implemente recursos avançados como typing/read receipts.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe gateway WebSocket ou equivalente.
- [ ] Conexão WebSocket exige token válido.
- [ ] Conexão sem token é rejeitada.
- [ ] Conexão com token inválido é rejeitada.
- [ ] Usuário autenticado é associado à conexão.
- [ ] Participante conectado recebe evento de nova mensagem.
- [ ] Usuário que não participa da conversa não recebe evento.
- [ ] Payload do evento é seguro.
- [ ] Envio de mensagem existente continua funcionando.
- [ ] Push notification mobile não foi implementado.
- [ ] Typing indicator não foi implementado.
- [ ] Read receipts não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
