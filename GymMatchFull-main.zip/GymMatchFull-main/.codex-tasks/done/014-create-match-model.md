# Task 014 - Criar modelo de matches

## Objetivo
Criar a modelagem de matches no banco de dados para representar a relação criada quando dois alunos se curtem mutuamente.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários e perfis já existem.
- Modelo de curtidas já existe.
- A criação automática de match será feita em task futura.
Um match representa uma relação entre dois usuários. Essa relação deve ser única, independente da ordem dos usuários.

## Escopo da task
- Criar modelo/tabela de matches no banco.
- Criar migration correspondente.
- Criar estrutura inicial do módulo `matches`, se ainda não existir.
- A tabela deve registrar:
 - userAId;
 - userBId;
 - status do match;
 - data de criação;
 - data de expiração, se aplicável;
 - campos de auditoria.
- Criar enum de status do match.
- Sugestão de status:
 - `ACTIVE`
 - `EXPIRED`
 - `UNMATCHED`
 - `BLOCKED`
- Criar constraint para impedir match duplicado entre o mesmo par de usuários.
- Criar service/repository básico para criar, buscar e verificar match existente.
- Criar testes básicos.

## Fora de escopo
- Não criar match automaticamente.
- Não criar endpoint de listagem de matches.
- Não criar chat.
- Não criar conversa.
- Não implementar notificações.
- Não implementar expiração automática.
- Não implementar desfazer match.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/matches/matches.module.ts`
- `backend/src/matches/matches.service.ts`
- `backend/src/matches/matches.repository.ts`
- `backend/src/matches/matches.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Match deve representar uma relação única entre dois usuários.
- Match duplicado entre o mesmo par deve ser impedido.
- Usuário não pode ter match consigo mesmo.
- Padronize a ordem dos usuários no match, se necessário, para garantir unicidade.
- Não implemente chat nesta task.
- Não implemente criação automática por curtida mútua nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe modelo/tabela de matches.
- [ ] Existe migration para matches.
- [ ] Match possui dois usuários.
- [ ] Match possui status.
- [ ] Match possui timestamp de criação.
- [ ] Match possui campos de auditoria conforme padrão do projeto.
- [ ] Existe constraint para impedir match duplicado.
- [ ] Usuário não consegue criar match consigo mesmo via service/repository.
- [ ] Service/repository consegue verificar se match já existe entre dois usuários.
- [ ] Chat não foi implementado.
- [ ] Match automático não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.
Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
