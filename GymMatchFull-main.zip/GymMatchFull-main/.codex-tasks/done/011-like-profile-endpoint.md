# Task 011 - Criar endpoint de curtir perfil

## Objetivo
Implementar o endpoint para que um aluno autenticado possa curtir o perfil de outro aluno elegível.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Perfis de alunos já existem.
- Descoberta de perfis já existe.
- Modelo de curtidas já existe.
- Match automático ainda não deve ser criado nesta task.
A curtida é uma ação do aluno autenticado sobre outro aluno.

## Escopo da task
- Criar endpoint autenticado para curtir perfil.
- Exemplo de rota: `POST /likes`.
- Receber o ID do usuário/perfil curtido.
- Permitir apenas usuários com role `STUDENT`.
- Validar que o usuário curtido existe.
- Validar que o usuário curtido é `STUDENT`.
- Validar que o usuário curtido está ativo.
- Validar que o usuário curtido não está soft deleted.
- Validar que o perfil curtido está completo.
- Validar que o perfil curtido possui foto.
- Validar que ambos pertencem à mesma academia/unidade.
- Impedir curtir a si mesmo.
- Impedir curtida duplicada.
- Se já existir estrutura de bloqueios, impedir curtida entre usuários bloqueados.
- Implementar limite diário básico do plano grátis, se já existir estrutura de planos.
- Se estrutura de planos ainda não existir, criar limite simples e centralizado para o plano grátis ou documentar decisão conservadora.
- Retornar a curtida criada ou resposta de sucesso segura.
- Criar ou atualizar testes.

## Fora de escopo
- Não criar match por curtida mútua.
- Não implementar notificações.
- Não implementar plano premium completo.
- Não implementar desfazer curtida.
- Não implementar sistema completo de assinaturas.
- Não criar tela mobile.
- Não alterar descoberta de perfis, exceto se necessário para reaproveitar regras de elegibilidade.
- Não implementar recusas.

## Arquivos prováveis
- `backend/src/likes/likes.controller.ts`
- `backend/src/likes/likes.service.ts`
- `backend/src/likes/dto/create-like.dto.ts`
- `backend/src/profiles/`
- `backend/src/users/`
- `backend/src/discovery/`
- `backend/src/plans/`, se já existir
- `backend/src/blocks/`, se já existir
- `backend/src/likes/likes.service.spec.ts`
- `backend/src/likes/likes.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas alunos podem curtir perfis.
- Usuário não pode curtir a si mesmo.
- Usuário não pode curtir perfil incompleto.
- Usuário não pode curtir perfil sem foto.
- Usuário não pode curtir usuário de outra academia/unidade.
- Usuário não pode curtir usuário inativo, banido, suspenso ou deletado.
- Usuário não pode curtir a mesma pessoa duas vezes.
- Não implemente criação de match nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para curtir perfil.
- [ ] Aluno autenticado consegue registrar curtida válida.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado.
- [ ] Curtir a si mesmo é bloqueado.
- [ ] Curtida duplicada é bloqueada.
- [ ] Curtir perfil incompleto é bloqueado.
- [ ] Curtir perfil sem foto é bloqueado.
- [ ] Curtir usuário de outra unidade/academia é bloqueado.
- [ ] Curtir usuário inativo/suspenso/banido/deletado é bloqueado.
- [ ] Se bloqueios existirem, curtida entre usuários bloqueados é bloqueada.
- [ ] Limite diário do plano grátis é respeitado ou decisão conservadora foi documentada.
- [ ] Match automático não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
