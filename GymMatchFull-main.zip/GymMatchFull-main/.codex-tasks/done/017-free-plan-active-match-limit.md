# Task 017 - Aplicar limite de matches ativos no plano grátis

## Objetivo
Impedir que um usuário do plano grátis crie novos matches quando já possuir 5 matches ativos.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários, perfis, curtidas e matches já existem.
- Match automático por curtida mútua já existe.
- Sistema completo de assinatura ainda pode não existir.

Regra de negócio: no plano grátis, o aluno pode ter no máximo 5 matches ativos. Usuários premium poderão ter limite maior ou ilimitado futuramente.
## Escopo da task
- Implementar verificação de limite de matches ativos antes de criar match em curtida mútua.
- Definir regra simples para plano grátis.
- Se já existir campo/modelo de plano no usuário, usar esse campo.
- Se ainda não existir sistema de planos, criar uma abordagem mínima e conservadora:
 - considerar todos os usuários como plano grátis por padrão;
 - centralizar constante `FREE_PLAN_ACTIVE_MATCH_LIMIT = 5`;
 - documentar no resumo final que o sistema completo de planos virá depois.
- Contar matches ativos do usuário antes de criar novo match.
- Se qualquer um dos dois usuários estiver no limite do plano grátis, impedir a criação do match.
- Definir resposta/erro adequado para limite atingido.
- Garantir que a curtida ainda possa ser registrada ou decidir se a curtida deve falhar junto com o match.
- Documentar a decisão.
- Criar ou atualizar testes.
## Fora de escopo
- Não implementar sistema completo de assinatura.
- Não implementar Stripe.
- Não implementar plano premium completo.
- Não implementar tela de upgrade.
- Não implementar pagamento.
- Não implementar notificações.
- Não implementar chat.
- Não implementar desfazer match.
- Não criar painel administrativo de planos.

## Arquivos prováveis
- `backend/src/matches/matches.service.ts`
- `backend/src/likes/likes.service.ts`
- `backend/src/plans/`, se já existir
- `backend/src/common/constants/`
- `backend/src/matches/matches.service.spec.ts`
- `backend/src/likes/likes.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Usuário grátis pode ter no máximo 5 matches ativos.
- Matches expirados, desfeitos, bloqueados ou inativos não contam como ativos.
- O limite deve ser verificado antes de criar novo match.
- A regra deve ser centralizada e fácil de alterar futuramente.
- Não implemente sistema completo de assinatura nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe regra centralizada de limite de matches ativos do plano grátis.
- [ ] Usuário grátis com menos de 5 matches ativos consegue criar novo match.
- [ ] Usuário grátis com 5 matches ativos não consegue criar novo match.
- [ ] Matches não ativos não contam no limite.
- [ ] A regra é aplicada no fluxo de curtida mútua.
- [ ] A resposta de limite atingido é clara.
- [ ] A decisão sobre registrar ou não a curtida quando o match é bloqueado foi documentada.
- [ ] Sistema completo de assinatura não foi implementado.
- [ ] Stripe não foi implementado.
- [ ] Chat não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.
## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
