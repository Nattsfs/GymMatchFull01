# Task 020 - Criar endpoint de envio de mensagem de texto

## Objetivo
Implementar endpoint para que usuários com match ativo possam enviar mensagens de texto em uma conversa.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Matches já existem.
- Conversas são criadas automaticamente após match.
- Mensagens já foram modeladas.
- O chat só é permitido entre participantes de um match ativo.
Nesta task, o foco é apenas mensagem de texto. Áudio, imagem e WebSocket ficam para tasks futuras.

## Escopo da task
- Criar endpoint autenticado para enviar mensagem de texto.
- Exemplo de rota: `POST /chat/conversations/:conversationId/messages`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Validar que a conversa existe.
- Validar que o usuário autenticado participa do match vinculado à conversa.
- Validar que o match está ativo.
- Validar que o match não está expirado, desfeito, bloqueado ou inativo.
- Se já existir módulo de bloqueios, impedir envio caso exista bloqueio entre os usuários.
- Validar conteúdo da mensagem:
 - obrigatório;
 - string;
 - não aceitar apenas espaços;
 - limitar tamanho máximo.
- Criar mensagem do tipo `TEXT`.
- Salvar mensagem vinculada à conversa e ao remetente.
- Retornar a mensagem criada de forma segura.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar áudio.
- Não implementar imagem.
- Não implementar upload de mídia.
- Não implementar WebSocket.
- Não implementar push notification.
- Não implementar listagem de mensagens.
- Não implementar exclusão de mensagens.
- Não criar tela mobile.
## Arquivos prováveis
- `backend/src/chat/chat.controller.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/chat/dto/send-text-message.dto.ts`
- `backend/src/messages/`, se existir módulo separado
- `backend/src/matches/`
- `backend/src/blocks/`, se já existir
- `backend/src/chat/chat.service.spec.ts`
- `backend/src/chat/chat.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas participantes do match podem enviar mensagem.
- Mensagem só pode ser enviada em match ativo.
- Mensagem vazia ou apenas com espaços deve ser rejeitada.
- Não permita envio por usuário fora da conversa.
- Não retorne dados sensíveis.
- Não implemente WebSocket nesta task.
- Não implemente áudio ou imagem nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint autenticado para envio de mensagem de texto.
- [ ] Participante do match consegue enviar mensagem válida.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário `ADMIN` é bloqueado.
- [ ] Usuário fora do match não consegue enviar mensagem.
- [ ] Mensagem em match expirado/inativo é bloqueada.
- [ ] Mensagem em match bloqueado é bloqueada, se esse status existir.
- [ ] Mensagem vazia é rejeitada.
- [ ] Mensagem criada fica vinculada à conversa correta.
- [ ] Mensagem criada fica vinculada ao remetente correto.
- [ ] A resposta não expõe dados sensíveis.
- [ ] WebSocket não foi implementado.
- [ ] Áudio e imagem não foram implementados.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
