# Task 019 - Criar conversa automaticamente após match
Você está retomando a Task 019 - Criar conversa automaticamente após match.

A execução anterior parece ter aplicado alterações e os comandos typecheck, lint, test e build passaram, mas o runner falhou tecnicamente com "write_stdin failed" / ELIFECYCLE depois da execução.

Objetivo agora:
Verificar o estado atual do código, confirmar se a Task 019 está realmente implementada corretamente e corrigir apenas o que estiver faltando ou inconsistente.

Contexto da Task 019:
Quando um match novo for criado, o sistema deve criar automaticamente uma conversa vinculada ao match.
Todo match ACTIVE novo deve ter uma conversa associada.
Match duplicado não deve criar conversa duplicada.
A criação deve ser idempotente.
O fluxo de curtida mútua deve continuar funcionando.
Não implementar envio de mensagens, WebSocket, notificações ou chat mobile.

Regras de negócio:
- Criar conversa automaticamente apenas para match com status ACTIVE.
- Não criar conversa para match BLOCKED, EXPIRED ou UNMATCHED.
- Se já existir match ACTIVE sem conversa, o sistema pode criar a conversa faltante sem duplicar o match.
- Se a conversa já existir, reutilizar a conversa existente.
- Não criar conversa duplicada para o mesmo match.

Tarefas:
1. Inspecione os arquivos alterados anteriormente:
   - backend/src/chat/chat.service.ts
   - backend/src/chat/chat.types.ts
   - backend/src/likes/likes.service.ts
   - backend/src/matches/matches.service.ts
   - testes relacionados de chat, likes e matches

2. Confirme se existe método equivalente a getOrCreateConversation no ChatService.

3. Confirme se MatchesService.createMatch cria conversa automaticamente para match ACTIVE.

4. Confirme se LikesService garante conversa no fluxo de curtida mútua.

5. Confirme se não há conversa duplicada para o mesmo match.

6. Corrija apenas inconsistências reais.

7. Rode:
   - pnpm --filter @gymmatch/backend typecheck
   - pnpm --filter @gymmatch/backend lint
   - pnpm --filter @gymmatch/backend test
   - pnpm --filter @gymmatch/backend build

Critérios de aceite:
- Match ACTIVE novo cria conversa automaticamente.
- Match duplicado não cria conversa duplicada.
- Curtida mútua cria match e conversa.
- Match ACTIVE existente sem conversa recebe conversa quando passar pelo fluxo.
- Match BLOCKED, EXPIRED ou UNMATCHED não cria conversa automaticamente.
- Testes cobrem criação, reutilização e não duplicação de conversa.
- Nenhuma funcionalidade fora da Task 019 é implementada.

Ao finalizar, responda com:
- Se a task já estava implementada ou se precisou corrigir algo.
- Arquivos alterados.
- Decisões tomadas.
- Comandos executados e resultado.
- Confirmação de que envio de mensagens, WebSocket e notificações não foram implementados.
## Objetivo
Integrar a criação de match com a criação automática de uma conversa vinculada ao match.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Match automático por curtida mútua já existe.
- Modelos de conversa e mensagens já existem.
- Chat só deve ficar disponível quando houver match.

Quando um match é criado, o sistema deve criar uma conversa associada. Essa conversa será usada futuramente para envio e listagem de mensagens.
## Escopo da task
- Atualizar o fluxo de criação de match.
- Ao criar um novo match, criar automaticamente uma conversa vinculada.
- Garantir que um match não receba conversas duplicadas.
- Usar transação se o padrão do projeto permitir.
- Criar função/service para buscar ou criar conversa de um match, se fizer sentido.
- Garantir que matches já existentes possam ser tratados sem quebrar.
- Criar testes para criação de conversa após match.

## Fora de escopo
- Não implementar envio de mensagens.
- Não implementar listagem de mensagens.
- Não implementar WebSocket.
- Não implementar notificações.
- Não criar chat no mobile.
- Não criar upload de mídia.
- Não criar conversa manual sem match.
## Arquivos prováveis
- `backend/src/matches/matches.service.ts`
- `backend/src/matches/matches.repository.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/chat/chat.repository.ts`
- `backend/src/matches/matches.service.spec.ts`
- `backend/src/chat/chat.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Todo novo match deve ter conversa associada.
- Match duplicado não deve criar conversa duplicada.
- Conversa só deve existir vinculada a match.
- Use transação se a arquitetura permitir.
- Não implemente envio de mensagens nesta task.
- Não implemente WebSocket nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Todo match novo cria uma conversa associada.
- [ ] Match duplicado não cria conversa duplicada.
- [ ] Conversa criada está vinculada ao match correto.
- [ ] A criação de match e conversa é feita de forma consistente.
- [ ] O fluxo de curtida mútua continua funcionando.
- [ ] Não foi implementado envio de mensagens.
- [ ] Não foi implementado WebSocket.
- [ ] Não foram implementadas notificações.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.
Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
