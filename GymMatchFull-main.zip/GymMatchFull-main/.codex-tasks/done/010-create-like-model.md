# Task 010 - Criar modelo de curtidas

## Objetivo
Criar a modelagem de curtidas no banco de dados, permitindo registrar quando um aluno curte outro perfil.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Usuários possuem role `STUDENT` e `ADMIN`.
- Perfil do aluno já existe.
- Descoberta de perfis já existe.
- Match será criado futuramente quando dois usuários se curtirem mutuamente.
A curtida representa uma ação unilateral: usuário A curtiu usuário B.

## Escopo da task
- Criar modelo/tabela de curtidas no banco.
- Criar migration correspondente.
- Criar estrutura inicial do módulo `likes`, se ainda não existir.
- A tabela deve registrar:
 - usuário que curtiu;
 - usuário curtido;
 - data da curtida;
 - campos de auditoria, se o projeto já usa esse padrão.
- Criar constraint para impedir curtida duplicada entre o mesmo par de usuários.
- Criar índices úteis para consultas futuras.
- Criar service/repository básico para criar e buscar curtidas.
- Criar testes básicos de modelagem/regra.

## Fora de escopo
- Não criar endpoint de curtir perfil.
- Não criar match automaticamente.
- Não implementar limite diário de curtidas.
- Não implementar plano grátis/premium.
- Não implementar desfazer curtida.
- Não alterar descoberta de perfis.
- Não criar telas mobile.
- Não implementar notificações.
## Arquivos prováveis
- `backend/prisma/schema.prisma`
- `backend/prisma/migrations/`
- `backend/src/likes/likes.module.ts`
- `backend/src/likes/likes.service.ts`
- `backend/src/likes/likes.repository.ts`
- `backend/src/likes/likes.service.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Um usuário não pode curtir a mesma pessoa duas vezes.
- Um usuário não pode curtir a si mesmo.
- Não implemente criação automática de match nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe modelo/tabela de curtidas.
- [ ] Existe migration para curtidas.
- [ ] A curtida registra usuário que curtiu e usuário curtido.
- [ ] A curtida possui timestamp de criação.
- [ ] Existe constraint de unicidade para impedir curtida duplicada.
- [ ] Existe índice para consultas por usuário que curtiu.
- [ ] Existe índice para consultas por usuário curtido.
- [ ] Usuário não consegue curtir a si mesmo via service/repository.
- [ ] Match automático não foi implementado.
- [ ] Endpoint público de curtida não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
