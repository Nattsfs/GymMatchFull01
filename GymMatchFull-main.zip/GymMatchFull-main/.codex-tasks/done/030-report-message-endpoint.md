# Task 030 - Criar endpoint de denúncia de mensagem

## Objetivo
Implementar endpoint para que um aluno consiga denunciar uma mensagem de conversa da qual participa.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- PostgreSQL com ORM, preferencialmente Prisma.
- Autenticação JWT já implementada.
- Chat, conversas e mensagens já existem.
- Modelo de denúncias já existe.
- Usuários podem denunciar mensagens inadequadas para moderação futura.

A denúncia de mensagem deve registrar o contexto da mensagem denunciada.


## Escopo da task
- Criar endpoint autenticado para denunciar mensagem.
- Exemplo de rota: `POST /reports/messages`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Receber:
 - ID da mensagem denunciada;
 - motivo;
 - descrição opcional.
- Validar que a mensagem existe.
- Validar que a mensagem pertence a uma conversa.
- Validar que o usuário autenticado participa da conversa/match.
- Identificar o usuário denunciado como o remetente da mensagem.
- Impedir usuário denunciar a própria mensagem, salvo se o projeto decidir permitir. Preferir bloquear.
- Validar motivo da denúncia.
- Registrar denúncia com tipo `MESSAGE`.
- Impedir denúncia duplicada da mesma mensagem pelo mesmo denunciante.
- Retornar resposta segura.
- Criar ou atualizar testes.

## Fora de escopo
- Não implementar análise administrativa.
- Não implementar tela administrativa.
- Não implementar suspensão ou banimento automático.
- Não implementar bloqueio automático nesta task, salvo se já for regra global obrigatória do projeto.
- Não implementar denúncia de conversa.
- Não implementar notificações.
- Não criar tela mobile.

## Arquivos prováveis
- `backend/src/reports/reports.controller.ts`
- `backend/src/reports/reports.service.ts`
- `backend/src/reports/dto/create-message-report.dto.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/messages/`, se existir módulo separado
- `backend/src/reports/reports.service.spec.ts`
- `backend/src/reports/reports.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.

## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas participante da conversa pode denunciar mensagem.
- Usuário fora da conversa não pode denunciar mensagem.
- Mensagem inexistente deve retornar erro adequado.
- Motivo da denúncia deve ser validado.
- Denúncia duplicada da mesma mensagem pelo mesmo usuário deve ser impedida.
- Denúncia deve registrar contexto da mensagem.
- Não implemente análise administrativa nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.

## Critérios de aceite
- [ ] Existe endpoint autenticado para denunciar mensagem.
- [ ] Participante da conversa consegue denunciar mensagem válida.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário fora da conversa é bloqueado.
- [ ] Mensagem inexistente retorna erro adequado.
- [ ] Motivo inválido é rejeitado.
- [ ] Denúncia duplicada da mesma mensagem pelo mesmo denunciante é impedida.
- [ ] Denúncia registra o remetente da mensagem como denunciado.
- [ ] Denúncia registra referência da mensagem denunciada.
- [ ] Análise administrativa não foi implementada.
- [ ] Tela administrativa não foi implementada.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
