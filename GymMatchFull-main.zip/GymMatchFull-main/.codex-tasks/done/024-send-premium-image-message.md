# Task 024 - Implementar envio de imagem premium no chat

## Objetivo
Permitir envio de imagem no chat apenas para usuários premium, bloqueando o recurso para usuários do plano grátis.

## Contexto do projeto
O projeto é o GymMatch, uma plataforma estilo Tinder de academia.

Stack esperada:
- Backend em TypeScript.
- Autenticação JWT já implementada.
- Conversas e mensagens já existem.
- Envio de mensagem de texto já existe.
- Envio de áudio pode existir.
- Upload de foto de perfil já existe ou existe abstração de storage/media.
- Sistema completo de assinatura pode ainda não existir.
Regra de negócio: envio de imagem no chat é recurso premium.

## Escopo da task
- Criar endpoint autenticado para envio de imagem no chat.
- Exemplo de rota: `POST /chat/conversations/:conversationId/image`.
- Permitir apenas usuários autenticados com role `STUDENT`.
- Validar que o usuário participa do match.
- Validar que o match está ativo.
- Validar que o usuário tem plano premium.
- Se ainda não existir sistema completo de planos:
 - usar helper centralizado para verificar premium;
 - considerar usuário grátis por padrão;
 - documentar decisão no resumo final;
 - não implementar Stripe.
- Validar arquivo de imagem:
 - tipo permitido;
 - tamanho máximo;
 - presença obrigatória.
- Usar abstraction de storage/media existente.
- Salvar referência da imagem na mensagem.
- Criar mensagem do tipo `IMAGE`.
- Retornar mensagem criada de forma segura.
- Criar ou atualizar testes.

Tipos de imagem sugeridos:
- `image/jpeg`
- `image/png`
- `image/webp`

## Fora de escopo
- Não implementar Stripe.
- Não implementar sistema completo de assinatura.
- Não implementar tela de upgrade.
- Não implementar imagem para usuário grátis.
- Não implementar WebSocket.
- Não implementar push notification.
- Não configurar storage definitivo de produção.
- Não criar tela mobile.
- Não implementar compressão/crop de imagem.
## Arquivos prováveis
- `backend/src/chat/chat.controller.ts`
- `backend/src/chat/chat.service.ts`
- `backend/src/media/`
- `backend/src/storage/`
- `backend/src/plans/`, se existir ou se for necessário helper mínimo
- `backend/src/messages/`, se existir módulo separado
- `backend/src/chat/chat.service.spec.ts`
- `backend/src/chat/chat.controller.spec.ts`
- O Codex deve identificar os arquivos corretos seguindo o padrão atual do projeto.
## Regras obrigatórias
- Siga o padrão atual do projeto.
- Não faça refatorações grandes fora do escopo da task.
- Não altere comportamento existente sem necessidade.
- Não remova código funcional.
- Use TypeScript.
- Use validações e padrões já existentes no projeto.
- Mantenha nomes consistentes com o domínio do projeto.
- Apenas participantes do match podem enviar imagem.
- Match deve estar ativo.
- Apenas usuário premium pode enviar imagem.
- Usuário grátis deve ser bloqueado.
- Arquivo de imagem deve ser validado por tipo e tamanho.
- Não aceite arquivos executáveis.
- Não implemente Stripe nesta task.
- Não implemente WebSocket nesta task.
- Ao finalizar, explique brevemente os arquivos alterados.
- Se encontrar ambiguidade, tome a decisão mais conservadora e registre no resumo final.
## Critérios de aceite
- [ ] Existe endpoint autenticado para envio de imagem no chat.
- [ ] Usuário premium participante do match consegue enviar imagem válida.
- [ ] Usuário grátis é bloqueado.
- [ ] Usuário sem token é bloqueado.
- [ ] Usuário fora do match é bloqueado.
- [ ] Match inativo/expirado é bloqueado.
- [ ] Arquivo ausente é rejeitado.
- [ ] Tipo inválido é rejeitado.
- [ ] Arquivo grande demais é rejeitado.
- [ ] Mensagem criada tem tipo `IMAGE`.
- [ ] Referência do arquivo é salva corretamente.
- [ ] Stripe não foi implementado.
- [ ] Sistema completo de assinatura não foi implementado.
- [ ] WebSocket não foi implementado.
- [ ] O código segue o padrão atual do projeto.
- [ ] Não há erros de TypeScript.
- [ ] As validações do projeto continuam passando.
- [ ] A task não implementou funcionalidades fora do escopo.

## Prompt para o Codex
Implemente esta task no projeto atual seguindo exatamente o objetivo, escopo, regras obrigatórias e critérios de aceite descritos acima.

Antes de alterar arquivos, analise rapidamente a estrutura existente do projeto.

Depois implemente a menor alteração segura possível.

Ao final, rode as validações disponíveis do projeto, se existirem, e gere um resumo com:
- arquivos criados
- arquivos alterados
- decisões tomadas
- como testar
