import { describe, expect, it } from 'vitest';

import { findCodexLogicalFailure } from './run-codex-tasks';

describe('findCodexLogicalFailure', () => {
  it.each([
    'bwrap: loopback: Failed RTM_NEWADDR',
    'Failed to write file',
    'write_stdin failed',
    'Unknown process id',
  ])('detecta gatilho forte direto: %s', (pattern) => {
    const result = findCodexLogicalFailure(`Saida do runner:\n${pattern}\nFim da execução.`);

    expect(result).toContain(pattern);
  });

  it.each([
    {
      description: 'falha de acesso ao shell',
      output: 'Nao foi possivel continuar porque o shell nao estava acessivel.',
      expectedReason: 'não conseguiu acessar o shell',
    },
    {
      description: 'falha de acesso ao filesystem',
      output: 'Não foi possível continuar porque o filesystem estava indisponível.',
      expectedReason: 'não conseguiu acessar o filesystem',
    },
    {
      description: 'falha genérica de sandbox',
      output: 'Nao consegui concluir a task por causa do sandbox.',
      expectedReason: 'falha de sandbox',
    },
    {
      description: 'task não concluída por sandbox',
      output: 'A task não foi concluída porque o sandbox bloqueou o acesso necessário.',
      expectedReason: 'task não foi concluída por sandbox',
    },
    {
      description: 'nenhum arquivo criado ou modificado e task não concluída',
      output:
        'Resumo final: arquivos criados ou modificados: nenhum. A task não foi concluída pelo ambiente.',
      expectedReason: 'nenhum arquivo foi alterado e a task não foi concluída',
    },
    {
      description: 'nenhum arquivo modificado e task não concluída',
      output:
        'Resultado: arquivos modificados: nenhum. A execução informa que não foi concluída.',
      expectedReason: 'nenhum arquivo foi modificado e a task não foi concluída',
    },
  ])('detecta combinação relevante: $description', ({ output, expectedReason }) => {
    const result = findCodexLogicalFailure(output);

    expect(result).toContain(expectedReason);
  });

  it.each([
    'Bloqueio de ambiente',
    'Operation not permitted',
    'Arquivos criados: nenhum',
    'Arquivos alterados: nenhum',
  ])('ignora termo fraco isolado: %s', (pattern) => {
    expect(findCodexLogicalFailure(`Mensagem informativa: ${pattern}.`)).toBeNull();
  });

  it('não falha quando o termo isolado aparece em uma task bem-sucedida', () => {
    const output = [
      'Task finalizada com sucesso.',
      'Contexto citado no prompt: Bloqueio de ambiente.',
      'Executando validação: pnpm lint',
      'Executando validação: pnpm test',
      'Todos os testes passaram.',
    ].join('\n');

    expect(findCodexLogicalFailure(output)).toBeNull();
  });
});
