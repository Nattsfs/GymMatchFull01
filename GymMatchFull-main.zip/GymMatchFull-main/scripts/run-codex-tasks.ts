import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { createWriteStream, promises as fs } from 'node:fs';
import type { WriteStream } from 'node:fs';
import path from 'node:path';
import { finished as streamFinished } from 'node:stream';
import { promisify } from 'node:util';

type TaskStatus = 'pending' | 'running' | 'done' | 'failed';

type ValidationCommand = [command: string, args: string[]];

interface TaskStateEntry {
  fileName: string;
  status: TaskStatus;
  startedAt: string | null;
  finishedAt: string | null;
  errorMessage: string | null;
  lastLogFile: string | null;
}

interface TaskStateFile {
  tasks: Record<string, TaskStateEntry>;
}

interface CommandOptions {
  command: string;
  args: string[];
  cwd: string;
  label: string;
  logStream: WriteStream;
  stdinText?: string;
}

const TASKS_ROOT = path.resolve(process.cwd(), '.codex-tasks');
const PENDING_DIR = path.join(TASKS_ROOT, 'pending');
const RUNNING_DIR = path.join(TASKS_ROOT, 'running');
const DONE_DIR = path.join(TASKS_ROOT, 'done');
const FAILED_DIR = path.join(TASKS_ROOT, 'failed');
const LOGS_DIR = path.join(TASKS_ROOT, 'logs');
const STATE_FILE = path.join(TASKS_ROOT, 'state.json');

const CODEX_COMMAND = 'codex';

const CODEX_SANDBOX_MODE = 'danger-full-access';

const CODEX_ARGS = ['exec', '--skip-git-repo-check', '--sandbox', CODEX_SANDBOX_MODE, '-'];
const CODEX_STRONG_FAILURE_PATTERNS = [
  'bwrap: loopback: Failed RTM_NEWADDR',
  'Failed to write file',
  'write_stdin failed',
  'Unknown process id',
];

const CODEX_COMBINED_FAILURE_PATTERNS: Array<{
  reason: string;
  patterns: string[];
}> = [
  {
    reason: 'Codex informou que não conseguiu acessar o shell.',
    patterns: ['não foi possível', 'shell'],
  },
  {
    reason: 'Codex informou que não conseguiu acessar o filesystem.',
    patterns: ['não foi possível', 'filesystem'],
  },
  {
    reason: 'Codex informou falha de sandbox.',
    patterns: ['não consegui concluir', 'sandbox'],
  },
  {
    reason: 'Codex informou que a task não foi concluída por sandbox.',
    patterns: ['task não foi concluída', 'sandbox'],
  },
  {
    reason: 'Codex informou que nenhum arquivo foi alterado e a task não foi concluída.',
    patterns: ['arquivos criados ou modificados: nenhum', 'não foi concluída'],
  },
  {
    reason: 'Codex informou que nenhum arquivo foi modificado e a task não foi concluída.',
    patterns: ['arquivos modificados: nenhum', 'não foi concluída'],
  },
];

// Ajuste essa lista conforme os checks desejados para o projeto.
const VALIDATION_COMMANDS: ValidationCommand[] = [
  ['pnpm', ['lint']],
  ['pnpm', ['test']],
];

const AUTO_COMMIT = false;
const AUTO_COMMIT_REPO_DIR = '';
const AUTO_COMMIT_MESSAGE_PREFIX = 'chore(codex-tasks): complete';
const finished = promisify(streamFinished);

function normalizeTextForSearch(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

// A saída do `codex exec` pode ecoar o próprio prompt da task.
// Por isso, padrões genéricos isolados são fracos demais e só devem falhar em combinação.
export function findCodexLogicalFailure(output: string): string | null {
  const normalizedOutput = normalizeTextForSearch(output);

  const strongMatch = CODEX_STRONG_FAILURE_PATTERNS.find((pattern) => {
    return normalizedOutput.includes(normalizeTextForSearch(pattern));
  });

  if (strongMatch) {
    return `Falha lógica detectada na saída do Codex. Erro técnico encontrado: "${strongMatch}".`;
  }

  const combinedMatch = CODEX_COMBINED_FAILURE_PATTERNS.find(({ patterns }) => {
    return patterns.every((pattern) => {
      return normalizedOutput.includes(normalizeTextForSearch(pattern));
    });
  });

  if (combinedMatch) {
    return `Falha lógica detectada na saída do Codex. ${combinedMatch.reason}`;
  }

  return null;
}

async function ensureWorkspaceStructure(): Promise<void> {
  await Promise.all([
    fs.mkdir(PENDING_DIR, { recursive: true }),
    fs.mkdir(RUNNING_DIR, { recursive: true }),
    fs.mkdir(DONE_DIR, { recursive: true }),
    fs.mkdir(FAILED_DIR, { recursive: true }),
    fs.mkdir(LOGS_DIR, { recursive: true }),
  ]);

  if (!(await pathExists(STATE_FILE))) {
    await writeState({ tasks: {} });
  }
}

async function pathExists(targetPath: string): Promise<boolean> {
  try {
    await fs.access(targetPath);
    return true;
  } catch {
    return false;
  }
}

async function readState(): Promise<TaskStateFile> {
  const rawContent = await fs.readFile(STATE_FILE, 'utf8');
  const parsed = JSON.parse(rawContent) as Partial<TaskStateFile>;

  if (
    parsed === null ||
    typeof parsed !== 'object' ||
    Array.isArray(parsed) ||
    parsed.tasks === null ||
    typeof parsed.tasks !== 'object' ||
    Array.isArray(parsed.tasks)
  ) {
    throw new Error(`Formato inválido em ${STATE_FILE}.`);
  }

  return {
    tasks: parsed.tasks as Record<string, TaskStateEntry>,
  };
}

async function writeState(state: TaskStateFile): Promise<void> {
  await fs.writeFile(STATE_FILE, `${JSON.stringify(state, null, 2)}\n`, 'utf8');
}

async function listMarkdownFiles(directoryPath: string): Promise<string[]> {
  const entries = await fs.readdir(directoryPath, { withFileTypes: true });

  return entries
    .filter((entry) => entry.isFile() && path.extname(entry.name).toLowerCase() === '.md')
    .map((entry) => entry.name)
    .sort((left, right) => left.localeCompare(right));
}

function createTaskEntry(fileName: string, status: TaskStatus): TaskStateEntry {
  return {
    fileName,
    status,
    startedAt: null,
    finishedAt: null,
    errorMessage: null,
    lastLogFile: null,
  };
}

function getOrCreateTaskEntry(state: TaskStateFile, fileName: string): TaskStateEntry {
  const existing = state.tasks[fileName];

  if (existing) {
    return existing;
  }

  const created = createTaskEntry(fileName, 'pending');
  state.tasks[fileName] = created;
  return created;
}

function timestampForFileName(date = new Date()): string {
  return date.toISOString().replace(/[:.]/g, '-');
}

function formatCommand(command: string, args: string[]): string {
  return [command, ...args].join(' ');
}

async function appendLog(logStream: WriteStream, content: string): Promise<void> {
  if (logStream.write(content)) {
    return;
  }

  await once(logStream, 'drain');
}

function createLogPath(taskFileName: string): string {
  const baseName = path.basename(taskFileName, path.extname(taskFileName));
  return path.join(LOGS_DIR, `${baseName}.${timestampForFileName()}.log`);
}

async function moveToDirectory(
  sourcePath: string,
  targetDirectory: string,
  preferredFileName: string,
): Promise<string> {
  const targetPath = await resolveUniquePath(targetDirectory, preferredFileName);
  await fs.rename(sourcePath, targetPath);
  return targetPath;
}

async function resolveUniquePath(
  directoryPath: string,
  preferredFileName: string,
): Promise<string> {
  let candidatePath = path.join(directoryPath, preferredFileName);

  if (!(await pathExists(candidatePath))) {
    return candidatePath;
  }

  const extension = path.extname(preferredFileName);
  const baseName = path.basename(preferredFileName, extension);
  const timestamp = timestampForFileName();
  let counter = 1;

  while (await pathExists(candidatePath)) {
    const suffix = counter === 1 ? timestamp : `${timestamp}-${counter}`;
    candidatePath = path.join(directoryPath, `${baseName}.${suffix}${extension}`);
    counter += 1;
  }

  return candidatePath;
}

async function recoverInterruptedTasks(state: TaskStateFile): Promise<void> {
  const runningTasks = await listMarkdownFiles(RUNNING_DIR);

  for (const taskFileName of runningTasks) {
    const runningTaskPath = path.join(RUNNING_DIR, taskFileName);
    await moveToDirectory(runningTaskPath, FAILED_DIR, taskFileName);

    const taskEntry = getOrCreateTaskEntry(state, taskFileName);
    taskEntry.status = 'failed';
    taskEntry.finishedAt = new Date().toISOString();
    taskEntry.errorMessage = 'Execução anterior interrompida antes de finalizar a task.';
  }

  if (runningTasks.length > 0) {
    await writeState(state);
    console.log(
      `Execução anterior interrompida. ${runningTasks.length} task(s) movida(s) de running para failed.`,
    );
  }
}

async function registerPendingTasks(state: TaskStateFile): Promise<string[]> {
  const pendingTasks = await listMarkdownFiles(PENDING_DIR);

  for (const taskFileName of pendingTasks) {
    state.tasks[taskFileName] = {
      fileName: taskFileName,
      status: 'pending',
      startedAt: null,
      finishedAt: null,
      errorMessage: null,
      lastLogFile: state.tasks[taskFileName]?.lastLogFile ?? null,
    };
  }

  await writeState(state);
  return pendingTasks;
}

async function runCommand(options: CommandOptions): Promise<string> {
  const { command, args, cwd, label, logStream, stdinText } = options;
  const renderedCommand = formatCommand(command, args);

  await appendLog(logStream, `\n[${new Date().toISOString()}] ${label}\n$ ${renderedCommand}\n`);

  return await new Promise<string>((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env: process.env,
      stdio: ['pipe', 'pipe', 'pipe'],
    });

    let combinedOutput = '';

    const forwardOutput = (target: NodeJS.WriteStream, chunk: Buffer | string): void => {
      const text = chunk.toString();
      combinedOutput += text;
      target.write(text);
      logStream.write(text);
    };

    child.stdout.on('data', (chunk) => {
      forwardOutput(process.stdout, chunk);
    });

    child.stderr.on('data', (chunk) => {
      forwardOutput(process.stderr, chunk);
    });

    child.on('error', (error) => {
      reject(new Error(`Falha ao iniciar ${renderedCommand}: ${error.message}`));
    });

    child.on('close', (code, signal) => {
      if (code === 0) {
        resolve(combinedOutput);
        return;
      }

      if (signal !== null) {
        reject(new Error(`${renderedCommand} terminou pelo sinal ${signal}.`));
        return;
      }

      reject(new Error(`${renderedCommand} terminou com código ${code ?? 'desconhecido'}.`));
    });

    child.stdin.end(stdinText);
  });
}

async function runValidations(logStream: WriteStream): Promise<void> {
  if (VALIDATION_COMMANDS.length === 0) {
    console.log('Nenhuma validação configurada. Pulando essa etapa.');
    return;
  }

  console.log('Rodando validações...');

  for (const [command, args] of VALIDATION_COMMANDS) {
    await runCommand({
      command,
      args,
      cwd: process.cwd(),
      label: `validation:${formatCommand(command, args)}`,
      logStream,
    });
  }
}

async function runAutoCommit(taskFileName: string, logStream: WriteStream): Promise<void> {
  if (!AUTO_COMMIT) {
    return;
  }

  if (AUTO_COMMIT_REPO_DIR.trim() === '') {
    throw new Error(
      'AUTO_COMMIT_REPO_DIR precisa apontar para um repositório Git quando AUTO_COMMIT=true.',
    );
  }

  const repositoryPath = path.resolve(process.cwd(), AUTO_COMMIT_REPO_DIR);

  await runCommand({
    command: 'git',
    args: ['-C', repositoryPath, 'rev-parse', '--is-inside-work-tree'],
    cwd: process.cwd(),
    label: 'git:verify-repository',
    logStream,
  });

  const statusOutput = await runCommand({
    command: 'git',
    args: ['-C', repositoryPath, 'status', '--short'],
    cwd: process.cwd(),
    label: 'git:status',
    logStream,
  });

  if (statusOutput.trim() === '') {
    console.log('AUTO_COMMIT ativo, mas sem alterações para commit no repositório configurado.');
    return;
  }

  await runCommand({
    command: 'git',
    args: ['-C', repositoryPath, 'add', '-A'],
    cwd: process.cwd(),
    label: 'git:add',
    logStream,
  });

  await runCommand({
    command: 'git',
    args: ['-C', repositoryPath, 'commit', '-m', `${AUTO_COMMIT_MESSAGE_PREFIX} ${taskFileName}`],
    cwd: process.cwd(),
    label: 'git:commit',
    logStream,
  });
}

async function finalizeTaskFailure(
  state: TaskStateFile,
  taskFileName: string,
  runningTaskPath: string,
  logStream: WriteStream,
  error: unknown,
): Promise<void> {
  if (await pathExists(runningTaskPath)) {
    await moveToDirectory(runningTaskPath, FAILED_DIR, taskFileName);
  }

  const taskEntry = getOrCreateTaskEntry(state, taskFileName);
  taskEntry.status = 'failed';
  taskEntry.finishedAt = new Date().toISOString();
  taskEntry.errorMessage = error instanceof Error ? error.message : String(error);

  await appendLog(logStream, `\n[${new Date().toISOString()}] ERROR\n${taskEntry.errorMessage}\n`);

  await writeState(state);
}

async function processTask(taskFileName: string, state: TaskStateFile): Promise<void> {
  const pendingTaskPath = path.join(PENDING_DIR, taskFileName);
  const runningTaskPath = path.join(RUNNING_DIR, taskFileName);
  const logPath = createLogPath(taskFileName);
  const logStream = createWriteStream(logPath, { flags: 'a', encoding: 'utf8' });
  const relativeLogPath = path.relative(process.cwd(), logPath);

  console.log(`Iniciando task ${taskFileName}`);

  await fs.rename(pendingTaskPath, runningTaskPath);

  const taskEntry = getOrCreateTaskEntry(state, taskFileName);
  taskEntry.status = 'running';
  taskEntry.startedAt = new Date().toISOString();
  taskEntry.finishedAt = null;
  taskEntry.errorMessage = null;
  taskEntry.lastLogFile = relativeLogPath;
  await writeState(state);

  try {
    await appendLog(
      logStream,
      `[${new Date().toISOString()}] Iniciando processamento de ${taskFileName}\n`,
    );

    const prompt = await fs.readFile(runningTaskPath, 'utf8');

    console.log('Executando Codex...');
    const codexOutput = await runCommand({
      command: CODEX_COMMAND,
      args: CODEX_ARGS,
      cwd: process.cwd(),
      label: 'codex',
      logStream,
      stdinText: prompt,
    });

    const logicalFailureMessage = findCodexLogicalFailure(codexOutput);

    if (logicalFailureMessage) {
      throw new Error(logicalFailureMessage);
    }

    await runValidations(logStream);
    await runAutoCommit(taskFileName, logStream);

    await moveToDirectory(runningTaskPath, DONE_DIR, taskFileName);

    taskEntry.status = 'done';
    taskEntry.finishedAt = new Date().toISOString();
    taskEntry.errorMessage = null;

    await appendLog(
      logStream,
      `\n[${new Date().toISOString()}] SUCCESS\nTask finalizada com sucesso.\n`,
    );

    await writeState(state);
    console.log('Task finalizada com sucesso.');
  } catch (error) {
    await finalizeTaskFailure(state, taskFileName, runningTaskPath, logStream, error);
    console.error('Task falhou. Movida para failed.');
    throw error;
  } finally {
    logStream.end();
    await finished(logStream);
  }
}

async function main(): Promise<void> {
  await ensureWorkspaceStructure();

  const state = await readState();

  await recoverInterruptedTasks(state);

  const pendingTasks = await registerPendingTasks(state);

  if (pendingTasks.length === 0) {
    console.log('Nenhuma task pendente encontrada.');
    return;
  }

  console.log(`${pendingTasks.length} task(s) pendente(s) encontrada(s).`);

  for (const taskFileName of pendingTasks) {
    await processTask(taskFileName, state);
  }

  console.log('Fila de tasks concluída.');
}

const isMainModule =
  process.argv[1] !== undefined &&
  [
    path.resolve(process.cwd(), 'scripts/run-codex-tasks.ts'),
    path.resolve(process.cwd(), 'scripts/run-codex-tasks.js'),
  ].includes(path.resolve(process.argv[1]));

if (isMainModule) {
  void main().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    console.error(message);
    process.exitCode = 1;
  });
}
