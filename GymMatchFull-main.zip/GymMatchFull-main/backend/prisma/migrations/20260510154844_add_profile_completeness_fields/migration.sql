ALTER TABLE "Profile"
ADD COLUMN "profilePhotoUrl" TEXT,
ADD COLUMN "isComplete" BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX "Profile_isComplete_idx" ON "Profile"("isComplete");
