-- CreateEnum
CREATE TYPE "ProfileGender" AS ENUM ('MAN', 'WOMAN', 'NON_BINARY', 'OTHER', 'PREFER_NOT_TO_SAY');

-- CreateEnum
CREATE TYPE "SexualOrientation" AS ENUM (
  'STRAIGHT',
  'GAY',
  'LESBIAN',
  'BISEXUAL',
  'PANSEXUAL',
  'ASEXUAL',
  'OTHER',
  'PREFER_NOT_TO_SAY'
);

-- CreateEnum
CREATE TYPE "AppGoal" AS ENUM ('TRAINING_PARTNER', 'FRIENDSHIP', 'NETWORKING', 'DATING');

-- CreateEnum
CREATE TYPE "TrainingLevel" AS ENUM ('BEGINNER', 'INTERMEDIATE', 'ADVANCED');

-- CreateEnum
CREATE TYPE "AvailablePeriod" AS ENUM (
  'EARLY_MORNING',
  'MORNING',
  'AFTERNOON',
  'EVENING',
  'NIGHT'
);

-- CreateEnum
CREATE TYPE "WorkoutModality" AS ENUM (
  'BODYBUILDING',
  'CROSSFIT',
  'FUNCTIONAL_TRAINING',
  'CARDIO',
  'FIGHT_SPORTS',
  'RUNNING',
  'YOGA',
  'PILATES',
  'SWIMMING',
  'OTHER'
);

-- CreateEnum
CREATE TYPE "WorkoutSplit" AS ENUM (
  'FULL_BODY',
  'UPPER_LOWER',
  'PUSH_PULL_LEGS',
  'ABC',
  'ABCD',
  'BRO_SPLIT',
  'OTHER'
);

-- CreateTable
CREATE TABLE "Profile" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "birthDate" DATE NOT NULL,
    "gender" "ProfileGender" NOT NULL,
    "sexualOrientation" "SexualOrientation" NOT NULL,
    "appGoal" "AppGoal" NOT NULL,
    "trainingLevel" "TrainingLevel" NOT NULL,
    "availablePeriods" "AvailablePeriod"[] NOT NULL,
    "preferredModalities" "WorkoutModality"[] NOT NULL,
    "workoutSplit" "WorkoutSplit" NOT NULL,
    "bio" TEXT,
    "showSexualOrientation" BOOLEAN NOT NULL DEFAULT false,
    "showAvailablePeriods" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Profile_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Profile_userId_key" ON "Profile"("userId");

-- CreateIndex
CREATE INDEX "Profile_deletedAt_idx" ON "Profile"("deletedAt");

-- CreateIndex
CREATE INDEX "Profile_createdAt_idx" ON "Profile"("createdAt");

-- AddForeignKey
ALTER TABLE "Profile"
ADD CONSTRAINT "Profile_userId_fkey"
FOREIGN KEY ("userId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
