-- CreateTable
CREATE TABLE "Like" (
    "id" TEXT NOT NULL,
    "likedByUserId" TEXT NOT NULL,
    "likedUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Like_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "Like_likedByUserId_likedUserId_check" CHECK ("likedByUserId" <> "likedUserId")
);

-- CreateIndex
CREATE UNIQUE INDEX "Like_likedByUserId_likedUserId_key" ON "Like"("likedByUserId", "likedUserId");

-- CreateIndex
CREATE INDEX "Like_likedByUserId_idx" ON "Like"("likedByUserId");

-- CreateIndex
CREATE INDEX "Like_likedUserId_idx" ON "Like"("likedUserId");

-- CreateIndex
CREATE INDEX "Like_createdAt_idx" ON "Like"("createdAt");

-- CreateIndex
CREATE INDEX "Like_deletedAt_idx" ON "Like"("deletedAt");

-- AddForeignKey
ALTER TABLE "Like"
ADD CONSTRAINT "Like_likedByUserId_fkey"
FOREIGN KEY ("likedByUserId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Like"
ADD CONSTRAINT "Like_likedUserId_fkey"
FOREIGN KEY ("likedUserId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
