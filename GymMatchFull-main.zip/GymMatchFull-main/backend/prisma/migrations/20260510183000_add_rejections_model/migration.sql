-- CreateTable
CREATE TABLE "Rejection" (
    "id" TEXT NOT NULL,
    "rejectedByUserId" TEXT NOT NULL,
    "rejectedUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Rejection_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "Rejection_rejectedByUserId_rejectedUserId_check" CHECK ("rejectedByUserId" <> "rejectedUserId")
);

-- CreateIndex
CREATE UNIQUE INDEX "Rejection_rejectedByUserId_rejectedUserId_key" ON "Rejection"("rejectedByUserId", "rejectedUserId");

-- CreateIndex
CREATE INDEX "Rejection_rejectedByUserId_idx" ON "Rejection"("rejectedByUserId");

-- CreateIndex
CREATE INDEX "Rejection_rejectedUserId_idx" ON "Rejection"("rejectedUserId");

-- CreateIndex
CREATE INDEX "Rejection_createdAt_idx" ON "Rejection"("createdAt");

-- CreateIndex
CREATE INDEX "Rejection_deletedAt_idx" ON "Rejection"("deletedAt");

-- AddForeignKey
ALTER TABLE "Rejection"
ADD CONSTRAINT "Rejection_rejectedByUserId_fkey"
FOREIGN KEY ("rejectedByUserId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Rejection"
ADD CONSTRAINT "Rejection_rejectedUserId_fkey"
FOREIGN KEY ("rejectedUserId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
