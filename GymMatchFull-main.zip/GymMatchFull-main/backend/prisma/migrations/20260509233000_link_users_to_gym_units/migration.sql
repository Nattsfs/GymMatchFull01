ALTER TABLE "User"
ADD COLUMN "gymId" TEXT,
ADD COLUMN "gymUnitId" TEXT;

CREATE UNIQUE INDEX "GymUnit_id_gymId_key" ON "GymUnit"("id", "gymId");

CREATE INDEX "User_gymId_idx" ON "User"("gymId");

CREATE INDEX "User_gymUnitId_idx" ON "User"("gymUnitId");

CREATE INDEX "User_role_gymUnitId_idx" ON "User"("role", "gymUnitId");

ALTER TABLE "User"
ADD CONSTRAINT "User_gym_registration_fields_check"
CHECK (("gymId" IS NULL) = ("gymUnitId" IS NULL));

ALTER TABLE "User"
ADD CONSTRAINT "User_student_requires_gym_check"
CHECK ("role" <> 'STUDENT' OR ("gymId" IS NOT NULL AND "gymUnitId" IS NOT NULL))
NOT VALID;

ALTER TABLE "User"
ADD CONSTRAINT "User_gymId_fkey"
FOREIGN KEY ("gymId") REFERENCES "Gym"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "User"
ADD CONSTRAINT "User_gymUnitId_fkey"
FOREIGN KEY ("gymUnitId") REFERENCES "GymUnit"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;

ALTER TABLE "User"
ADD CONSTRAINT "User_gymUnitId_gymId_fkey"
FOREIGN KEY ("gymUnitId", "gymId") REFERENCES "GymUnit"("id", "gymId")
ON DELETE RESTRICT ON UPDATE CASCADE;
