-- CreateTable
CREATE TABLE "Block" (
    "id" TEXT NOT NULL,
    "blockedByUserId" TEXT NOT NULL,
    "blockedUserId" TEXT NOT NULL,
    "reason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Block_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "Block_blockedByUserId_blockedUserId_check" CHECK ("blockedByUserId" <> "blockedUserId")
);

-- CreateIndex
CREATE UNIQUE INDEX "Block_blockedByUserId_blockedUserId_key" ON "Block"("blockedByUserId", "blockedUserId");

-- CreateIndex
CREATE INDEX "Block_blockedByUserId_idx" ON "Block"("blockedByUserId");

-- CreateIndex
CREATE INDEX "Block_blockedUserId_idx" ON "Block"("blockedUserId");

-- CreateIndex
CREATE INDEX "Block_createdAt_idx" ON "Block"("createdAt");

-- CreateIndex
CREATE INDEX "Block_deletedAt_idx" ON "Block"("deletedAt");

-- AddForeignKey
ALTER TABLE "Block"
ADD CONSTRAINT "Block_blockedByUserId_fkey"
FOREIGN KEY ("blockedByUserId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Block"
ADD CONSTRAINT "Block_blockedUserId_fkey"
FOREIGN KEY ("blockedUserId") REFERENCES "User"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
