CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE "GymUnit"
ADD COLUMN "qrCodeToken" TEXT;

UPDATE "GymUnit"
SET "qrCodeToken" = encode(gen_random_bytes(24), 'hex')
WHERE "qrCodeToken" IS NULL;

ALTER TABLE "GymUnit"
ALTER COLUMN "qrCodeToken"
SET NOT NULL;

CREATE UNIQUE INDEX "GymUnit_qrCodeToken_key" ON "GymUnit"("qrCodeToken");
