-- CreateEnum
CREATE TYPE "GymStatus" AS ENUM ('ACTIVE', 'INACTIVE', 'DELETED');

-- CreateEnum
CREATE TYPE "GymUnitStatus" AS ENUM ('ACTIVE', 'INACTIVE', 'DELETED');

-- CreateTable
CREATE TABLE "Gym" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "legalName" TEXT,
    "document" TEXT,
    "email" TEXT,
    "phone" TEXT,
    "status" "GymStatus" NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "Gym_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GymUnit" (
    "id" TEXT NOT NULL,
    "gymId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "addressLine" TEXT,
    "number" TEXT,
    "complement" TEXT,
    "neighborhood" TEXT,
    "city" TEXT,
    "state" TEXT,
    "zipCode" TEXT,
    "latitude" DECIMAL(65,30),
    "longitude" DECIMAL(65,30),
    "status" "GymUnitStatus" NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deletedAt" TIMESTAMP(3),

    CONSTRAINT "GymUnit_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Gym_document_key" ON "Gym"("document");

-- CreateIndex
CREATE INDEX "Gym_status_idx" ON "Gym"("status");

-- CreateIndex
CREATE INDEX "Gym_deletedAt_idx" ON "Gym"("deletedAt");

-- CreateIndex
CREATE INDEX "Gym_createdAt_idx" ON "Gym"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "GymUnit_gymId_name_key" ON "GymUnit"("gymId", "name");

-- CreateIndex
CREATE INDEX "GymUnit_gymId_idx" ON "GymUnit"("gymId");

-- CreateIndex
CREATE INDEX "GymUnit_status_idx" ON "GymUnit"("status");

-- CreateIndex
CREATE INDEX "GymUnit_deletedAt_idx" ON "GymUnit"("deletedAt");

-- CreateIndex
CREATE INDEX "GymUnit_city_state_idx" ON "GymUnit"("city", "state");

-- AddForeignKey
ALTER TABLE "GymUnit"
ADD CONSTRAINT "GymUnit_gymId_fkey"
FOREIGN KEY ("gymId") REFERENCES "Gym"("id")
ON DELETE RESTRICT ON UPDATE CASCADE;
