import { spawn } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { config as loadDotEnv } from 'dotenv';

const currentDirectory = dirname(fileURLToPath(import.meta.url));
const backendRoot = resolve(currentDirectory, '..');
const repositoryRoot = resolve(backendRoot, '..');
const rootEnvPath = resolve(repositoryRoot, '.env');
const prismaCliPath = resolve(backendRoot, 'node_modules/prisma/build/index.js');
const prismaArgs = process.argv.slice(2);
const placeholderDatabaseUrl = 'postgresql://USER:PASSWORD@HOST:5432/DATABASE?schema=public';

loadDotEnv({ path: rootEnvPath });

if (!process.env.DATABASE_URL && (prismaArgs[0] === 'validate' || prismaArgs[0] === 'generate')) {
  process.env.DATABASE_URL = placeholderDatabaseUrl;
}

const child = spawn(process.execPath, [prismaCliPath, ...prismaArgs], {
  cwd: backendRoot,
  env: process.env,
  stdio: 'inherit',
});

child.on('error', (error) => {
  console.error(`Failed to run Prisma CLI.\n${error.message}`);
  process.exitCode = 1;
});

child.on('exit', (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }

  process.exit(code ?? 0);
});
