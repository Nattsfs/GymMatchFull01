import { Prisma, UserStatus as PrismaUserStatus, type PrismaClient } from '@prisma/client';

import type { AdminMetricsServiceContract, AdminMetricsSummary } from './admin-metrics.types.js';

type DatabaseClient = PrismaClient | Prisma.TransactionClient;

export class AdminMetricsService implements AdminMetricsServiceContract {
  constructor(private readonly prisma: DatabaseClient) {}

  async getSummary(): Promise<AdminMetricsSummary> {
    const [totalUsers, activeUsers, totalMatches, totalReports] = await Promise.all([
      this.prisma.user.count({
        where: {
          deletedAt: null,
        },
      }),
      this.prisma.user.count({
        where: {
          deletedAt: null,
          status: PrismaUserStatus.ACTIVE,
        },
      }),
      this.prisma.match.count({
        where: {
          deletedAt: null,
        },
      }),
      this.prisma.report.count({
        where: {
          deletedAt: null,
        },
      }),
    ]);

    return {
      totalUsers,
      activeUsers,
      totalMatches,
      totalReports,
      // The subscription domain is not implemented yet, so the dashboard exposes zero for now.
      premiumSubscriptions: 0,
    };
  }
}
