import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import type { SafeUser } from '../users/users.types.js';
import type { AdminMetricsServiceContract, AdminMetricsSummary } from './admin-metrics.types.js';

const FIXED_NOW = new Date('2026-05-10T22:15:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

class InMemoryUsersService {
  private readonly users = new Map<string, SafeUser>();

  seedUser(input: {
    id: string;
    role: PrismaUserRole;
    status?: PrismaUserStatus;
  }): SafeUser {
    const user: SafeUser = {
      id: input.id,
      name: `User ${input.id}`,
      email: `${input.id}@example.com`,
      phone: `11999999${input.id.slice(-2).padStart(2, '0')}`,
      cpf: `123456789${input.id.slice(-2).padStart(2, '0')}`,
      role: input.role,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      gymId: null,
      gymUnitId: null,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: null,
    };

    this.users.set(user.id, user);

    return user;
  }

  async createUser(): Promise<SafeUser> {
    throw new Error('Not implemented in this test.');
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.get(id) ?? null;
  }

  async findUserByEmail(): Promise<SafeUser | null> {
    return null;
  }

  async findUserByIdWithRefreshToken() {
    return null;
  }

  async findUserByEmailWithPassword() {
    return null;
  }

  async findUserByPasswordResetTokenHash() {
    return null;
  }

  async updateLastLoginAt(): Promise<void> {}

  async updateRefreshTokenHash(): Promise<void> {}

  async updatePasswordResetToken(): Promise<void> {}

  async updatePasswordAfterReset(): Promise<void> {}
}

class InMemoryAdminMetricsService implements AdminMetricsServiceContract {
  constructor(private readonly summary: AdminMetricsSummary) {}

  async getSummary(): Promise<AdminMetricsSummary> {
    return this.summary;
  }
}

function createTestApp(summary: AdminMetricsSummary) {
  const usersService = new InMemoryUsersService();
  const adminMetricsService = new InMemoryAdminMetricsService(summary);
  const app = buildApp({
    config,
    services: {
      adminMetricsService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('GET /admin/metrics', () => {
  it('returns dashboard metrics for an authenticated admin', async () => {
    const { app, usersService } = createTestApp({
      totalUsers: 42,
      activeUsers: 38,
      totalMatches: 16,
      totalReports: 4,
      premiumSubscriptions: 0,
    });
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/metrics',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({
      totalUsers: 42,
      activeUsers: 38,
      totalMatches: 16,
      totalReports: 4,
      premiumSubscriptions: 0,
    });
  });

  it('blocks students and anonymous users from admin metrics', async () => {
    const { app, usersService } = createTestApp({
      totalUsers: 0,
      activeUsers: 0,
      totalMatches: 0,
      totalReports: 0,
      premiumSubscriptions: 0,
    });
    const student = usersService.seedUser({
      id: 'student_1',
      role: PrismaUserRole.STUDENT,
    });

    await app.ready();

    const anonymousResponse = await app.inject({
      method: 'GET',
      url: '/admin/metrics',
    });

    expect(anonymousResponse.statusCode).toBe(401);
    expect(anonymousResponse.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });

    const forbiddenResponse = await app.inject({
      method: 'GET',
      url: '/admin/metrics',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(forbiddenResponse.statusCode).toBe(403);
    expect(forbiddenResponse.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });
});
