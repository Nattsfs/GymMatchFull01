export interface AdminMetricsSummary {
  totalUsers: number;
  activeUsers: number;
  totalMatches: number;
  totalReports: number;
  premiumSubscriptions: number;
}

export interface AdminMetricsServiceContract {
  getSummary(): Promise<AdminMetricsSummary>;
}
