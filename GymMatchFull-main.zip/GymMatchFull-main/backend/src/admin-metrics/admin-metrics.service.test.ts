import { UserStatus as PrismaUserStatus, type PrismaClient } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';

import { AdminMetricsService } from './admin-metrics.service.js';

describe('AdminMetricsService', () => {
  it('counts non-deleted records and returns zero premium subscriptions until plans exist', async () => {
    const userCount = vi.fn().mockResolvedValueOnce(24).mockResolvedValueOnce(19);
    const matchCount = vi.fn().mockResolvedValueOnce(8);
    const reportCount = vi.fn().mockResolvedValueOnce(3);
    const prisma = {
      user: {
        count: userCount,
      },
      match: {
        count: matchCount,
      },
      report: {
        count: reportCount,
      },
    } as unknown as PrismaClient;
    const service = new AdminMetricsService(prisma);

    await expect(service.getSummary()).resolves.toEqual({
      totalUsers: 24,
      activeUsers: 19,
      totalMatches: 8,
      totalReports: 3,
      premiumSubscriptions: 0,
    });
    expect(userCount).toHaveBeenNthCalledWith(1, {
      where: {
        deletedAt: null,
      },
    });
    expect(userCount).toHaveBeenNthCalledWith(2, {
      where: {
        deletedAt: null,
        status: PrismaUserStatus.ACTIVE,
      },
    });
    expect(matchCount).toHaveBeenCalledWith({
      where: {
        deletedAt: null,
      },
    });
    expect(reportCount).toHaveBeenCalledWith({
      where: {
        deletedAt: null,
      },
    });
  });
});
