import type { MatchStatus, PrismaClient } from '@prisma/client';
import { MatchStatus as PrismaMatchStatus } from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { ChatServiceContract, ConversationRecord } from '../chat/chat.types.js';
import { MatchesRepository } from './matches.repository.js';
import { MatchesService } from './matches.service.js';
import type { CreateMatchInput, MatchRecord } from './matches.types.js';
import { MatchConflictError, MatchSelfMatchError } from './matches.types.js';

const FIXED_NOW = new Date('2026-05-10T19:30:00.000Z');

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async createMatch(input: CreateMatchInput): Promise<MatchRecord> {
    if (input.userAId === input.userBId) {
      throw new MatchSelfMatchError();
    }

    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const existingMatch = this.matches.find(
      (match) =>
        match.userAId === normalizedPair.userAId &&
        match.userBId === normalizedPair.userBId &&
        match.deletedAt === null,
    );

    if (existingMatch) {
      throw new MatchConflictError('userPair');
    }

    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  async findActiveMatchBetweenUsers(
    firstUserId: string,
    secondUserId: string,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (match) =>
          match.userAId === normalizedPair.userAId &&
          match.userBId === normalizedPair.userBId &&
          match.deletedAt === null,
      ) ?? null
    );
  }

  async existsActiveMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    return (await this.findActiveMatchBetweenUsers(firstUserId, secondUserId)) !== null;
  }

  seedMatch(input: CreateMatchInput & { createdAt?: Date; updatedAt?: Date }): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }
}

class InMemoryChatConversationService {
  private readonly conversations: ConversationRecord[] = [];
  private nextConversationId = 1;

  async getOrCreateConversation(input: { matchId: string }): Promise<ConversationRecord> {
    const existingConversation = this.conversations.find(
      (conversation) => conversation.matchId === input.matchId,
    );

    if (existingConversation) {
      return existingConversation;
    }

    const conversation: ConversationRecord = {
      id: `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  findConversationByMatchId(matchId: string): ConversationRecord | null {
    return this.conversations.find((conversation) => conversation.matchId === matchId) ?? null;
  }

  countConversations(): number {
    return this.conversations.length;
  }
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function createMatchesService(
  options: {
    chatService?: InMemoryChatConversationService;
    matchesRepository?: InMemoryMatchesRepository;
  } = {},
): MatchesService {
  return new MatchesService({} as PrismaClient, {
    chatService:
      (options.chatService ??
        new InMemoryChatConversationService()) as unknown as Pick<
        ChatServiceContract,
        'getOrCreateConversation'
      >,
    matchesRepository: (options.matchesRepository ??
      new InMemoryMatchesRepository()) as unknown as MatchesRepository,
  });
}

describe('MatchesService', () => {
  it('creates a match with normalized user order', async () => {
    const chatService = new InMemoryChatConversationService();
    const service = createMatchesService({ chatService });
    const expiresAt = new Date('2026-06-10T19:30:00.000Z');

    const match = await service.createMatch({
      userAId: 'user_9',
      userBId: 'user_2',
      status: PrismaMatchStatus.ACTIVE,
      expiresAt,
    });

    expect(match).toMatchObject({
      userAId: 'user_2',
      userBId: 'user_9',
      status: PrismaMatchStatus.ACTIVE,
      expiresAt,
      deletedAt: null,
    });
    expect(chatService.findConversationByMatchId(match.id)).toMatchObject({
      matchId: match.id,
    });
    expect(chatService.countConversations()).toBe(1);
  });

  it('rejects duplicate matches independently of input order', async () => {
    const matchesRepository = new InMemoryMatchesRepository();
    matchesRepository.seedMatch({
      userAId: 'user_1',
      userBId: 'user_2',
    });
    const service = createMatchesService({ matchesRepository });

    await expect(
      service.createMatch({
        userAId: 'user_2',
        userBId: 'user_1',
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Match already exists between these users.',
    });
  });

  it('rejects self match attempts', async () => {
    const service = createMatchesService();

    await expect(
      service.createMatch({
        userAId: 'user_1',
        userBId: 'user_1',
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Users cannot match with themselves.',
    });
  });

  it('finds an existing match regardless of user order', async () => {
    const matchesRepository = new InMemoryMatchesRepository();
    const seededMatch = matchesRepository.seedMatch({
      userAId: 'user_3',
      userBId: 'user_1',
      status: PrismaMatchStatus.BLOCKED,
    });
    const service = createMatchesService({ matchesRepository });

    await expect(service.findMatchBetweenUsers('user_1', 'user_3')).resolves.toEqual(seededMatch);
    await expect(service.findMatchBetweenUsers('user_3', 'user_1')).resolves.toEqual(seededMatch);
  });

  it('reports whether a match already exists between two users', async () => {
    const matchesRepository = new InMemoryMatchesRepository();
    matchesRepository.seedMatch({
      userAId: 'user_10',
      userBId: 'user_4',
      status: PrismaMatchStatus.EXPIRED,
    });
    const service = createMatchesService({ matchesRepository });

    await expect(service.matchExistsBetweenUsers('user_4', 'user_10')).resolves.toBe(true);
    await expect(service.matchExistsBetweenUsers('user_4', 'user_11')).resolves.toBe(false);
  });

  it('accepts all supported match statuses', async () => {
    const chatService = new InMemoryChatConversationService();
    const service = createMatchesService({ chatService });
    const statuses: MatchStatus[] = [
      PrismaMatchStatus.ACTIVE,
      PrismaMatchStatus.EXPIRED,
      PrismaMatchStatus.UNMATCHED,
      PrismaMatchStatus.BLOCKED,
    ];

    for (const status of statuses) {
      const match = await service.createMatch({
        userAId: `user_${status}_1`,
        userBId: `user_${status}_2`,
        status,
      });

      expect(match.status).toBe(status);
    }

    expect(chatService.countConversations()).toBe(1);
  });
});
