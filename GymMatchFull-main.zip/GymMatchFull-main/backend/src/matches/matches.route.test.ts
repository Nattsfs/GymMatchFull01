import type { PrismaClient } from '@prisma/client';
import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  MatchStatus as PrismaMatchStatus,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import { MatchesService } from './matches.service.js';
import type {
  CreateMatchInput,
  MatchRecord,
  MatchWithParticipantsRecord,
} from './matches.types.js';
import { MatchConflictError, MatchSelfMatchError } from './matches.types.js';
import type { SafeUser } from '../users/users.types.js';

const FIXED_NOW = new Date('2026-05-10T19:30:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(overrides: Partial<SafeUser> = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: overrides.id ?? `user_${index}`,
      name: overrides.name ?? `Aluno ${index}`,
      email: overrides.email ?? `aluno_${index}@example.com`,
      phone: overrides.phone ?? `1199999999${index}`,
      cpf: overrides.cpf ?? `1234567890${index}`,
      gymId: overrides.gymId ?? 'gym_1',
      gymUnitId: overrides.gymUnitId ?? 'unit_1',
      role: overrides.role ?? PrismaUserRole.STUDENT,
      status: overrides.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: overrides.emailVerifiedAt ?? null,
      phoneVerifiedAt: overrides.phoneVerifiedAt ?? null,
      termsAcceptedAt: overrides.termsAcceptedAt ?? null,
      lastLoginAt: overrides.lastLoginAt ?? null,
      createdAt: overrides.createdAt ?? FIXED_NOW,
      updatedAt: overrides.updatedAt ?? FIXED_NOW,
      deletedAt: overrides.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private readonly matchSources: MatchWithParticipantsRecord[] = [];
  private nextId = 1;

  async createMatch(input: CreateMatchInput): Promise<MatchRecord> {
    if (input.userAId === input.userBId) {
      throw new MatchSelfMatchError();
    }

    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const existingMatch = this.matches.find(
      (match) =>
        match.userAId === normalizedPair.userAId &&
        match.userBId === normalizedPair.userBId &&
        match.deletedAt === null,
    );

    if (existingMatch) {
      throw new MatchConflictError('userPair');
    }

    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  async findActiveMatchBetweenUsers(
    firstUserId: string,
    secondUserId: string,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (match) =>
          match.userAId === normalizedPair.userAId &&
          match.userBId === normalizedPair.userBId &&
          match.deletedAt === null,
      ) ?? null
    );
  }

  async existsActiveMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    return (await this.findActiveMatchBetweenUsers(firstUserId, secondUserId)) !== null;
  }

  async findActiveMatchesForUser(
    userId: string,
    now: Date,
  ): Promise<MatchWithParticipantsRecord[]> {
    return this.matchSources
      .filter(
        (match) =>
          match.deletedAt === null &&
          match.status === PrismaMatchStatus.ACTIVE &&
          (match.expiresAt === null || match.expiresAt.getTime() > now.getTime()) &&
          (match.userAId === userId || match.userBId === userId),
      )
      .sort(compareMatchesByListOrder);
  }

  seedMatchSource(match: MatchWithParticipantsRecord): void {
    this.matchSources.push(match);
    this.matches.push(stripParticipants(match));
  }
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const matchesRepository = new InMemoryMatchesRepository();
  const matchesService = new MatchesService({} as PrismaClient, {
    matchesRepository,
    usersService,
    now: () => FIXED_NOW,
  });
  const app = buildApp({
    config,
    services: {
      matchesService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return { app, matchesRepository, usersService };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

type MatchParticipantOverride = Partial<Omit<MatchWithParticipantsRecord['userA'], 'profile'>> & {
  profile?: Partial<NonNullable<MatchWithParticipantsRecord['userA']['profile']>> | null;
};

type MatchSourceOverride = Partial<Omit<MatchWithParticipantsRecord, 'userA' | 'userB'>> & {
  userA?: MatchParticipantOverride;
  userB?: MatchParticipantOverride;
};

function makeMatchSource(overrides: MatchSourceOverride = {}): MatchWithParticipantsRecord {
  const createdAt = overrides.createdAt ?? FIXED_NOW;
  const updatedAt = overrides.updatedAt ?? createdAt;

  return {
    id: overrides.id ?? `match_seed_${Math.random().toString(36).slice(2, 8)}`,
    userAId: overrides.userAId ?? 'student_1',
    userBId: overrides.userBId ?? 'student_2',
    status: overrides.status ?? PrismaMatchStatus.ACTIVE,
    expiresAt: overrides.expiresAt ?? null,
    createdAt,
    updatedAt,
    deletedAt: overrides.deletedAt ?? null,
    userA: {
      id: overrides.userA?.id ?? overrides.userAId ?? 'student_1',
      name: overrides.userA?.name ?? 'Aluno Atual',
      role: overrides.userA?.role ?? PrismaUserRole.STUDENT,
      status: overrides.userA?.status ?? PrismaUserStatus.ACTIVE,
      deletedAt: overrides.userA?.deletedAt ?? null,
      gym: overrides.userA?.gym ?? {
        id: 'gym_1',
        name: 'Academia Centro',
      },
      gymUnit: overrides.userA?.gymUnit ?? {
        id: 'unit_1',
        name: 'Unidade Paulista',
        city: 'Sao Paulo',
        state: 'SP',
      },
      profile:
        overrides.userA?.profile === null
          ? null
          : {
              id: overrides.userA?.profile?.id ?? 'profile_student_1',
              userId:
                overrides.userA?.profile?.userId ??
                overrides.userA?.id ??
                overrides.userAId ??
                'student_1',
              birthDate:
                overrides.userA?.profile?.birthDate ?? new Date('1997-01-15T00:00:00.000Z'),
              gender: overrides.userA?.profile?.gender ?? PrismaProfileGender.MAN,
              sexualOrientation:
                overrides.userA?.profile?.sexualOrientation ?? PrismaSexualOrientation.STRAIGHT,
              appGoal: overrides.userA?.profile?.appGoal ?? PrismaAppGoal.TRAINING_PARTNER,
              trainingLevel:
                overrides.userA?.profile?.trainingLevel ?? PrismaTrainingLevel.INTERMEDIATE,
              availablePeriods: overrides.userA?.profile?.availablePeriods ?? [
                PrismaAvailablePeriod.MORNING,
              ],
              preferredModalities: overrides.userA?.profile?.preferredModalities ?? [
                PrismaWorkoutModality.BODYBUILDING,
              ],
              workoutSplit: overrides.userA?.profile?.workoutSplit ?? PrismaWorkoutSplit.ABC,
              profilePhotoUrl:
                overrides.userA?.profile?.profilePhotoUrl ??
                'https://cdn.gymmatch.test/student-1.jpg',
              isComplete: overrides.userA?.profile?.isComplete ?? true,
              bio: overrides.userA?.profile?.bio ?? 'Treino cedo durante a semana.',
              showSexualOrientation: overrides.userA?.profile?.showSexualOrientation ?? false,
              showAvailablePeriods: overrides.userA?.profile?.showAvailablePeriods ?? true,
              createdAt: overrides.userA?.profile?.createdAt ?? createdAt,
              updatedAt: overrides.userA?.profile?.updatedAt ?? updatedAt,
              deletedAt: overrides.userA?.profile?.deletedAt ?? null,
            },
    },
    userB: {
      id: overrides.userB?.id ?? overrides.userBId ?? 'student_2',
      name: overrides.userB?.name ?? 'Maria Silva',
      role: overrides.userB?.role ?? PrismaUserRole.STUDENT,
      status: overrides.userB?.status ?? PrismaUserStatus.ACTIVE,
      deletedAt: overrides.userB?.deletedAt ?? null,
      gym: overrides.userB?.gym ?? {
        id: 'gym_1',
        name: 'Academia Centro',
      },
      gymUnit: overrides.userB?.gymUnit ?? {
        id: 'unit_1',
        name: 'Unidade Paulista',
        city: 'Sao Paulo',
        state: 'SP',
      },
      profile:
        overrides.userB?.profile === null
          ? null
          : {
              id: overrides.userB?.profile?.id ?? 'profile_student_2',
              userId:
                overrides.userB?.profile?.userId ??
                overrides.userB?.id ??
                overrides.userBId ??
                'student_2',
              birthDate:
                overrides.userB?.profile?.birthDate ?? new Date('1998-06-20T00:00:00.000Z'),
              gender: overrides.userB?.profile?.gender ?? PrismaProfileGender.WOMAN,
              sexualOrientation:
                overrides.userB?.profile?.sexualOrientation ?? PrismaSexualOrientation.BISEXUAL,
              appGoal: overrides.userB?.profile?.appGoal ?? PrismaAppGoal.TRAINING_PARTNER,
              trainingLevel:
                overrides.userB?.profile?.trainingLevel ?? PrismaTrainingLevel.ADVANCED,
              availablePeriods: overrides.userB?.profile?.availablePeriods ?? [
                PrismaAvailablePeriod.EVENING,
              ],
              preferredModalities: overrides.userB?.profile?.preferredModalities ?? [
                PrismaWorkoutModality.CROSSFIT,
              ],
              workoutSplit:
                overrides.userB?.profile?.workoutSplit ?? PrismaWorkoutSplit.PUSH_PULL_LEGS,
              profilePhotoUrl:
                overrides.userB?.profile?.profilePhotoUrl ??
                'https://cdn.gymmatch.test/student-2.jpg',
              isComplete: overrides.userB?.profile?.isComplete ?? true,
              bio:
                overrides.userB?.profile?.bio ??
                'Procuro parceria para treinar depois do trabalho.',
              showSexualOrientation: overrides.userB?.profile?.showSexualOrientation ?? false,
              showAvailablePeriods: overrides.userB?.profile?.showAvailablePeriods ?? true,
              createdAt: overrides.userB?.profile?.createdAt ?? createdAt,
              updatedAt: overrides.userB?.profile?.updatedAt ?? updatedAt,
              deletedAt: overrides.userB?.profile?.deletedAt ?? null,
            },
    },
  };
}

function stripParticipants(match: MatchWithParticipantsRecord): MatchRecord {
  return {
    id: match.id,
    userAId: match.userAId,
    userBId: match.userBId,
    status: match.status,
    expiresAt: match.expiresAt,
    createdAt: match.createdAt,
    updatedAt: match.updatedAt,
    deletedAt: match.deletedAt,
  };
}

function compareMatchesByListOrder(
  left: MatchWithParticipantsRecord,
  right: MatchWithParticipantsRecord,
): number {
  const createdAtComparison = right.createdAt.getTime() - left.createdAt.getTime();

  if (createdAtComparison !== 0) {
    return createdAtComparison;
  }

  return left.id.localeCompare(right.id);
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('GET /matches/me', () => {
  it('returns only the authenticated student active matches with public-safe data', async () => {
    const { app, matchesRepository, usersService } = createTestApp();
    const currentUser = usersService.seedUser({
      id: 'student_1',
      name: 'Aluno Atual',
    });

    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_visible',
        createdAt: new Date('2026-05-10T18:30:00.000Z'),
        userAId: currentUser.id,
        userA: {
          id: currentUser.id,
          name: currentUser.name,
        },
        userBId: 'student_2',
        userB: {
          id: 'student_2',
          name: 'Maria Silva',
        },
      }),
    );
    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_expired_status',
        status: PrismaMatchStatus.EXPIRED,
        userAId: currentUser.id,
        userA: { id: currentUser.id, name: currentUser.name },
        userBId: 'student_3',
        userB: { id: 'student_3', name: 'Aluno Expirado' },
      }),
    );
    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_unmatched',
        status: PrismaMatchStatus.UNMATCHED,
        userAId: currentUser.id,
        userA: { id: currentUser.id, name: currentUser.name },
        userBId: 'student_4',
        userB: { id: 'student_4', name: 'Aluno Desfeito' },
      }),
    );
    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_blocked',
        status: PrismaMatchStatus.BLOCKED,
        userAId: currentUser.id,
        userA: { id: currentUser.id, name: currentUser.name },
        userBId: 'student_5',
        userB: { id: 'student_5', name: 'Aluno Bloqueado' },
      }),
    );
    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_deleted',
        deletedAt: new Date('2026-05-10T17:00:00.000Z'),
        userAId: currentUser.id,
        userA: { id: currentUser.id, name: currentUser.name },
        userBId: 'student_6',
        userB: { id: 'student_6', name: 'Aluno Deletado' },
      }),
    );
    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_expired_at',
        expiresAt: new Date('2026-05-10T18:00:00.000Z'),
        userAId: currentUser.id,
        userA: { id: currentUser.id, name: currentUser.name },
        userBId: 'student_7',
        userB: { id: 'student_7', name: 'Aluno Vencido' },
      }),
    );
    matchesRepository.seedMatchSource(
      makeMatchSource({
        id: 'match_other_user',
        userAId: 'student_8',
        userA: { id: 'student_8', name: 'Outro Aluno' },
        userBId: 'student_9',
        userB: { id: 'student_9', name: 'Terceiro Aluno' },
      }),
    );

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/matches/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, currentUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();

    expect(body.data).toHaveLength(1);
    expect(body.data).toEqual([
      {
        id: 'match_visible',
        status: PrismaMatchStatus.ACTIVE,
        createdAt: '2026-05-10T18:30:00.000Z',
        user: {
          id: 'student_2',
          name: 'Maria Silva',
        },
        profile: {
          id: 'student_2',
          name: 'Maria Silva',
          age: 27,
          gender: PrismaProfileGender.WOMAN,
          appGoal: PrismaAppGoal.TRAINING_PARTNER,
          trainingLevel: PrismaTrainingLevel.ADVANCED,
          preferredModalities: [PrismaWorkoutModality.CROSSFIT],
          workoutSplit: PrismaWorkoutSplit.PUSH_PULL_LEGS,
          profilePhotoUrl: 'https://cdn.gymmatch.test/student-2.jpg',
          bio: 'Procuro parceria para treinar depois do trabalho.',
          availablePeriods: [PrismaAvailablePeriod.EVENING],
          gym: {
            id: 'gym_1',
            name: 'Academia Centro',
          },
          gymUnit: {
            id: 'unit_1',
            name: 'Unidade Paulista',
            city: 'Sao Paulo',
            state: 'SP',
          },
        },
      },
    ]);
    expect(body.data[0].user).not.toHaveProperty('email');
    expect(body.data[0].user).not.toHaveProperty('phone');
    expect(body.data[0].user).not.toHaveProperty('cpf');
    expect(body.data[0].profile).not.toHaveProperty('email');
    expect(body.data[0].profile).not.toHaveProperty('phone');
    expect(body.data[0].profile).not.toHaveProperty('cpf');
    expect(body.data[0].profile).not.toHaveProperty('passwordHash');
    expect(body.data[0].profile).not.toHaveProperty('refreshTokenHash');
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/matches/me',
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from listing student matches', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/matches/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });
});
