import type { Match, MatchStatus, UserRole, UserStatus } from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';
import type { ListStudentMatchesResult } from './dto/list-student-matches-response.dto.js';
import type {
  PublicStudentProfileSource,
  PublicStudentProfileSourceUser,
} from '../profiles/profiles.serializer.js';

export interface CreateMatchInput {
  userAId: string;
  userBId: string;
  status?: MatchStatus;
  expiresAt?: Date | null;
  deletedAt?: Date;
}

export type MatchRecord = Match;
export type SafeMatch = MatchRecord;
export type MatchParticipantProfileRecord = Omit<PublicStudentProfileSource, 'user'>;
export type MatchParticipantUserRecord = Omit<
  PublicStudentProfileSourceUser,
  'role' | 'status' | 'deletedAt'
> & {
  role: UserRole;
  status: UserStatus;
  deletedAt: Date | null;
  profile: MatchParticipantProfileRecord | null;
};
export type MatchWithParticipantsRecord = MatchRecord & {
  userA: MatchParticipantUserRecord;
  userB: MatchParticipantUserRecord;
};

export interface MatchesServiceContract {
  createMatch(input: CreateMatchInput): Promise<SafeMatch>;
  findMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<SafeMatch | null>;
  matchExistsBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean>;
  listCurrentUserMatches(currentUser: CurrentUserContext): Promise<ListStudentMatchesResult>;
}

export class MatchConflictError extends Error {
  readonly field: 'userPair' | 'unknown';

  constructor(field: 'userPair' | 'unknown') {
    const fieldLabel = field === 'userPair' ? 'user match pair' : 'unique match field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'MatchConflictError';
    this.field = field;
  }
}

export class MatchSelfMatchError extends Error {
  constructor() {
    super('A user cannot match with themselves.');
    this.name = 'MatchSelfMatchError';
  }
}
