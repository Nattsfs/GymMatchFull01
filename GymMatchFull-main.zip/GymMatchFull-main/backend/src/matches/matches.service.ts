import {
  MatchStatus as PrismaMatchStatus,
  UserRole as PrismaUserRole,
  type PrismaClient,
} from '@prisma/client';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { ChatService } from '../chat/chat.service.js';
import type { ChatServiceContract } from '../chat/chat.types.js';
import { HttpError } from '../common/errors/http-error.js';
import { UsersService } from '../users/users.service.js';
import { serializeStudentMatch } from './matches.serializer.js';
import { MatchesRepository } from './matches.repository.js';
import type { CreateMatchInput, MatchesServiceContract, SafeMatch } from './matches.types.js';
import { MatchConflictError, MatchSelfMatchError } from './matches.types.js';

const DUPLICATE_MATCH_MESSAGE = 'Match already exists between these users.';
const SELF_MATCH_MESSAGE = 'Users cannot match with themselves.';
const INVALID_ACCESS_TOKEN_MESSAGE = 'Invalid access token.';
const MATCHES_STUDENT_ONLY_MESSAGE = 'Only STUDENT users can list their own matches.';

type MatchesUsersReader = Pick<AuthUsersServiceContract, 'findUserById'>;
type MatchesChatConversationManager = Pick<ChatServiceContract, 'getOrCreateConversation'>;
type MatchesRepositoryContract = Pick<
  MatchesRepository,
  | 'createMatch'
  | 'findActiveMatchBetweenUsers'
  | 'existsActiveMatchBetweenUsers'
  | 'findActiveMatchesForUser'
>;
type MatchesTransactionRunner = <T>(
  callback: (dependencies: {
    matchesRepository: MatchesRepositoryContract;
    chatService: MatchesChatConversationManager;
  }) => Promise<T>,
) => Promise<T>;

interface MatchesServiceDependencies {
  chatService?: MatchesChatConversationManager;
  matchesRepository?: MatchesRepositoryContract;
  transactionRunner?: MatchesTransactionRunner;
  usersService?: MatchesUsersReader;
  now?: () => Date;
}

export class MatchesService implements MatchesServiceContract {
  private readonly chatService: MatchesChatConversationManager;
  private readonly matchesRepository: MatchesRepositoryContract;
  private readonly transactionRunner: MatchesTransactionRunner;
  private readonly usersService: MatchesUsersReader;
  private readonly now: () => Date;

  constructor(prisma: PrismaClient, dependencies: MatchesServiceDependencies = {}) {
    this.chatService = dependencies.chatService ?? new ChatService(prisma);
    this.matchesRepository = dependencies.matchesRepository ?? new MatchesRepository(prisma);
    this.usersService = dependencies.usersService ?? new UsersService(prisma);
    const hasCustomDataAccess =
      dependencies.chatService !== undefined || dependencies.matchesRepository !== undefined;
    this.transactionRunner =
      dependencies.transactionRunner ??
      (hasCustomDataAccess || typeof prisma.$transaction !== 'function'
        ? async (callback) =>
            callback({
              matchesRepository: this.matchesRepository,
              chatService: this.chatService,
            })
        : async (callback) =>
            prisma.$transaction(async (transaction) =>
              callback({
                matchesRepository: new MatchesRepository(transaction),
                chatService: new ChatService(transaction),
              }),
            ));
    this.now = dependencies.now ?? (() => new Date());
  }

  async createMatch(input: CreateMatchInput): Promise<SafeMatch> {
    if (input.userAId === input.userBId) {
      throw new HttpError(400, SELF_MATCH_MESSAGE);
    }

    return this.transactionRunner(async ({ matchesRepository, chatService }) => {
      const match = await this.createMatchWithRepository(matchesRepository, input);

      await this.ensureConversationForActiveMatch(chatService, match);

      return match;
    });
  }

  findMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<SafeMatch | null> {
    return this.matchesRepository.findActiveMatchBetweenUsers(firstUserId, secondUserId);
  }

  matchExistsBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    return this.matchesRepository.existsActiveMatchBetweenUsers(firstUserId, secondUserId);
  }

  async listCurrentUserMatches(currentUser: CurrentUserContext) {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, MATCHES_STUDENT_ONLY_MESSAGE);
    }

    const authenticatedUser = await this.usersService.findUserById(currentUser.id);

    if (!authenticatedUser) {
      throw new HttpError(401, INVALID_ACCESS_TOKEN_MESSAGE);
    }

    const matches = await this.matchesRepository.findActiveMatchesForUser(
      currentUser.id,
      this.now(),
    );

    return {
      data: matches
        .map((match) => serializeStudentMatch(match, currentUser.id))
        .filter((match): match is NonNullable<typeof match> => match !== null),
    };
  }

  private async createMatchWithRepository(
    matchesRepository: MatchesRepositoryContract,
    input: CreateMatchInput,
  ): Promise<SafeMatch> {
    try {
      return await matchesRepository.createMatch(input);
    } catch (error) {
      if (error instanceof MatchSelfMatchError) {
        throw new HttpError(400, SELF_MATCH_MESSAGE);
      }

      if (error instanceof MatchConflictError && error.field === 'userPair') {
        throw new HttpError(409, DUPLICATE_MATCH_MESSAGE);
      }

      throw error;
    }
  }

  private async ensureConversationForActiveMatch(
    chatService: MatchesChatConversationManager,
    match: SafeMatch,
  ): Promise<void> {
    if (match.deletedAt !== null || match.status !== PrismaMatchStatus.ACTIVE) {
      return;
    }

    await chatService.getOrCreateConversation({
      matchId: match.id,
    });
  }
}
