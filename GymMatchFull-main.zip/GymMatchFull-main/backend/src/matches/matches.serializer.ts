import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';

import { serializePublicStudentProfile } from '../profiles/profiles.serializer.js';
import type { StudentMatchListItemDto } from './dto/list-student-matches-response.dto.js';
import type {
  MatchParticipantProfileRecord,
  MatchParticipantUserRecord,
  MatchWithParticipantsRecord,
} from './matches.types.js';

export function serializeStudentMatch(
  match: MatchWithParticipantsRecord,
  currentUserId: string,
): StudentMatchListItemDto | null {
  const otherUser = getOtherParticipant(match, currentUserId);

  if (!otherUser || !isVisibleMatchedStudent(otherUser) || !otherUser.profile) {
    return null;
  }

  return {
    id: match.id,
    status: match.status,
    createdAt: match.createdAt,
    user: {
      id: otherUser.id,
      name: otherUser.name,
    },
    profile: serializePublicStudentProfile({
      ...otherUser.profile,
      user: otherUser,
    }),
  };
}

function getOtherParticipant(
  match: MatchWithParticipantsRecord,
  currentUserId: string,
): MatchParticipantUserRecord | null {
  if (match.userA.id === currentUserId) {
    return match.userB;
  }

  if (match.userB.id === currentUserId) {
    return match.userA;
  }

  return null;
}

function isVisibleMatchedStudent(
  user: MatchParticipantUserRecord,
): user is MatchParticipantUserRecord & { profile: MatchParticipantProfileRecord } {
  return (
    user.role === PrismaUserRole.STUDENT &&
    user.status === PrismaUserStatus.ACTIVE &&
    user.deletedAt === null &&
    user.profile !== null &&
    user.profile.deletedAt === null
  );
}
