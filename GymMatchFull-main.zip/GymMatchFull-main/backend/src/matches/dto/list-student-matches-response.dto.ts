import type { MatchStatus } from '@prisma/client';

import type { PublicStudentProfileDto } from '../../profiles/dto/public-student-profile.dto.js';

export interface PublicMatchedStudentUserDto {
  id: string;
  name: string;
}

export interface StudentMatchListItemDto {
  id: string;
  status: MatchStatus;
  createdAt: Date;
  user: PublicMatchedStudentUserDto;
  profile: PublicStudentProfileDto;
}

export interface ListStudentMatchesResult {
  data: StudentMatchListItemDto[];
}
