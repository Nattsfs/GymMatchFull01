export { MatchesRepository } from './matches.repository.js';
export { serializeStudentMatch } from './matches.serializer.js';
export { MatchesService } from './matches.service.js';
export type {
  ListStudentMatchesResult,
  StudentMatchListItemDto,
} from './dto/list-student-matches-response.dto.js';
export type {
  CreateMatchInput,
  MatchRecord,
  MatchWithParticipantsRecord,
  MatchesServiceContract,
  SafeMatch,
} from './matches.types.js';
export { MatchConflictError, MatchSelfMatchError } from './matches.types.js';
