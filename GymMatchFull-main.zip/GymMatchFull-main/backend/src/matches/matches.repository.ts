import { Prisma } from '@prisma/client';
import { MatchStatus as PrismaMatchStatus, type MatchStatus } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';

import type {
  CreateMatchInput,
  MatchRecord,
  MatchWithParticipantsRecord,
} from './matches.types.js';
import { MatchConflictError, MatchSelfMatchError } from './matches.types.js';

function getConflictField(
  error: Prisma.PrismaClientKnownRequestError,
): MatchConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('userAId') && target.includes('userBId')) {
    return 'userPair';
  }

  return 'unknown';
}

function isUserPairOrderConstraintError(error: Prisma.PrismaClientKnownRequestError): boolean {
  if (error.code !== 'P2004') {
    return false;
  }

  return String(error.meta?.database_error ?? '').includes('Match_userAId_userBId_order_check');
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

type DatabaseClient = PrismaClient | Prisma.TransactionClient;

const MATCH_LIST_ORDER_BY: Prisma.MatchOrderByWithRelationInput[] = [
  { createdAt: 'desc' },
  { id: 'asc' },
];

const MATCH_PARTICIPANT_PROFILE_SELECT = {
  id: true,
  userId: true,
  birthDate: true,
  gender: true,
  sexualOrientation: true,
  appGoal: true,
  trainingLevel: true,
  availablePeriods: true,
  preferredModalities: true,
  workoutSplit: true,
  profilePhotoUrl: true,
  isComplete: true,
  bio: true,
  showSexualOrientation: true,
  showAvailablePeriods: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true,
} satisfies Prisma.ProfileSelect;

const MATCH_PARTICIPANT_SELECT = {
  id: true,
  name: true,
  role: true,
  status: true,
  deletedAt: true,
  gym: {
    select: {
      id: true,
      name: true,
    },
  },
  gymUnit: {
    select: {
      id: true,
      name: true,
      city: true,
      state: true,
    },
  },
  profile: {
    select: MATCH_PARTICIPANT_PROFILE_SELECT,
  },
} satisfies Prisma.UserSelect;

export class MatchesRepository {
  constructor(private readonly prisma: DatabaseClient) {}

  async createMatch(input: CreateMatchInput): Promise<MatchRecord> {
    if (input.userAId === input.userBId) {
      throw new MatchSelfMatchError();
    }

    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const data: Prisma.MatchCreateInput = {
      userA: {
        connect: {
          id: normalizedPair.userAId,
        },
      },
      userB: {
        connect: {
          id: normalizedPair.userBId,
        },
      },
      ...(input.status !== undefined ? { status: input.status } : {}),
      ...(input.expiresAt !== undefined ? { expiresAt: input.expiresAt } : {}),
      ...(input.deletedAt !== undefined ? { deletedAt: input.deletedAt } : {}),
    };

    try {
      return await this.prisma.match.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new MatchConflictError(getConflictField(error));
      }

      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        isUserPairOrderConstraintError(error)
      ) {
        throw new MatchSelfMatchError();
      }

      throw error;
    }
  }

  findActiveMatchBetweenUsers(
    firstUserId: string,
    secondUserId: string,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return Promise.resolve(null);
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return this.prisma.match.findFirst({
      where: {
        userAId: normalizedPair.userAId,
        userBId: normalizedPair.userBId,
        deletedAt: null,
      },
    });
  }

  async existsActiveMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    if (firstUserId === secondUserId) {
      return false;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);
    const count = await this.prisma.match.count({
      where: {
        userAId: normalizedPair.userAId,
        userBId: normalizedPair.userBId,
        deletedAt: null,
      },
    });

    return count > 0;
  }

  async updateMatchStatusBetweenUsers(
    firstUserId: string,
    secondUserId: string,
    status: MatchStatus,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);
    const existingMatch = await this.prisma.match.findFirst({
      where: {
        userAId: normalizedPair.userAId,
        userBId: normalizedPair.userBId,
        deletedAt: null,
      },
    });

    if (!existingMatch) {
      return null;
    }

    if (existingMatch.status === status) {
      return existingMatch;
    }

    return this.prisma.match.update({
      where: {
        id: existingMatch.id,
      },
      data: {
        status,
      },
    });
  }

  countActiveMatchesForUser(userId: string, now: Date): Promise<number> {
    return this.prisma.match.count({
      where: {
        deletedAt: null,
        status: PrismaMatchStatus.ACTIVE,
        OR: [{ userAId: userId }, { userBId: userId }],
        AND: [
          {
            OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
          },
        ],
      },
    });
  }

  findActiveMatchesForUser(userId: string, now: Date): Promise<MatchWithParticipantsRecord[]> {
    return this.prisma.match.findMany({
      where: {
        deletedAt: null,
        status: PrismaMatchStatus.ACTIVE,
        AND: [
          {
            OR: [{ userAId: userId }, { userBId: userId }],
          },
          {
            OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
          },
        ],
      },
      select: {
        id: true,
        userAId: true,
        userBId: true,
        status: true,
        expiresAt: true,
        createdAt: true,
        updatedAt: true,
        deletedAt: true,
        userA: {
          select: MATCH_PARTICIPANT_SELECT,
        },
        userB: {
          select: MATCH_PARTICIPANT_SELECT,
        },
      },
      orderBy: MATCH_LIST_ORDER_BY,
    });
  }
}
