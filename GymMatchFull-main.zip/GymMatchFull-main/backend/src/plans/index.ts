export {
  PremiumAccessService,
  type PremiumAccessServiceContract,
} from './premium-access.service.js';
