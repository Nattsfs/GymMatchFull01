export interface PremiumAccessServiceContract {
  hasPremiumChatImageAccess(userId: string): Promise<boolean>;
}

export class PremiumAccessService implements PremiumAccessServiceContract {
  async hasPremiumChatImageAccess(_userId: string): Promise<boolean> {
    return false;
  }
}
