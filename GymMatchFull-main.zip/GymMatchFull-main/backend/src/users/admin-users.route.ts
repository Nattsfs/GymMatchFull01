import { UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync } from 'fastify';

import { AuthService } from '../auth/auth.service.js';
import type { AuthServiceContract, AuthUsersServiceContract } from '../auth/auth.types.js';
import { createJwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { createRolesGuard } from '../auth/roles.guard.js';
import { HttpError } from '../common/errors/http-error.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { parseListAdminUsersQuery } from './dto/list-admin-users-query.dto.js';
import { UsersService } from './users.service.js';
import type { AdminUsersServiceContract } from './users.types.js';

interface AdminUsersRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  adminUsersService?: AdminUsersServiceContract;
  authService?: AuthServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  usersService?: AuthUsersServiceContract;
}

export const adminUsersRoutes: FastifyPluginAsync<AdminUsersRoutesOptions> = async (
  app,
  options,
) => {
  const defaultUsersService = new UsersService(app.prisma);
  const authUsersService = options.usersService ?? defaultUsersService;
  const adminUsersService = options.adminUsersService ?? defaultUsersService;
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      authUsersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const authenticate = createJwtAuthGuard(authService);
  const requireAdmin = createRolesGuard([PrismaUserRole.ADMIN]);

  app.get('/admin/users', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const query = parseListAdminUsersQuery(request.query);

    return adminUsersService.listAdminUsers(query);
  });

  app.get('/admin/users/:id', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const userId = parseRouteParam(request.params, 'id');

    return adminUsersService.getAdminUserById(userId);
  });
};

function parseRouteParam(payload: unknown, field: string): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const value = payload[field];

  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return value.trim();
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
