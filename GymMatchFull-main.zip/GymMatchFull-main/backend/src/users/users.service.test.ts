import type { PrismaClient } from '@prisma/client';
import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { describe, expect, it } from 'vitest';

import { UsersRepository } from './users.repository.js';
import { UsersService } from './users.service.js';
import type { CreateUserInput, UserRecord } from './users.types.js';
import { UserConflictError } from './users.types.js';

class InMemoryUsersRepository {
  private readonly users: UserRecord[] = [];
  private nextId = 1;

  async createUser(input: CreateUserInput): Promise<UserRecord> {
    const existingByEmail = this.users.find((user) => user.email === input.email);

    if (existingByEmail) {
      throw new UserConflictError('email');
    }

    const existingByCpf = this.users.find((user) => user.cpf === input.cpf);

    if (existingByCpf) {
      throw new UserConflictError('cpf');
    }

    const existingByPhone = this.users.find((user) => user.phone === input.phone);

    if (existingByPhone) {
      throw new UserConflictError('phone');
    }

    const now = new Date();
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name,
      email: input.email,
      phone: input.phone,
      cpf: input.cpf,
      passwordHash: input.passwordHash,
      gymId: input.gymId ?? null,
      gymUnitId: input.gymUnitId ?? null,
      refreshTokenHash: input.refreshTokenHash ?? null,
      passwordResetTokenHash: null,
      passwordResetTokenExpiresAt: null,
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: input.emailVerifiedAt ?? null,
      phoneVerifiedAt: input.phoneVerifiedAt ?? null,
      termsAcceptedAt: input.termsAcceptedAt ?? null,
      lastLoginAt: input.lastLoginAt ?? null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<UserRecord | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }

  async findUserByEmail(email: string): Promise<UserRecord | null> {
    return this.users.find((user) => user.email === email) ?? null;
  }

  async findUserByCpf(cpf: string): Promise<UserRecord | null> {
    return this.users.find((user) => user.cpf === cpf) ?? null;
  }

  async findUserByPhone(phone: string): Promise<UserRecord | null> {
    return this.users.find((user) => user.phone === phone) ?? null;
  }
}

function makeCreateUserInput(overrides: Partial<CreateUserInput> = {}): CreateUserInput {
  return {
    name: 'Pedro Gimenez',
    email: 'pedro@example.com',
    phone: '+5511999999999',
    cpf: '12345678901',
    passwordHash: 'hashed-password',
    gymId: 'gym_1',
    gymUnitId: 'unit_1',
    ...overrides,
  };
}

function createUsersService(): UsersService {
  const repository = new InMemoryUsersRepository();

  return new UsersService({} as PrismaClient, repository as unknown as UsersRepository);
}

describe('UsersService', () => {
  it('creates a valid student user', async () => {
    const service = createUsersService();

    const user = await service.createUser(makeCreateUserInput({ role: PrismaUserRole.STUDENT }));

    expect(user.role).toBe(PrismaUserRole.STUDENT);
    expect(user.status).toBe(PrismaUserStatus.ACTIVE);
    expect(user.gymId).toBe('gym_1');
    expect(user.gymUnitId).toBe('unit_1');
    expect(user).not.toHaveProperty('passwordHash');
    expect(user).not.toHaveProperty('refreshTokenHash');
    expect(user).not.toHaveProperty('passwordResetTokenHash');
    expect(user).not.toHaveProperty('passwordResetTokenExpiresAt');
  });

  it('creates a valid admin user without requiring gym fields', async () => {
    const service = createUsersService();

    const user = await service.createUser({
      name: 'Admin User',
      email: 'admin@example.com',
      phone: '+5511888888888',
      cpf: '98765432100',
      passwordHash: 'hashed-password',
      role: PrismaUserRole.ADMIN,
    });

    expect(user.role).toBe(PrismaUserRole.ADMIN);
    expect(user.status).toBe(PrismaUserStatus.ACTIVE);
    expect(user.gymId).toBeNull();
    expect(user.gymUnitId).toBeNull();
  });

  it('uses ACTIVE as the default status', async () => {
    const service = createUsersService();

    const user = await service.createUser(makeCreateUserInput());

    expect(user.status).toBe(PrismaUserStatus.ACTIVE);
  });

  it('prevents duplicate email', async () => {
    const service = createUsersService();

    await service.createUser(makeCreateUserInput());

    await expect(
      service.createUser(
        makeCreateUserInput({
          cpf: '00011122233',
          phone: '+5511777777777',
        }),
      ),
    ).rejects.toMatchObject({
      name: 'UserConflictError',
      field: 'email',
    });
  });

  it('prevents duplicate cpf', async () => {
    const service = createUsersService();

    await service.createUser(makeCreateUserInput());

    await expect(
      service.createUser(
        makeCreateUserInput({
          email: 'other@example.com',
          phone: '+5511777777777',
        }),
      ),
    ).rejects.toMatchObject({
      name: 'UserConflictError',
      field: 'cpf',
    });
  });

  it('prevents duplicate phone', async () => {
    const service = createUsersService();

    await service.createUser(makeCreateUserInput());

    await expect(
      service.createUser(
        makeCreateUserInput({
          email: 'other@example.com',
          cpf: '00011122233',
        }),
      ),
    ).rejects.toMatchObject({
      name: 'UserConflictError',
      field: 'phone',
    });
  });

  it('finds a user by id and by email', async () => {
    const service = createUsersService();

    const createdUser = await service.createUser(makeCreateUserInput());
    const userById = await service.findUserById(createdUser.id);
    const userByEmail = await service.findUserByEmail(createdUser.email);

    expect(userById).toEqual(createdUser);
    expect(userByEmail).toEqual(createdUser);
  });

  it('finds a user by cpf and by phone', async () => {
    const service = createUsersService();

    const createdUser = await service.createUser(makeCreateUserInput());
    const userByCpf = await service.findUserByCpf(createdUser.cpf);
    const userByPhone = await service.findUserByPhone(createdUser.phone);

    expect(userByCpf).toEqual(createdUser);
    expect(userByPhone).toEqual(createdUser);
  });
});
