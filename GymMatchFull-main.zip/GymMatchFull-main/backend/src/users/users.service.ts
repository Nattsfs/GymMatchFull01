import type { PrismaClient, UserStatus } from '@prisma/client';

import { UsersRepository } from './users.repository.js';
import { serializeAdminUserDetail, serializeAdminUserListItem, serializeUser } from './users.serializer.js';
import { HttpError } from '../common/errors/http-error.js';
import type {
  CreateUserInput,
  ListAdminUsersQueryInput,
  ListAdminUsersResult,
  SafeAdminUserDetail,
  SafeUser,
  UserRecord,
} from './users.types.js';

export class UsersService {
  private readonly usersRepository: UsersRepository;

  constructor(prisma: PrismaClient, usersRepository?: UsersRepository) {
    this.usersRepository = usersRepository ?? new UsersRepository(prisma);
  }

  async createUser(input: CreateUserInput): Promise<SafeUser> {
    const user = await this.usersRepository.createUser(input);

    return serializeUser(user);
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    const user = await this.usersRepository.findUserById(id);

    return user ? serializeUser(user) : null;
  }

  findUserByIdWithRefreshToken(id: string): Promise<UserRecord | null> {
    return this.usersRepository.findUserById(id);
  }

  async findUserByEmail(email: string): Promise<SafeUser | null> {
    const user = await this.usersRepository.findUserByEmail(email);

    return user ? serializeUser(user) : null;
  }

  findUserByEmailWithPassword(email: string): Promise<UserRecord | null> {
    return this.usersRepository.findUserByEmail(email);
  }

  findUserByPasswordResetTokenHash(passwordResetTokenHash: string): Promise<UserRecord | null> {
    return this.usersRepository.findUserByPasswordResetTokenHash(passwordResetTokenHash);
  }

  async findUserByCpf(cpf: string): Promise<SafeUser | null> {
    const user = await this.usersRepository.findUserByCpf(cpf);

    return user ? serializeUser(user) : null;
  }

  async findUserByPhone(phone: string): Promise<SafeUser | null> {
    const user = await this.usersRepository.findUserByPhone(phone);

    return user ? serializeUser(user) : null;
  }

  async updateLastLoginAt(id: string, lastLoginAt: Date): Promise<void> {
    await this.usersRepository.updateLastLoginAt(id, lastLoginAt);
  }

  async updateRefreshTokenHash(id: string, refreshTokenHash: string | null): Promise<void> {
    await this.usersRepository.updateRefreshTokenHash(id, refreshTokenHash);
  }

  async updatePasswordResetToken(
    id: string,
    passwordResetTokenHash: string | null,
    passwordResetTokenExpiresAt: Date | null,
  ): Promise<void> {
    await this.usersRepository.updatePasswordResetToken(
      id,
      passwordResetTokenHash,
      passwordResetTokenExpiresAt,
    );
  }

  async updatePasswordAfterReset(id: string, passwordHash: string): Promise<void> {
    await this.usersRepository.updatePasswordAfterReset(id, passwordHash);
  }

  async updateUserStatus(id: string, status: UserStatus): Promise<SafeUser> {
    const user = await this.usersRepository.updateStatus(id, status);

    return serializeUser(user);
  }

  async listAdminUsers(input: ListAdminUsersQueryInput): Promise<ListAdminUsersResult> {
    const { data, total } = await this.usersRepository.listAdminUsers(input);

    return {
      data: data.map(serializeAdminUserListItem),
      pagination: {
        page: input.page,
        limit: input.limit,
        total,
        totalPages: Math.max(1, Math.ceil(total / input.limit)),
      },
    };
  }

  async getAdminUserById(id: string): Promise<SafeAdminUserDetail> {
    const user = await this.usersRepository.findAdminUserById(id);

    if (!user) {
      throw new HttpError(404, 'User not found.');
    }

    return serializeAdminUserDetail(user);
  }
}
