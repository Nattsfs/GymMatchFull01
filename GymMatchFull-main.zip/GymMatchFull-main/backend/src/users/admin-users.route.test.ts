import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { HttpError } from '../common/errors/http-error.js';
import { buildConfig } from '../config/env.js';
import type { SafeUser } from './users.types.js';
import type {
  AdminUsersServiceContract,
  ListAdminUsersQueryInput,
  ListAdminUsersResult,
  SafeAdminUserDetail,
} from './users.types.js';

const FIXED_NOW = new Date('2026-05-10T22:15:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

class InMemoryUsersService {
  private readonly users = new Map<string, SafeUser>();

  seedUser(input: {
    id: string;
    role: PrismaUserRole;
    status?: PrismaUserStatus;
  }): SafeUser {
    const user: SafeUser = {
      id: input.id,
      name: `User ${input.id}`,
      email: `${input.id}@example.com`,
      phone: `11999999${input.id.slice(-2).padStart(2, '0')}`,
      cpf: `123456789${input.id.slice(-2).padStart(2, '0')}`,
      role: input.role,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      gymId: null,
      gymUnitId: null,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: null,
    };

    this.users.set(user.id, user);

    return user;
  }

  async createUser(): Promise<SafeUser> {
    throw new Error('Not implemented in this test.');
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.get(id) ?? null;
  }

  async findUserByEmail(): Promise<SafeUser | null> {
    return null;
  }

  async findUserByIdWithRefreshToken() {
    return null;
  }

  async findUserByEmailWithPassword() {
    return null;
  }

  async findUserByPasswordResetTokenHash() {
    return null;
  }

  async updateLastLoginAt(): Promise<void> {}

  async updateRefreshTokenHash(): Promise<void> {}

  async updatePasswordResetToken(): Promise<void> {}

  async updatePasswordAfterReset(): Promise<void> {}
}

class StubAdminUsersService implements AdminUsersServiceContract {
  lastRequestedId: string | null = null;
  lastQuery: ListAdminUsersQueryInput | null = null;

  constructor(
    private readonly listResponse: ListAdminUsersResult,
    private readonly details: SafeAdminUserDetail[],
  ) {}

  async listAdminUsers(input: ListAdminUsersQueryInput): Promise<ListAdminUsersResult> {
    this.lastQuery = input;

    return this.listResponse;
  }

  async getAdminUserById(id: string): Promise<SafeAdminUserDetail> {
    this.lastRequestedId = id;

    const user = this.details.find((item) => item.id === id);

    if (!user) {
      throw new HttpError(404, 'User not found.');
    }

    return user;
  }
}

function createAdminUserDetail(id: string): SafeAdminUserDetail {
  return {
    id,
    name: 'Ana Admin',
    email: 'ana.admin@gymmatch.com',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    createdAt: FIXED_NOW,
    lastLoginAt: FIXED_NOW,
    deletedAt: null,
    gym: {
      id: 'gym_1',
      name: 'GymMatch Centro',
      status: 'ACTIVE',
    },
    gymUnit: {
      id: 'unit_1',
      name: 'Unidade Centro',
      status: 'ACTIVE',
    },
  };
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const adminUser = createAdminUserDetail('user_1');
  const adminUsersService = new StubAdminUsersService(
    {
      data: [
        {
          id: adminUser.id,
          name: adminUser.name,
          email: adminUser.email,
          role: adminUser.role,
          status: adminUser.status,
          createdAt: adminUser.createdAt,
          gym: adminUser.gym,
          gymUnit: adminUser.gymUnit,
        },
      ],
      pagination: {
        page: 2,
        limit: 20,
        total: 21,
        totalPages: 2,
      },
    },
    [adminUser],
  );
  const app = buildApp({
    config,
    services: {
      adminUsersService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    adminUsersService,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('admin users routes', () => {
  it('returns a paginated users list for an authenticated admin', async () => {
    const { app, adminUsersService, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/users?page=2&limit=20&search=ana&gymId=gym_1&gymUnitId=unit_1&status=ACTIVE',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(adminUsersService.lastQuery).toEqual({
      page: 2,
      limit: 20,
      search: 'ana',
      gymId: 'gym_1',
      gymUnitId: 'unit_1',
      status: PrismaUserStatus.ACTIVE,
    });
    expect(response.json()).toEqual({
      data: [
        {
          id: 'user_1',
          name: 'Ana Admin',
          email: 'ana.admin@gymmatch.com',
          role: 'STUDENT',
          status: 'ACTIVE',
          createdAt: FIXED_NOW.toISOString(),
          gym: {
            id: 'gym_1',
            name: 'GymMatch Centro',
            status: 'ACTIVE',
          },
          gymUnit: {
            id: 'unit_1',
            name: 'Unidade Centro',
            status: 'ACTIVE',
          },
        },
      ],
      pagination: {
        page: 2,
        limit: 20,
        total: 21,
        totalPages: 2,
      },
    });
    expect(response.json().data[0]).not.toHaveProperty('passwordHash');
    expect(response.json().data[0]).not.toHaveProperty('refreshTokenHash');
  });

  it('blocks students and anonymous users from listing users', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser({
      id: 'student_1',
      role: PrismaUserRole.STUDENT,
    });

    await app.ready();

    const anonymousResponse = await app.inject({
      method: 'GET',
      url: '/admin/users',
    });

    expect(anonymousResponse.statusCode).toBe(401);
    expect(anonymousResponse.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });

    const forbiddenResponse = await app.inject({
      method: 'GET',
      url: '/admin/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(forbiddenResponse.statusCode).toBe(403);
    expect(forbiddenResponse.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('returns the basic user detail for an authenticated admin', async () => {
    const { app, adminUsersService, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_2',
      role: PrismaUserRole.ADMIN,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/users/user_1',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(adminUsersService.lastRequestedId).toBe('user_1');
    expect(response.json()).toEqual({
      id: 'user_1',
      name: 'Ana Admin',
      email: 'ana.admin@gymmatch.com',
      role: 'STUDENT',
      status: 'ACTIVE',
      createdAt: FIXED_NOW.toISOString(),
      lastLoginAt: FIXED_NOW.toISOString(),
      deletedAt: null,
      gym: {
        id: 'gym_1',
        name: 'GymMatch Centro',
        status: 'ACTIVE',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Centro',
        status: 'ACTIVE',
      },
    });
  });

  it('returns not found when the requested user does not exist', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_3',
      role: PrismaUserRole.ADMIN,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/users/missing-user',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'User not found.',
    });
  });
});
