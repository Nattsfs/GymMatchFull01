import type {
  GymStatus,
  GymUnitStatus,
  User,
  UserRole,
  UserStatus,
} from '@prisma/client';

export interface CreateUserInput {
  name: string;
  email: string;
  phone: string;
  cpf: string;
  passwordHash: string;
  gymId?: string;
  gymUnitId?: string;
  refreshTokenHash?: string | null;
  role?: UserRole;
  status?: UserStatus;
  emailVerifiedAt?: Date;
  phoneVerifiedAt?: Date;
  termsAcceptedAt?: Date;
  lastLoginAt?: Date;
  deletedAt?: Date;
}

export type UserRecord = User;

export type SafeUser = Omit<
  UserRecord,
  'passwordHash' | 'refreshTokenHash' | 'passwordResetTokenHash' | 'passwordResetTokenExpiresAt'
>;

export interface AdminUserGymSummary {
  id: string;
  name: string;
  status: GymStatus;
}

export interface AdminUserGymUnitSummary {
  id: string;
  name: string;
  status: GymUnitStatus;
}

export interface ListAdminUsersQueryInput {
  page: number;
  limit: number;
  search?: string;
  gymId?: string;
  gymUnitId?: string;
  status?: UserStatus;
}

export interface PaginationResult {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface SafeAdminUserListItem {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  createdAt: Date;
  gym: AdminUserGymSummary | null;
  gymUnit: AdminUserGymUnitSummary | null;
}

export interface SafeAdminUserDetail extends SafeAdminUserListItem {
  lastLoginAt: Date | null;
  deletedAt: Date | null;
}

export interface ListAdminUsersResult {
  data: SafeAdminUserListItem[];
  pagination: PaginationResult;
}

export type AdminUserListRecord = SafeAdminUserListItem;

export type AdminUserDetailRecord = SafeAdminUserDetail;

export interface AdminUsersServiceContract {
  listAdminUsers(input: ListAdminUsersQueryInput): Promise<ListAdminUsersResult>;
  getAdminUserById(id: string): Promise<SafeAdminUserDetail>;
}

export class UserConflictError extends Error {
  readonly field: 'email' | 'cpf' | 'phone' | 'unknown';

  constructor(field: 'email' | 'cpf' | 'phone' | 'unknown') {
    const fieldLabel = field === 'unknown' ? 'unique user field' : field;

    super(`A user with the same ${fieldLabel} already exists.`);
    this.name = 'UserConflictError';
    this.field = field;
  }
}
