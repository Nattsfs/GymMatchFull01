import type {
  AdminUserDetailRecord,
  AdminUserListRecord,
  SafeAdminUserDetail,
  SafeAdminUserListItem,
  SafeUser,
  UserRecord,
} from './users.types.js';

export function serializeUser(user: UserRecord): SafeUser {
  const {
    passwordHash: _passwordHash,
    refreshTokenHash: _refreshTokenHash,
    passwordResetTokenHash: _passwordResetTokenHash,
    passwordResetTokenExpiresAt: _passwordResetTokenExpiresAt,
    ...safeUser
  } = user;

  return safeUser;
}

export function serializeAdminUserListItem(user: AdminUserListRecord): SafeAdminUserListItem {
  return {
    ...user,
    gym: user.gym ? { ...user.gym } : null,
    gymUnit: user.gymUnit ? { ...user.gymUnit } : null,
  };
}

export function serializeAdminUserDetail(user: AdminUserDetailRecord): SafeAdminUserDetail {
  return {
    ...serializeAdminUserListItem(user),
    lastLoginAt: user.lastLoginAt,
    deletedAt: user.deletedAt,
  };
}
