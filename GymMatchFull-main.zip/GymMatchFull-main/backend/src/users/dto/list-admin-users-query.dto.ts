import { UserStatus as PrismaUserStatus } from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import type { ListAdminUsersQueryInput } from '../users.types.js';

interface ListAdminUsersQuery {
  page?: unknown;
  limit?: unknown;
  search?: unknown;
  gymId?: unknown;
  gymUnitId?: unknown;
  status?: unknown;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 50;

export function parseListAdminUsersQuery(payload: unknown): ListAdminUsersQueryInput {
  if (!isObject(payload)) {
    return {
      page: DEFAULT_PAGE,
      limit: DEFAULT_LIMIT,
    };
  }

  const query = payload as ListAdminUsersQuery;
  const page = parsePositiveInteger(query.page, 'page', DEFAULT_PAGE);
  const limit = parsePositiveInteger(query.limit, 'limit', DEFAULT_LIMIT, MAX_LIMIT);
  const search = parseOptionalString(query.search, 'search');
  const gymId = parseOptionalString(query.gymId, 'gymId');
  const gymUnitId = parseOptionalString(query.gymUnitId, 'gymUnitId');
  const status = parseOptionalStatus(query.status);

  return {
    page,
    limit,
    ...(search !== undefined ? { search } : {}),
    ...(gymId !== undefined ? { gymId } : {}),
    ...(gymUnitId !== undefined ? { gymUnitId } : {}),
    ...(status !== undefined ? { status } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parsePositiveInteger(
  value: unknown,
  field: string,
  fallback: number,
  max?: number,
): number {
  if (value === undefined) {
    return fallback;
  }

  const stringValue = typeof value === 'number' ? String(value) : value;

  if (typeof stringValue !== 'string') {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const normalizedValue = stringValue.trim();

  if (!/^[1-9]\d*$/.test(normalizedValue)) {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    throw new HttpError(400, `${field} must be less than or equal to ${max}.`);
  }

  return parsedValue;
}

function parseOptionalString(value: unknown, field: string): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string when provided.`);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : undefined;
}

function parseOptionalStatus(value: unknown): PrismaUserStatus | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'status must be a string when provided.');
  }

  const normalizedStatus = value.trim().toUpperCase();

  if (
    normalizedStatus === PrismaUserStatus.ACTIVE ||
    normalizedStatus === PrismaUserStatus.PENDING ||
    normalizedStatus === PrismaUserStatus.SUSPENDED ||
    normalizedStatus === PrismaUserStatus.BANNED ||
    normalizedStatus === PrismaUserStatus.DELETED
  ) {
    return normalizedStatus;
  }

  throw new HttpError(400, 'status must be one of: ACTIVE, PENDING, SUSPENDED, BANNED, DELETED.');
}
