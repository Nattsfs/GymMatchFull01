import { Prisma, UserStatus as PrismaUserStatus } from '@prisma/client';
import type { PrismaClient, UserStatus } from '@prisma/client';

import type {
  AdminUserDetailRecord,
  AdminUserListRecord,
  CreateUserInput,
  ListAdminUsersQueryInput,
  UserRecord,
} from './users.types.js';
import { UserConflictError } from './users.types.js';

function getConflictField(error: Prisma.PrismaClientKnownRequestError): UserConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta?.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('email')) {
    return 'email';
  }

  if (target.includes('cpf')) {
    return 'cpf';
  }

  if (target.includes('phone')) {
    return 'phone';
  }

  return 'unknown';
}

export class UsersRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async createUser(input: CreateUserInput): Promise<UserRecord> {
    const data: Prisma.UserCreateInput = {
      name: input.name,
      email: input.email,
      phone: input.phone,
      cpf: input.cpf,
      passwordHash: input.passwordHash,
    };

    if (input.gymId !== undefined) {
      data.gym = {
        connect: {
          id: input.gymId,
        },
      };
    }

    if (input.gymUnitId !== undefined) {
      data.gymUnit = {
        connect: {
          id: input.gymUnitId,
        },
      };
    }

    if (input.refreshTokenHash !== undefined) {
      data.refreshTokenHash = input.refreshTokenHash;
    }

    if (input.role !== undefined) {
      data.role = input.role;
    }

    if (input.status !== undefined) {
      data.status = input.status;
    }

    if (input.emailVerifiedAt !== undefined) {
      data.emailVerifiedAt = input.emailVerifiedAt;
    }

    if (input.phoneVerifiedAt !== undefined) {
      data.phoneVerifiedAt = input.phoneVerifiedAt;
    }

    if (input.termsAcceptedAt !== undefined) {
      data.termsAcceptedAt = input.termsAcceptedAt;
    }

    if (input.lastLoginAt !== undefined) {
      data.lastLoginAt = input.lastLoginAt;
    }

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.user.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new UserConflictError(getConflictField(error));
      }

      throw error;
    }
  }

  findUserById(id: string): Promise<UserRecord | null> {
    return this.prisma.user.findUnique({
      where: { id },
    });
  }

  findUserByEmail(email: string): Promise<UserRecord | null> {
    return this.prisma.user.findUnique({
      where: { email },
    });
  }

  findUserByPasswordResetTokenHash(passwordResetTokenHash: string): Promise<UserRecord | null> {
    return this.prisma.user.findFirst({
      where: {
        passwordResetTokenHash,
      },
    });
  }

  findUserByCpf(cpf: string): Promise<UserRecord | null> {
    return this.prisma.user.findUnique({
      where: { cpf },
    });
  }

  findUserByPhone(phone: string): Promise<UserRecord | null> {
    return this.prisma.user.findUnique({
      where: { phone },
    });
  }

  async updateLastLoginAt(id: string, lastLoginAt: Date): Promise<void> {
    await this.prisma.user.update({
      where: { id },
      data: {
        lastLoginAt,
      },
    });
  }

  async updateRefreshTokenHash(id: string, refreshTokenHash: string | null): Promise<void> {
    await this.prisma.user.update({
      where: { id },
      data: {
        refreshTokenHash,
      },
    });
  }

  async updatePasswordResetToken(
    id: string,
    passwordResetTokenHash: string | null,
    passwordResetTokenExpiresAt: Date | null,
  ): Promise<void> {
    await this.prisma.user.update({
      where: { id },
      data: {
        passwordResetTokenHash,
        passwordResetTokenExpiresAt,
      },
    });
  }

  async updatePasswordAfterReset(id: string, passwordHash: string): Promise<void> {
    await this.prisma.user.update({
      where: { id },
      data: {
        passwordHash,
        refreshTokenHash: null,
        passwordResetTokenHash: null,
        passwordResetTokenExpiresAt: null,
      },
    });
  }

  updateStatus(id: string, status: UserStatus): Promise<UserRecord> {
    return this.prisma.user.update({
      where: { id },
      data: {
        status,
      },
    });
  }

  findAdminUserById(id: string): Promise<AdminUserDetailRecord | null> {
    return this.prisma.user.findUnique({
      where: { id },
      select: adminUserDetailSelect,
    });
  }

  async listAdminUsers(
    input: ListAdminUsersQueryInput,
  ): Promise<{ data: AdminUserListRecord[]; total: number }> {
    const where = buildListAdminUsersWhere(input);

    const [data, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({
        where,
        orderBy: {
          createdAt: 'desc',
        },
        skip: (input.page - 1) * input.limit,
        take: input.limit,
        select: adminUserListSelect,
      }),
      this.prisma.user.count({
        where,
      }),
    ]);

    return {
      data,
      total,
    };
  }
}

const adminUserGymSelect = {
  id: true,
  name: true,
  status: true,
} satisfies Prisma.GymSelect;

const adminUserGymUnitSelect = {
  id: true,
  name: true,
  status: true,
} satisfies Prisma.GymUnitSelect;

const adminUserListSelect = {
  id: true,
  name: true,
  email: true,
  role: true,
  status: true,
  createdAt: true,
  gym: {
    select: adminUserGymSelect,
  },
  gymUnit: {
    select: adminUserGymUnitSelect,
  },
} satisfies Prisma.UserSelect;

const adminUserDetailSelect = {
  ...adminUserListSelect,
  lastLoginAt: true,
  deletedAt: true,
} satisfies Prisma.UserSelect;

function buildListAdminUsersWhere(input: ListAdminUsersQueryInput): Prisma.UserWhereInput {
  const where: Prisma.UserWhereInput = {
    ...(input.gymId ? { gymId: input.gymId } : {}),
    ...(input.gymUnitId ? { gymUnitId: input.gymUnitId } : {}),
    ...(input.search
      ? {
          OR: [
            {
              name: {
                contains: input.search,
                mode: 'insensitive',
              },
            },
            {
              email: {
                contains: input.search,
                mode: 'insensitive',
              },
            },
          ],
        }
      : {}),
  };

  if (input.status === PrismaUserStatus.DELETED) {
    where.status = PrismaUserStatus.DELETED;
    where.deletedAt = {
      not: null,
    };

    return where;
  }

  where.deletedAt = null;

  if (input.status) {
    where.status = input.status;
  } else {
    where.status = {
      not: PrismaUserStatus.DELETED,
    };
  }

  return where;
}
