import { MessageType as PrismaMessageType, UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync } from 'fastify';

import { AuthService } from '../auth/auth.service.js';
import type { AuthServiceContract, AuthUsersServiceContract } from '../auth/auth.types.js';
import { getCurrentUserContext } from '../auth/current-user.js';
import { createJwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { createRolesGuard } from '../auth/roles.guard.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import { parseAudioMessageUploadInput, parseImageMessageUploadInput } from './chat.multipart.js';
import { parseDeleteMessageInput } from './dto/delete-message-params.dto.js';
import { parseListConversationMessagesInput } from './dto/list-messages-query.dto.js';
import { parseSendTextMessageInput } from './dto/send-text-message.dto.js';
import { ChatService } from './chat.service.js';
import type { ChatMessageEventPublisherContract, ChatServiceContract } from './chat.types.js';

interface ChatRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  chatService?: ChatServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  messageEventPublisher?: ChatMessageEventPublisherContract;
  usersService?: AuthUsersServiceContract;
}

export const chatRoutes: FastifyPluginAsync<ChatRoutesOptions> = async (app, options) => {
  const usersService = options.usersService ?? new UsersService(app.prisma);
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const chatService =
    options.chatService ??
    new ChatService(app.prisma, {
      ...(options.messageEventPublisher
        ? { messageEventPublisher: options.messageEventPublisher }
        : {}),
    });
  const authenticate = createJwtAuthGuard(authService);
  const requireStudent = createRolesGuard([PrismaUserRole.STUDENT]);

  app.get(
    '/chat/conversations/:conversationId/messages',
    { preHandler: [authenticate, requireStudent] },
    async (request) => {
      const input = parseListConversationMessagesInput(request.params, request.query);
      const currentUser = getCurrentUserContext(request);

      return chatService.listConversationMessages({
        conversationId: input.conversationId,
        currentUserId: currentUser.id,
        page: input.page,
        limit: input.limit,
      });
    },
  );

  app.post(
    '/chat/conversations/:conversationId/messages',
    { preHandler: [authenticate, requireStudent] },
    async (request, reply) => {
      const input = parseSendTextMessageInput(request.params, request.body);
      const currentUser = getCurrentUserContext(request);
      const message = await chatService.createMessage({
        conversationId: input.conversationId,
        senderId: currentUser.id,
        type: PrismaMessageType.TEXT,
        content: input.content,
      });

      return reply.status(201).send(message);
    },
  );

  app.post(
    '/chat/conversations/:conversationId/audio',
    { preHandler: [authenticate, requireStudent] },
    async (request, reply) => {
      const input = await parseAudioMessageUploadInput(request, app);
      const currentUser = getCurrentUserContext(request);
      const message = await chatService.uploadAudioMessage({
        conversationId: input.conversationId,
        senderId: currentUser.id,
        audio: input.audio,
      });

      return reply.status(201).send(message);
    },
  );

  app.post(
    '/chat/conversations/:conversationId/image',
    { preHandler: [authenticate, requireStudent] },
    async (request, reply) => {
      const input = await parseImageMessageUploadInput(request, app);
      const currentUser = getCurrentUserContext(request);
      const message = await chatService.uploadImageMessage({
        conversationId: input.conversationId,
        senderId: currentUser.id,
        image: input.image,
      });

      return reply.status(201).send(message);
    },
  );

  app.delete(
    '/chat/messages/:messageId',
    { preHandler: [authenticate, requireStudent] },
    async (request, reply) => {
      const input = parseDeleteMessageInput(request.params);
      const currentUser = getCurrentUserContext(request);

      await chatService.deleteMessage({
        messageId: input.messageId,
        currentUserId: currentUser.id,
      });

      return reply.status(204).send();
    },
  );
};
