import type { WebSocket } from '@fastify/websocket';
import { UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync, FastifyRequest, preValidationAsyncHookHandler } from 'fastify';

import { AuthService } from '../auth/auth.service.js';
import { getCurrentUserContext } from '../auth/current-user.js';
import type {
  AccessTokenPayload,
  AuthServiceContract,
  AuthUsersServiceContract,
} from '../auth/auth.types.js';
import { createRolesGuard } from '../auth/roles.guard.js';
import { HttpError } from '../common/errors/http-error.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import type {
  ChatMessageCreatedEvent,
  ChatMessageEventPublisherContract,
  PublishMessageCreatedInput,
} from './chat.types.js';

const ACCESS_TOKEN_ERROR_MESSAGE = 'Invalid or missing access token.';

type ChatGatewayAuthService = Pick<AuthServiceContract, 'getCurrentUser'>;

export const CHAT_MESSAGE_CREATED_EVENT = 'message.created';

export interface ChatRealtimeGatewayContract extends ChatMessageEventPublisherContract {
  registerConnection(input: { userId: string; socket: WebSocket }): void;
}

interface ChatGatewayRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  chatRealtimeGateway: ChatRealtimeGatewayContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  usersService?: AuthUsersServiceContract;
}

export class ChatRealtimeGateway implements ChatRealtimeGatewayContract {
  private readonly socketsByUserId = new Map<string, Set<WebSocket>>();

  registerConnection(input: { userId: string; socket: WebSocket }): void {
    const sockets = this.socketsByUserId.get(input.userId) ?? new Set<WebSocket>();

    sockets.add(input.socket);
    this.socketsByUserId.set(input.userId, sockets);

    const cleanup = () => {
      this.removeConnection(input.userId, input.socket);
    };

    input.socket.once('close', cleanup);
    input.socket.once('error', cleanup);
  }

  async publishMessageCreated(input: PublishMessageCreatedInput): Promise<void> {
    const event = createMessageCreatedEvent(input);
    const serializedEvent = JSON.stringify(event);

    for (const participantId of new Set(input.participantIds)) {
      const sockets = this.socketsByUserId.get(participantId);

      if (!sockets) {
        continue;
      }

      for (const socket of [...sockets]) {
        try {
          socket.send(serializedEvent);
        } catch {
          this.removeConnection(participantId, socket);
        }
      }
    }
  }

  private removeConnection(userId: string, socket: WebSocket): void {
    const sockets = this.socketsByUserId.get(userId);

    if (!sockets) {
      return;
    }

    sockets.delete(socket);

    if (sockets.size === 0) {
      this.socketsByUserId.delete(userId);
    }
  }
}

export const chatGatewayRoutes: FastifyPluginAsync<ChatGatewayRoutesOptions> = async (
  app,
  options,
) => {
  const usersService = options.usersService ?? new UsersService(app.prisma);
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const authenticate = createChatWebSocketAuthGuard(app, authService);
  const requireStudent = createRolesGuard([PrismaUserRole.STUDENT]);

  app.get(
    '/chat/ws',
    {
      websocket: true,
      preValidation: [authenticate, requireStudent],
    },
    (socket, request) => {
      const currentUser = getCurrentUserContext(request);

      options.chatRealtimeGateway.registerConnection({
        userId: currentUser.id,
        socket,
      });
    },
  );
};

function createChatWebSocketAuthGuard(
  app: { jwt: { verify<T>(token: string): Promise<T> } },
  authService: ChatGatewayAuthService,
): preValidationAsyncHookHandler {
  return async function chatWebSocketAuthGuard(request): Promise<void> {
    const accessToken = resolveAccessToken(request);

    let tokenPayload: AccessTokenPayload;

    try {
      tokenPayload = await app.jwt.verify<AccessTokenPayload>(accessToken);
    } catch {
      throw new HttpError(401, ACCESS_TOKEN_ERROR_MESSAGE);
    }

    request.authTokenPayload = tokenPayload;
    request.currentUser = await authService.getCurrentUser(tokenPayload.sub);
  };
}

function resolveAccessToken(request: FastifyRequest): string {
  const authorizationHeader = request.headers.authorization;
  const authorizationToken = extractBearerToken(authorizationHeader);

  if (authorizationToken) {
    return authorizationToken;
  }

  const queryToken = extractQueryToken(request.query);

  if (queryToken) {
    return queryToken;
  }

  throw new HttpError(401, ACCESS_TOKEN_ERROR_MESSAGE);
}

function extractBearerToken(authorizationHeader: string | string[] | undefined): string | null {
  if (typeof authorizationHeader !== 'string') {
    return null;
  }

  const [scheme, token] = authorizationHeader.split(' ');

  if (scheme !== 'Bearer' || !token || token.trim().length === 0) {
    return null;
  }

  return token.trim();
}

function extractQueryToken(query: FastifyRequest['query']): string | null {
  if (!query || typeof query !== 'object') {
    return null;
  }

  const token = 'token' in query ? query.token : undefined;

  return typeof token === 'string' && token.trim().length > 0 ? token.trim() : null;
}

function createMessageCreatedEvent(
  input: PublishMessageCreatedInput,
): ChatMessageCreatedEvent {
  return {
    event: CHAT_MESSAGE_CREATED_EVENT,
    data: {
      id: input.message.id,
      conversationId: input.message.conversationId,
      senderId: input.message.senderId,
      type: input.message.type,
      content: input.message.content,
      mediaReference: input.message.mediaReference,
      createdAt: input.message.createdAt.toISOString(),
    },
  };
}
