import { MessageStatus as PrismaMessageStatus, Prisma, type MessageStatus } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';

import type {
  ConversationMessageRecord,
  ConversationMatchRecord,
  ConversationRecord,
  ConversationWithMatchRecord,
  CreateConversationInput,
  CreateMessageInput,
  MessageRecord,
} from './chat.types.js';
import { ConversationConflictError, ConversationMatchNotFoundError } from './chat.types.js';

type DatabaseClient = PrismaClient | Prisma.TransactionClient;

const CONVERSATION_WITH_MATCH_SELECT = {
  id: true,
  matchId: true,
  createdAt: true,
  updatedAt: true,
  match: {
    select: {
      id: true,
      userAId: true,
      userBId: true,
      status: true,
      expiresAt: true,
      deletedAt: true,
    },
  },
} satisfies Prisma.ConversationSelect;

const MESSAGE_WITH_SENDER_SELECT = {
  id: true,
  conversationId: true,
  senderId: true,
  type: true,
  status: true,
  content: true,
  mediaReference: true,
  createdAt: true,
  updatedAt: true,
  sender: {
    select: {
      id: true,
      name: true,
    },
  },
} satisfies Prisma.MessageSelect;

function getConversationConflictField(
  error: Prisma.PrismaClientKnownRequestError,
): ConversationConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('matchId')) {
    return 'matchId';
  }

  return 'unknown';
}

function isConversationMatchRelationError(error: Prisma.PrismaClientKnownRequestError): boolean {
  return error.code === 'P2003' || error.code === 'P2025';
}

export class ChatRepository {
  constructor(private readonly prisma: DatabaseClient) {}

  async createConversation(input: CreateConversationInput): Promise<ConversationRecord> {
    const data: Prisma.ConversationCreateInput = {
      match: {
        connect: {
          id: input.matchId,
        },
      },
    };

    try {
      return await this.prisma.conversation.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConversationConflictError(getConversationConflictField(error));
      }

      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        isConversationMatchRelationError(error)
      ) {
        throw new ConversationMatchNotFoundError();
      }

      throw error;
    }
  }

  findConversationByMatchId(matchId: string): Promise<ConversationRecord | null> {
    return this.prisma.conversation.findUnique({
      where: {
        matchId,
      },
    });
  }

  findConversationByIdWithMatch(conversationId: string): Promise<ConversationWithMatchRecord | null> {
    return this.prisma.conversation.findUnique({
      where: {
        id: conversationId,
      },
      select: CONVERSATION_WITH_MATCH_SELECT,
    });
  }

  findMatchById(matchId: string): Promise<ConversationMatchRecord | null> {
    return this.prisma.match.findUnique({
      where: {
        id: matchId,
      },
      select: {
        id: true,
        userAId: true,
        userBId: true,
        status: true,
        expiresAt: true,
        deletedAt: true,
      },
    });
  }

  createMessage(input: CreateMessageInput): Promise<MessageRecord> {
    const data: Prisma.MessageCreateInput = {
      conversation: {
        connect: {
          id: input.conversationId,
        },
      },
      sender: {
        connect: {
          id: input.senderId,
        },
      },
      ...(input.type !== undefined ? { type: input.type } : {}),
      ...(input.status !== undefined ? { status: input.status } : {}),
      ...(input.content !== undefined ? { content: input.content } : {}),
      ...(input.mediaReference !== undefined ? { mediaReference: input.mediaReference } : {}),
    };

    return this.prisma.message.create({
      data,
    });
  }

  findMessageById(messageId: string): Promise<MessageRecord | null> {
    return this.prisma.message.findUnique({
      where: {
        id: messageId,
      },
    });
  }

  softDeleteMessage(messageId: string): Promise<MessageRecord> {
    return this.prisma.message.update({
      where: {
        id: messageId,
      },
      data: {
        status: PrismaMessageStatus.DELETED,
      },
    });
  }

  findMessagesByConversationId(
    conversationId: string,
    input: {
      skip: number;
      take: number;
      visibleStatuses: MessageStatus[];
    },
  ): Promise<ConversationMessageRecord[]> {
    return this.prisma.message.findMany({
      where: {
        conversationId,
        status: {
          in: input.visibleStatuses,
        },
      },
      orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
      skip: input.skip,
      take: input.take,
      select: MESSAGE_WITH_SENDER_SELECT,
    });
  }

  countMessagesByConversationId(
    conversationId: string,
    visibleStatuses: MessageStatus[],
  ): Promise<number> {
    return this.prisma.message.count({
      where: {
        conversationId,
        status: {
          in: visibleStatuses,
        },
      },
    });
  }
}
