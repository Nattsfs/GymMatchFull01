import { HttpError } from '../../common/errors/http-error.js';

interface DeleteMessageRouteParams {
  messageId?: unknown;
}

export interface DeleteMessageInput {
  messageId: string;
}

export function parseDeleteMessageInput(paramsPayload: unknown): DeleteMessageInput {
  if (!isObject(paramsPayload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const params = paramsPayload as DeleteMessageRouteParams;

  if (typeof params.messageId !== 'string' || params.messageId.trim().length === 0) {
    throw new HttpError(400, 'messageId is required and must be a non-empty string.');
  }

  return {
    messageId: params.messageId.trim(),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
