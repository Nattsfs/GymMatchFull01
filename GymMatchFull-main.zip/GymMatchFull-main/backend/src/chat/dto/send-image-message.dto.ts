import { HttpError } from '../../common/errors/http-error.js';
import type { UploadChatImageFileInput } from '../chat.types.js';

const IMAGE_SIGNATURE_JPEG = [0xff, 0xd8, 0xff] as const;
const IMAGE_SIGNATURE_PNG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a] as const;

const MIME_TYPE_ALIASES = {
  'image/jpg': 'image/jpeg',
  'image/jpeg': 'image/jpeg',
  'image/png': 'image/png',
  'image/webp': 'image/webp',
} as const;

export const CHAT_IMAGE_FORM_FIELD_NAME = 'image';
export const MAX_CHAT_IMAGE_FILE_SIZE_BYTES = 5 * 1024 * 1024;
export const CHAT_IMAGE_INVALID_TYPE_MESSAGE =
  'image must be a JPG, JPEG, PNG, or WEBP image.';

interface SendImageMessageRouteParams {
  conversationId?: unknown;
}

interface ParseSendImageMessageUploadInput {
  fieldName: string;
  mimeType: string;
  buffer: Buffer;
}

type SupportedImageMimeType = keyof typeof MIME_TYPE_ALIASES;

interface DetectedImageType {
  extension: UploadChatImageFileInput['extension'];
  mimeType: UploadChatImageFileInput['contentType'];
}

export interface SendImageMessageInput {
  conversationId: string;
  image: UploadChatImageFileInput;
}

export function parseSendImageMessageInput(
  paramsPayload: unknown,
  uploadPayload: ParseSendImageMessageUploadInput,
): SendImageMessageInput {
  if (uploadPayload.fieldName !== CHAT_IMAGE_FORM_FIELD_NAME) {
    throw new HttpError(
      400,
      `Image must be sent using the "${CHAT_IMAGE_FORM_FIELD_NAME}" form field.`,
    );
  }

  if (uploadPayload.buffer.length === 0) {
    throw new HttpError(400, 'image file cannot be empty.');
  }

  const normalizedMimeType = normalizeMimeType(uploadPayload.mimeType);
  const detectedImageType = detectImageType(uploadPayload.buffer);

  if (!normalizedMimeType || !detectedImageType || detectedImageType.mimeType !== normalizedMimeType) {
    throw new HttpError(400, CHAT_IMAGE_INVALID_TYPE_MESSAGE);
  }

  return {
    conversationId: parseConversationId(paramsPayload),
    image: {
      data: uploadPayload.buffer,
      contentType: detectedImageType.mimeType,
      extension: detectedImageType.extension,
    },
  };
}

function parseConversationId(payload: unknown): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const params = payload as SendImageMessageRouteParams;

  if (typeof params.conversationId !== 'string' || params.conversationId.trim().length === 0) {
    throw new HttpError(400, 'conversationId is required and must be a non-empty string.');
  }

  return params.conversationId.trim();
}

function normalizeMimeType(value: string): UploadChatImageFileInput['contentType'] | null {
  const normalizedValue = value.trim().toLowerCase().split(';', 1)[0] as SupportedImageMimeType;
  const normalizedMimeType = MIME_TYPE_ALIASES[normalizedValue];

  return normalizedMimeType ?? null;
}

function detectImageType(buffer: Buffer): DetectedImageType | null {
  if (hasSignature(buffer, IMAGE_SIGNATURE_JPEG)) {
    return {
      extension: 'jpg',
      mimeType: 'image/jpeg',
    };
  }

  if (hasSignature(buffer, IMAGE_SIGNATURE_PNG)) {
    return {
      extension: 'png',
      mimeType: 'image/png',
    };
  }

  if (
    buffer.length >= 12 &&
    buffer.toString('ascii', 0, 4) === 'RIFF' &&
    buffer.toString('ascii', 8, 12) === 'WEBP'
  ) {
    return {
      extension: 'webp',
      mimeType: 'image/webp',
    };
  }

  return null;
}

function hasSignature(buffer: Buffer, signature: readonly number[]): boolean {
  return signature.every((value, index) => buffer[index] === value);
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
