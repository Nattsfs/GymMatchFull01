import { HttpError } from '../../common/errors/http-error.js';
import type { ListConversationMessagesQueryInput } from '../chat.types.js';

interface ConversationRouteParams {
  conversationId?: unknown;
}

interface ListMessagesQuery {
  page?: unknown;
  limit?: unknown;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 50;

export interface ListConversationMessagesInput extends ListConversationMessagesQueryInput {
  conversationId: string;
}

export function parseListConversationMessagesInput(
  paramsPayload: unknown,
  queryPayload: unknown,
): ListConversationMessagesInput {
  return {
    conversationId: parseConversationId(paramsPayload),
    ...parseListConversationMessagesQuery(queryPayload),
  };
}

function parseListConversationMessagesQuery(payload: unknown): ListConversationMessagesQueryInput {
  if (!isObject(payload)) {
    return {
      page: DEFAULT_PAGE,
      limit: DEFAULT_LIMIT,
    };
  }

  const query = payload as ListMessagesQuery;

  return {
    page: parsePositiveInteger(query.page, 'page', DEFAULT_PAGE),
    limit: parsePositiveInteger(query.limit, 'limit', DEFAULT_LIMIT, MAX_LIMIT),
  };
}

function parseConversationId(payload: unknown): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const params = payload as ConversationRouteParams;

  if (typeof params.conversationId !== 'string' || params.conversationId.trim().length === 0) {
    throw new HttpError(400, 'conversationId is required and must be a non-empty string.');
  }

  return params.conversationId.trim();
}

function parsePositiveInteger(
  value: unknown,
  field: string,
  fallback: number,
  max?: number,
): number {
  if (value === undefined) {
    return fallback;
  }

  const stringValue = typeof value === 'number' ? String(value) : value;

  if (typeof stringValue !== 'string') {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const normalizedValue = stringValue.trim();

  if (!/^[1-9]\d*$/.test(normalizedValue)) {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    throw new HttpError(400, `${field} must be less than or equal to ${max}.`);
  }

  return parsedValue;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
