import { HttpError } from '../../common/errors/http-error.js';
import type { UploadChatAudioFileInput } from '../chat.types.js';

const MP3_SIGNATURE_ID3 = [0x49, 0x44, 0x33] as const;
const OGG_SIGNATURE = [0x4f, 0x67, 0x67, 0x53] as const;
const RIFF_SIGNATURE = [0x52, 0x49, 0x46, 0x46] as const;
const WAVE_SIGNATURE = [0x57, 0x41, 0x56, 0x45] as const;
const WEBM_SIGNATURE = [0x1a, 0x45, 0xdf, 0xa3] as const;

const MIME_TYPE_ALIASES = {
  'audio/mpeg': 'audio/mpeg',
  'audio/mp3': 'audio/mpeg',
  'audio/mp4': 'audio/mp4',
  'audio/m4a': 'audio/mp4',
  'audio/x-m4a': 'audio/mp4',
  'audio/wav': 'audio/wav',
  'audio/wave': 'audio/wav',
  'audio/x-wav': 'audio/wav',
  'audio/webm': 'audio/webm',
  'audio/ogg': 'audio/ogg',
} as const;

export const CHAT_AUDIO_FORM_FIELD_NAME = 'audio';
export const MAX_CHAT_AUDIO_FILE_SIZE_BYTES = 10 * 1024 * 1024;
export const CHAT_AUDIO_INVALID_TYPE_MESSAGE =
  'audio must be an MPEG, MP4, WAV, WEBM, or OGG audio file.';

interface SendAudioMessageRouteParams {
  conversationId?: unknown;
}

interface ParseSendAudioMessageUploadInput {
  fieldName: string;
  mimeType: string;
  buffer: Buffer;
}

type SupportedAudioMimeType = keyof typeof MIME_TYPE_ALIASES;

interface DetectedAudioType {
  extension: UploadChatAudioFileInput['extension'];
  mimeType: UploadChatAudioFileInput['contentType'];
}

export interface SendAudioMessageInput {
  conversationId: string;
  audio: UploadChatAudioFileInput;
}

export function parseSendAudioMessageInput(
  paramsPayload: unknown,
  uploadPayload: ParseSendAudioMessageUploadInput,
): SendAudioMessageInput {
  if (uploadPayload.fieldName !== CHAT_AUDIO_FORM_FIELD_NAME) {
    throw new HttpError(
      400,
      `Audio must be sent using the "${CHAT_AUDIO_FORM_FIELD_NAME}" form field.`,
    );
  }

  if (uploadPayload.buffer.length === 0) {
    throw new HttpError(400, 'audio file cannot be empty.');
  }

  const normalizedMimeType = normalizeMimeType(uploadPayload.mimeType);
  const detectedAudioType = detectAudioType(uploadPayload.buffer);

  if (!normalizedMimeType || !detectedAudioType || detectedAudioType.mimeType !== normalizedMimeType) {
    throw new HttpError(400, CHAT_AUDIO_INVALID_TYPE_MESSAGE);
  }

  return {
    conversationId: parseConversationId(paramsPayload),
    audio: {
      data: uploadPayload.buffer,
      contentType: detectedAudioType.mimeType,
      extension: detectedAudioType.extension,
    },
  };
}

function parseConversationId(payload: unknown): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const params = payload as SendAudioMessageRouteParams;

  if (typeof params.conversationId !== 'string' || params.conversationId.trim().length === 0) {
    throw new HttpError(400, 'conversationId is required and must be a non-empty string.');
  }

  return params.conversationId.trim();
}

function normalizeMimeType(value: string): UploadChatAudioFileInput['contentType'] | null {
  const normalizedValue = value.trim().toLowerCase().split(';', 1)[0] as SupportedAudioMimeType;
  const normalizedMimeType = MIME_TYPE_ALIASES[normalizedValue];

  return normalizedMimeType ?? null;
}

function detectAudioType(buffer: Buffer): DetectedAudioType | null {
  if (hasSignature(buffer, MP3_SIGNATURE_ID3) || hasMp3FrameSync(buffer)) {
    return {
      extension: 'mp3',
      mimeType: 'audio/mpeg',
    };
  }

  if (hasSignature(buffer, OGG_SIGNATURE)) {
    return {
      extension: 'ogg',
      mimeType: 'audio/ogg',
    };
  }

  if (
    hasSignature(buffer, RIFF_SIGNATURE) &&
    buffer.length >= 12 &&
    hasSignature(buffer.subarray(8, 12), WAVE_SIGNATURE)
  ) {
    return {
      extension: 'wav',
      mimeType: 'audio/wav',
    };
  }

  if (hasSignature(buffer, WEBM_SIGNATURE)) {
    return {
      extension: 'webm',
      mimeType: 'audio/webm',
    };
  }

  if (buffer.length >= 12 && buffer.toString('ascii', 4, 8) === 'ftyp') {
    return {
      extension: 'mp4',
      mimeType: 'audio/mp4',
    };
  }

  return null;
}

function hasMp3FrameSync(buffer: Buffer): boolean {
  const firstByte = buffer.at(0);
  const secondByte = buffer.at(1);

  return firstByte === 0xff && secondByte !== undefined && (secondByte & 0xe0) === 0xe0;
}

function hasSignature(buffer: Buffer, signature: readonly number[]): boolean {
  return signature.every((value, index) => buffer[index] === value);
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
