import { HttpError } from '../../common/errors/http-error.js';
import { TEXT_MESSAGE_MAX_LENGTH } from '../chat.types.js';

interface SendTextMessageRequestBody {
  content?: unknown;
}

export interface SendTextMessageInput {
  content: string;
  conversationId: string;
}

export function parseSendTextMessageInput(
  paramsPayload: unknown,
  bodyPayload: unknown,
): SendTextMessageInput {
  const conversationId = parseConversationId(paramsPayload);
  const content = parseContent(bodyPayload);

  return {
    conversationId,
    content,
  };
}

function parseConversationId(payload: unknown): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const value = payload.conversationId;

  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new HttpError(400, 'conversationId is required and must be a non-empty string.');
  }

  return value.trim();
}

function parseContent(payload: unknown): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as SendTextMessageRequestBody;

  if (typeof body.content !== 'string') {
    throw new HttpError(400, 'content is required and must be a string.');
  }

  const normalizedContent = body.content.trim();

  if (normalizedContent.length === 0) {
    throw new HttpError(400, 'content is required and must be a non-empty string.');
  }

  if (normalizedContent.length > TEXT_MESSAGE_MAX_LENGTH) {
    throw new HttpError(
      400,
      `content must be at most ${TEXT_MESSAGE_MAX_LENGTH} characters long.`,
    );
  }

  return normalizedContent;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
