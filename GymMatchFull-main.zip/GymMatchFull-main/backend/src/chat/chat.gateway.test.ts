import type { PrismaClient } from '@prisma/client';
import {
  MatchStatus as PrismaMatchStatus,
  MessageStatus as PrismaMessageStatus,
  MessageType as PrismaMessageType,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
} from '@prisma/client';
import type { WebSocket } from 'ws';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import type { SafeUser } from '../users/users.types.js';
import { CHAT_MESSAGE_CREATED_EVENT, ChatRealtimeGateway } from './chat.gateway.js';
import { ChatRepository } from './chat.repository.js';
import { ChatService } from './chat.service.js';
import type {
  ChatMessageCreatedEvent,
  ConversationMessageRecord,
  ConversationMatchRecord,
  ConversationRecord,
  ConversationWithMatchRecord,
  CreateConversationInput,
  CreateMessageInput,
  MessageRecord,
} from './chat.types.js';

const FIXED_NOW = new Date('2026-05-10T21:30:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];
const socketsToClose: WebSocket[] = [];

interface SeedMatchInput {
  deletedAt?: Date | null;
  expiresAt?: Date | null;
  id?: string;
  status?: PrismaMatchStatus;
  userAId?: string;
  userBId?: string;
}

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryChatRepository {
  private readonly conversations: ConversationRecord[] = [];
  private readonly matches: ConversationMatchRecord[] = [];
  private readonly messages: ConversationMessageRecord[] = [];
  private nextConversationId = 1;
  private nextMessageId = 1;

  async createConversation(input: CreateConversationInput): Promise<ConversationRecord> {
    const existingConversation = this.conversations.find(
      (conversation) => conversation.matchId === input.matchId,
    );

    if (existingConversation) {
      return existingConversation;
    }

    const conversation: ConversationRecord = {
      id: `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  async findConversationByIdWithMatch(
    conversationId: string,
  ): Promise<ConversationWithMatchRecord | null> {
    const conversation = this.conversations.find((item) => item.id === conversationId);

    if (!conversation) {
      return null;
    }

    const match = this.matches.find((item) => item.id === conversation.matchId);

    if (!match) {
      return null;
    }

    return {
      ...conversation,
      match,
    };
  }

  async findConversationByMatchId(matchId: string): Promise<ConversationRecord | null> {
    return this.conversations.find((conversation) => conversation.matchId === matchId) ?? null;
  }

  async findMatchById(matchId: string): Promise<ConversationMatchRecord | null> {
    return this.matches.find((match) => match.id === matchId) ?? null;
  }

  async createMessage(input: CreateMessageInput): Promise<MessageRecord> {
    const message: ConversationMessageRecord = {
      id: `message_${this.nextMessageId++}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      sender: {
        id: input.senderId,
        name: `Aluno ${input.senderId}`,
      },
    };

    this.messages.push(message);

    return toMessageRecord(message);
  }

  async findMessageById(messageId: string): Promise<MessageRecord | null> {
    const message = this.messages.find((item) => item.id === messageId);

    return message ? toMessageRecord(message) : null;
  }

  async softDeleteMessage(messageId: string): Promise<MessageRecord> {
    const message = this.messages.find((item) => item.id === messageId);

    if (!message) {
      throw new Error(`Message ${messageId} not found.`);
    }

    message.status = PrismaMessageStatus.DELETED;
    message.updatedAt = FIXED_NOW;

    return toMessageRecord(message);
  }

  async findMessagesByConversationId(): Promise<ConversationMessageRecord[]> {
    return [];
  }

  async countMessagesByConversationId(): Promise<number> {
    return 0;
  }

  seedConversation(input: { id?: string; matchId: string }): ConversationRecord {
    const conversation: ConversationRecord = {
      id: input.id ?? `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  seedMatch(input: SeedMatchInput = {}): ConversationMatchRecord {
    const index = this.matches.length + 1;
    const match: ConversationMatchRecord = {
      id: input.id ?? `match_${index}`,
      userAId: input.userAId ?? `user_${index}_a`,
      userBId: input.userBId ?? `user_${index}_b`,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const chatRepository = new InMemoryChatRepository();
  const chatRealtimeGateway = new ChatRealtimeGateway();
  const chatService = new ChatService({} as PrismaClient, {
    chatRepository: chatRepository as unknown as ChatRepository,
    messageEventPublisher: chatRealtimeGateway,
  });
  const app = buildApp({
    config,
    services: {
      chatRealtimeGateway,
      chatService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    chatRepository,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

function trackSocket(socket: WebSocket): WebSocket {
  socketsToClose.push(socket);
  return socket;
}

function waitForSocketEvent(socket: WebSocket): Promise<ChatMessageCreatedEvent> {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error('Timed out waiting for websocket event.'));
    }, 500);

    const onMessage = (data: Buffer) => {
      cleanup();
      resolve(JSON.parse(data.toString('utf8')) as ChatMessageCreatedEvent);
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };

    const cleanup = () => {
      clearTimeout(timeout);
      socket.off('message', onMessage);
      socket.off('error', onError);
    };

    socket.on('message', onMessage);
    socket.on('error', onError);
  });
}

function expectNoSocketEvent(socket: WebSocket, timeoutMs = 100): Promise<void> {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      resolve();
    }, timeoutMs);

    const onMessage = (data: Buffer) => {
      cleanup();
      reject(new Error(`Unexpected websocket event received: ${data.toString('utf8')}`));
    };
    const onError = (error: Error) => {
      cleanup();
      reject(error);
    };

    const cleanup = () => {
      clearTimeout(timeout);
      socket.off('message', onMessage);
      socket.off('error', onError);
    };

    socket.on('message', onMessage);
    socket.on('error', onError);
  });
}

function toMessageRecord(message: ConversationMessageRecord): MessageRecord {
  return {
    id: message.id,
    conversationId: message.conversationId,
    senderId: message.senderId,
    type: message.type,
    status: message.status,
    content: message.content,
    mediaReference: message.mediaReference,
    createdAt: message.createdAt,
    updatedAt: message.updatedAt,
  };
}

afterEach(async () => {
  while (socketsToClose.length > 0) {
    const socket = socketsToClose.pop();

    if (socket) {
      socket.terminate();
    }
  }

  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('chat websocket gateway', () => {
  it('accepts an authenticated websocket connection', async () => {
    const { app, usersService } = createTestApp();
    const user = usersService.seedUser({ id: 'student_ws_ok' });

    await app.ready();

    const socket = trackSocket(
      await app.injectWS(`/chat/ws?token=${signAccessToken(app, user)}`),
    );

    expect(socket.readyState).toBe(1);
  });

  it('rejects websocket connections without a token', async () => {
    const { app } = createTestApp();

    await app.ready();

    await expect(app.injectWS('/chat/ws')).rejects.toThrow('Unexpected server response: 401');
  });

  it('rejects websocket connections with an invalid token', async () => {
    const { app } = createTestApp();

    await app.ready();

    await expect(app.injectWS('/chat/ws?token=invalid-token')).rejects.toThrow(
      'Unexpected server response: 401',
    );
  });

  it('emits message.created only to conversation participants', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const participantA = usersService.seedUser({ id: 'student_participant_a' });
    const participantB = usersService.seedUser({ id: 'student_participant_b' });
    const outsider = usersService.seedUser({ id: 'student_outsider' });
    const match = chatRepository.seedMatch({
      id: 'match_ws_1',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_ws_1',
      matchId: match.id,
    });

    await app.ready();

    const participantASocket = trackSocket(
      await app.injectWS(`/chat/ws?token=${signAccessToken(app, participantA)}`),
    );
    const participantBSocket = trackSocket(
      await app.injectWS(`/chat/ws?token=${signAccessToken(app, participantB)}`),
    );
    const outsiderSocket = trackSocket(
      await app.injectWS(`/chat/ws?token=${signAccessToken(app, outsider)}`),
    );

    const participantAEventPromise = waitForSocketEvent(participantASocket);
    const participantBEventPromise = waitForSocketEvent(participantBSocket);
    const outsiderNoEventPromise = expectNoSocketEvent(outsiderSocket);

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/messages`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, participantA)}`,
      },
      payload: {
        content: 'Partiu treino de peito?',
      },
    });

    expect(response.statusCode).toBe(201);

    const responseBody = response.json();
    const [participantAEvent, participantBEvent] = await Promise.all([
      participantAEventPromise,
      participantBEventPromise,
      outsiderNoEventPromise,
    ]);

    expect(participantAEvent).toEqual({
      event: CHAT_MESSAGE_CREATED_EVENT,
      data: {
        id: responseBody.id,
        conversationId: responseBody.conversationId,
        senderId: responseBody.senderId,
        type: responseBody.type,
        content: responseBody.content,
        mediaReference: responseBody.mediaReference,
        createdAt: responseBody.createdAt,
      },
    });
    expect(participantBEvent).toEqual(participantAEvent);
  });
});
