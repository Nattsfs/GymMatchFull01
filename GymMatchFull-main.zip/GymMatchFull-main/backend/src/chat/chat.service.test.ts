import {
  MatchStatus as PrismaMatchStatus,
  MessageStatus as PrismaMessageStatus,
  MessageType as PrismaMessageType,
  type PrismaClient,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { PremiumAccessServiceContract } from '../plans/premium-access.service.js';
import type { StorageServiceContract } from '../storage/storage.service.js';
import { ChatRepository } from './chat.repository.js';
import { ChatService } from './chat.service.js';
import { TEXT_MESSAGE_MAX_LENGTH } from './chat.types.js';
import type {
  ChatMessageEventPublisherContract,
  ConversationMessageRecord,
  ConversationMatchRecord,
  ConversationRecord,
  ConversationWithMatchRecord,
  CreateConversationInput,
  CreateMessageInput,
  MessageRecord,
  PublishMessageCreatedInput,
  UploadAudioMessageInput,
  UploadImageMessageInput,
} from './chat.types.js';
import { ConversationConflictError } from './chat.types.js';

const FIXED_NOW = new Date('2026-05-10T20:30:00.000Z');

interface SeedMatchInput {
  deletedAt?: Date | null;
  expiresAt?: Date | null;
  id?: string;
  status?: PrismaMatchStatus;
  userAId?: string;
  userBId?: string;
}

class InMemoryChatRepository {
  private readonly matches: ConversationMatchRecord[] = [];
  private readonly conversations: ConversationRecord[] = [];
  private readonly messages: ConversationMessageRecord[] = [];
  private nextConversationId = 1;
  private nextMessageId = 1;
  private createMessageError: Error | null = null;

  async createConversation(input: CreateConversationInput): Promise<ConversationRecord> {
    const existingConversation = this.conversations.find(
      (conversation) => conversation.matchId === input.matchId,
    );

    if (existingConversation) {
      throw new ConversationConflictError('matchId');
    }

    const conversation: ConversationRecord = {
      id: `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  async findConversationByIdWithMatch(
    conversationId: string,
  ): Promise<ConversationWithMatchRecord | null> {
    const conversation = this.conversations.find((item) => item.id === conversationId);

    if (!conversation) {
      return null;
    }

    const match = this.matches.find((item) => item.id === conversation.matchId);

    if (!match) {
      return null;
    }

    return {
      ...conversation,
      match,
    };
  }

  async findConversationByMatchId(matchId: string): Promise<ConversationRecord | null> {
    return this.conversations.find((conversation) => conversation.matchId === matchId) ?? null;
  }

  async findMatchById(matchId: string): Promise<ConversationMatchRecord | null> {
    return this.matches.find((match) => match.id === matchId) ?? null;
  }

  async createMessage(input: CreateMessageInput): Promise<MessageRecord> {
    if (this.createMessageError) {
      throw this.createMessageError;
    }

    const message: ConversationMessageRecord = {
      id: `message_${this.nextMessageId++}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      sender: {
        id: input.senderId,
        name: `Aluno ${input.senderId}`,
      },
    };

    this.messages.push(message);

    return toMessageRecord(message);
  }

  async findMessageById(messageId: string): Promise<MessageRecord | null> {
    const message = this.messages.find((item) => item.id === messageId);

    return message ? toMessageRecord(message) : null;
  }

  async softDeleteMessage(messageId: string): Promise<MessageRecord> {
    const message = this.messages.find((item) => item.id === messageId);

    if (!message) {
      throw new Error(`Message ${messageId} not found.`);
    }

    message.status = PrismaMessageStatus.DELETED;
    message.updatedAt = FIXED_NOW;

    return toMessageRecord(message);
  }

  async findMessagesByConversationId(
    conversationId: string,
    input: {
      skip: number;
      take: number;
      visibleStatuses: PrismaMessageStatus[];
    },
  ): Promise<ConversationMessageRecord[]> {
    return this.messages
      .filter(
        (message) =>
          message.conversationId === conversationId &&
          input.visibleStatuses.includes(message.status),
      )
      .sort(compareMessages)
      .slice(input.skip, input.skip + input.take);
  }

  async countMessagesByConversationId(
    conversationId: string,
    visibleStatuses: PrismaMessageStatus[],
  ): Promise<number> {
    return this.messages.filter(
      (message) =>
        message.conversationId === conversationId && visibleStatuses.includes(message.status),
    ).length;
  }

  seedConversation(input: { id?: string; matchId: string }): ConversationRecord {
    const conversation: ConversationRecord = {
      id: input.id ?? `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  seedMatch(input: SeedMatchInput = {}): ConversationMatchRecord {
    const index = this.matches.length + 1;
    const match: ConversationMatchRecord = {
      id: input.id ?? `match_${index}`,
      userAId: input.userAId ?? `user_${index}_a`,
      userBId: input.userBId ?? `user_${index}_b`,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  countConversations(): number {
    return this.conversations.length;
  }

  setCreateMessageError(error: Error | null): void {
    this.createMessageError = error;
  }

  seedMessage(
    input: {
      id?: string;
      conversationId: string;
      senderId: string;
      senderName?: string;
      type?: PrismaMessageType;
      status?: PrismaMessageStatus;
      content?: string | null;
      mediaReference?: string | null;
      createdAt?: Date;
      updatedAt?: Date;
    },
  ): ConversationMessageRecord {
    const message: ConversationMessageRecord = {
      id: input.id ?? `message_${this.nextMessageId++}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      sender: {
        id: input.senderId,
        name: input.senderName ?? `Aluno ${input.senderId}`,
      },
    };

    this.messages.push(message);

    return message;
  }
}

class InMemoryStorageService implements StorageServiceContract {
  readonly savedFiles: Array<{
    key: string;
    contentType: string;
    data: Buffer;
  }> = [];
  readonly deletedPublicUrls: string[] = [];

  async saveFile(input: {
    key: string;
    contentType: string;
    data: Buffer;
  }): Promise<{ key: string; publicUrl: string }> {
    this.savedFiles.push({
      key: input.key,
      contentType: input.contentType,
      data: input.data,
    });

    return {
      key: input.key,
      publicUrl: `/storage/${input.key}`,
    };
  }

  async deleteFileByPublicUrl(publicUrl: string): Promise<void> {
    this.deletedPublicUrls.push(publicUrl);
  }
}

class InMemoryPremiumAccessService implements PremiumAccessServiceContract {
  private readonly premiumUserIds = new Set<string>();

  async hasPremiumChatImageAccess(userId: string): Promise<boolean> {
    return this.premiumUserIds.has(userId);
  }

  seedPremiumUser(userId: string): void {
    this.premiumUserIds.add(userId);
  }
}

class InMemoryChatMessageEventPublisher implements ChatMessageEventPublisherContract {
  readonly publishedMessages: PublishMessageCreatedInput[] = [];

  async publishMessageCreated(input: PublishMessageCreatedInput): Promise<void> {
    this.publishedMessages.push(input);
  }
}

function createChatService(
  options: {
    chatRepository?: InMemoryChatRepository;
    messageEventPublisher?: InMemoryChatMessageEventPublisher;
    premiumAccessService?: InMemoryPremiumAccessService;
    storageService?: InMemoryStorageService;
  } = {},
): ChatService {
  return new ChatService({} as PrismaClient, {
    chatRepository: (options.chatRepository ??
      new InMemoryChatRepository()) as unknown as ChatRepository,
    ...(options.messageEventPublisher
      ? { messageEventPublisher: options.messageEventPublisher }
      : {}),
    ...(options.premiumAccessService
      ? { premiumAccessService: options.premiumAccessService }
      : {}),
    ...(options.storageService ? { storageService: options.storageService } : {}),
  });
}

function makeUploadAudioInput(
  overrides: Partial<UploadAudioMessageInput> = {},
): UploadAudioMessageInput {
  return {
    conversationId: 'conversation_audio_1',
    senderId: 'user_audio_1',
    audio: {
      data: Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00]),
      contentType: 'audio/mpeg',
      extension: 'mp3',
    },
    ...overrides,
  };
}

function makeUploadImageInput(
  overrides: Partial<UploadImageMessageInput> = {},
): UploadImageMessageInput {
  return {
    conversationId: 'conversation_image_1',
    senderId: 'user_image_1',
    image: {
      data: Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43, 0x00, 0x08]),
      contentType: 'image/jpeg',
      extension: 'jpg',
    },
    ...overrides,
  };
}

function compareMessages(
  left: Pick<ConversationMessageRecord, 'createdAt' | 'id'>,
  right: Pick<ConversationMessageRecord, 'createdAt' | 'id'>,
): number {
  const timeDiff = left.createdAt.getTime() - right.createdAt.getTime();

  if (timeDiff !== 0) {
    return timeDiff;
  }

  return left.id.localeCompare(right.id);
}

function toMessageRecord(message: ConversationMessageRecord): MessageRecord {
  return {
    id: message.id,
    conversationId: message.conversationId,
    senderId: message.senderId,
    type: message.type,
    status: message.status,
    content: message.content,
    mediaReference: message.mediaReference,
    createdAt: message.createdAt,
    updatedAt: message.updatedAt,
  };
}

describe('ChatService', () => {
  it('creates one conversation for an active match', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_1',
      userAId: 'user_1',
      userBId: 'user_2',
    });
    const service = createChatService({ chatRepository });

    const conversation = await service.createConversation({
      matchId: match.id,
    });

    expect(conversation).toMatchObject({
      matchId: match.id,
    });
    await expect(service.findConversationByMatchId(match.id)).resolves.toEqual(conversation);
  });

  it('rejects a second conversation for the same match', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_2',
      userAId: 'user_3',
      userBId: 'user_4',
    });
    chatRepository.seedConversation({
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createConversation({
        matchId: match.id,
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Conversation already exists for this match.',
    });
  });

  it('rejects conversation creation for inactive matches', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_blocked_1',
      status: PrismaMatchStatus.BLOCKED,
      userAId: 'user_5',
      userBId: 'user_6',
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createConversation({
        matchId: match.id,
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Conversation can only be created for active matches.',
    });
  });

  it('gets or creates a single conversation for the same active match', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_2b',
      userAId: 'user_3b',
      userBId: 'user_4b',
    });
    const service = createChatService({ chatRepository });

    const createdConversation = await service.getOrCreateConversation({
      matchId: match.id,
    });
    const reusedConversation = await service.getOrCreateConversation({
      matchId: match.id,
    });

    expect(createdConversation).toEqual(reusedConversation);
    expect(chatRepository.countConversations()).toBe(1);
  });

  it('creates a text message for a conversation participant', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_3',
      userAId: 'user_7',
      userBId: 'user_8',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_active_3',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    const message = await service.createMessage({
      conversationId: conversation.id,
      senderId: match.userAId,
      content: '  Bora treinar costas hoje?  ',
    });

    expect(message).toMatchObject({
      conversationId: conversation.id,
      senderId: match.userAId,
      type: PrismaMessageType.TEXT,
      status: PrismaMessageStatus.SENT,
      content: 'Bora treinar costas hoje?',
      mediaReference: null,
    });
    await expect(service.findMessageById(message.id)).resolves.toEqual(message);
  });

  it('publishes realtime metadata when a text message is created', async () => {
    const chatRepository = new InMemoryChatRepository();
    const messageEventPublisher = new InMemoryChatMessageEventPublisher();
    const match = chatRepository.seedMatch({
      id: 'match_realtime_text_1',
      userAId: 'user_realtime_1',
      userBId: 'user_realtime_2',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_realtime_text_1',
      matchId: match.id,
    });
    const service = createChatService({
      chatRepository,
      messageEventPublisher,
    });

    const message = await service.createMessage({
      conversationId: conversation.id,
      senderId: match.userAId,
      content: 'Treino de perna hoje.',
    });

    expect(messageEventPublisher.publishedMessages).toEqual([
      {
        message,
        participantIds: [match.userAId, match.userBId],
      },
    ]);
  });

  it('soft deletes a sender message and keeps the original content persisted', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_delete_1',
      userAId: 'user_delete_1',
      userBId: 'user_delete_2',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_active_delete_1',
      matchId: match.id,
    });
    const seededMessage = chatRepository.seedMessage({
      id: 'message_delete_1',
      conversationId: conversation.id,
      senderId: match.userAId,
      content: 'Mensagem que precisa sumir da listagem.',
    });
    const service = createChatService({ chatRepository });

    const deletedMessage = await service.deleteMessage({
      messageId: seededMessage.id,
      currentUserId: match.userAId,
    });

    expect(deletedMessage).toMatchObject({
      id: seededMessage.id,
      senderId: match.userAId,
      status: PrismaMessageStatus.DELETED,
      content: 'Mensagem que precisa sumir da listagem.',
    });
    await expect(service.findMessageById(seededMessage.id)).resolves.toMatchObject({
      id: seededMessage.id,
      status: PrismaMessageStatus.DELETED,
      content: 'Mensagem que precisa sumir da listagem.',
    });

    const result = await service.listConversationMessages({
      conversationId: conversation.id,
      currentUserId: match.userAId,
      page: 1,
      limit: 20,
    });

    expect(result.data).toEqual([]);
    expect(result.pagination).toMatchObject({
      page: 1,
      limit: 20,
      total: 0,
      totalPages: 1,
    });
  });

  it('rejects soft deletion when the message does not exist', async () => {
    const service = createChatService();

    await expect(
      service.deleteMessage({
        messageId: 'message_missing',
        currentUserId: 'user_delete_missing',
      }),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Message not found.',
    });
  });

  it('rejects soft deletion when the current user is not the sender', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_delete_2',
      userAId: 'user_delete_3',
      userBId: 'user_delete_4',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_active_delete_2',
      matchId: match.id,
    });
    const seededMessage = chatRepository.seedMessage({
      id: 'message_delete_2',
      conversationId: conversation.id,
      senderId: match.userAId,
      content: 'Mensagem protegida.',
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.deleteMessage({
        messageId: seededMessage.id,
        currentUserId: match.userBId,
      }),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only the sender can delete this message.',
    });
    await expect(service.findMessageById(seededMessage.id)).resolves.toMatchObject({
      id: seededMessage.id,
      status: PrismaMessageStatus.SENT,
      content: 'Mensagem protegida.',
    });
  });

  it('rejects message creation when the conversation does not exist', async () => {
    const service = createChatService();

    await expect(
      service.createMessage({
        conversationId: 'conversation_missing',
        senderId: 'user_9',
        content: 'Mensagem sem conversa',
      }),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Conversation not found.',
    });
  });

  it('rejects senders that do not belong to the conversation match', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_4',
      userAId: 'user_10',
      userBId: 'user_11',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_active_4',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createMessage({
        conversationId: conversation.id,
        senderId: 'user_intruder',
        content: 'Eu não deveria entrar aqui',
      }),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Sender is not part of this conversation.',
    });
  });

  it('rejects blank text messages', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_5',
      userAId: 'user_12',
      userBId: 'user_13',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_active_5',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createMessage({
        conversationId: conversation.id,
        senderId: match.userAId,
        content: '   ',
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Text messages require content.',
    });
  });

  it('rejects text messages that exceed the maximum length', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_5b',
      userAId: 'user_12b',
      userBId: 'user_13b',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_active_5b',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createMessage({
        conversationId: conversation.id,
        senderId: match.userAId,
        content: 'a'.repeat(TEXT_MESSAGE_MAX_LENGTH + 1),
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: `content must be at most ${TEXT_MESSAGE_MAX_LENGTH} characters long.`,
    });
  });

  it('accepts audio and image messages with a media reference', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_active_6',
      userAId: 'user_14',
      userBId: 'user_15',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_active_6',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    const audioMessage = await service.createMessage({
      conversationId: conversation.id,
      senderId: match.userAId,
      type: PrismaMessageType.AUDIO,
      mediaReference: 'media/audio_1',
    });
    const imageMessage = await service.createMessage({
      conversationId: conversation.id,
      senderId: match.userBId,
      type: PrismaMessageType.IMAGE,
      status: PrismaMessageStatus.MODERATION_HIDDEN,
      mediaReference: 'media/image_1',
    });

    expect(audioMessage).toMatchObject({
      type: PrismaMessageType.AUDIO,
      mediaReference: 'media/audio_1',
      content: null,
    });
    expect(imageMessage).toMatchObject({
      type: PrismaMessageType.IMAGE,
      status: PrismaMessageStatus.MODERATION_HIDDEN,
      mediaReference: 'media/image_1',
    });
  });

  it('uploads an audio file and creates an audio message', async () => {
    const chatRepository = new InMemoryChatRepository();
    const messageEventPublisher = new InMemoryChatMessageEventPublisher();
    const storageService = new InMemoryStorageService();
    const match = chatRepository.seedMatch({
      id: 'match_audio_upload_1',
      userAId: 'user_audio_1',
      userBId: 'user_audio_2',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_upload_1',
      matchId: match.id,
    });
    const service = createChatService({
      chatRepository,
      messageEventPublisher,
      storageService,
    });

    const message = await service.uploadAudioMessage(
      makeUploadAudioInput({
        conversationId: conversation.id,
        senderId: match.userAId,
      }),
    );

    expect(message).toMatchObject({
      conversationId: conversation.id,
      senderId: match.userAId,
      type: PrismaMessageType.AUDIO,
      status: PrismaMessageStatus.SENT,
      content: null,
    });
    expect(messageEventPublisher.publishedMessages).toEqual([
      {
        message,
        participantIds: [match.userAId, match.userBId],
      },
    ]);
    expect(message.mediaReference).toMatch(
      new RegExp(`^/storage/chat-audios/${conversation.id}/${match.userAId}/.+\\.mp3$`),
    );
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.savedFiles[0]).toMatchObject({
      contentType: 'audio/mpeg',
      data: Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00]),
    });
  });

  it('rejects audio uploads from users outside the conversation without storing the file', async () => {
    const chatRepository = new InMemoryChatRepository();
    const storageService = new InMemoryStorageService();
    const match = chatRepository.seedMatch({
      id: 'match_audio_upload_2',
      userAId: 'user_audio_3',
      userBId: 'user_audio_4',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_upload_2',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository, storageService });

    await expect(
      service.uploadAudioMessage(
        makeUploadAudioInput({
          conversationId: conversation.id,
          senderId: 'user_intruder',
        }),
      ),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Sender is not part of this conversation.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('deletes the stored audio when message persistence fails', async () => {
    const chatRepository = new InMemoryChatRepository();
    const storageService = new InMemoryStorageService();
    const match = chatRepository.seedMatch({
      id: 'match_audio_upload_3',
      userAId: 'user_audio_5',
      userBId: 'user_audio_6',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_upload_3',
      matchId: match.id,
    });
    chatRepository.setCreateMessageError(new Error('message write failed'));
    const service = createChatService({ chatRepository, storageService });

    await expect(
      service.uploadAudioMessage(
        makeUploadAudioInput({
          conversationId: conversation.id,
          senderId: match.userAId,
        }),
      ),
    ).rejects.toThrow('message write failed');
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.deletedPublicUrls).toEqual([
      `/storage/${storageService.savedFiles[0]?.key}`,
    ]);
  });

  it('uploads an image file and creates an image message for a premium user', async () => {
    const chatRepository = new InMemoryChatRepository();
    const messageEventPublisher = new InMemoryChatMessageEventPublisher();
    const storageService = new InMemoryStorageService();
    const premiumAccessService = new InMemoryPremiumAccessService();
    const match = chatRepository.seedMatch({
      id: 'match_image_upload_1',
      userAId: 'user_image_1',
      userBId: 'user_image_2',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_upload_1',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(match.userAId);
    const service = createChatService({
      chatRepository,
      messageEventPublisher,
      premiumAccessService,
      storageService,
    });

    const message = await service.uploadImageMessage(
      makeUploadImageInput({
        conversationId: conversation.id,
        senderId: match.userAId,
      }),
    );

    expect(message).toMatchObject({
      conversationId: conversation.id,
      senderId: match.userAId,
      type: PrismaMessageType.IMAGE,
      status: PrismaMessageStatus.SENT,
      content: null,
    });
    expect(messageEventPublisher.publishedMessages).toEqual([
      {
        message,
        participantIds: [match.userAId, match.userBId],
      },
    ]);
    expect(message.mediaReference).toMatch(
      new RegExp(`^/storage/chat-images/${conversation.id}/${match.userAId}/.+\\.jpg$`),
    );
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.savedFiles[0]).toMatchObject({
      contentType: 'image/jpeg',
      data: Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43, 0x00, 0x08]),
    });
  });

  it('rejects image uploads for free users without storing the file', async () => {
    const chatRepository = new InMemoryChatRepository();
    const storageService = new InMemoryStorageService();
    const premiumAccessService = new InMemoryPremiumAccessService();
    const match = chatRepository.seedMatch({
      id: 'match_image_upload_2',
      userAId: 'user_image_3',
      userBId: 'user_image_4',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_upload_2',
      matchId: match.id,
    });
    const service = createChatService({
      chatRepository,
      premiumAccessService,
      storageService,
    });

    await expect(
      service.uploadImageMessage(
        makeUploadImageInput({
          conversationId: conversation.id,
          senderId: match.userAId,
        }),
      ),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only premium users can send chat images.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('deletes the stored image when message persistence fails', async () => {
    const chatRepository = new InMemoryChatRepository();
    const storageService = new InMemoryStorageService();
    const premiumAccessService = new InMemoryPremiumAccessService();
    const match = chatRepository.seedMatch({
      id: 'match_image_upload_3',
      userAId: 'user_image_5',
      userBId: 'user_image_6',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_upload_3',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(match.userAId);
    chatRepository.setCreateMessageError(new Error('image message write failed'));
    const service = createChatService({
      chatRepository,
      premiumAccessService,
      storageService,
    });

    await expect(
      service.uploadImageMessage(
        makeUploadImageInput({
          conversationId: conversation.id,
          senderId: match.userAId,
        }),
      ),
    ).rejects.toThrow('image message write failed');
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.deletedPublicUrls).toEqual([
      `/storage/${storageService.savedFiles[0]?.key}`,
    ]);
  });

  it('rejects new messages when the related match is no longer active', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_expired_1',
      status: PrismaMatchStatus.EXPIRED,
      userAId: 'user_16',
      userBId: 'user_17',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_expired_1',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createMessage({
        conversationId: conversation.id,
        senderId: match.userAId,
        content: 'Mensagem inválida',
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Messages can only be sent for active matches.',
    });
  });

  it('rejects new messages when the related match has already expired by date', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_expired_by_date_1',
      expiresAt: new Date('2000-01-01T00:00:00.000Z'),
      userAId: 'user_18',
      userBId: 'user_19',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_match_expired_by_date_1',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.createMessage({
        conversationId: conversation.id,
        senderId: match.userAId,
        content: 'Mensagem com data de expiracao vencida',
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Messages can only be sent for active matches.',
    });
  });

  it('lists conversation messages with pagination, stable ordering and safe sender data', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_history_1',
      userAId: 'user_20',
      userBId: 'user_21',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_history_1',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    chatRepository.seedMessage({
      id: 'message_b',
      conversationId: conversation.id,
      senderId: match.userAId,
      senderName: 'Aluno A',
      content: 'Segunda mensagem por id',
      createdAt: new Date('2026-05-10T20:00:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_a',
      conversationId: conversation.id,
      senderId: match.userBId,
      senderName: 'Aluno B',
      content: 'Primeira por desempate',
      createdAt: new Date('2026-05-10T20:00:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_hidden',
      conversationId: conversation.id,
      senderId: match.userBId,
      senderName: 'Aluno B',
      status: PrismaMessageStatus.MODERATION_HIDDEN,
      content: 'Nao deve aparecer',
      createdAt: new Date('2026-05-10T20:01:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_deleted',
      conversationId: conversation.id,
      senderId: match.userAId,
      senderName: 'Aluno A',
      status: PrismaMessageStatus.DELETED,
      content: 'Nao deve aparecer',
      createdAt: new Date('2026-05-10T20:02:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_c',
      conversationId: conversation.id,
      senderId: match.userAId,
      senderName: 'Aluno A',
      content: 'Terceira visivel',
      createdAt: new Date('2026-05-10T20:03:00.000Z'),
    });

    const result = await service.listConversationMessages({
      conversationId: conversation.id,
      currentUserId: match.userAId,
      page: 1,
      limit: 2,
    });

    expect(result).toMatchObject({
      pagination: {
        page: 1,
        limit: 2,
        total: 3,
        totalPages: 2,
      },
    });
    expect(result.data.map((message) => message.id)).toEqual(['message_a', 'message_b']);
    const firstMessage = result.data[0];

    expect(firstMessage).toBeDefined();

    if (!firstMessage) {
      throw new Error('Expected the first paginated message to be defined.');
    }

    expect(firstMessage).toMatchObject({
      senderId: match.userBId,
      sender: {
        id: match.userBId,
        name: 'Aluno B',
      },
    });
    expect(firstMessage.sender).not.toHaveProperty('email');
    expect(firstMessage.sender).not.toHaveProperty('phone');
    expect(firstMessage.sender).not.toHaveProperty('cpf');

    const secondPage = await service.listConversationMessages({
      conversationId: conversation.id,
      currentUserId: match.userBId,
      page: 2,
      limit: 2,
    });

    expect(secondPage).toMatchObject({
      pagination: {
        page: 2,
        limit: 2,
        total: 3,
        totalPages: 2,
      },
    });
    expect(secondPage.data.map((message) => message.id)).toEqual(['message_c']);
  });

  it('rejects listing messages for users outside the conversation', async () => {
    const chatRepository = new InMemoryChatRepository();
    const match = chatRepository.seedMatch({
      id: 'match_history_2',
      userAId: 'user_22',
      userBId: 'user_23',
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_history_2',
      matchId: match.id,
    });
    const service = createChatService({ chatRepository });

    await expect(
      service.listConversationMessages({
        conversationId: conversation.id,
        currentUserId: 'user_intruder',
        page: 1,
        limit: 20,
      }),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'User is not part of this conversation.',
    });
  });

  it('rejects listing messages when the conversation does not exist', async () => {
    const service = createChatService();

    await expect(
      service.listConversationMessages({
        conversationId: 'conversation_missing',
        currentUserId: 'user_24',
        page: 1,
        limit: 20,
      }),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Conversation not found.',
    });
  });
});
