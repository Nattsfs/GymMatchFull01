import type {
  Conversation,
  Match,
  Message,
  MessageStatus,
  MessageType,
  User,
} from '@prisma/client';

export const TEXT_MESSAGE_MAX_LENGTH = 1000;

export interface CreateConversationInput {
  matchId: string;
}

export interface CreateMessageInput {
  conversationId: string;
  senderId: string;
  type?: MessageType;
  status?: MessageStatus;
  content?: string | null;
  mediaReference?: string | null;
}

export interface UploadChatAudioFileInput {
  data: Buffer;
  contentType: 'audio/mpeg' | 'audio/mp4' | 'audio/wav' | 'audio/webm' | 'audio/ogg';
  extension: 'mp3' | 'mp4' | 'wav' | 'webm' | 'ogg';
}

export interface UploadChatImageFileInput {
  data: Buffer;
  contentType: 'image/jpeg' | 'image/png' | 'image/webp';
  extension: 'jpg' | 'png' | 'webp';
}

export interface UploadAudioMessageInput {
  conversationId: string;
  senderId: string;
  audio: UploadChatAudioFileInput;
}

export interface UploadImageMessageInput {
  conversationId: string;
  senderId: string;
  image: UploadChatImageFileInput;
}

export interface DeleteMessageInput {
  messageId: string;
  currentUserId: string;
}

export type ConversationRecord = Conversation;
export type SafeConversation = ConversationRecord;
export type MessageRecord = Message;
export type SafeMessage = MessageRecord;
export type SafeMessageSender = Pick<User, 'id' | 'name'>;
export type ConversationMessageRecord = MessageRecord & {
  sender: SafeMessageSender;
};
export type SafeConversationMessage = ConversationMessageRecord;
export interface MessageCreatedPayload {
  id: string;
  conversationId: string;
  senderId: string;
  type: MessageType;
  content: string | null;
  mediaReference: string | null;
  createdAt: string;
}
export interface ChatMessageCreatedEvent {
  event: 'message.created';
  data: MessageCreatedPayload;
}
export type ConversationMatchRecord = Pick<
  Match,
  'id' | 'userAId' | 'userBId' | 'status' | 'expiresAt' | 'deletedAt'
>;
export type ConversationWithMatchRecord = ConversationRecord & {
  match: ConversationMatchRecord;
};

export interface ListConversationMessagesQueryInput {
  page: number;
  limit: number;
}

export interface ListConversationMessagesInput extends ListConversationMessagesQueryInput {
  conversationId: string;
  currentUserId: string;
}

export interface ConversationMessagePaginationResult {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface ListConversationMessagesResult {
  data: SafeConversationMessage[];
  pagination: ConversationMessagePaginationResult;
}

export interface PublishMessageCreatedInput {
  message: SafeMessage;
  participantIds: string[];
}

export interface ChatMessageEventPublisherContract {
  publishMessageCreated(input: PublishMessageCreatedInput): Promise<void>;
}

export interface ChatServiceContract {
  createConversation(input: CreateConversationInput): Promise<SafeConversation>;
  findConversationByMatchId(matchId: string): Promise<SafeConversation | null>;
  getOrCreateConversation(input: CreateConversationInput): Promise<SafeConversation>;
  createMessage(input: CreateMessageInput): Promise<SafeMessage>;
  uploadAudioMessage(input: UploadAudioMessageInput): Promise<SafeMessage>;
  uploadImageMessage(input: UploadImageMessageInput): Promise<SafeMessage>;
  deleteMessage(input: DeleteMessageInput): Promise<SafeMessage>;
  findMessageById(messageId: string): Promise<SafeMessage | null>;
  listConversationMessages(
    input: ListConversationMessagesInput,
  ): Promise<ListConversationMessagesResult>;
}

export class ConversationConflictError extends Error {
  readonly field: 'matchId' | 'unknown';

  constructor(field: 'matchId' | 'unknown') {
    const fieldLabel = field === 'matchId' ? 'match conversation' : 'unique conversation field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'ConversationConflictError';
    this.field = field;
  }
}

export class ConversationMatchNotFoundError extends Error {
  constructor() {
    super('The related match was not found.');
    this.name = 'ConversationMatchNotFoundError';
  }
}
