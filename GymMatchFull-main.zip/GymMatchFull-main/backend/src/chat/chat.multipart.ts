import type { FastifyInstance, FastifyRequest } from 'fastify';

import { HttpError } from '../common/errors/http-error.js';
import {
  MAX_CHAT_AUDIO_FILE_SIZE_BYTES,
  parseSendAudioMessageInput,
} from './dto/send-audio-message.dto.js';
import {
  MAX_CHAT_IMAGE_FILE_SIZE_BYTES,
  parseSendImageMessageInput,
} from './dto/send-image-message.dto.js';

export async function parseAudioMessageUploadInput(
  request: FastifyRequest,
  app: FastifyInstance,
) {
  try {
    const file = await request.file({
      limits: {
        files: 1,
        fields: 0,
        parts: 1,
        fileSize: MAX_CHAT_AUDIO_FILE_SIZE_BYTES,
      },
    });

    if (!file) {
      throw new HttpError(400, 'audio is required and must be a file.');
    }

    return parseSendAudioMessageInput(request.params, {
      fieldName: file.fieldname,
      mimeType: file.mimetype,
      buffer: await file.toBuffer(),
    });
  } catch (error) {
    if (error instanceof HttpError) {
      throw error;
    }

    if (error instanceof app.multipartErrors.RequestFileTooLargeError) {
      throw new HttpError(
        413,
        `audio must be at most ${MAX_CHAT_AUDIO_FILE_SIZE_BYTES} bytes.`,
      );
    }

    if (
      error instanceof app.multipartErrors.FilesLimitError ||
      error instanceof app.multipartErrors.FieldsLimitError ||
      error instanceof app.multipartErrors.PartsLimitError
    ) {
      throw new HttpError(400, 'Only one audio file may be uploaded.');
    }

    if (error instanceof app.multipartErrors.InvalidMultipartContentTypeError) {
      throw new HttpError(400, 'Request must use multipart/form-data.');
    }

    throw error;
  }
}

export async function parseImageMessageUploadInput(
  request: FastifyRequest,
  app: FastifyInstance,
) {
  try {
    const file = await request.file({
      limits: {
        files: 1,
        fields: 0,
        parts: 1,
        fileSize: MAX_CHAT_IMAGE_FILE_SIZE_BYTES,
      },
    });

    if (!file) {
      throw new HttpError(400, 'image is required and must be a file.');
    }

    return parseSendImageMessageInput(request.params, {
      fieldName: file.fieldname,
      mimeType: file.mimetype,
      buffer: await file.toBuffer(),
    });
  } catch (error) {
    if (error instanceof HttpError) {
      throw error;
    }

    if (error instanceof app.multipartErrors.RequestFileTooLargeError) {
      throw new HttpError(
        413,
        `image must be at most ${MAX_CHAT_IMAGE_FILE_SIZE_BYTES} bytes.`,
      );
    }

    if (
      error instanceof app.multipartErrors.FilesLimitError ||
      error instanceof app.multipartErrors.FieldsLimitError ||
      error instanceof app.multipartErrors.PartsLimitError
    ) {
      throw new HttpError(400, 'Only one image file may be uploaded.');
    }

    if (error instanceof app.multipartErrors.InvalidMultipartContentTypeError) {
      throw new HttpError(400, 'Request must use multipart/form-data.');
    }

    throw error;
  }
}
