import type { PrismaClient } from '@prisma/client';
import {
  MatchStatus as PrismaMatchStatus,
  MessageStatus as PrismaMessageStatus,
  MessageType as PrismaMessageType,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import type { PremiumAccessServiceContract } from '../plans/premium-access.service.js';
import type { StorageServiceContract } from '../storage/storage.service.js';
import type { SafeUser } from '../users/users.types.js';
import { ChatRepository } from './chat.repository.js';
import { ChatService } from './chat.service.js';
import { TEXT_MESSAGE_MAX_LENGTH } from './chat.types.js';
import {
  CHAT_AUDIO_FORM_FIELD_NAME,
  CHAT_AUDIO_INVALID_TYPE_MESSAGE,
  MAX_CHAT_AUDIO_FILE_SIZE_BYTES,
} from './dto/send-audio-message.dto.js';
import {
  CHAT_IMAGE_FORM_FIELD_NAME,
  CHAT_IMAGE_INVALID_TYPE_MESSAGE,
  MAX_CHAT_IMAGE_FILE_SIZE_BYTES,
} from './dto/send-image-message.dto.js';
import type {
  ConversationMessageRecord,
  ConversationMatchRecord,
  ConversationRecord,
  ConversationWithMatchRecord,
  CreateConversationInput,
  CreateMessageInput,
  MessageRecord,
} from './chat.types.js';

const FIXED_NOW = new Date('2026-05-10T21:00:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedConversationInput {
  id?: string;
  matchId: string;
}

interface SeedMatchInput {
  deletedAt?: Date | null;
  expiresAt?: Date | null;
  id?: string;
  status?: PrismaMatchStatus;
  userAId?: string;
  userBId?: string;
}

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }

  getUserName(id: string): string | null {
    return this.users.find((user) => user.id === id)?.name ?? null;
  }
}

class InMemoryChatRepository {
  constructor(
    private readonly resolveSenderName: (senderId: string) => string | null = () => null,
  ) {}

  private readonly conversations: ConversationRecord[] = [];
  private readonly matches: ConversationMatchRecord[] = [];
  private readonly messages: ConversationMessageRecord[] = [];
  private nextConversationId = 1;
  private nextMessageId = 1;

  async createConversation(input: CreateConversationInput): Promise<ConversationRecord> {
    const existingConversation = this.conversations.find(
      (conversation) => conversation.matchId === input.matchId,
    );

    if (existingConversation) {
      return existingConversation;
    }

    const conversation: ConversationRecord = {
      id: `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  async findConversationByIdWithMatch(
    conversationId: string,
  ): Promise<ConversationWithMatchRecord | null> {
    const conversation = this.conversations.find((item) => item.id === conversationId);

    if (!conversation) {
      return null;
    }

    const match = this.matches.find((item) => item.id === conversation.matchId);

    if (!match) {
      return null;
    }

    return {
      ...conversation,
      match,
    };
  }

  async findConversationByMatchId(matchId: string): Promise<ConversationRecord | null> {
    return this.conversations.find((conversation) => conversation.matchId === matchId) ?? null;
  }

  async findMatchById(matchId: string): Promise<ConversationMatchRecord | null> {
    return this.matches.find((match) => match.id === matchId) ?? null;
  }

  async createMessage(input: CreateMessageInput): Promise<MessageRecord> {
    const message: ConversationMessageRecord = {
      id: `message_${this.nextMessageId++}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      sender: {
        id: input.senderId,
        name: this.resolveSenderName(input.senderId) ?? `Aluno ${input.senderId}`,
      },
    };

    this.messages.push(message);

    return toMessageRecord(message);
  }

  async findMessageById(messageId: string): Promise<MessageRecord | null> {
    const message = this.messages.find((item) => item.id === messageId);

    return message ? toMessageRecord(message) : null;
  }

  async softDeleteMessage(messageId: string): Promise<MessageRecord> {
    const message = this.messages.find((item) => item.id === messageId);

    if (!message) {
      throw new Error(`Message ${messageId} not found.`);
    }

    message.status = PrismaMessageStatus.DELETED;
    message.updatedAt = FIXED_NOW;

    return toMessageRecord(message);
  }

  async findMessagesByConversationId(
    conversationId: string,
    input: {
      skip: number;
      take: number;
      visibleStatuses: PrismaMessageStatus[];
    },
  ): Promise<ConversationMessageRecord[]> {
    return this.messages
      .filter(
        (message) =>
          message.conversationId === conversationId &&
          input.visibleStatuses.includes(message.status),
      )
      .sort(compareMessages)
      .slice(input.skip, input.skip + input.take);
  }

  async countMessagesByConversationId(
    conversationId: string,
    visibleStatuses: PrismaMessageStatus[],
  ): Promise<number> {
    return this.messages.filter(
      (message) =>
        message.conversationId === conversationId && visibleStatuses.includes(message.status),
    ).length;
  }

  seedConversation(input: SeedConversationInput): ConversationRecord {
    const conversation: ConversationRecord = {
      id: input.id ?? `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  seedMatch(input: SeedMatchInput = {}): ConversationMatchRecord {
    const index = this.matches.length + 1;
    const match: ConversationMatchRecord = {
      id: input.id ?? `match_${index}`,
      userAId: input.userAId ?? `user_${index}_a`,
      userBId: input.userBId ?? `user_${index}_b`,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  seedMessage(
    input: {
      id?: string;
      conversationId: string;
      senderId: string;
      type?: PrismaMessageType;
      status?: PrismaMessageStatus;
      content?: string | null;
      mediaReference?: string | null;
      createdAt?: Date;
      updatedAt?: Date;
    },
  ): ConversationMessageRecord {
    const message: ConversationMessageRecord = {
      id: input.id ?? `message_${this.nextMessageId++}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      sender: {
        id: input.senderId,
        name: this.resolveSenderName(input.senderId) ?? `Aluno ${input.senderId}`,
      },
    };

    this.messages.push(message);

    return message;
  }
}

class InMemoryStorageService implements StorageServiceContract {
  readonly savedFiles: Array<{
    key: string;
    contentType: string;
    data: Buffer;
  }> = [];
  readonly deletedPublicUrls: string[] = [];

  async saveFile(input: {
    key: string;
    contentType: string;
    data: Buffer;
  }): Promise<{ key: string; publicUrl: string }> {
    this.savedFiles.push({
      key: input.key,
      contentType: input.contentType,
      data: input.data,
    });

    return {
      key: input.key,
      publicUrl: `/storage/${input.key}`,
    };
  }

  async deleteFileByPublicUrl(publicUrl: string): Promise<void> {
    this.deletedPublicUrls.push(publicUrl);
  }
}

class InMemoryPremiumAccessService implements PremiumAccessServiceContract {
  private readonly premiumUserIds = new Set<string>();

  async hasPremiumChatImageAccess(userId: string): Promise<boolean> {
    return this.premiumUserIds.has(userId);
  }

  seedPremiumUser(userId: string): void {
    this.premiumUserIds.add(userId);
  }
}

function createMultipartPayload(
  parts: Array<
    | {
        type: 'file';
        fieldName: string;
        fileName: string;
        contentType: string;
        data: Buffer;
      }
    | {
        type: 'field';
        fieldName: string;
        value: string;
      }
  >,
): { boundary: string; body: Buffer } {
  const boundary = '----GymMatchChatBoundary7MA4YWxkTrZu0gW';
  const chunks: Buffer[] = [];

  for (const part of parts) {
    chunks.push(Buffer.from(`--${boundary}\r\n`, 'utf8'));

    if (part.type === 'field') {
      chunks.push(
        Buffer.from(
          `Content-Disposition: form-data; name="${part.fieldName}"\r\n\r\n${part.value}\r\n`,
          'utf8',
        ),
      );
      continue;
    }

    chunks.push(
      Buffer.from(
        `Content-Disposition: form-data; name="${part.fieldName}"; filename="${part.fileName}"\r\n`,
        'utf8',
      ),
    );
    chunks.push(Buffer.from(`Content-Type: ${part.contentType}\r\n\r\n`, 'utf8'));
    chunks.push(part.data);
    chunks.push(Buffer.from('\r\n', 'utf8'));
  }

  chunks.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));

  return {
    boundary,
    body: Buffer.concat(chunks),
  };
}

function makeMp3Buffer(): Buffer {
  return Buffer.from([0x49, 0x44, 0x33, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21]);
}

function makeJpegBuffer(): Buffer {
  return Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43, 0x00, 0x08]);
}

function makePngBuffer(): Buffer {
  return Buffer.from([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  ]);
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const chatRepository = new InMemoryChatRepository((senderId) => usersService.getUserName(senderId));
  const premiumAccessService = new InMemoryPremiumAccessService();
  const storageService = new InMemoryStorageService();
  const chatService = new ChatService({} as PrismaClient, {
    chatRepository: chatRepository as unknown as ChatRepository,
    premiumAccessService,
    storageService,
  });
  const app = buildApp({
    config,
    services: {
      chatService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    chatRepository,
    premiumAccessService,
    storageService,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

function compareMessages(
  left: Pick<ConversationMessageRecord, 'createdAt' | 'id'>,
  right: Pick<ConversationMessageRecord, 'createdAt' | 'id'>,
): number {
  const timeDiff = left.createdAt.getTime() - right.createdAt.getTime();

  if (timeDiff !== 0) {
    return timeDiff;
  }

  return left.id.localeCompare(right.id);
}

function toMessageRecord(message: ConversationMessageRecord): MessageRecord {
  return {
    id: message.id,
    conversationId: message.conversationId,
    senderId: message.senderId,
    type: message.type,
    status: message.status,
    content: message.content,
    mediaReference: message.mediaReference,
    createdAt: message.createdAt,
    updatedAt: message.updatedAt,
  };
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('GET /chat/conversations/:conversationId/messages', () => {
  it('lists paginated messages for an authenticated student in the conversation', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const participantA = usersService.seedUser({ id: 'student_1' });
    const participantB = usersService.seedUser({ id: 'student_2' });
    const match = chatRepository.seedMatch({
      id: 'match_history_1',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_history_1',
      matchId: match.id,
    });

    chatRepository.seedMessage({
      id: 'message_b',
      conversationId: conversation.id,
      senderId: participantA.id,
      content: 'Segunda por id',
      createdAt: new Date('2026-05-10T20:00:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_a',
      conversationId: conversation.id,
      senderId: participantB.id,
      content: 'Primeira por desempate',
      createdAt: new Date('2026-05-10T20:00:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_hidden',
      conversationId: conversation.id,
      senderId: participantB.id,
      status: PrismaMessageStatus.MODERATION_HIDDEN,
      content: 'Nao deve aparecer',
      createdAt: new Date('2026-05-10T20:01:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_deleted',
      conversationId: conversation.id,
      senderId: participantA.id,
      status: PrismaMessageStatus.DELETED,
      content: 'Nao deve aparecer',
      createdAt: new Date('2026-05-10T20:02:00.000Z'),
    });
    chatRepository.seedMessage({
      id: 'message_c',
      conversationId: conversation.id,
      senderId: participantA.id,
      content: 'Terceira visivel',
      createdAt: new Date('2026-05-10T20:03:00.000Z'),
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: `/chat/conversations/${conversation.id}/messages?page=1&limit=2`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, participantA)}`,
      },
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();

    expect(body).toMatchObject({
      pagination: {
        page: 1,
        limit: 2,
        total: 3,
        totalPages: 2,
      },
    });
    expect(body.data.map((message: { id: string }) => message.id)).toEqual([
      'message_a',
      'message_b',
    ]);
    expect(body.data[0]).toMatchObject({
      senderId: participantB.id,
      sender: {
        id: participantB.id,
        name: participantB.name,
      },
    });
    expect(body.data[0].sender).not.toHaveProperty('email');
    expect(body.data[0].sender).not.toHaveProperty('phone');
    expect(body.data[0].sender).not.toHaveProperty('cpf');
  });

  it('rejects listing messages without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/chat/conversations/conversation_1/messages',
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from listing messages', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/chat/conversations/conversation_1/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks users that are not part of the conversation when listing messages', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const participantA = usersService.seedUser({ id: 'student_1' });
    const participantB = usersService.seedUser({ id: 'student_2' });
    const intruder = usersService.seedUser({ id: 'student_3' });
    const match = chatRepository.seedMatch({
      id: 'match_history_2',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_history_2',
      matchId: match.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: `/chat/conversations/${conversation.id}/messages`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, intruder)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'User is not part of this conversation.',
    });
  });

  it('rejects invalid pagination query params when listing messages', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const participantA = usersService.seedUser({ id: 'student_1' });
    const participantB = usersService.seedUser({ id: 'student_2' });
    const match = chatRepository.seedMatch({
      id: 'match_history_3',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_history_3',
      matchId: match.id,
    });

    await app.ready();

    const invalidPageResponse = await app.inject({
      method: 'GET',
      url: `/chat/conversations/${conversation.id}/messages?page=0`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, participantA)}`,
      },
    });

    expect(invalidPageResponse.statusCode).toBe(400);
    expect(invalidPageResponse.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'page must be a positive integer when provided.',
    });

    const invalidLimitResponse = await app.inject({
      method: 'GET',
      url: `/chat/conversations/${conversation.id}/messages?limit=51`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, participantA)}`,
      },
    });

    expect(invalidLimitResponse.statusCode).toBe(400);
    expect(invalidLimitResponse.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'limit must be less than or equal to 50.',
    });
  });
});

describe('POST /chat/conversations/:conversationId/messages', () => {
  it('creates a text message for an authenticated student in the conversation', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const recipient = usersService.seedUser({ id: 'student_2' });
    const match = chatRepository.seedMatch({
      id: 'match_active_1',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_active_1',
      matchId: match.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/messages`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        content: '  Bora treinar pernas hoje?  ',
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      conversationId: conversation.id,
      senderId: sender.id,
      type: PrismaMessageType.TEXT,
      status: PrismaMessageStatus.SENT,
      content: 'Bora treinar pernas hoje?',
      mediaReference: null,
    });
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_1/messages',
      payload: {
        content: 'Mensagem sem token',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from sending chat messages', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_1/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        content: 'Mensagem de admin',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks users that are not part of the conversation match', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const participantA = usersService.seedUser({ id: 'student_1' });
    const participantB = usersService.seedUser({ id: 'student_2' });
    const intruder = usersService.seedUser({ id: 'student_3' });
    const match = chatRepository.seedMatch({
      id: 'match_active_2',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_active_2',
      matchId: match.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/messages`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, intruder)}`,
      },
      payload: {
        content: 'Tentando entrar na conversa',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Sender is not part of this conversation.',
    });
  });

  it('blocks messages when the match is blocked', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const recipient = usersService.seedUser({ id: 'student_2' });
    const match = chatRepository.seedMatch({
      id: 'match_blocked_1',
      status: PrismaMatchStatus.BLOCKED,
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_blocked_1',
      matchId: match.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/messages`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        content: 'Mensagem em match bloqueado',
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Messages can only be sent for active matches.',
    });
  });

  it('rejects blank messages', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_1/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        content: '   ',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'content is required and must be a non-empty string.',
    });
  });

  it('rejects messages that exceed the maximum length', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_1/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        content: 'a'.repeat(TEXT_MESSAGE_MAX_LENGTH + 1),
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: `content must be at most ${TEXT_MESSAGE_MAX_LENGTH} characters long.`,
    });
  });
});

describe('POST /chat/conversations/:conversationId/audio', () => {
  it('uploads a valid audio message for an authenticated student in the conversation', async () => {
    const { app, chatRepository, storageService, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_audio_1' });
    const recipient = usersService.seedUser({ id: 'student_audio_2' });
    const match = chatRepository.seedMatch({
      id: 'match_audio_route_1',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_route_1',
      matchId: match.id,
    });

    await app.ready();

    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.mp3',
        contentType: 'audio/mpeg',
        data: makeMp3Buffer(),
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/audio`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      conversationId: conversation.id,
      senderId: sender.id,
      type: PrismaMessageType.AUDIO,
      status: PrismaMessageStatus.SENT,
      content: null,
    });
    expect(response.json().mediaReference).toMatch(
      new RegExp(`^/storage/chat-audios/${conversation.id}/${sender.id}/.+\\.mp3$`),
    );
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.savedFiles[0]).toMatchObject({
      contentType: 'audio/mpeg',
      data: makeMp3Buffer(),
    });
  });

  it('rejects audio uploads without an access token', async () => {
    const { app } = createTestApp();
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.mp3',
        contentType: 'audio/mpeg',
        data: makeMp3Buffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_audio_route_2/audio',
      headers: {
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from uploading chat audio', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_audio_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.mp3',
        contentType: 'audio/mpeg',
        data: makeMp3Buffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_audio_route_3/audio',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks users outside the conversation match from uploading audio', async () => {
    const { app, chatRepository, storageService, usersService } = createTestApp();
    const participantA = usersService.seedUser({ id: 'student_audio_3' });
    const participantB = usersService.seedUser({ id: 'student_audio_4' });
    const intruder = usersService.seedUser({ id: 'student_audio_5' });
    const match = chatRepository.seedMatch({
      id: 'match_audio_route_4',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_route_4',
      matchId: match.id,
    });
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.mp3',
        contentType: 'audio/mpeg',
        data: makeMp3Buffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/audio`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, intruder)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Sender is not part of this conversation.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('blocks audio uploads when the match has expired', async () => {
    const { app, chatRepository, storageService, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_audio_6' });
    const recipient = usersService.seedUser({ id: 'student_audio_7' });
    const match = chatRepository.seedMatch({
      id: 'match_audio_route_5',
      userAId: sender.id,
      userBId: recipient.id,
      expiresAt: new Date('2000-01-01T00:00:00.000Z'),
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_route_5',
      matchId: match.id,
    });
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.mp3',
        contentType: 'audio/mpeg',
        data: makeMp3Buffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/audio`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Messages can only be sent for active matches.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('rejects requests without an audio file', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_audio_8' });
    const recipient = usersService.seedUser({ id: 'student_audio_9' });
    const match = chatRepository.seedMatch({
      id: 'match_audio_route_6',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_route_6',
      matchId: match.id,
    });
    const multipartPayload = createMultipartPayload([]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/audio`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'audio is required and must be a file.',
    });
  });

  it('rejects audio files with invalid content types', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_audio_10' });
    const recipient = usersService.seedUser({ id: 'student_audio_11' });
    const match = chatRepository.seedMatch({
      id: 'match_audio_route_7',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_route_7',
      matchId: match.id,
    });
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.txt',
        contentType: 'text/plain',
        data: Buffer.from('not-an-audio-file', 'utf8'),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/audio`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: CHAT_AUDIO_INVALID_TYPE_MESSAGE,
    });
  });

  it('rejects audio files that exceed the maximum size', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_audio_12' });
    const recipient = usersService.seedUser({ id: 'student_audio_13' });
    const match = chatRepository.seedMatch({
      id: 'match_audio_route_8',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_audio_route_8',
      matchId: match.id,
    });
    const oversizedAudio = Buffer.concat([
      makeMp3Buffer(),
      Buffer.alloc(MAX_CHAT_AUDIO_FILE_SIZE_BYTES + 1),
    ]);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_AUDIO_FORM_FIELD_NAME,
        fileName: 'voice.mp3',
        contentType: 'audio/mpeg',
        data: oversizedAudio,
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/audio`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(413);
    expect(response.json()).toEqual({
      statusCode: 413,
      error: 'Payload Too Large',
      message: `audio must be at most ${MAX_CHAT_AUDIO_FILE_SIZE_BYTES} bytes.`,
    });
  });
});

describe('POST /chat/conversations/:conversationId/image', () => {
  it('uploads a valid image message for a premium authenticated student in the conversation', async () => {
    const { app, chatRepository, premiumAccessService, storageService, usersService } =
      createTestApp();
    const sender = usersService.seedUser({ id: 'student_image_1' });
    const recipient = usersService.seedUser({ id: 'student_image_2' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_1',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_1',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(sender.id);

    await app.ready();

    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      conversationId: conversation.id,
      senderId: sender.id,
      type: PrismaMessageType.IMAGE,
      status: PrismaMessageStatus.SENT,
      content: null,
    });
    expect(response.json().mediaReference).toMatch(
      new RegExp(`^/storage/chat-images/${conversation.id}/${sender.id}/.+\\.jpg$`),
    );
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.savedFiles[0]).toMatchObject({
      contentType: 'image/jpeg',
      data: makeJpegBuffer(),
    });
  });

  it('rejects image uploads without an access token', async () => {
    const { app } = createTestApp();
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_image_route_2/image',
      headers: {
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from uploading chat images', async () => {
    const { app, premiumAccessService, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_image_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    premiumAccessService.seedPremiumUser(admin.id);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/chat/conversations/conversation_image_route_3/image',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks users outside the conversation match from uploading images even if marked premium', async () => {
    const { app, chatRepository, premiumAccessService, storageService, usersService } =
      createTestApp();
    const participantA = usersService.seedUser({ id: 'student_image_3' });
    const participantB = usersService.seedUser({ id: 'student_image_4' });
    const intruder = usersService.seedUser({ id: 'student_image_5' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_4',
      userAId: participantA.id,
      userBId: participantB.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_4',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(intruder.id);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, intruder)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Sender is not part of this conversation.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('blocks image uploads when the match has expired', async () => {
    const { app, chatRepository, premiumAccessService, storageService, usersService } =
      createTestApp();
    const sender = usersService.seedUser({ id: 'student_image_6' });
    const recipient = usersService.seedUser({ id: 'student_image_7' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_5',
      userAId: sender.id,
      userBId: recipient.id,
      expiresAt: new Date('2000-01-01T00:00:00.000Z'),
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_5',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(sender.id);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Messages can only be sent for active matches.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('blocks free users from uploading chat images', async () => {
    const { app, chatRepository, storageService, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_image_8' });
    const recipient = usersService.seedUser({ id: 'student_image_9' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_6',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_6',
      matchId: match.id,
    });
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Only premium users can send chat images.',
    });
    expect(storageService.savedFiles).toEqual([]);
  });

  it('rejects requests without an image file', async () => {
    const { app, chatRepository, premiumAccessService, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_image_10' });
    const recipient = usersService.seedUser({ id: 'student_image_11' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_7',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_7',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(sender.id);
    const multipartPayload = createMultipartPayload([]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'image is required and must be a file.',
    });
  });

  it('rejects image files with invalid content types', async () => {
    const { app, chatRepository, premiumAccessService, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_image_12' });
    const recipient = usersService.seedUser({ id: 'student_image_13' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_8',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_8',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(sender.id);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.txt',
        contentType: 'text/plain',
        data: Buffer.from('not-an-image-file', 'utf8'),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: CHAT_IMAGE_INVALID_TYPE_MESSAGE,
    });
  });

  it('rejects image files that exceed the maximum size', async () => {
    const { app, chatRepository, premiumAccessService, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_image_14' });
    const recipient = usersService.seedUser({ id: 'student_image_15' });
    const match = chatRepository.seedMatch({
      id: 'match_image_route_9',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_image_route_9',
      matchId: match.id,
    });
    premiumAccessService.seedPremiumUser(sender.id);
    const oversizedImage = Buffer.concat([
      makePngBuffer(),
      Buffer.alloc(MAX_CHAT_IMAGE_FILE_SIZE_BYTES + 1),
    ]);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: CHAT_IMAGE_FORM_FIELD_NAME,
        fileName: 'photo.png',
        contentType: 'image/png',
        data: oversizedImage,
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: `/chat/conversations/${conversation.id}/image`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(413);
    expect(response.json()).toEqual({
      statusCode: 413,
      error: 'Payload Too Large',
      message: `image must be at most ${MAX_CHAT_IMAGE_FILE_SIZE_BYTES} bytes.`,
    });
  });
});

describe('DELETE /chat/messages/:messageId', () => {
  it('soft deletes a sender message and hides it from the default conversation listing', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_delete_1' });
    const recipient = usersService.seedUser({ id: 'student_delete_2' });
    const match = chatRepository.seedMatch({
      id: 'match_delete_1',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_delete_1',
      matchId: match.id,
    });
    const message = chatRepository.seedMessage({
      id: 'message_delete_1',
      conversationId: conversation.id,
      senderId: sender.id,
      content: 'Mensagem apagada logicamente.',
    });

    await app.ready();

    const deleteResponse = await app.inject({
      method: 'DELETE',
      url: `/chat/messages/${message.id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
    });

    expect(deleteResponse.statusCode).toBe(204);
    expect(deleteResponse.body).toBe('');
    await expect(chatRepository.findMessageById(message.id)).resolves.toMatchObject({
      id: message.id,
      status: PrismaMessageStatus.DELETED,
      content: 'Mensagem apagada logicamente.',
    });

    const listResponse = await app.inject({
      method: 'GET',
      url: `/chat/conversations/${conversation.id}/messages`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
    });

    expect(listResponse.statusCode).toBe(200);
    expect(listResponse.json()).toMatchObject({
      data: [],
      pagination: {
        page: 1,
        limit: 20,
        total: 0,
        totalPages: 1,
      },
    });
  });

  it('rejects delete requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'DELETE',
      url: '/chat/messages/message_1',
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from deleting chat messages', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_delete_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'DELETE',
      url: '/chat/messages/message_1',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('prevents a student from deleting another sender message', async () => {
    const { app, chatRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_delete_3' });
    const recipient = usersService.seedUser({ id: 'student_delete_4' });
    const match = chatRepository.seedMatch({
      id: 'match_delete_2',
      userAId: sender.id,
      userBId: recipient.id,
    });
    const conversation = chatRepository.seedConversation({
      id: 'conversation_delete_2',
      matchId: match.id,
    });
    const message = chatRepository.seedMessage({
      id: 'message_delete_2',
      conversationId: conversation.id,
      senderId: sender.id,
      content: 'Somente o remetente pode apagar.',
    });

    await app.ready();

    const response = await app.inject({
      method: 'DELETE',
      url: `/chat/messages/${message.id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, recipient)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Only the sender can delete this message.',
    });
    await expect(chatRepository.findMessageById(message.id)).resolves.toMatchObject({
      id: message.id,
      status: PrismaMessageStatus.SENT,
      content: 'Somente o remetente pode apagar.',
    });
  });

  it('returns not found when the message does not exist', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_delete_5' });

    await app.ready();

    const response = await app.inject({
      method: 'DELETE',
      url: '/chat/messages/message_missing',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Message not found.',
    });
  });
});
