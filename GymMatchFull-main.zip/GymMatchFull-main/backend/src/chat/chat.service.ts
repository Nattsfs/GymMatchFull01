import { randomUUID } from 'node:crypto';

import {
  MatchStatus as PrismaMatchStatus,
  MessageStatus as PrismaMessageStatus,
  MessageType as PrismaMessageType,
  Prisma,
  type PrismaClient,
} from '@prisma/client';

import { HttpError } from '../common/errors/http-error.js';
import {
  PremiumAccessService,
  type PremiumAccessServiceContract,
} from '../plans/premium-access.service.js';
import { LocalStorageService } from '../storage/local-storage.service.js';
import type { StorageServiceContract } from '../storage/storage.service.js';
import { ChatRepository } from './chat.repository.js';
import type {
  ChatMessageEventPublisherContract,
  ChatServiceContract,
  ConversationMatchRecord,
  CreateConversationInput,
  DeleteMessageInput,
  CreateMessageInput,
  ListConversationMessagesInput,
  ListConversationMessagesResult,
  SafeConversation,
  SafeMessage,
  UploadAudioMessageInput,
  UploadImageMessageInput,
} from './chat.types.js';
import {
  ConversationConflictError,
  ConversationMatchNotFoundError,
  TEXT_MESSAGE_MAX_LENGTH,
} from './chat.types.js';

const MATCH_NOT_FOUND_MESSAGE = 'Match not found.';
const CONVERSATION_ALREADY_EXISTS_MESSAGE = 'Conversation already exists for this match.';
const CONVERSATION_MATCH_INACTIVE_MESSAGE = 'Conversation can only be created for active matches.';
const CONVERSATION_NOT_FOUND_MESSAGE = 'Conversation not found.';
const CONVERSATION_SENDER_FORBIDDEN_MESSAGE = 'Sender is not part of this conversation.';
const CONVERSATION_VIEWER_FORBIDDEN_MESSAGE = 'User is not part of this conversation.';
const MESSAGE_NOT_FOUND_MESSAGE = 'Message not found.';
const MESSAGE_DELETE_FORBIDDEN_MESSAGE = 'Only the sender can delete this message.';
const MESSAGE_MATCH_INACTIVE_MESSAGE = 'Messages can only be sent for active matches.';
const IMAGE_MESSAGE_PREMIUM_REQUIRED_MESSAGE = 'Only premium users can send chat images.';
const TEXT_MESSAGE_CONTENT_REQUIRED_MESSAGE = 'Text messages require content.';
const TEXT_MESSAGE_CONTENT_TOO_LONG_MESSAGE = `content must be at most ${TEXT_MESSAGE_MAX_LENGTH} characters long.`;
const MEDIA_MESSAGE_REFERENCE_REQUIRED_MESSAGE =
  'Audio and image messages require a media reference.';
const STUDENT_VISIBLE_MESSAGE_STATUSES = [PrismaMessageStatus.SENT];
const NOOP_CHAT_MESSAGE_EVENT_PUBLISHER: ChatMessageEventPublisherContract = {
  async publishMessageCreated(): Promise<void> {},
};

type ChatRepositoryContract = Pick<
  ChatRepository,
  | 'createConversation'
  | 'findConversationByIdWithMatch'
  | 'findConversationByMatchId'
  | 'findMatchById'
  | 'createMessage'
  | 'findMessageById'
  | 'softDeleteMessage'
  | 'findMessagesByConversationId'
  | 'countMessagesByConversationId'
>;

type DatabaseClient = PrismaClient | Prisma.TransactionClient;

interface ChatServiceDependencies {
  chatRepository?: ChatRepositoryContract;
  messageEventPublisher?: ChatMessageEventPublisherContract;
  premiumAccessService?: PremiumAccessServiceContract;
  storageService?: StorageServiceContract;
}

export class ChatService implements ChatServiceContract {
  private readonly chatRepository: ChatRepositoryContract;
  private readonly messageEventPublisher: ChatMessageEventPublisherContract;
  private readonly premiumAccessService: PremiumAccessServiceContract;
  private readonly storageService: StorageServiceContract;

  constructor(prisma: DatabaseClient, dependencies: ChatServiceDependencies = {}) {
    this.chatRepository = dependencies.chatRepository ?? new ChatRepository(prisma);
    this.messageEventPublisher =
      dependencies.messageEventPublisher ?? NOOP_CHAT_MESSAGE_EVENT_PUBLISHER;
    this.premiumAccessService =
      dependencies.premiumAccessService ?? new PremiumAccessService();
    this.storageService = dependencies.storageService ?? new LocalStorageService();
  }

  async createConversation(input: CreateConversationInput): Promise<SafeConversation> {
    await this.ensureMatchCanHaveConversation(input.matchId);

    try {
      return await this.chatRepository.createConversation(input);
    } catch (error) {
      this.throwConversationWriteError(error);
    }
  }

  findConversationByMatchId(matchId: string): Promise<SafeConversation | null> {
    return this.chatRepository.findConversationByMatchId(matchId);
  }

  async getOrCreateConversation(input: CreateConversationInput): Promise<SafeConversation> {
    await this.ensureMatchCanHaveConversation(input.matchId);

    const existingConversation = await this.chatRepository.findConversationByMatchId(input.matchId);

    if (existingConversation) {
      return existingConversation;
    }

    try {
      return await this.chatRepository.createConversation(input);
    } catch (error) {
      if (error instanceof ConversationConflictError && error.field === 'matchId') {
        const concurrentConversation = await this.chatRepository.findConversationByMatchId(
          input.matchId,
        );

        if (concurrentConversation) {
          return concurrentConversation;
        }
      }

      this.throwConversationWriteError(error);
    }
  }

  async createMessage(input: CreateMessageInput): Promise<SafeMessage> {
    const conversation = await this.ensureConversationParticipant(
      input.conversationId,
      input.senderId,
      CONVERSATION_SENDER_FORBIDDEN_MESSAGE,
    );

    this.ensureMatchActiveForMessaging(conversation.match);

    const type = input.type ?? PrismaMessageType.TEXT;
    const content = normalizeOptionalText(input.content);
    const mediaReference = normalizeOptionalText(input.mediaReference);

    if (type === PrismaMessageType.TEXT && content === null) {
      throw new HttpError(400, TEXT_MESSAGE_CONTENT_REQUIRED_MESSAGE);
    }

    if (content !== null && content.length > TEXT_MESSAGE_MAX_LENGTH) {
      throw new HttpError(400, TEXT_MESSAGE_CONTENT_TOO_LONG_MESSAGE);
    }

    if (
      (type === PrismaMessageType.AUDIO || type === PrismaMessageType.IMAGE) &&
      mediaReference === null
    ) {
      throw new HttpError(400, MEDIA_MESSAGE_REFERENCE_REQUIRED_MESSAGE);
    }

    const message = await this.chatRepository.createMessage({
      ...input,
      type,
      content,
      mediaReference,
    });

    await this.publishMessageCreated(message, conversation.match);

    return message;
  }

  async uploadAudioMessage(input: UploadAudioMessageInput): Promise<SafeMessage> {
    const conversation = await this.ensureConversationParticipant(
      input.conversationId,
      input.senderId,
      CONVERSATION_SENDER_FORBIDDEN_MESSAGE,
    );

    this.ensureMatchActiveForMessaging(conversation.match);

    const storedFile = await this.storageService.saveFile({
      key: buildChatAudioStorageKey(
        input.conversationId,
        input.senderId,
        input.audio.extension,
      ),
      contentType: input.audio.contentType,
      data: input.audio.data,
    });

    try {
      const message = await this.chatRepository.createMessage({
        conversationId: input.conversationId,
        senderId: input.senderId,
        type: PrismaMessageType.AUDIO,
        content: null,
        mediaReference: storedFile.publicUrl,
      });

      await this.publishMessageCreated(message, conversation.match);

      return message;
    } catch (error) {
      await this.storageService.deleteFileByPublicUrl(storedFile.publicUrl).catch(() => undefined);
      throw error;
    }
  }

  async uploadImageMessage(input: UploadImageMessageInput): Promise<SafeMessage> {
    const conversation = await this.ensureConversationParticipant(
      input.conversationId,
      input.senderId,
      CONVERSATION_SENDER_FORBIDDEN_MESSAGE,
    );

    this.ensureMatchActiveForMessaging(conversation.match);

    const hasPremiumAccess = await this.premiumAccessService.hasPremiumChatImageAccess(
      input.senderId,
    );

    if (!hasPremiumAccess) {
      throw new HttpError(403, IMAGE_MESSAGE_PREMIUM_REQUIRED_MESSAGE);
    }

    const storedFile = await this.storageService.saveFile({
      key: buildChatImageStorageKey(
        input.conversationId,
        input.senderId,
        input.image.extension,
      ),
      contentType: input.image.contentType,
      data: input.image.data,
    });

    try {
      const message = await this.chatRepository.createMessage({
        conversationId: input.conversationId,
        senderId: input.senderId,
        type: PrismaMessageType.IMAGE,
        content: null,
        mediaReference: storedFile.publicUrl,
      });

      await this.publishMessageCreated(message, conversation.match);

      return message;
    } catch (error) {
      await this.storageService.deleteFileByPublicUrl(storedFile.publicUrl).catch(() => undefined);
      throw error;
    }
  }

  findMessageById(messageId: string): Promise<SafeMessage | null> {
    return this.chatRepository.findMessageById(messageId);
  }

  async deleteMessage(input: DeleteMessageInput): Promise<SafeMessage> {
    const message = await this.chatRepository.findMessageById(input.messageId);

    if (!message) {
      throw new HttpError(404, MESSAGE_NOT_FOUND_MESSAGE);
    }

    if (message.senderId !== input.currentUserId) {
      throw new HttpError(403, MESSAGE_DELETE_FORBIDDEN_MESSAGE);
    }

    if (message.status === PrismaMessageStatus.DELETED) {
      return message;
    }

    return this.chatRepository.softDeleteMessage(input.messageId);
  }

  async listConversationMessages(
    input: ListConversationMessagesInput,
  ): Promise<ListConversationMessagesResult> {
    await this.ensureConversationParticipant(
      input.conversationId,
      input.currentUserId,
      CONVERSATION_VIEWER_FORBIDDEN_MESSAGE,
    );

    const skip = calculateSkip(input.page, input.limit);
    const [messages, total] = await Promise.all([
      this.chatRepository.findMessagesByConversationId(input.conversationId, {
        skip,
        take: input.limit,
        visibleStatuses: STUDENT_VISIBLE_MESSAGE_STATUSES,
      }),
      this.chatRepository.countMessagesByConversationId(
        input.conversationId,
        STUDENT_VISIBLE_MESSAGE_STATUSES,
      ),
    ]);

    return {
      data: messages,
      pagination: {
        page: input.page,
        limit: input.limit,
        total,
        totalPages: Math.max(1, Math.ceil(total / input.limit)),
      },
    };
  }

  private async ensureMatchCanHaveConversation(matchId: string): Promise<ConversationMatchRecord> {
    const match = await this.chatRepository.findMatchById(matchId);

    if (!match || match.deletedAt !== null) {
      throw new HttpError(404, MATCH_NOT_FOUND_MESSAGE);
    }

    if (match.status !== PrismaMatchStatus.ACTIVE) {
      throw new HttpError(409, CONVERSATION_MATCH_INACTIVE_MESSAGE);
    }

    return match;
  }

  private async ensureConversationParticipant(
    conversationId: string,
    userId: string,
    forbiddenMessage: string,
  ) {
    const conversation = await this.chatRepository.findConversationByIdWithMatch(conversationId);

    if (!conversation) {
      throw new HttpError(404, CONVERSATION_NOT_FOUND_MESSAGE);
    }

    if (userId !== conversation.match.userAId && userId !== conversation.match.userBId) {
      throw new HttpError(403, forbiddenMessage);
    }

    return conversation;
  }

  private ensureMatchActiveForMessaging(match: ConversationMatchRecord): void {
    if (isMatchInactiveForMessaging(match)) {
      throw new HttpError(409, MESSAGE_MATCH_INACTIVE_MESSAGE);
    }
  }

  private async publishMessageCreated(
    message: SafeMessage,
    match: ConversationMatchRecord,
  ): Promise<void> {
    await this.messageEventPublisher.publishMessageCreated({
      message,
      participantIds: [match.userAId, match.userBId],
    });
  }

  private throwConversationWriteError(error: unknown): never {
    if (error instanceof ConversationMatchNotFoundError) {
      throw new HttpError(404, MATCH_NOT_FOUND_MESSAGE);
    }

    if (error instanceof ConversationConflictError && error.field === 'matchId') {
      throw new HttpError(409, CONVERSATION_ALREADY_EXISTS_MESSAGE);
    }

    throw error;
  }
}

function calculateSkip(page: number, limit: number): number {
  return (page - 1) * limit;
}

function isMatchInactiveForMessaging(match: ConversationMatchRecord): boolean {
  if (match.deletedAt !== null || match.status !== PrismaMatchStatus.ACTIVE) {
    return true;
  }

  return match.expiresAt !== null && match.expiresAt.getTime() <= Date.now();
}

function normalizeOptionalText(value: string | null | undefined): string | null {
  if (value === undefined || value === null) {
    return null;
  }

  const normalized = value.trim();

  return normalized.length > 0 ? normalized : null;
}

function buildChatAudioStorageKey(
  conversationId: string,
  senderId: string,
  extension: UploadAudioMessageInput['audio']['extension'],
): string {
  return `chat-audios/${conversationId}/${senderId}/${randomUUID()}.${extension}`;
}

function buildChatImageStorageKey(
  conversationId: string,
  senderId: string,
  extension: UploadImageMessageInput['image']['extension'],
): string {
  return `chat-images/${conversationId}/${senderId}/${randomUUID()}.${extension}`;
}
