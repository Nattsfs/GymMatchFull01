import { HttpError } from '../../common/errors/http-error.js';
import type { CreateMessageReportForCurrentUserInput } from '../reports.types.js';

interface CreateMessageReportRequestBody {
  description?: unknown;
  messageId?: unknown;
  reason?: unknown;
}

export function parseCreateMessageReportInput(
  payload: unknown,
): CreateMessageReportForCurrentUserInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as CreateMessageReportRequestBody;

  return {
    messageId: parseRequiredString(body.messageId, 'messageId'),
    reason: parseRequiredString(body.reason, 'reason'),
    ...(body.description !== undefined
      ? { description: parseOptionalDescription(body.description) }
      : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseRequiredString(value: unknown, field: string): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} is required and must be a string.`);
  }

  const normalizedValue = value.trim();

  if (normalizedValue.length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return normalizedValue;
}

function parseOptionalDescription(value: unknown): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'description must be a string when provided.');
  }

  return value.trim();
}
