import { HttpError } from '../../common/errors/http-error.js';

interface UpdateReportUrgencyRequestBody {
  isUrgent?: unknown;
}

export function parseUpdateReportUrgencyInput(payload: unknown): boolean {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as UpdateReportUrgencyRequestBody;

  if (typeof body.isUrgent !== 'boolean') {
    throw new HttpError(400, 'isUrgent is required and must be a boolean.');
  }

  return body.isUrgent;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
