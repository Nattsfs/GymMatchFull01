import { ReportStatus as PrismaReportStatus } from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';

interface UpdateReportStatusRequestBody {
  status?: unknown;
}

export function parseUpdateReportStatusInput(payload: unknown): PrismaReportStatus {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as UpdateReportStatusRequestBody;

  if (typeof body.status !== 'string') {
    throw new HttpError(400, 'status is required and must be a string.');
  }

  const normalizedValue = body.status.trim().toUpperCase();

  if (
    normalizedValue === PrismaReportStatus.OPEN ||
    normalizedValue === PrismaReportStatus.IN_REVIEW ||
    normalizedValue === PrismaReportStatus.RESOLVED ||
    normalizedValue === PrismaReportStatus.REJECTED
  ) {
    return normalizedValue;
  }

  throw new HttpError(400, 'status must be one of: OPEN, IN_REVIEW, RESOLVED, REJECTED.');
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
