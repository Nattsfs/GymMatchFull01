import {
  ReportReason as PrismaReportReason,
  ReportStatus as PrismaReportStatus,
  ReportType as PrismaReportType,
} from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import type { ListAdminReportsQueryInput } from '../reports.types.js';

interface ListReportsQuery {
  isUrgent?: unknown;
  limit?: unknown;
  page?: unknown;
  reason?: unknown;
  status?: unknown;
  type?: unknown;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 50;

export function parseListReportsQuery(payload: unknown): ListAdminReportsQueryInput {
  if (!isObject(payload)) {
    return {
      page: DEFAULT_PAGE,
      limit: DEFAULT_LIMIT,
    };
  }

  const query = payload as ListReportsQuery;
  const page = parsePositiveInteger(query.page, 'page', DEFAULT_PAGE);
  const limit = parsePositiveInteger(query.limit, 'limit', DEFAULT_LIMIT, MAX_LIMIT);
  const status = parseOptionalStatus(query.status);
  const isUrgent = parseOptionalBoolean(query.isUrgent, 'isUrgent');
  const type = parseOptionalType(query.type);
  const reason = parseOptionalReason(query.reason);

  return {
    page,
    limit,
    ...(status !== undefined ? { status } : {}),
    ...(isUrgent !== undefined ? { isUrgent } : {}),
    ...(type !== undefined ? { type } : {}),
    ...(reason !== undefined ? { reason } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parsePositiveInteger(
  value: unknown,
  field: string,
  fallback: number,
  max?: number,
): number {
  if (value === undefined) {
    return fallback;
  }

  const stringValue = typeof value === 'number' ? String(value) : value;

  if (typeof stringValue !== 'string') {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const normalizedValue = stringValue.trim();

  if (!/^[1-9]\d*$/.test(normalizedValue)) {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    throw new HttpError(400, `${field} must be less than or equal to ${max}.`);
  }

  return parsedValue;
}

function parseOptionalBoolean(value: unknown, field: string): boolean | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value === 'boolean') {
    return value;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be true or false when provided.`);
  }

  const normalizedValue = value.trim().toLowerCase();

  if (normalizedValue === 'true') {
    return true;
  }

  if (normalizedValue === 'false') {
    return false;
  }

  throw new HttpError(400, `${field} must be true or false when provided.`);
}

function parseOptionalStatus(value: unknown): PrismaReportStatus | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'status must be a string when provided.');
  }

  const normalizedValue = value.trim().toUpperCase();

  if (
    normalizedValue === PrismaReportStatus.OPEN ||
    normalizedValue === PrismaReportStatus.IN_REVIEW ||
    normalizedValue === PrismaReportStatus.RESOLVED ||
    normalizedValue === PrismaReportStatus.REJECTED
  ) {
    return normalizedValue;
  }

  throw new HttpError(400, 'status must be one of: OPEN, IN_REVIEW, RESOLVED, REJECTED.');
}

function parseOptionalType(value: unknown): PrismaReportType | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'type must be a string when provided.');
  }

  const normalizedValue = value.trim().toUpperCase();

  if (
    normalizedValue === PrismaReportType.USER ||
    normalizedValue === PrismaReportType.PROFILE ||
    normalizedValue === PrismaReportType.MESSAGE ||
    normalizedValue === PrismaReportType.CONVERSATION
  ) {
    return normalizedValue;
  }

  throw new HttpError(400, 'type must be one of: USER, PROFILE, MESSAGE, CONVERSATION.');
}

function parseOptionalReason(value: unknown): PrismaReportReason | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'reason must be a string when provided.');
  }

  const normalizedValue = value.trim().toUpperCase();

  if (
    normalizedValue === PrismaReportReason.HARASSMENT ||
    normalizedValue === PrismaReportReason.FAKE_PROFILE ||
    normalizedValue === PrismaReportReason.OFFENSIVE_LANGUAGE ||
    normalizedValue === PrismaReportReason.SPAM ||
    normalizedValue === PrismaReportReason.INAPPROPRIATE_BEHAVIOR ||
    normalizedValue === PrismaReportReason.RACISM ||
    normalizedValue === PrismaReportReason.OTHER
  ) {
    return normalizedValue;
  }

  throw new HttpError(
    400,
    'reason must be one of: HARASSMENT, FAKE_PROFILE, OFFENSIVE_LANGUAGE, SPAM, INAPPROPRIATE_BEHAVIOR, RACISM, OTHER.',
  );
}
