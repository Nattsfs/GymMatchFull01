import type { SafeUser } from '../users/users.types.js';
import type {
  AdminReportMessageRecord,
  ReportRecord,
  SafeAdminReportDetail,
  SafeAdminReportListItem,
  SafeAdminReportUserSummary,
} from './reports.types.js';

export function serializeAdminReportUserSummary(
  user: Pick<SafeUser, 'id' | 'name' | 'role' | 'status'>,
): SafeAdminReportUserSummary {
  return {
    id: user.id,
    name: user.name,
    role: user.role,
    status: user.status,
  };
}

export function serializeAdminReportListItem(
  report: ReportRecord,
  reporterUser: Pick<SafeUser, 'id' | 'name' | 'role' | 'status'>,
  reportedUser: Pick<SafeUser, 'id' | 'name' | 'role' | 'status'>,
): SafeAdminReportListItem {
  return {
    ...report,
    reporterUser: serializeAdminReportUserSummary(reporterUser),
    reportedUser: serializeAdminReportUserSummary(reportedUser),
  };
}

export function serializeAdminReportDetail(
  report: ReportRecord,
  reporterUser: Pick<SafeUser, 'id' | 'name' | 'role' | 'status'>,
  reportedUser: Pick<SafeUser, 'id' | 'name' | 'role' | 'status'>,
  message: AdminReportMessageRecord | null,
): SafeAdminReportDetail {
  return {
    ...serializeAdminReportListItem(report, reporterUser, reportedUser),
    message: message
      ? {
          ...message,
        }
      : null,
  };
}
