import { Prisma } from '@prisma/client';
import type { PrismaClient, ReportStatus } from '@prisma/client';

import type {
  AdminReportMessageRecord,
  CreateReportInput,
  ListAdminReportsQueryInput,
  ReportConversationContextRecord,
  ReportMessageContextRecord,
  ReportRecord,
} from './reports.types.js';
import { ReportSelfReportError } from './reports.types.js';

type DatabaseClient = PrismaClient | Prisma.TransactionClient;

const REPORT_ORDER_BY: Prisma.ReportOrderByWithRelationInput[] = [
  { createdAt: 'desc' },
  { id: 'asc' },
];

const REPORT_MESSAGE_CONTEXT_SELECT = {
  id: true,
  conversationId: true,
  senderId: true,
} satisfies Prisma.MessageSelect;

const REPORT_CONVERSATION_CONTEXT_SELECT = {
  id: true,
  match: {
    select: {
      userAId: true,
      userBId: true,
    },
  },
} satisfies Prisma.ConversationSelect;

const ADMIN_REPORT_MESSAGE_SELECT = {
  id: true,
  conversationId: true,
  senderId: true,
  type: true,
  status: true,
  content: true,
  mediaReference: true,
  createdAt: true,
} satisfies Prisma.MessageSelect;

function isSelfReportConstraintError(error: Prisma.PrismaClientKnownRequestError): boolean {
  if (error.code !== 'P2004') {
    return false;
  }

  return String(error.meta?.database_error ?? '').includes(
    'Report_reporterUserId_reportedUserId_check',
  );
}

export class ReportsRepository {
  constructor(private readonly prisma: DatabaseClient) {}

  async createReport(input: CreateReportInput): Promise<ReportRecord> {
    if (input.reporterUserId === input.reportedUserId) {
      throw new ReportSelfReportError();
    }

    const data: Prisma.ReportCreateInput = {
      reporterUser: {
        connect: {
          id: input.reporterUserId,
        },
      },
      reportedUser: {
        connect: {
          id: input.reportedUserId,
        },
      },
      type: input.type,
      reason: input.reason,
    };

    if (input.description !== undefined) {
      data.description = input.description ?? null;
    }

    if (input.isUrgent !== undefined) {
      data.isUrgent = input.isUrgent;
    }

    if (input.messageId !== undefined) {
      data.message = {
        connect: {
          id: input.messageId,
        },
      };
    }

    if (input.conversationId !== undefined) {
      data.conversation = {
        connect: {
          id: input.conversationId,
        },
      };
    }

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.report.create({
        data,
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        isSelfReportConstraintError(error)
      ) {
        throw new ReportSelfReportError();
      }

      throw error;
    }
  }

  findReportById(reportId: string): Promise<ReportRecord | null> {
    return this.prisma.report.findFirst({
      where: {
        id: reportId,
        deletedAt: null,
      },
    });
  }

  async listReports(
    input: ListAdminReportsQueryInput,
  ): Promise<{ data: ReportRecord[]; total: number }> {
    const where: Prisma.ReportWhereInput = {
      deletedAt: null,
      ...(input.status ? { status: input.status } : {}),
      ...(input.isUrgent !== undefined ? { isUrgent: input.isUrgent } : {}),
      ...(input.type ? { type: input.type } : {}),
      ...(input.reason ? { reason: input.reason } : {}),
    };

    const [data, total] = await Promise.all([
      this.prisma.report.findMany({
        where,
        orderBy: REPORT_ORDER_BY,
        skip: (input.page - 1) * input.limit,
        take: input.limit,
      }),
      this.prisma.report.count({
        where,
      }),
    ]);

    return {
      data,
      total,
    };
  }

  findActiveDuplicateReport(
    input: Pick<CreateReportInput, 'reporterUserId' | 'reportedUserId' | 'type'> & {
      messageId?: string;
      conversationId?: string;
    },
  ): Promise<ReportRecord | null> {
    return this.prisma.report.findFirst({
      where: {
        reporterUserId: input.reporterUserId,
        reportedUserId: input.reportedUserId,
        type: input.type,
        messageId: input.messageId ?? null,
        conversationId: input.conversationId ?? null,
        deletedAt: null,
      },
      orderBy: REPORT_ORDER_BY,
    });
  }

  findActiveReportsSentByUser(reporterUserId: string): Promise<ReportRecord[]> {
    return this.prisma.report.findMany({
      where: {
        reporterUserId,
        deletedAt: null,
      },
      orderBy: REPORT_ORDER_BY,
    });
  }

  findActiveReportsReceivedByUser(reportedUserId: string): Promise<ReportRecord[]> {
    return this.prisma.report.findMany({
      where: {
        reportedUserId,
        deletedAt: null,
      },
      orderBy: REPORT_ORDER_BY,
    });
  }

  findMessageContextById(messageId: string): Promise<ReportMessageContextRecord | null> {
    return this.prisma.message.findUnique({
      where: {
        id: messageId,
      },
      select: REPORT_MESSAGE_CONTEXT_SELECT,
    });
  }

  findAdminMessageById(messageId: string): Promise<AdminReportMessageRecord | null> {
    return this.prisma.message.findUnique({
      where: {
        id: messageId,
      },
      select: ADMIN_REPORT_MESSAGE_SELECT,
    });
  }

  findConversationContextById(
    conversationId: string,
  ): Promise<ReportConversationContextRecord | null> {
    return this.prisma.conversation.findUnique({
      where: {
        id: conversationId,
      },
      select: REPORT_CONVERSATION_CONTEXT_SELECT,
    });
  }

  updateReportStatus(id: string, status: ReportStatus): Promise<ReportRecord> {
    return this.prisma.report.update({
      where: { id },
      data: {
        status,
      },
    });
  }

  updateReportUrgency(id: string, isUrgent: boolean): Promise<ReportRecord> {
    return this.prisma.report.update({
      where: { id },
      data: {
        isUrgent,
      },
    });
  }
}
