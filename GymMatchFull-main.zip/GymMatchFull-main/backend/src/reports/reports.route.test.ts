import type { PrismaClient } from '@prisma/client';
import {
  MatchStatus as PrismaMatchStatus,
  MessageStatus as PrismaMessageStatus,
  MessageType as PrismaMessageType,
  ReportReason as PrismaReportReason,
  ReportStatus as PrismaReportStatus,
  ReportType as PrismaReportType,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import { BlocksRepository } from '../blocks/blocks.repository.js';
import type { BlockRecord, CreateBlockInput } from '../blocks/blocks.types.js';
import { BlockConflictError, BlockSelfBlockError } from '../blocks/blocks.types.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import type { CreateMatchInput, MatchRecord } from '../matches/matches.types.js';
import type { SafeUser } from '../users/users.types.js';
import { ReportsRepository } from './reports.repository.js';
import { ReportsService } from './reports.service.js';
import type {
  AdminReportMessageRecord,
  CreateReportInput,
  ListAdminReportsQueryInput,
  ReportConversationContextRecord,
  ReportMessageContextRecord,
  ReportRecord,
} from './reports.types.js';
import { DEFAULT_REPORT_STATUS } from './reports.types.js';

const FIXED_NOW = new Date('2026-05-10T22:15:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

interface SeedConversationInput {
  id?: string;
  userAId: string;
  userBId: string;
}

interface SeedMessageInput {
  content?: string | null;
  conversationId: string;
  id?: string;
  mediaReference?: string | null;
  senderId: string;
  status?: PrismaMessageStatus;
  type?: PrismaMessageType;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }

  async updateUserStatus(id: string, status: PrismaUserStatus): Promise<SafeUser> {
    const user = this.users.find((item) => item.id === id);

    if (!user) {
      throw new Error(`Unknown user ${id}`);
    }

    user.status = status;
    user.updatedAt = FIXED_NOW;

    return user;
  }
}

class InMemoryReportsRepository {
  private readonly reports: ReportRecord[] = [];
  private readonly conversations: ReportConversationContextRecord[] = [];
  private readonly messages: AdminReportMessageRecord[] = [];
  private nextId = 1;

  async createReport(input: CreateReportInput): Promise<ReportRecord> {
    const report: ReportRecord = {
      id: `report_${this.nextId++}`,
      reporterUserId: input.reporterUserId,
      reportedUserId: input.reportedUserId,
      type: input.type,
      reason: input.reason,
      description: input.description ?? null,
      status: DEFAULT_REPORT_STATUS,
      isUrgent: input.isUrgent ?? false,
      messageId: input.messageId ?? null,
      conversationId: input.conversationId ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.reports.push(report);

    return report;
  }

  async findActiveDuplicateReport(
    input: Pick<CreateReportInput, 'reporterUserId' | 'reportedUserId' | 'type'> & {
      messageId?: string;
      conversationId?: string;
    },
  ): Promise<ReportRecord | null> {
    return (
      this.reports.find(
        (report) =>
          report.reporterUserId === input.reporterUserId &&
          report.reportedUserId === input.reportedUserId &&
          report.type === input.type &&
          report.messageId === (input.messageId ?? null) &&
          report.conversationId === (input.conversationId ?? null) &&
          report.deletedAt === null,
      ) ?? null
    );
  }

  async findReportById(reportId: string): Promise<ReportRecord | null> {
    return this.reports.find((report) => report.id === reportId && report.deletedAt === null) ?? null;
  }

  async listReports(
    input: ListAdminReportsQueryInput,
  ): Promise<{ data: ReportRecord[]; total: number }> {
    const filteredReports = this.reports.filter(
      (report) =>
        report.deletedAt === null &&
        (input.status === undefined || report.status === input.status) &&
        (input.isUrgent === undefined || report.isUrgent === input.isUrgent) &&
        (input.type === undefined || report.type === input.type) &&
        (input.reason === undefined || report.reason === input.reason),
    );
    const start = (input.page - 1) * input.limit;

    return {
      data: filteredReports.slice(start, start + input.limit),
      total: filteredReports.length,
    };
  }

  async findActiveReportsSentByUser(reporterUserId: string): Promise<ReportRecord[]> {
    return this.reports.filter(
      (report) => report.reporterUserId === reporterUserId && report.deletedAt === null,
    );
  }

  async findActiveReportsReceivedByUser(reportedUserId: string): Promise<ReportRecord[]> {
    return this.reports.filter(
      (report) => report.reportedUserId === reportedUserId && report.deletedAt === null,
    );
  }

  async findMessageContextById(messageId: string): Promise<ReportMessageContextRecord | null> {
    const message = this.messages.find((item) => item.id === messageId) ?? null;

    if (!message) {
      return null;
    }

    return {
      id: message.id,
      conversationId: message.conversationId,
      senderId: message.senderId,
    };
  }

  async findAdminMessageById(messageId: string): Promise<AdminReportMessageRecord | null> {
    return this.messages.find((message) => message.id === messageId) ?? null;
  }

  async findConversationContextById(
    conversationId: string,
  ): Promise<ReportConversationContextRecord | null> {
    return this.conversations.find((conversation) => conversation.id === conversationId) ?? null;
  }

  seedConversation(input: SeedConversationInput): ReportConversationContextRecord {
    const conversation: ReportConversationContextRecord = {
      id: input.id ?? `conversation_${this.conversations.length + 1}`,
      match: {
        userAId: input.userAId,
        userBId: input.userBId,
      },
    };

    this.conversations.push(conversation);

    return conversation;
  }

  seedMessage(input: SeedMessageInput): ReportMessageContextRecord {
    const message: AdminReportMessageRecord = {
      id: input.id ?? `message_${this.messages.length + 1}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: FIXED_NOW,
    };

    this.messages.push(message);

    return {
      id: message.id,
      conversationId: message.conversationId,
      senderId: message.senderId,
    };
  }

  seedReport(
    input: CreateReportInput & {
      createdAt?: Date;
      id?: string;
      status?: PrismaReportStatus;
      updatedAt?: Date;
    },
  ): ReportRecord {
    const report: ReportRecord = {
      id: input.id ?? `report_${this.nextId++}`,
      reporterUserId: input.reporterUserId,
      reportedUserId: input.reportedUserId,
      type: input.type,
      reason: input.reason,
      description: input.description ?? null,
      status: input.status ?? PrismaReportStatus.OPEN,
      isUrgent: input.isUrgent ?? false,
      messageId: input.messageId ?? null,
      conversationId: input.conversationId ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.reports.push(report);

    return report;
  }

  async updateReportStatus(id: string, status: PrismaReportStatus): Promise<ReportRecord> {
    const report = this.reports.find((item) => item.id === id);

    if (!report) {
      throw new Error(`Unknown report ${id}`);
    }

    report.status = status;
    report.updatedAt = FIXED_NOW;

    return report;
  }

  async updateReportUrgency(id: string, isUrgent: boolean): Promise<ReportRecord> {
    const report = this.reports.find((item) => item.id === id);

    if (!report) {
      throw new Error(`Unknown report ${id}`);
    }

    report.isUrgent = isUrgent;
    report.updatedAt = FIXED_NOW;

    return report;
  }
}

class InMemoryBlocksRepository {
  private readonly blocks: BlockRecord[] = [];
  private nextId = 1;

  async createBlock(input: CreateBlockInput): Promise<BlockRecord> {
    if (input.blockedByUserId === input.blockedUserId) {
      throw new BlockSelfBlockError();
    }

    const existingBlock = this.blocks.find(
      (block) =>
        block.blockedByUserId === input.blockedByUserId &&
        block.blockedUserId === input.blockedUserId &&
        block.deletedAt === null,
    );

    if (existingBlock) {
      throw new BlockConflictError('userPair');
    }

    const block: BlockRecord = {
      id: `block_${this.nextId++}`,
      blockedByUserId: input.blockedByUserId,
      blockedUserId: input.blockedUserId,
      reason: input.reason ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.blocks.push(block);

    return block;
  }

  async findActiveBlockBetweenUsers(
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<BlockRecord | null> {
    return (
      this.blocks.find(
        (block) =>
          block.blockedByUserId === blockedByUserId &&
          block.blockedUserId === blockedUserId &&
          block.deletedAt === null,
      ) ?? null
    );
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async updateMatchStatusBetweenUsers(
    firstUserId: string,
    secondUserId: string,
    status: PrismaMatchStatus,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);
    const match = this.matches.find(
      (item) =>
        item.userAId === normalizedPair.userAId &&
        item.userBId === normalizedPair.userBId &&
        item.deletedAt === null,
    );

    if (!match) {
      return null;
    }

    match.status = status;
    match.updatedAt = FIXED_NOW;

    return match;
  }

  seedMatch(input: CreateMatchInput): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  findMatchBetweenUsers(firstUserId: string, secondUserId: string): MatchRecord | null {
    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (item) =>
          item.userAId === normalizedPair.userAId &&
          item.userBId === normalizedPair.userBId &&
          item.deletedAt === null,
      ) ?? null
    );
  }
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const reportsRepository = new InMemoryReportsRepository();
  const blocksRepository = new InMemoryBlocksRepository();
  const matchesRepository = new InMemoryMatchesRepository();
  const reportsService = new ReportsService({} as PrismaClient, {
    reportsRepository: reportsRepository as unknown as ReportsRepository,
    blocksRepository: blocksRepository as unknown as BlocksRepository,
    matchesRepository: matchesRepository as unknown as MatchesRepository,
    usersService,
  });
  const app = buildApp({
    config,
    services: {
      reportsService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    blocksRepository,
    matchesRepository,
    reportsRepository,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('POST /reports/messages', () => {
  it('creates a message report for an authenticated student and blocks the message sender', async () => {
    const { app, blocksRepository, matchesRepository, reportsRepository, usersService } =
      createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    matchesRepository.seedMatch({
      userAId: reporter.id,
      userBId: reported.id,
      status: PrismaMatchStatus.ACTIVE,
    });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: message.id,
        reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
        description: 'Mensagem ofensiva no chat',
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
      messageId: message.id,
      conversationId: conversation.id,
      status: PrismaReportStatus.OPEN,
      deletedAt: null,
    });
    await expect(
      blocksRepository.findActiveBlockBetweenUsers(reporter.id, reported.id),
    ).resolves.toMatchObject({
      blockedByUserId: reporter.id,
      blockedUserId: reported.id,
    });
    expect(matchesRepository.findMatchBetweenUsers(reporter.id, reported.id)).toMatchObject({
      status: PrismaMatchStatus.BLOCKED,
    });
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      payload: {
        messageId: 'message_1',
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('rejects invalid report reasons', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: message.id,
        reason: 'NOT_A_REASON',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message:
        'reason must be one of: HARASSMENT, FAKE_PROFILE, OFFENSIVE_LANGUAGE, SPAM, INAPPROPRIATE_BEHAVIOR, RACISM, OTHER.',
    });
  });

  it('rejects reports for missing messages', async () => {
    const { app, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: 'message_missing',
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Reported message not found.',
    });
  });

  it('rejects reports for messages outside the current user conversation', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const thirdUser = usersService.seedUser({ id: 'student_3' });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reported.id,
      userBId: thirdUser.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: message.id,
        reason: PrismaReportReason.HARASSMENT,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Reporter user must participate in the informed conversation.',
    });
  });

  it('rejects self report attempts when the message was sent by the current user', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reporter.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: message.id,
        reason: PrismaReportReason.HARASSMENT,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Users cannot report themselves.',
    });
  });

  it('rejects duplicate reports for the same message-report context', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });

    await app.ready();

    const firstResponse = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: message.id,
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(firstResponse.statusCode).toBe(201);

    const secondResponse = await app.inject({
      method: 'POST',
      url: '/reports/messages',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        messageId: message.id,
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(secondResponse.statusCode).toBe(409);
    expect(secondResponse.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Report already exists for this context.',
    });
  });
});

describe('POST /reports/users', () => {
  it('creates a user report for an authenticated student and blocks the reported user', async () => {
    const { app, blocksRepository, matchesRepository, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    matchesRepository.seedMatch({
      userAId: reporter.id,
      userBId: reported.id,
      status: PrismaMatchStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        reportedUserId: reported.id,
        reason: PrismaReportReason.SPAM,
        description: 'Mensagens insistentes fora do contexto do app',
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      status: PrismaReportStatus.OPEN,
      deletedAt: null,
    });
    await expect(
      blocksRepository.findActiveBlockBetweenUsers(reporter.id, reported.id),
    ).resolves.toMatchObject({
      blockedByUserId: reporter.id,
      blockedUserId: reported.id,
    });
    expect(matchesRepository.findMatchBetweenUsers(reporter.id, reported.id)).toMatchObject({
      status: PrismaMatchStatus.BLOCKED,
    });
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/users',
      payload: {
        reportedUserId: 'student_2',
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from creating user reports through the student endpoint', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        reportedUserId: 'student_2',
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('rejects self report attempts', async () => {
    const { app, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        reportedUserId: reporter.id,
        reason: PrismaReportReason.HARASSMENT,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Users cannot report themselves.',
    });
  });

  it('rejects invalid report reasons', async () => {
    const { app, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        reportedUserId: reported.id,
        reason: 'NOT_A_REASON',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message:
        'reason must be one of: HARASSMENT, FAKE_PROFILE, OFFENSIVE_LANGUAGE, SPAM, INAPPROPRIATE_BEHAVIOR, RACISM, OTHER.',
    });
  });

  it('rejects reports for unknown users', async () => {
    const { app, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        reportedUserId: 'student_missing',
        reason: PrismaReportReason.SPAM,
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Reported user not found.',
    });
  });

  it('rejects duplicate reports for the same user-report context', async () => {
    const { app, usersService } = createTestApp();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });

    await app.ready();

    const firstResponse = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        reportedUserId: reported.id,
        reason: PrismaReportReason.FAKE_PROFILE,
      },
    });

    expect(firstResponse.statusCode).toBe(201);

    const secondResponse = await app.inject({
      method: 'POST',
      url: '/reports/users',
      headers: {
        authorization: `Bearer ${signAccessToken(app, reporter)}`,
      },
      payload: {
        reportedUserId: reported.id,
        reason: PrismaReportReason.FAKE_PROFILE,
      },
    });

    expect(secondResponse.statusCode).toBe(409);
    expect(secondResponse.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Report already exists for this context.',
    });
  });
});

describe('Admin report routes', () => {
  it('lists paginated reports for admins with filters', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    usersService.seedUser({ id: 'student_3' });
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      status: PrismaReportStatus.OPEN,
      isUrgent: true,
    });
    reportsRepository.seedReport({
      id: 'report_2',
      reporterUserId: 'student_3',
      reportedUserId: reported.id,
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.HARASSMENT,
      status: PrismaReportStatus.IN_REVIEW,
      isUrgent: false,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/reports?page=1&limit=10&status=OPEN&isUrgent=true',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      data: [
        {
          id: 'report_1',
          reporterUser: {
            id: reporter.id,
          },
          reportedUser: {
            id: reported.id,
          },
        },
      ],
      pagination: {
        page: 1,
        limit: 10,
        total: 1,
        totalPages: 1,
      },
    });
  });

  it('returns report detail for admins', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
      content: 'Mensagem denunciada',
    });
    const report = reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
      messageId: message.id,
      conversationId: conversation.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: `/admin/reports/${report.id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: report.id,
      reporterUser: {
        id: reporter.id,
      },
      reportedUser: {
        id: reported.id,
      },
      message: {
        id: message.id,
        content: 'Mensagem denunciada',
      },
    });
  });

  it('updates report status for admins and rejects invalid statuses', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    usersService.seedUser({ id: 'student_1' });
    usersService.seedUser({ id: 'student_2' });
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
    });

    await app.ready();

    const invalidResponse = await app.inject({
      method: 'PATCH',
      url: '/admin/reports/report_1/status',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        status: 'INVALID',
      },
    });

    expect(invalidResponse.statusCode).toBe(400);
    expect(invalidResponse.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'status must be one of: OPEN, IN_REVIEW, RESOLVED, REJECTED.',
    });

    const response = await app.inject({
      method: 'PATCH',
      url: '/admin/reports/report_1/status',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        status: PrismaReportStatus.RESOLVED,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: 'report_1',
      status: PrismaReportStatus.RESOLVED,
    });
  });

  it('updates report urgency for admins', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    usersService.seedUser({ id: 'student_1' });
    usersService.seedUser({ id: 'student_2' });
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      isUrgent: false,
    });

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/admin/reports/report_1/urgency',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        isUrgent: true,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: 'report_1',
      isUrgent: true,
    });
  });

  it('suspends and bans the reported user for admins without deleting the account', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.HARASSMENT,
    });

    await app.ready();

    const suspendResponse = await app.inject({
      method: 'POST',
      url: '/admin/reports/report_1/suspend-reported-user',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(suspendResponse.statusCode).toBe(200);
    expect(suspendResponse.json()).toMatchObject({
      id: 'report_1',
      reportedUser: {
        id: reported.id,
        status: PrismaUserStatus.SUSPENDED,
      },
    });
    await expect(usersService.findUserById(reported.id)).resolves.toMatchObject({
      status: PrismaUserStatus.SUSPENDED,
      deletedAt: null,
    });

    const banResponse = await app.inject({
      method: 'POST',
      url: '/admin/reports/report_1/ban-reported-user',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(banResponse.statusCode).toBe(200);
    expect(banResponse.json()).toMatchObject({
      id: 'report_1',
      reportedUser: {
        id: reported.id,
        status: PrismaUserStatus.BANNED,
      },
    });
    await expect(usersService.findUserById(reported.id)).resolves.toMatchObject({
      status: PrismaUserStatus.BANNED,
      deletedAt: null,
    });
  });

  it('blocks students and anonymous users from admin report routes', async () => {
    const { app, reportsRepository, usersService } = createTestApp();
    const student = usersService.seedUser({ id: 'student_1' });
    usersService.seedUser({ id: 'student_2' });
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
    });

    await app.ready();

    const anonymousResponse = await app.inject({
      method: 'GET',
      url: '/admin/reports',
    });

    expect(anonymousResponse.statusCode).toBe(401);
    expect(anonymousResponse.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });

    const forbiddenResponse = await app.inject({
      method: 'GET',
      url: '/admin/reports',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(forbiddenResponse.statusCode).toBe(403);
    expect(forbiddenResponse.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });
});
