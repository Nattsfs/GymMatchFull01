import {
  MatchStatus as PrismaMatchStatus,
  ReportReason as PrismaReportReason,
  ReportStatus as PrismaReportStatus,
  ReportType as PrismaReportType,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  type PrismaClient,
} from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';
import { HttpError } from '../common/errors/http-error.js';
import { BlocksRepository } from '../blocks/blocks.repository.js';
import { BlockConflictError, BlockSelfBlockError } from '../blocks/blocks.types.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import { UsersService } from '../users/users.service.js';
import { serializeAdminReportDetail, serializeAdminReportListItem } from './reports.serializer.js';
import { ReportsRepository } from './reports.repository.js';
import type {
  CreateMessageReportForCurrentUserInput,
  CreateReportInput,
  CreateUserReportForCurrentUserInput,
  ListAdminReportsQueryInput,
  ListAdminReportsResult,
  ReportConversationContextRecord,
  ReportMessageContextRecord,
  SafeAdminReportDetail,
  SafeReport,
  ReportsServiceContract,
} from './reports.types.js';
import {
  REPORT_REASONS,
  REPORT_TYPES,
  ReportSelfReportError,
} from './reports.types.js';

const SELF_REPORT_MESSAGE = 'Users cannot report themselves.';
const REPORTER_USER_NOT_FOUND_MESSAGE = 'Reporter user not found.';
const REPORTED_USER_NOT_FOUND_MESSAGE = 'Reported user not found.';
const INVALID_REPORT_TYPE_MESSAGE = `type must be one of: ${REPORT_TYPES.join(', ')}.`;
const INVALID_REPORT_REASON_MESSAGE = `reason must be one of: ${REPORT_REASONS.join(', ')}.`;
const INVALID_DESCRIPTION_MESSAGE = 'description must be a string when provided.';
const INVALID_URGENCY_MESSAGE = 'isUrgent must be a boolean when provided.';
const INVALID_MESSAGE_ID_MESSAGE = 'messageId must be a non-empty string when provided.';
const INVALID_CONVERSATION_ID_MESSAGE =
  'conversationId must be a non-empty string when provided.';
const MESSAGE_REPORT_REQUIRES_MESSAGE_ID_MESSAGE =
  'MESSAGE reports must include a messageId.';
const CONVERSATION_REPORT_REQUIRES_CONVERSATION_ID_MESSAGE =
  'CONVERSATION reports must include a conversationId.';
const MESSAGE_NOT_FOUND_MESSAGE = 'Reported message not found.';
const CONVERSATION_NOT_FOUND_MESSAGE = 'Reported conversation not found.';
const MESSAGE_REPORTED_USER_MISMATCH_MESSAGE =
  'Reported user must be the sender of the informed message.';
const MESSAGE_CONVERSATION_MISMATCH_MESSAGE =
  'Reported message must belong to the informed conversation.';
const REPORTER_NOT_IN_CONVERSATION_MESSAGE =
  'Reporter user must participate in the informed conversation.';
const REPORTED_USER_NOT_IN_CONVERSATION_MESSAGE =
  'Reported user must participate in the informed conversation.';
const REPORTS_STUDENT_ONLY_MESSAGE = 'Only STUDENT users can report other users.';
const DUPLICATE_REPORT_MESSAGE = 'Report already exists for this context.';
const REPORTS_ADMIN_ONLY_MESSAGE = 'Only ADMIN users can manage reports.';
const REPORT_NOT_FOUND_MESSAGE = 'Report not found.';
const REPORTED_USER_DELETED_MESSAGE = 'Deleted users cannot be moderated through report actions.';

type ReportsRepositoryContract = Pick<
  ReportsRepository,
  | 'createReport'
  | 'findAdminMessageById'
  | 'findActiveDuplicateReport'
  | 'findConversationContextById'
  | 'findMessageContextById'
  | 'listReports'
  | 'findReportById'
  | 'findActiveReportsReceivedByUser'
  | 'findActiveReportsSentByUser'
  | 'updateReportStatus'
  | 'updateReportUrgency'
>;
type ReportsBlocksWriter = Pick<
  BlocksRepository,
  'createBlock' | 'findActiveBlockBetweenUsers'
>;
type ReportsMatchesWriter = Pick<MatchesRepository, 'updateMatchStatusBetweenUsers'>;
type ReportsUsersServiceContract = Pick<UsersService, 'findUserById' | 'updateUserStatus'>;
type ReportsTransactionRunner = <T>(
  callback: (dependencies: {
    reportsRepository: ReportsRepositoryContract;
    blocksRepository: ReportsBlocksWriter;
    matchesRepository: ReportsMatchesWriter;
  }) => Promise<T>,
) => Promise<T>;

interface ReportsServiceDependencies {
  blocksRepository?: ReportsBlocksWriter;
  matchesRepository?: ReportsMatchesWriter;
  reportsRepository?: ReportsRepositoryContract;
  transactionRunner?: ReportsTransactionRunner;
  usersService?: ReportsUsersServiceContract;
}

interface NormalizedCreateReportInput {
  reporterUserId: string;
  reportedUserId: string;
  type: PrismaReportType;
  reason: PrismaReportReason;
  description?: string | null;
  isUrgent?: boolean;
  messageId?: string;
  conversationId?: string;
  deletedAt?: Date;
}

export class ReportsService implements ReportsServiceContract {
  private readonly blocksRepository: ReportsBlocksWriter;
  private readonly matchesRepository: ReportsMatchesWriter;
  private readonly reportsRepository: ReportsRepositoryContract;
  private readonly transactionRunner: ReportsTransactionRunner;
  private readonly usersService: ReportsUsersServiceContract;

  constructor(prisma: PrismaClient, dependencies: ReportsServiceDependencies = {}) {
    this.reportsRepository = dependencies.reportsRepository ?? new ReportsRepository(prisma);
    this.blocksRepository = dependencies.blocksRepository ?? new BlocksRepository(prisma);
    this.matchesRepository = dependencies.matchesRepository ?? new MatchesRepository(prisma);
    this.usersService = dependencies.usersService ?? new UsersService(prisma);
    const hasCustomDataAccess =
      dependencies.reportsRepository !== undefined ||
      dependencies.blocksRepository !== undefined ||
      dependencies.matchesRepository !== undefined;
    this.transactionRunner =
      dependencies.transactionRunner ??
      (hasCustomDataAccess || typeof prisma.$transaction !== 'function'
        ? async (callback) =>
            callback({
              reportsRepository: this.reportsRepository,
              blocksRepository: this.blocksRepository,
              matchesRepository: this.matchesRepository,
            })
        : async (callback) =>
            prisma.$transaction(async (transaction) =>
              callback({
                reportsRepository: new ReportsRepository(transaction),
                blocksRepository: new BlocksRepository(transaction),
                matchesRepository: new MatchesRepository(transaction),
              }),
            ));
  }

  async createReport(input: CreateReportInput): Promise<SafeReport> {
    return this.createReportWithDependencies(this.reportsRepository, input);
  }

  async createUserReportForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateUserReportForCurrentUserInput,
  ): Promise<SafeReport> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, REPORTS_STUDENT_ONLY_MESSAGE);
    }

    return this.transactionRunner(async (dependencies) => {
      const report = await this.createReportWithDependencies(dependencies.reportsRepository, {
        reporterUserId: currentUser.id,
        reportedUserId: input.reportedUserId,
        type: PrismaReportType.USER,
        reason: input.reason as PrismaReportReason,
        ...(input.description !== undefined ? { description: input.description } : {}),
      });

      await this.ensureAutomaticBlock(
        dependencies.blocksRepository,
        dependencies.matchesRepository,
        currentUser.id,
        input.reportedUserId,
      );

      return report;
    });
  }

  async createMessageReportForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateMessageReportForCurrentUserInput,
  ): Promise<SafeReport> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, REPORTS_STUDENT_ONLY_MESSAGE);
    }

    return this.transactionRunner(async (dependencies) => {
      const messageId = normalizeRequiredString(input.messageId, 'messageId');
      const messageContext = await dependencies.reportsRepository.findMessageContextById(messageId);

      if (!messageContext) {
        throw new HttpError(404, MESSAGE_NOT_FOUND_MESSAGE);
      }

      const report = await this.createReportWithDependencies(dependencies.reportsRepository, {
        reporterUserId: currentUser.id,
        reportedUserId: messageContext.senderId,
        type: PrismaReportType.MESSAGE,
        reason: input.reason as PrismaReportReason,
        messageId,
        ...(input.description !== undefined ? { description: input.description } : {}),
      });

      await this.ensureAutomaticBlock(
        dependencies.blocksRepository,
        dependencies.matchesRepository,
        currentUser.id,
        messageContext.senderId,
      );

      return report;
    });
  }

  findReportById(reportId: string): Promise<SafeReport | null> {
    return this.reportsRepository.findReportById(reportId);
  }

  findReportsSentByUser(reporterUserId: string): Promise<SafeReport[]> {
    return this.reportsRepository.findActiveReportsSentByUser(reporterUserId);
  }

  findReportsReceivedByUser(reportedUserId: string): Promise<SafeReport[]> {
    return this.reportsRepository.findActiveReportsReceivedByUser(reportedUserId);
  }

  async listReportsForAdmin(
    currentUser: CurrentUserContext,
    input: ListAdminReportsQueryInput,
  ): Promise<ListAdminReportsResult> {
    this.ensureAdminCurrentUser(currentUser);

    const { data, total } = await this.reportsRepository.listReports(input);
    const reports = await Promise.all(
      data.map((report) => this.hydrateAdminReportListItem(report)),
    );

    return {
      data: reports,
      pagination: {
        page: input.page,
        limit: input.limit,
        total,
        totalPages: Math.max(1, Math.ceil(total / input.limit)),
      },
    };
  }

  async getReportDetailForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
  ): Promise<SafeAdminReportDetail> {
    this.ensureAdminCurrentUser(currentUser);

    const report = await this.getReportRecordOrThrow(reportId);

    return this.hydrateAdminReportDetail(report);
  }

  async updateReportStatusForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
    status: PrismaReportStatus,
  ): Promise<SafeAdminReportDetail> {
    this.ensureAdminCurrentUser(currentUser);
    await this.getReportRecordOrThrow(reportId);
    await this.reportsRepository.updateReportStatus(reportId, status);
    await this.recordAdminReportAction(currentUser.id, reportId, 'report.status.updated', {
      status,
    });

    return this.getReportDetailForAdmin(currentUser, reportId);
  }

  async updateReportUrgencyForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
    isUrgent: boolean,
  ): Promise<SafeAdminReportDetail> {
    this.ensureAdminCurrentUser(currentUser);
    await this.getReportRecordOrThrow(reportId);
    await this.reportsRepository.updateReportUrgency(reportId, isUrgent);
    await this.recordAdminReportAction(currentUser.id, reportId, 'report.urgency.updated', {
      isUrgent,
    });

    return this.getReportDetailForAdmin(currentUser, reportId);
  }

  suspendReportedUserForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
  ): Promise<SafeAdminReportDetail> {
    return this.updateReportedUserStatusForAdmin(
      currentUser,
      reportId,
      PrismaUserStatus.SUSPENDED,
      'report.reported-user.suspended',
    );
  }

  banReportedUserForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
  ): Promise<SafeAdminReportDetail> {
    return this.updateReportedUserStatusForAdmin(
      currentUser,
      reportId,
      PrismaUserStatus.BANNED,
      'report.reported-user.banned',
    );
  }

  private async createReportWithDependencies(
    reportsRepository: ReportsRepositoryContract,
    input: CreateReportInput,
  ): Promise<SafeReport> {
    const normalizedInput = this.normalizeInput(input);

    if (normalizedInput.reporterUserId === normalizedInput.reportedUserId) {
      throw new HttpError(400, SELF_REPORT_MESSAGE);
    }

    const reporterUser = await this.usersService.findUserById(normalizedInput.reporterUserId);

    if (!reporterUser) {
      throw new HttpError(404, REPORTER_USER_NOT_FOUND_MESSAGE);
    }

    const reportedUser = await this.usersService.findUserById(normalizedInput.reportedUserId);

    if (!reportedUser) {
      throw new HttpError(404, REPORTED_USER_NOT_FOUND_MESSAGE);
    }

    let conversationContext: ReportConversationContextRecord | null = null;

    if (normalizedInput.conversationId) {
      conversationContext = await reportsRepository.findConversationContextById(
        normalizedInput.conversationId,
      );

      if (!conversationContext) {
        throw new HttpError(404, CONVERSATION_NOT_FOUND_MESSAGE);
      }
    }

    let messageContext: ReportMessageContextRecord | null = null;

    if (normalizedInput.messageId) {
      messageContext = await reportsRepository.findMessageContextById(normalizedInput.messageId);

      if (!messageContext) {
        throw new HttpError(404, MESSAGE_NOT_FOUND_MESSAGE);
      }

      if (messageContext.senderId !== normalizedInput.reportedUserId) {
        throw new HttpError(400, MESSAGE_REPORTED_USER_MISMATCH_MESSAGE);
      }

      if (
        conversationContext !== null &&
        messageContext.conversationId !== conversationContext.id
      ) {
        throw new HttpError(400, MESSAGE_CONVERSATION_MISMATCH_MESSAGE);
      }

      if (!conversationContext) {
        conversationContext = await reportsRepository.findConversationContextById(
          messageContext.conversationId,
        );

        if (!conversationContext) {
          throw new HttpError(404, CONVERSATION_NOT_FOUND_MESSAGE);
        }

        normalizedInput.conversationId = messageContext.conversationId;
      }
    }

    if (normalizedInput.type === PrismaReportType.MESSAGE && !normalizedInput.messageId) {
      throw new HttpError(400, MESSAGE_REPORT_REQUIRES_MESSAGE_ID_MESSAGE);
    }

    if (
      normalizedInput.type === PrismaReportType.CONVERSATION &&
      !normalizedInput.conversationId
    ) {
      throw new HttpError(400, CONVERSATION_REPORT_REQUIRES_CONVERSATION_ID_MESSAGE);
    }

    if (conversationContext) {
      this.ensureConversationParticipant(
        conversationContext,
        normalizedInput.reporterUserId,
        REPORTER_NOT_IN_CONVERSATION_MESSAGE,
      );
      this.ensureConversationParticipant(
        conversationContext,
        normalizedInput.reportedUserId,
        REPORTED_USER_NOT_IN_CONVERSATION_MESSAGE,
      );
    }

    const duplicateReport = await reportsRepository.findActiveDuplicateReport({
      reporterUserId: normalizedInput.reporterUserId,
      reportedUserId: normalizedInput.reportedUserId,
      type: normalizedInput.type,
      ...(normalizedInput.messageId !== undefined
        ? { messageId: normalizedInput.messageId }
        : {}),
      ...(normalizedInput.conversationId !== undefined
        ? { conversationId: normalizedInput.conversationId }
        : {}),
    });

    if (duplicateReport) {
      throw new HttpError(409, DUPLICATE_REPORT_MESSAGE);
    }

    try {
      return await reportsRepository.createReport(normalizedInput);
    } catch (error) {
      if (error instanceof ReportSelfReportError) {
        throw new HttpError(400, SELF_REPORT_MESSAGE);
      }

      throw error;
    }
  }

  private normalizeInput(input: CreateReportInput): NormalizedCreateReportInput {
    const reporterUserId = normalizeRequiredString(input.reporterUserId, 'reporterUserId');
    const reportedUserId = normalizeRequiredString(input.reportedUserId, 'reportedUserId');
    const type = parseReportType(input.type);
    const reason = parseReportReason(input.reason);
    const description = normalizeOptionalDescription(input.description);
    const isUrgent = normalizeOptionalUrgency(input.isUrgent);
    const messageId = normalizeOptionalContextId(input.messageId, 'messageId');
    const conversationId = normalizeOptionalContextId(input.conversationId, 'conversationId');

    return {
      reporterUserId,
      reportedUserId,
      type,
      reason,
      ...(description !== undefined ? { description } : {}),
      ...(isUrgent !== undefined ? { isUrgent } : {}),
      ...(messageId !== undefined ? { messageId } : {}),
      ...(conversationId !== undefined ? { conversationId } : {}),
      ...(input.deletedAt !== undefined ? { deletedAt: input.deletedAt } : {}),
    };
  }

  private ensureConversationParticipant(
    conversation: ReportConversationContextRecord,
    userId: string,
    errorMessage: string,
  ): void {
    if (
      conversation.match.userAId !== userId &&
      conversation.match.userBId !== userId
    ) {
      throw new HttpError(400, errorMessage);
    }
  }

  private async ensureAutomaticBlock(
    blocksRepository: ReportsBlocksWriter,
    matchesRepository: ReportsMatchesWriter,
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<void> {
    const existingDirectBlock = await blocksRepository.findActiveBlockBetweenUsers(
      blockedByUserId,
      blockedUserId,
    );

    if (!existingDirectBlock) {
      try {
        await blocksRepository.createBlock({
          blockedByUserId,
          blockedUserId,
        });
      } catch (error) {
        if (error instanceof BlockConflictError && error.field === 'userPair') {
          // Another request created the same direct block concurrently.
        } else if (error instanceof BlockSelfBlockError) {
          throw new HttpError(400, SELF_REPORT_MESSAGE);
        } else {
          throw error;
        }
      }
    }

    await matchesRepository.updateMatchStatusBetweenUsers(
      blockedByUserId,
      blockedUserId,
      PrismaMatchStatus.BLOCKED,
    );
  }

  private ensureAdminCurrentUser(currentUser: CurrentUserContext): void {
    if (currentUser.role !== PrismaUserRole.ADMIN) {
      throw new HttpError(403, REPORTS_ADMIN_ONLY_MESSAGE);
    }
  }

  private async getReportRecordOrThrow(reportId: string): Promise<SafeReport> {
    const report = await this.reportsRepository.findReportById(reportId);

    if (!report) {
      throw new HttpError(404, REPORT_NOT_FOUND_MESSAGE);
    }

    return report;
  }

  private async hydrateAdminReportListItem(report: SafeReport) {
    const [reporterUser, reportedUser] = await Promise.all([
      this.getUserForReportOrThrow(report.reporterUserId, REPORTER_USER_NOT_FOUND_MESSAGE),
      this.getUserForReportOrThrow(report.reportedUserId, REPORTED_USER_NOT_FOUND_MESSAGE),
    ]);

    return serializeAdminReportListItem(report, reporterUser, reportedUser);
  }

  private async hydrateAdminReportDetail(report: SafeReport): Promise<SafeAdminReportDetail> {
    const [reporterUser, reportedUser, message] = await Promise.all([
      this.getUserForReportOrThrow(report.reporterUserId, REPORTER_USER_NOT_FOUND_MESSAGE),
      this.getUserForReportOrThrow(report.reportedUserId, REPORTED_USER_NOT_FOUND_MESSAGE),
      report.messageId
        ? this.reportsRepository.findAdminMessageById(report.messageId)
        : Promise.resolve(null),
    ]);

    return serializeAdminReportDetail(report, reporterUser, reportedUser, message);
  }

  private async getUserForReportOrThrow(userId: string, errorMessage: string) {
    const user = await this.usersService.findUserById(userId);

    if (!user) {
      throw new HttpError(404, errorMessage);
    }

    return user;
  }

  private async updateReportedUserStatusForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
    status: PrismaUserStatus,
    auditAction: string,
  ): Promise<SafeAdminReportDetail> {
    this.ensureAdminCurrentUser(currentUser);
    const report = await this.getReportRecordOrThrow(reportId);
    const reportedUser = await this.getUserForReportOrThrow(
      report.reportedUserId,
      REPORTED_USER_NOT_FOUND_MESSAGE,
    );

    if (reportedUser.deletedAt !== null || reportedUser.status === PrismaUserStatus.DELETED) {
      throw new HttpError(409, REPORTED_USER_DELETED_MESSAGE);
    }

    await this.usersService.updateUserStatus(reportedUser.id, status);
    await this.recordAdminReportAction(currentUser.id, reportId, auditAction, {
      reportedUserId: reportedUser.id,
      status,
    });

    return this.getReportDetailForAdmin(currentUser, reportId);
  }

  private async recordAdminReportAction(
    _adminUserId: string,
    _reportId: string,
    _action: string,
    _metadata: Record<string, unknown>,
  ): Promise<void> {
    // Centralized no-op hook until the project gains a dedicated audit log module.
  }
}

function normalizeRequiredString(value: unknown, field: string): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} is required and must be a string.`);
  }

  const normalizedValue = value.trim();

  if (normalizedValue.length === 0) {
    throw new HttpError(400, `${field} must not be empty.`);
  }

  return normalizedValue;
}

function normalizeOptionalDescription(value: unknown): string | null | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, INVALID_DESCRIPTION_MESSAGE);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : null;
}

function normalizeOptionalUrgency(value: unknown): boolean | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'boolean') {
    throw new HttpError(400, INVALID_URGENCY_MESSAGE);
  }

  return value;
}

function normalizeOptionalContextId(
  value: unknown,
  field: 'messageId' | 'conversationId',
): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(
      400,
      field === 'messageId' ? INVALID_MESSAGE_ID_MESSAGE : INVALID_CONVERSATION_ID_MESSAGE,
    );
  }

  const normalizedValue = value.trim();

  if (normalizedValue.length === 0) {
    throw new HttpError(
      400,
      field === 'messageId' ? INVALID_MESSAGE_ID_MESSAGE : INVALID_CONVERSATION_ID_MESSAGE,
    );
  }

  return normalizedValue;
}

function parseReportType(value: unknown): PrismaReportType {
  if (typeof value !== 'string') {
    throw new HttpError(400, INVALID_REPORT_TYPE_MESSAGE);
  }

  const normalizedValue = value.trim().toUpperCase();

  if (REPORT_TYPES.includes(normalizedValue as PrismaReportType)) {
    return normalizedValue as PrismaReportType;
  }

  throw new HttpError(400, INVALID_REPORT_TYPE_MESSAGE);
}

function parseReportReason(value: unknown): PrismaReportReason {
  if (typeof value !== 'string') {
    throw new HttpError(400, INVALID_REPORT_REASON_MESSAGE);
  }

  const normalizedValue = value.trim().toUpperCase();

  if (REPORT_REASONS.includes(normalizedValue as PrismaReportReason)) {
    return normalizedValue as PrismaReportReason;
  }

  throw new HttpError(400, INVALID_REPORT_REASON_MESSAGE);
}
