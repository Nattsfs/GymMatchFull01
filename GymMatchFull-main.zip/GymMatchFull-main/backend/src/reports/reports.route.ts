import { UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync } from 'fastify';

import { AuthService } from '../auth/auth.service.js';
import type { AuthServiceContract, AuthUsersServiceContract } from '../auth/auth.types.js';
import { getCurrentUserContext } from '../auth/current-user.js';
import { createJwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { createRolesGuard } from '../auth/roles.guard.js';
import { HttpError } from '../common/errors/http-error.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import { parseCreateMessageReportInput } from './dto/create-message-report.dto.js';
import { parseCreateUserReportInput } from './dto/create-user-report.dto.js';
import { parseListReportsQuery } from './dto/list-reports-query.dto.js';
import { parseUpdateReportStatusInput } from './dto/update-report-status.dto.js';
import { parseUpdateReportUrgencyInput } from './dto/update-report-urgency.dto.js';
import { ReportsService } from './reports.service.js';
import type { ReportsServiceContract } from './reports.types.js';

interface ReportsRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  reportsService?: ReportsServiceContract;
  usersService?: AuthUsersServiceContract;
}

export const reportsRoutes: FastifyPluginAsync<ReportsRoutesOptions> = async (app, options) => {
  const reportsUsersService = new UsersService(app.prisma);
  const usersService = options.usersService ?? reportsUsersService;
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const reportsService =
    options.reportsService ?? new ReportsService(app.prisma, { usersService: reportsUsersService });
  const authenticate = createJwtAuthGuard(authService);
  const requireAdmin = createRolesGuard([PrismaUserRole.ADMIN]);
  const requireStudent = createRolesGuard([PrismaUserRole.STUDENT]);

  app.post(
    '/reports/messages',
    { preHandler: [authenticate, requireStudent] },
    async (request, reply) => {
      const input = parseCreateMessageReportInput(request.body);
      const currentUser = getCurrentUserContext(request);
      const report = await reportsService.createMessageReportForCurrentUser(currentUser, input);

      return reply.status(201).send(report);
    },
  );

  app.post(
    '/reports/users',
    { preHandler: [authenticate, requireStudent] },
    async (request, reply) => {
      const input = parseCreateUserReportInput(request.body);
      const currentUser = getCurrentUserContext(request);
      const report = await reportsService.createUserReportForCurrentUser(currentUser, input);

      return reply.status(201).send(report);
    },
  );

  app.get('/admin/reports', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const currentUser = getCurrentUserContext(request);
    const query = parseListReportsQuery(request.query);

    return reportsService.listReportsForAdmin(currentUser, query);
  });

  app.get(
    '/admin/reports/:id',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const currentUser = getCurrentUserContext(request);
      const reportId = parseRouteParam(request.params, 'id');

      return reportsService.getReportDetailForAdmin(currentUser, reportId);
    },
  );

  app.patch(
    '/admin/reports/:id/status',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const currentUser = getCurrentUserContext(request);
      const reportId = parseRouteParam(request.params, 'id');
      const status = parseUpdateReportStatusInput(request.body);

      return reportsService.updateReportStatusForAdmin(currentUser, reportId, status);
    },
  );

  app.patch(
    '/admin/reports/:id/urgency',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const currentUser = getCurrentUserContext(request);
      const reportId = parseRouteParam(request.params, 'id');
      const isUrgent = parseUpdateReportUrgencyInput(request.body);

      return reportsService.updateReportUrgencyForAdmin(currentUser, reportId, isUrgent);
    },
  );

  app.post(
    '/admin/reports/:id/suspend-reported-user',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const currentUser = getCurrentUserContext(request);
      const reportId = parseRouteParam(request.params, 'id');

      return reportsService.suspendReportedUserForAdmin(currentUser, reportId);
    },
  );

  app.post(
    '/admin/reports/:id/ban-reported-user',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const currentUser = getCurrentUserContext(request);
      const reportId = parseRouteParam(request.params, 'id');

      return reportsService.banReportedUserForAdmin(currentUser, reportId);
    },
  );
};

function parseRouteParam(payload: unknown, field: string): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const value = payload[field];

  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return value.trim();
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
