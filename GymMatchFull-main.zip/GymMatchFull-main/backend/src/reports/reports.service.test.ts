import type { PrismaClient } from '@prisma/client';
import {
  MatchStatus as PrismaMatchStatus,
  MessageStatus as PrismaMessageStatus,
  MessageType as PrismaMessageType,
  ReportReason as PrismaReportReason,
  ReportStatus as PrismaReportStatus,
  ReportType as PrismaReportType,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { CurrentUserContext } from '../auth/current-user.js';
import { BlocksRepository } from '../blocks/blocks.repository.js';
import type { BlockRecord, CreateBlockInput } from '../blocks/blocks.types.js';
import { BlockConflictError, BlockSelfBlockError } from '../blocks/blocks.types.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import type { CreateMatchInput, MatchRecord } from '../matches/matches.types.js';
import type { SafeUser } from '../users/users.types.js';
import { ReportsRepository } from './reports.repository.js';
import { ReportsService } from './reports.service.js';
import type {
  AdminReportMessageRecord,
  CreateReportInput,
  ListAdminReportsQueryInput,
  ReportConversationContextRecord,
  ReportMessageContextRecord,
  ReportRecord,
} from './reports.types.js';
import { DEFAULT_REPORT_STATUS, ReportSelfReportError } from './reports.types.js';

const FIXED_NOW = new Date('2026-05-10T21:45:00.000Z');

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

interface SeedConversationInput {
  id?: string;
  userAId: string;
  userBId: string;
}

interface SeedMessageInput {
  content?: string | null;
  conversationId: string;
  id?: string;
  mediaReference?: string | null;
  senderId: string;
  status?: PrismaMessageStatus;
  type?: PrismaMessageType;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }

  async updateUserStatus(id: string, status: PrismaUserStatus): Promise<SafeUser> {
    const user = this.users.find((item) => item.id === id);

    if (!user) {
      throw new Error(`Unknown user ${id}`);
    }

    user.status = status;
    user.updatedAt = FIXED_NOW;

    return user;
  }
}

class InMemoryReportsRepository {
  private readonly reports: ReportRecord[] = [];
  private readonly conversations: ReportConversationContextRecord[] = [];
  private readonly messages: AdminReportMessageRecord[] = [];
  private nextId = 1;

  async createReport(input: CreateReportInput): Promise<ReportRecord> {
    if (input.reporterUserId === input.reportedUserId) {
      throw new ReportSelfReportError();
    }

    const report: ReportRecord = {
      id: `report_${this.nextId++}`,
      reporterUserId: input.reporterUserId,
      reportedUserId: input.reportedUserId,
      type: input.type,
      reason: input.reason,
      description: input.description ?? null,
      status: DEFAULT_REPORT_STATUS,
      isUrgent: input.isUrgent ?? false,
      messageId: input.messageId ?? null,
      conversationId: input.conversationId ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.reports.push(report);

    return report;
  }

  async findReportById(reportId: string): Promise<ReportRecord | null> {
    return this.reports.find((report) => report.id === reportId && report.deletedAt === null) ?? null;
  }

  async listReports(
    input: ListAdminReportsQueryInput,
  ): Promise<{ data: ReportRecord[]; total: number }> {
    const filteredReports = this.reports.filter(
      (report) =>
        report.deletedAt === null &&
        (input.status === undefined || report.status === input.status) &&
        (input.isUrgent === undefined || report.isUrgent === input.isUrgent) &&
        (input.type === undefined || report.type === input.type) &&
        (input.reason === undefined || report.reason === input.reason),
    );
    const start = (input.page - 1) * input.limit;

    return {
      data: filteredReports.slice(start, start + input.limit),
      total: filteredReports.length,
    };
  }

  async findActiveDuplicateReport(
    input: Pick<CreateReportInput, 'reporterUserId' | 'reportedUserId' | 'type'> & {
      messageId?: string;
      conversationId?: string;
    },
  ): Promise<ReportRecord | null> {
    return (
      this.reports.find(
        (report) =>
          report.reporterUserId === input.reporterUserId &&
          report.reportedUserId === input.reportedUserId &&
          report.type === input.type &&
          report.messageId === (input.messageId ?? null) &&
          report.conversationId === (input.conversationId ?? null) &&
          report.deletedAt === null,
      ) ?? null
    );
  }

  async findActiveReportsSentByUser(reporterUserId: string): Promise<ReportRecord[]> {
    return this.reports.filter(
      (report) => report.reporterUserId === reporterUserId && report.deletedAt === null,
    );
  }

  async findActiveReportsReceivedByUser(reportedUserId: string): Promise<ReportRecord[]> {
    return this.reports.filter(
      (report) => report.reportedUserId === reportedUserId && report.deletedAt === null,
    );
  }

  async findMessageContextById(messageId: string): Promise<ReportMessageContextRecord | null> {
    const message = this.messages.find((item) => item.id === messageId) ?? null;

    if (!message) {
      return null;
    }

    return {
      id: message.id,
      conversationId: message.conversationId,
      senderId: message.senderId,
    };
  }

  async findAdminMessageById(messageId: string): Promise<AdminReportMessageRecord | null> {
    return this.messages.find((message) => message.id === messageId) ?? null;
  }

  async findConversationContextById(
    conversationId: string,
  ): Promise<ReportConversationContextRecord | null> {
    return this.conversations.find((conversation) => conversation.id === conversationId) ?? null;
  }

  seedConversation(input: SeedConversationInput): ReportConversationContextRecord {
    const conversation: ReportConversationContextRecord = {
      id: input.id ?? `conversation_${this.conversations.length + 1}`,
      match: {
        userAId: input.userAId,
        userBId: input.userBId,
      },
    };

    this.conversations.push(conversation);

    return conversation;
  }

  seedMessage(input: SeedMessageInput): ReportMessageContextRecord {
    const message: AdminReportMessageRecord = {
      id: input.id ?? `message_${this.messages.length + 1}`,
      conversationId: input.conversationId,
      senderId: input.senderId,
      type: input.type ?? PrismaMessageType.TEXT,
      status: input.status ?? PrismaMessageStatus.SENT,
      content: input.content ?? null,
      mediaReference: input.mediaReference ?? null,
      createdAt: FIXED_NOW,
    };

    this.messages.push(message);

    return {
      id: message.id,
      conversationId: message.conversationId,
      senderId: message.senderId,
    };
  }

  seedReport(
    input: CreateReportInput & {
      createdAt?: Date;
      id?: string;
      status?: PrismaReportStatus;
      updatedAt?: Date;
    },
  ): ReportRecord {
    const report: ReportRecord = {
      id: input.id ?? `report_${this.nextId++}`,
      reporterUserId: input.reporterUserId,
      reportedUserId: input.reportedUserId,
      type: input.type,
      reason: input.reason,
      description: input.description ?? null,
      status: input.status ?? PrismaReportStatus.OPEN,
      isUrgent: input.isUrgent ?? false,
      messageId: input.messageId ?? null,
      conversationId: input.conversationId ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.reports.push(report);

    return report;
  }

  async updateReportStatus(id: string, status: PrismaReportStatus): Promise<ReportRecord> {
    const report = this.reports.find((item) => item.id === id);

    if (!report) {
      throw new Error(`Unknown report ${id}`);
    }

    report.status = status;
    report.updatedAt = FIXED_NOW;

    return report;
  }

  async updateReportUrgency(id: string, isUrgent: boolean): Promise<ReportRecord> {
    const report = this.reports.find((item) => item.id === id);

    if (!report) {
      throw new Error(`Unknown report ${id}`);
    }

    report.isUrgent = isUrgent;
    report.updatedAt = FIXED_NOW;

    return report;
  }
}

class InMemoryBlocksRepository {
  private readonly blocks: BlockRecord[] = [];
  private nextId = 1;

  async createBlock(input: CreateBlockInput): Promise<BlockRecord> {
    if (input.blockedByUserId === input.blockedUserId) {
      throw new BlockSelfBlockError();
    }

    const existingBlock = this.blocks.find(
      (block) =>
        block.blockedByUserId === input.blockedByUserId &&
        block.blockedUserId === input.blockedUserId &&
        block.deletedAt === null,
    );

    if (existingBlock) {
      throw new BlockConflictError('userPair');
    }

    const block: BlockRecord = {
      id: `block_${this.nextId++}`,
      blockedByUserId: input.blockedByUserId,
      blockedUserId: input.blockedUserId,
      reason: input.reason ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.blocks.push(block);

    return block;
  }

  async findActiveBlockBetweenUsers(
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<BlockRecord | null> {
    return (
      this.blocks.find(
        (block) =>
          block.blockedByUserId === blockedByUserId &&
          block.blockedUserId === blockedUserId &&
          block.deletedAt === null,
      ) ?? null
    );
  }

  async findActiveBlocksSentByUser(blockedByUserId: string): Promise<BlockRecord[]> {
    return this.blocks.filter(
      (block) => block.blockedByUserId === blockedByUserId && block.deletedAt === null,
    );
  }

  seedBlock(input: CreateBlockInput & { createdAt?: Date; updatedAt?: Date }): BlockRecord {
    const block: BlockRecord = {
      id: `block_${this.nextId++}`,
      blockedByUserId: input.blockedByUserId,
      blockedUserId: input.blockedUserId,
      reason: input.reason ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.blocks.push(block);

    return block;
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async updateMatchStatusBetweenUsers(
    firstUserId: string,
    secondUserId: string,
    status: PrismaMatchStatus,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);
    const match = this.matches.find(
      (item) =>
        item.userAId === normalizedPair.userAId &&
        item.userBId === normalizedPair.userBId &&
        item.deletedAt === null,
    );

    if (!match) {
      return null;
    }

    match.status = status;
    match.updatedAt = FIXED_NOW;

    return match;
  }

  seedMatch(input: CreateMatchInput): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  findMatchBetweenUsers(firstUserId: string, secondUserId: string): MatchRecord | null {
    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (item) =>
          item.userAId === normalizedPair.userAId &&
          item.userBId === normalizedPair.userBId &&
          item.deletedAt === null,
      ) ?? null
    );
  }
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function makeCurrentUser(overrides: Partial<CurrentUserContext> = {}): CurrentUserContext {
  return {
    id: 'student_1',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    ...overrides,
  };
}

function createReportsService(
  options: {
    blocksRepository?: InMemoryBlocksRepository;
    matchesRepository?: InMemoryMatchesRepository;
    reportsRepository?: InMemoryReportsRepository;
    usersService?: InMemoryUsersService;
  } = {},
): ReportsService {
  return new ReportsService({} as PrismaClient, {
    blocksRepository: (options.blocksRepository ??
      new InMemoryBlocksRepository()) as unknown as BlocksRepository,
    matchesRepository: (options.matchesRepository ??
      new InMemoryMatchesRepository()) as unknown as MatchesRepository,
    reportsRepository: (options.reportsRepository ??
      new InMemoryReportsRepository()) as unknown as ReportsRepository,
    usersService: options.usersService ?? new InMemoryUsersService(),
  });
}

describe('ReportsService', () => {
  it('creates an OPEN user report with a default non-urgent flag', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const service = createReportsService({ usersService });

    const report = await service.createReport({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      description: 'Repeatedly sending unwanted invites',
    });

    expect(report).toMatchObject({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      status: PrismaReportStatus.OPEN,
      isUrgent: false,
      messageId: null,
      conversationId: null,
      deletedAt: null,
    });
    await expect(service.findReportById(report.id)).resolves.toEqual(report);
  });

  it('creates a user report for the current student and automatically blocks the reported user', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const blocksRepository = new InMemoryBlocksRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    matchesRepository.seedMatch({
      userAId: reporter.id,
      userBId: reported.id,
      status: PrismaMatchStatus.ACTIVE,
    });
    const service = createReportsService({
      blocksRepository,
      matchesRepository,
      usersService,
    });

    const report = await service.createUserReportForCurrentUser(makeCurrentUser(), {
      reportedUserId: reported.id,
      reason: PrismaReportReason.HARASSMENT,
      description: 'Persistiu em mensagens e convites indesejados',
    });

    expect(report).toMatchObject({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.HARASSMENT,
      status: PrismaReportStatus.OPEN,
    });
    await expect(
      blocksRepository.findActiveBlockBetweenUsers(reporter.id, reported.id),
    ).resolves.toMatchObject({
      blockedByUserId: reporter.id,
      blockedUserId: reported.id,
    });
    expect(matchesRepository.findMatchBetweenUsers(reporter.id, reported.id)).toMatchObject({
      status: PrismaMatchStatus.BLOCKED,
    });
  });

  it('creates a message report and derives conversationId from the message context', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });
    const service = createReportsService({ reportsRepository, usersService });

    const report = await service.createReport({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
      messageId: message.id,
      isUrgent: true,
    });

    expect(report.messageId).toBe(message.id);
    expect(report.conversationId).toBe(conversation.id);
    expect(report.isUrgent).toBe(true);
    expect(report.status).toBe(PrismaReportStatus.OPEN);
  });

  it('creates a message report for the current student and automatically blocks the message sender', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    const blocksRepository = new InMemoryBlocksRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    matchesRepository.seedMatch({
      userAId: reporter.id,
      userBId: reported.id,
      status: PrismaMatchStatus.ACTIVE,
    });
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });
    const service = createReportsService({
      blocksRepository,
      matchesRepository,
      reportsRepository,
      usersService,
    });

    const report = await service.createMessageReportForCurrentUser(
      makeCurrentUser({ id: reporter.id }),
      {
        messageId: message.id,
        reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
        description: 'Mensagem ofensiva no chat',
      },
    );

    expect(report).toMatchObject({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
      messageId: message.id,
      conversationId: conversation.id,
      status: PrismaReportStatus.OPEN,
    });
    await expect(
      blocksRepository.findActiveBlockBetweenUsers(reporter.id, reported.id),
    ).resolves.toMatchObject({
      blockedByUserId: reporter.id,
      blockedUserId: reported.id,
    });
    expect(matchesRepository.findMatchBetweenUsers(reporter.id, reported.id)).toMatchObject({
      status: PrismaMatchStatus.BLOCKED,
    });
  });

  it('rejects self report attempts', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const service = createReportsService({ usersService });

    await expect(
      service.createReport({
        reporterUserId: reporter.id,
        reportedUserId: reporter.id,
        type: PrismaReportType.USER,
        reason: PrismaReportReason.OTHER,
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Users cannot report themselves.',
    });
  });

  it('rejects duplicate reports for the same user-report context', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    reportsRepository.seedReport({
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
    });
    const service = createReportsService({ reportsRepository, usersService });

    await expect(
      service.createUserReportForCurrentUser(makeCurrentUser({ id: reporter.id }), {
        reportedUserId: reported.id,
        reason: PrismaReportReason.SPAM,
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Report already exists for this context.',
    });
  });

  it('rejects invalid report reasons through service validation', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const service = createReportsService({ usersService });

    await expect(
      service.createReport({
        reporterUserId: reporter.id,
        reportedUserId: reported.id,
        type: PrismaReportType.USER,
        reason: 'NOT_A_REASON' as PrismaReportReason,
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message:
        'reason must be one of: HARASSMENT, FAKE_PROFILE, OFFENSIVE_LANGUAGE, SPAM, INAPPROPRIATE_BEHAVIOR, RACISM, OTHER.',
    });
  });

  it('rejects message reports without a messageId', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const service = createReportsService({ usersService });

    await expect(
      service.createReport({
        reporterUserId: reporter.id,
        reportedUserId: reported.id,
        type: PrismaReportType.MESSAGE,
        reason: PrismaReportReason.HARASSMENT,
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'MESSAGE reports must include a messageId.',
    });
  });

  it('rejects reports when the informed message sender does not match the reported user', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const thirdUser = usersService.seedUser({ id: 'student_3' });
    const reportsRepository = new InMemoryReportsRepository();
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: thirdUser.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: thirdUser.id,
    });
    const service = createReportsService({ reportsRepository, usersService });

    await expect(
      service.createReport({
        reporterUserId: reporter.id,
        reportedUserId: reported.id,
        type: PrismaReportType.MESSAGE,
        reason: PrismaReportReason.HARASSMENT,
        messageId: message.id,
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Reported user must be the sender of the informed message.',
    });
  });

  it('rejects message reports from users outside the conversation', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const outsider = usersService.seedUser({ id: 'student_3' });
    const reportsRepository = new InMemoryReportsRepository();
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reported.id,
      userBId: outsider.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
    });
    const service = createReportsService({ reportsRepository, usersService });

    await expect(
      service.createMessageReportForCurrentUser(makeCurrentUser({ id: reporter.id }), {
        messageId: message.id,
        reason: PrismaReportReason.HARASSMENT,
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Reporter user must participate in the informed conversation.',
    });
  });

  it('reuses an existing automatic block instead of creating a duplicate one', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const blocksRepository = new InMemoryBlocksRepository();
    blocksRepository.seedBlock({
      blockedByUserId: reporter.id,
      blockedUserId: reported.id,
    });
    const service = createReportsService({ blocksRepository, usersService });

    await service.createUserReportForCurrentUser(makeCurrentUser({ id: reporter.id }), {
      reportedUserId: reported.id,
      reason: PrismaReportReason.OTHER,
      description: 'Perfil suspeito',
    });

    await expect(blocksRepository.findActiveBlocksSentByUser(reporter.id)).resolves.toHaveLength(1);
  });

  it('lists only active reports sent and received by a user', async () => {
    const reportsRepository = new InMemoryReportsRepository();
    reportsRepository.seedReport({
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      id: 'report_1',
    });
    reportsRepository.seedReport({
      reporterUserId: 'student_3',
      reportedUserId: 'student_1',
      type: PrismaReportType.PROFILE,
      reason: PrismaReportReason.FAKE_PROFILE,
      id: 'report_2',
    });
    reportsRepository.seedReport({
      reporterUserId: 'student_1',
      reportedUserId: 'student_4',
      type: PrismaReportType.CONVERSATION,
      reason: PrismaReportReason.OTHER,
      conversationId: 'conversation_10',
      id: 'report_3',
      deletedAt: FIXED_NOW,
    });
    const service = createReportsService({ reportsRepository });

    await expect(service.findReportsSentByUser('student_1')).resolves.toMatchObject([
      { id: 'report_1' },
    ]);
    await expect(service.findReportsReceivedByUser('student_1')).resolves.toMatchObject([
      { id: 'report_2' },
    ]);
  });

  it('lists paginated reports for admins with filters and user summaries', async () => {
    const usersService = new InMemoryUsersService();
    usersService.seedUser({ id: 'student_1' });
    usersService.seedUser({ id: 'student_2' });
    usersService.seedUser({ id: 'student_3' });
    const reportsRepository = new InMemoryReportsRepository();
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
      isUrgent: true,
      status: PrismaReportStatus.OPEN,
    });
    reportsRepository.seedReport({
      id: 'report_2',
      reporterUserId: 'student_3',
      reportedUserId: 'student_2',
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.HARASSMENT,
      isUrgent: false,
      status: PrismaReportStatus.IN_REVIEW,
    });
    const service = createReportsService({ reportsRepository, usersService });

    const result = await service.listReportsForAdmin(
      makeCurrentUser({ id: 'admin_1', role: PrismaUserRole.ADMIN }),
      {
        page: 1,
        limit: 10,
        status: PrismaReportStatus.OPEN,
        isUrgent: true,
      },
    );

    expect(result.pagination).toEqual({
      page: 1,
      limit: 10,
      total: 1,
      totalPages: 1,
    });
    expect(result.data).toMatchObject([
      {
        id: 'report_1',
        reporterUser: {
          id: 'student_1',
        },
        reportedUser: {
          id: 'student_2',
        },
      },
    ]);
  });

  it('returns admin report detail with the related message context', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    const conversation = reportsRepository.seedConversation({
      id: 'conversation_1',
      userAId: reporter.id,
      userBId: reported.id,
    });
    const message = reportsRepository.seedMessage({
      id: 'message_1',
      conversationId: conversation.id,
      senderId: reported.id,
      content: 'Mensagem denunciada',
    });
    const report = reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.MESSAGE,
      reason: PrismaReportReason.OFFENSIVE_LANGUAGE,
      messageId: message.id,
      conversationId: conversation.id,
    });
    const service = createReportsService({ reportsRepository, usersService });

    const detail = await service.getReportDetailForAdmin(
      makeCurrentUser({ id: 'admin_1', role: PrismaUserRole.ADMIN }),
      report.id,
    );

    expect(detail).toMatchObject({
      id: report.id,
      reporterUser: {
        id: reporter.id,
      },
      reportedUser: {
        id: reported.id,
      },
      message: {
        id: message.id,
        content: 'Mensagem denunciada',
      },
    });
  });

  it('updates report status and urgency for admins', async () => {
    const usersService = new InMemoryUsersService();
    usersService.seedUser({ id: 'student_1' });
    usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    const report = reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
    });
    const service = createReportsService({ reportsRepository, usersService });
    const admin = makeCurrentUser({ id: 'admin_1', role: PrismaUserRole.ADMIN });

    const updatedStatus = await service.updateReportStatusForAdmin(
      admin,
      report.id,
      PrismaReportStatus.RESOLVED,
    );
    const updatedUrgency = await service.updateReportUrgencyForAdmin(admin, report.id, true);

    expect(updatedStatus.status).toBe(PrismaReportStatus.RESOLVED);
    expect(updatedUrgency.isUrgent).toBe(true);
  });

  it('suspends and bans the reported user for admins without deleting the account', async () => {
    const usersService = new InMemoryUsersService();
    const reporter = usersService.seedUser({ id: 'student_1' });
    const reported = usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: reporter.id,
      reportedUserId: reported.id,
      type: PrismaReportType.USER,
      reason: PrismaReportReason.HARASSMENT,
    });
    const service = createReportsService({ reportsRepository, usersService });
    const admin = makeCurrentUser({ id: 'admin_1', role: PrismaUserRole.ADMIN });

    const suspendedReport = await service.suspendReportedUserForAdmin(admin, 'report_1');

    expect(suspendedReport.reportedUser.status).toBe(PrismaUserStatus.SUSPENDED);
    await expect(usersService.findUserById(reported.id)).resolves.toMatchObject({
      status: PrismaUserStatus.SUSPENDED,
      deletedAt: null,
    });

    const bannedReport = await service.banReportedUserForAdmin(admin, 'report_1');

    expect(bannedReport.reportedUser.status).toBe(PrismaUserStatus.BANNED);
    await expect(usersService.findUserById(reported.id)).resolves.toMatchObject({
      status: PrismaUserStatus.BANNED,
      deletedAt: null,
    });
  });

  it('rejects admin report actions for non-admin users', async () => {
    const usersService = new InMemoryUsersService();
    usersService.seedUser({ id: 'student_1' });
    usersService.seedUser({ id: 'student_2' });
    const reportsRepository = new InMemoryReportsRepository();
    reportsRepository.seedReport({
      id: 'report_1',
      reporterUserId: 'student_1',
      reportedUserId: 'student_2',
      type: PrismaReportType.USER,
      reason: PrismaReportReason.SPAM,
    });
    const service = createReportsService({ reportsRepository, usersService });

    await expect(
      service.listReportsForAdmin(makeCurrentUser(), {
        page: 1,
        limit: 10,
      }),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only ADMIN users can manage reports.',
    });
  });
});
