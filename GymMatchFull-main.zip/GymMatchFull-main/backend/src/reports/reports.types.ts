import type {
  Conversation,
  Message,
  Report,
  ReportReason,
  ReportStatus,
  ReportType,
} from '@prisma/client';
import {
  ReportReason as PrismaReportReason,
  ReportStatus as PrismaReportStatus,
  ReportType as PrismaReportType,
} from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';
import type { SafeUser } from '../users/users.types.js';

export const REPORT_TYPES = [
  PrismaReportType.USER,
  PrismaReportType.PROFILE,
  PrismaReportType.MESSAGE,
  PrismaReportType.CONVERSATION,
] as const;

export const REPORT_REASONS = [
  PrismaReportReason.HARASSMENT,
  PrismaReportReason.FAKE_PROFILE,
  PrismaReportReason.OFFENSIVE_LANGUAGE,
  PrismaReportReason.SPAM,
  PrismaReportReason.INAPPROPRIATE_BEHAVIOR,
  PrismaReportReason.RACISM,
  PrismaReportReason.OTHER,
] as const;

export const REPORT_STATUSES = [
  PrismaReportStatus.OPEN,
  PrismaReportStatus.IN_REVIEW,
  PrismaReportStatus.RESOLVED,
  PrismaReportStatus.REJECTED,
] as const;

export const DEFAULT_REPORT_STATUS = PrismaReportStatus.OPEN;

export interface CreateReportInput {
  reporterUserId: string;
  reportedUserId: string;
  type: ReportType;
  reason: ReportReason;
  description?: string | null;
  isUrgent?: boolean;
  messageId?: string;
  conversationId?: string;
  deletedAt?: Date;
}

export interface CreateUserReportForCurrentUserInput {
  reportedUserId: string;
  reason: ReportReason | string;
  description?: string | null;
}

export interface CreateMessageReportForCurrentUserInput {
  messageId: string;
  reason: ReportReason | string;
  description?: string | null;
}

export type ReportRecord = Report;
export type SafeReport = ReportRecord;

export type ReportMessageContextRecord = Pick<Message, 'id' | 'conversationId' | 'senderId'>;
export type AdminReportMessageRecord = Pick<
  Message,
  'id' | 'conversationId' | 'senderId' | 'type' | 'status' | 'content' | 'mediaReference' | 'createdAt'
>;

export interface ReportConversationContextRecord extends Pick<Conversation, 'id'> {
  match: {
    userAId: string;
    userBId: string;
  };
}

export interface ListAdminReportsQueryInput {
  page: number;
  limit: number;
  status?: ReportStatus;
  isUrgent?: boolean;
  type?: ReportType;
  reason?: ReportReason;
}

export interface PaginationResult {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export type SafeAdminReportUserSummary = Pick<SafeUser, 'id' | 'name' | 'role' | 'status'>;
export type SafeAdminReportMessage = AdminReportMessageRecord;

export interface SafeAdminReportListItem extends ReportRecord {
  reporterUser: SafeAdminReportUserSummary;
  reportedUser: SafeAdminReportUserSummary;
}

export interface SafeAdminReportDetail extends SafeAdminReportListItem {
  message: SafeAdminReportMessage | null;
}

export interface ListAdminReportsResult {
  data: SafeAdminReportListItem[];
  pagination: PaginationResult;
}

export interface ReportsServiceContract {
  createReport(input: CreateReportInput): Promise<SafeReport>;
  createMessageReportForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateMessageReportForCurrentUserInput,
  ): Promise<SafeReport>;
  createUserReportForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateUserReportForCurrentUserInput,
  ): Promise<SafeReport>;
  findReportById(reportId: string): Promise<SafeReport | null>;
  findReportsSentByUser(reporterUserId: string): Promise<SafeReport[]>;
  findReportsReceivedByUser(reportedUserId: string): Promise<SafeReport[]>;
  listReportsForAdmin(
    currentUser: CurrentUserContext,
    input: ListAdminReportsQueryInput,
  ): Promise<ListAdminReportsResult>;
  getReportDetailForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
  ): Promise<SafeAdminReportDetail>;
  updateReportStatusForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
    status: ReportStatus,
  ): Promise<SafeAdminReportDetail>;
  updateReportUrgencyForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
    isUrgent: boolean,
  ): Promise<SafeAdminReportDetail>;
  suspendReportedUserForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
  ): Promise<SafeAdminReportDetail>;
  banReportedUserForAdmin(
    currentUser: CurrentUserContext,
    reportId: string,
  ): Promise<SafeAdminReportDetail>;
}

export class ReportSelfReportError extends Error {
  constructor() {
    super('A user cannot report themselves.');
    this.name = 'ReportSelfReportError';
  }
}
