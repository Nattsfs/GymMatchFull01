import { access, mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { afterEach, describe, expect, it } from 'vitest';

import { LocalStorageService } from './local-storage.service.js';

const temporaryDirectories: string[] = [];

async function createTemporaryDirectory(): Promise<string> {
  const directory = await mkdtemp(join(tmpdir(), 'gymmatch-storage-'));

  temporaryDirectories.push(directory);

  return directory;
}

afterEach(async () => {
  while (temporaryDirectories.length > 0) {
    const directory = temporaryDirectories.pop();

    if (directory) {
      await rm(directory, { recursive: true, force: true });
    }
  }
});

describe('LocalStorageService', () => {
  it('saves files under the configured root directory and returns a public URL', async () => {
    const rootDirectory = await createTemporaryDirectory();
    const service = new LocalStorageService({
      rootDirectory,
      publicPathPrefix: '/storage',
    });

    const savedFile = await service.saveFile({
      key: 'profile-photos/student_1/profile.jpg',
      contentType: 'image/jpeg',
      data: Buffer.from([0xff, 0xd8, 0xff]),
    });

    expect(savedFile).toEqual({
      key: 'profile-photos/student_1/profile.jpg',
      publicUrl: '/storage/profile-photos/student_1/profile.jpg',
    });

    const storedBuffer = await readFile(join(rootDirectory, 'profile-photos/student_1/profile.jpg'));

    expect(storedBuffer.equals(Buffer.from([0xff, 0xd8, 0xff]))).toBe(true);
  });

  it('deletes files by their public URL when they were stored locally', async () => {
    const rootDirectory = await createTemporaryDirectory();
    const service = new LocalStorageService({
      rootDirectory,
      publicPathPrefix: '/storage',
    });

    await service.saveFile({
      key: 'profile-photos/student_2/profile.png',
      contentType: 'image/png',
      data: Buffer.from([0x89, 0x50, 0x4e, 0x47]),
    });

    await service.deleteFileByPublicUrl('/storage/profile-photos/student_2/profile.png');

    await expect(
      access(join(rootDirectory, 'profile-photos/student_2/profile.png')),
    ).rejects.toMatchObject({
      code: 'ENOENT',
    });
  });
});
