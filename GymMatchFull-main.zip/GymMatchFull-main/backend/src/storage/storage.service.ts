export interface SaveFileInput {
  key: string;
  contentType: string;
  data: Buffer;
}

export interface SaveFileResult {
  key: string;
  publicUrl: string;
}

export interface StorageServiceContract {
  saveFile(input: SaveFileInput): Promise<SaveFileResult>;
  deleteFileByPublicUrl(publicUrl: string): Promise<void>;
}
