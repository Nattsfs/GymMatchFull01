import { mkdir, unlink, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import type { SaveFileInput, SaveFileResult, StorageServiceContract } from './storage.service.js';

const storageDirectory = dirname(fileURLToPath(import.meta.url));

export const LOCAL_STORAGE_ROOT_DIRECTORY = resolve(storageDirectory, '../../../tmp/storage');
export const LOCAL_STORAGE_PUBLIC_PATH_PREFIX = '/storage';

interface LocalStorageServiceOptions {
  rootDirectory?: string;
  publicPathPrefix?: string;
}

export class LocalStorageService implements StorageServiceContract {
  private readonly rootDirectory: string;
  private readonly publicPathPrefix: string;

  constructor(options: LocalStorageServiceOptions = {}) {
    this.rootDirectory = options.rootDirectory ?? LOCAL_STORAGE_ROOT_DIRECTORY;
    this.publicPathPrefix = normalizePublicPathPrefix(
      options.publicPathPrefix ?? LOCAL_STORAGE_PUBLIC_PATH_PREFIX,
    );
  }

  async saveFile(input: SaveFileInput): Promise<SaveFileResult> {
    const key = normalizeStorageKey(input.key);
    const absolutePath = resolve(this.rootDirectory, key);
    const parentDirectory = dirname(absolutePath);

    await mkdir(parentDirectory, { recursive: true });
    await writeFile(absolutePath, input.data);

    return {
      key,
      publicUrl: this.buildPublicUrl(key),
    };
  }

  async deleteFileByPublicUrl(publicUrl: string): Promise<void> {
    const key = this.parseStorageKey(publicUrl);

    if (!key) {
      return;
    }

    const absolutePath = resolve(this.rootDirectory, key);

    try {
      await unlink(absolutePath);
    } catch (error) {
      if (isMissingFileError(error)) {
        return;
      }

      throw error;
    }
  }

  private buildPublicUrl(key: string): string {
    return `${this.publicPathPrefix}/${key}`;
  }

  private parseStorageKey(publicUrl: string): string | null {
    const normalizedPublicUrl = publicUrl.trim();
    const expectedPrefix = `${this.publicPathPrefix}/`;

    if (!normalizedPublicUrl.startsWith(expectedPrefix)) {
      return null;
    }

    return normalizeStorageKey(normalizedPublicUrl.slice(expectedPrefix.length));
  }
}

function normalizePublicPathPrefix(value: string): string {
  const normalizedValue = value.trim().replace(/\/+$/, '');

  if (!normalizedValue.startsWith('/')) {
    return `/${normalizedValue}`;
  }

  return normalizedValue;
}

function normalizeStorageKey(key: string): string {
  const normalizedKey = key.replace(/\\/g, '/').replace(/^\/+/, '');
  const segments = normalizedKey.split('/').filter((segment) => segment.length > 0);

  if (segments.length === 0 || segments.some((segment) => segment === '.' || segment === '..')) {
    throw new Error('Invalid storage key.');
  }

  return segments.join('/');
}

function isMissingFileError(error: unknown): boolean {
  return (
    typeof error === 'object' &&
    error !== null &&
    'code' in error &&
    error.code === 'ENOENT'
  );
}
