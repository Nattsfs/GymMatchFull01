export {
  LocalStorageService,
  LOCAL_STORAGE_PUBLIC_PATH_PREFIX,
  LOCAL_STORAGE_ROOT_DIRECTORY,
} from './local-storage.service.js';
export type { SaveFileInput, SaveFileResult, StorageServiceContract } from './storage.service.js';
