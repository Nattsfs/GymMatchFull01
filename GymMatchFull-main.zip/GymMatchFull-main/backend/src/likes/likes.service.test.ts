import type { PrismaClient } from '@prisma/client';
import {
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  MatchStatus as PrismaMatchStatus,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { BlocksServiceContract } from '../blocks/blocks.types.js';
import type { ChatServiceContract, ConversationRecord } from '../chat/chat.types.js';
import { FREE_PLAN_ACTIVE_MATCH_LIMIT } from '../common/constants/plans.js';
import type { SafeUser } from '../users/users.types.js';
import { HttpError } from '../common/errors/http-error.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import type { CreateMatchInput, MatchRecord } from '../matches/matches.types.js';
import { MatchConflictError, MatchSelfMatchError } from '../matches/matches.types.js';
import { ProfilesRepository } from '../profiles/profiles.repository.js';
import type { ProfileRecord } from '../profiles/profiles.types.js';
import { LikesRepository } from './likes.repository.js';
import { FREE_PLAN_DAILY_LIKE_LIMIT, LikesService } from './likes.service.js';
import type { CreateLikeInput, LikeRecord } from './likes.types.js';
import { LikeConflictError, LikeSelfLikeError } from './likes.types.js';

const FIXED_NOW = new Date('2026-05-10T15:00:00.000Z');

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

interface SeedProfileInput {
  deletedAt?: Date | null;
  isComplete?: boolean;
  profilePhotoUrl?: string | null;
  userId: string;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryProfilesRepository {
  private readonly profiles: ProfileRecord[] = [];

  seedProfile(input: SeedProfileInput): ProfileRecord {
    const profile: ProfileRecord = {
      id: `profile_${this.profiles.length + 1}`,
      userId: input.userId,
      birthDate: new Date('1998-01-15T00:00:00.000Z'),
      gender: PrismaProfileGender.WOMAN,
      sexualOrientation: PrismaSexualOrientation.BISEXUAL,
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      availablePeriods: [PrismaAvailablePeriod.MORNING],
      preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl:
        input.profilePhotoUrl === undefined
          ? 'https://cdn.gymmatch.test/profile.jpg'
          : input.profilePhotoUrl,
      isComplete: input.isComplete ?? true,
      bio: null,
      showSexualOrientation: false,
      showAvailablePeriods: true,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.profiles.push(profile);

    return profile;
  }

  async findActiveProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.profiles.find((profile) => profile.userId === userId && profile.deletedAt === null) ?? null;
  }
}

class InMemoryChatConversationService {
  private readonly conversations: ConversationRecord[] = [];
  private nextConversationId = 1;

  async getOrCreateConversation(input: { matchId: string }): Promise<ConversationRecord> {
    const existingConversation = this.conversations.find(
      (conversation) => conversation.matchId === input.matchId,
    );

    if (existingConversation) {
      return existingConversation;
    }

    const conversation: ConversationRecord = {
      id: `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  findConversationByMatchId(matchId: string): ConversationRecord | null {
    return this.conversations.find((conversation) => conversation.matchId === matchId) ?? null;
  }

  seedConversation(input: { id?: string; matchId: string }): ConversationRecord {
    const conversation: ConversationRecord = {
      id: input.id ?? `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }

  countConversations(): number {
    return this.conversations.length;
  }
}

class InMemoryBlocksService {
  private readonly blockedPairs = new Set<string>();

  seedBlock(firstUserId: string, secondUserId: string): void {
    this.blockedPairs.add(buildPairKey(firstUserId, secondUserId));
  }

  async blockExistsBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    if (firstUserId === secondUserId) {
      return false;
    }

    return this.blockedPairs.has(buildPairKey(firstUserId, secondUserId));
  }
}

class InMemoryLikesRepository {
  private readonly likes: LikeRecord[] = [];
  private nextId = 1;

  async createLike(input: CreateLikeInput): Promise<LikeRecord> {
    if (input.likedByUserId === input.likedUserId) {
      throw new LikeSelfLikeError();
    }

    const existingLike = this.likes.find(
      (like) =>
        like.likedByUserId === input.likedByUserId &&
        like.likedUserId === input.likedUserId &&
        like.deletedAt === null,
    );

    if (existingLike) {
      throw new LikeConflictError('userPair');
    }

    const now = FIXED_NOW;
    const like: LikeRecord = {
      id: `like_${this.nextId++}`,
      likedByUserId: input.likedByUserId,
      likedUserId: input.likedUserId,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.likes.push(like);

    return like;
  }

  async findActiveLikeBetweenUsers(
    likedByUserId: string,
    likedUserId: string,
  ): Promise<LikeRecord | null> {
    return (
      this.likes.find(
        (like) =>
          like.likedByUserId === likedByUserId &&
          like.likedUserId === likedUserId &&
          like.deletedAt === null,
      ) ?? null
    );
  }

  async findActiveLikesSentByUser(likedByUserId: string): Promise<LikeRecord[]> {
    return this.likes.filter(
      (like) => like.likedByUserId === likedByUserId && like.deletedAt === null,
    );
  }

  async findActiveLikesReceivedByUser(likedUserId: string): Promise<LikeRecord[]> {
    return this.likes.filter((like) => like.likedUserId === likedUserId && like.deletedAt === null);
  }

  async countActiveLikesSentByUserBetween(
    likedByUserId: string,
    rangeStart: Date,
    rangeEnd: Date,
  ): Promise<number> {
    return this.likes.filter(
      (like) =>
        like.likedByUserId === likedByUserId &&
        like.deletedAt === null &&
        like.createdAt >= rangeStart &&
        like.createdAt < rangeEnd,
    ).length;
  }

  seedLike(input: CreateLikeInput & { createdAt?: Date; updatedAt?: Date }): LikeRecord {
    const like: LikeRecord = {
      id: `like_${this.nextId++}`,
      likedByUserId: input.likedByUserId,
      likedUserId: input.likedUserId,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.likes.push(like);

    return like;
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async createMatch(input: CreateMatchInput): Promise<MatchRecord> {
    if (input.userAId === input.userBId) {
      throw new MatchSelfMatchError();
    }

    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const existingMatch = this.matches.find(
      (match) =>
        match.userAId === normalizedPair.userAId &&
        match.userBId === normalizedPair.userBId &&
        match.deletedAt === null,
    );

    if (existingMatch) {
      throw new MatchConflictError('userPair');
    }

    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  async findActiveMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (match) =>
          match.userAId === normalizedPair.userAId &&
          match.userBId === normalizedPair.userBId &&
          match.deletedAt === null,
      ) ?? null
    );
  }

  async countActiveMatchesForUser(userId: string, now: Date): Promise<number> {
    return this.matches.filter(
      (match) =>
        match.deletedAt === null &&
        match.status === PrismaMatchStatus.ACTIVE &&
        (match.userAId === userId || match.userBId === userId) &&
        (match.expiresAt === null || match.expiresAt.getTime() > now.getTime()),
    ).length;
  }

  seedMatch(input: CreateMatchInput): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  countActiveMatches(): number {
    return this.matches.filter((match) => match.deletedAt === null).length;
  }
}

function normalizeUserPair(firstUserId: string, secondUserId: string): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function buildPairKey(firstUserId: string, secondUserId: string): string {
  const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

  return `${normalizedPair.userAId}:${normalizedPair.userBId}`;
}

function createLikesService(options: {
  blocksService?: InMemoryBlocksService;
  chatService?: InMemoryChatConversationService;
  likesRepository?: InMemoryLikesRepository;
  matchesRepository?: InMemoryMatchesRepository;
  profilesRepository?: InMemoryProfilesRepository;
  usersService?: InMemoryUsersService;
  now?: () => Date;
} = {}): LikesService {
  return new LikesService({} as PrismaClient, {
    blocksService:
      (options.blocksService ?? new InMemoryBlocksService()) as unknown as Pick<
        BlocksServiceContract,
        'blockExistsBetweenUsers'
      >,
    chatService:
      (options.chatService ??
        new InMemoryChatConversationService()) as unknown as Pick<
        ChatServiceContract,
        'getOrCreateConversation'
      >,
    likesRepository:
      (options.likesRepository ?? new InMemoryLikesRepository()) as unknown as LikesRepository,
    matchesRepository:
      (options.matchesRepository ??
        new InMemoryMatchesRepository()) as unknown as MatchesRepository,
    profilesRepository:
      (options.profilesRepository ??
        new InMemoryProfilesRepository()) as unknown as ProfilesRepository,
    usersService:
      (options.usersService ?? new InMemoryUsersService()) as unknown as AuthUsersServiceContract,
    now: options.now ?? (() => FIXED_NOW),
  });
}

function toCurrentUser(user: Pick<SafeUser, 'id' | 'role' | 'status'>) {
  return {
    id: user.id,
    role: user.role,
    status: user.status,
  };
}

describe('LikesService', () => {
  it('creates a simple like without creating a match', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });
    const service = createLikesService({ usersService, profilesRepository });

    const result = await service.createForCurrentUser(toCurrentUser(sender), {
      likedUserId: target.id,
    });

    expect(result).toMatchObject({
      matchCreated: false,
      match: null,
    });
    expect(result.like.likedByUserId).toBe(sender.id);
    expect(result.like.likedUserId).toBe(target.id);
  });

  it('rejects likes when a block exists in either direction', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const blocksService = new InMemoryBlocksService();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });
    blocksService.seedBlock(sender.id, target.id);
    const service = createLikesService({ usersService, profilesRepository, blocksService });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        likedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Users cannot like each other when a block exists between them.',
    });
  });

  it('creates an active match when the like is mutual', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const chatService = new InMemoryChatConversationService();
    const likesRepository = new InMemoryLikesRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    const sender = usersService.seedUser({ id: 'student_9' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });
    const service = createLikesService({
      chatService,
      likesRepository,
      matchesRepository,
      profilesRepository,
      usersService,
    });

    const result = await service.createForCurrentUser(toCurrentUser(sender), {
      likedUserId: target.id,
    });

    expect(result.matchCreated).toBe(true);
    expect(result.match).toMatchObject({
      userAId: target.id,
      userBId: sender.id,
      status: PrismaMatchStatus.ACTIVE,
      deletedAt: null,
    });
    expect(matchesRepository.countActiveMatches()).toBe(1);
    expect(chatService.findConversationByMatchId(result.match!.id)).toMatchObject({
      matchId: result.match!.id,
    });
    expect(chatService.countConversations()).toBe(1);
  });

  it('does not count non-active matches toward the free plan active match limit', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const likesRepository = new InMemoryLikesRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });
    matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: 'student_blocked',
      status: PrismaMatchStatus.BLOCKED,
    });
    matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: 'student_expired_status',
      status: PrismaMatchStatus.EXPIRED,
    });
    matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: 'student_unmatched',
      status: PrismaMatchStatus.UNMATCHED,
    });
    matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: 'student_expired_at',
      status: PrismaMatchStatus.ACTIVE,
      expiresAt: new Date('2026-05-10T14:59:59.000Z'),
    });
    matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: 'student_deleted',
      status: PrismaMatchStatus.ACTIVE,
      deletedAt: new Date('2026-05-10T14:00:00.000Z'),
    });
    const service = createLikesService({
      likesRepository,
      matchesRepository,
      profilesRepository,
      usersService,
    });

    await expect(matchesRepository.countActiveMatchesForUser(sender.id, FIXED_NOW)).resolves.toBe(0);

    const result = await service.createForCurrentUser(toCurrentUser(sender), {
      likedUserId: target.id,
    });

    expect(result.matchCreated).toBe(true);
    await expect(matchesRepository.countActiveMatchesForUser(sender.id, FIXED_NOW)).resolves.toBe(1);
  });

  it('rejects a mutual like when the sender has reached the free plan active match limit', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const likesRepository = new InMemoryLikesRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });

    for (let index = 0; index < FREE_PLAN_ACTIVE_MATCH_LIMIT; index += 1) {
      matchesRepository.seedMatch({
        userAId: sender.id,
        userBId: `student_limit_${index}`,
        status: PrismaMatchStatus.ACTIVE,
      });
    }

    const service = createLikesService({
      likesRepository,
      matchesRepository,
      profilesRepository,
      usersService,
    });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        likedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      name: HttpError.name,
      statusCode: 403,
      message: `Cannot create a new match because one of the users has reached the free plan limit of active matches. Limit: ${FREE_PLAN_ACTIVE_MATCH_LIMIT} active matches.`,
    });
    await expect(likesRepository.findActiveLikeBetweenUsers(sender.id, target.id)).resolves.toBeNull();
    expect(matchesRepository.countActiveMatches()).toBe(FREE_PLAN_ACTIVE_MATCH_LIMIT);
  });

  it('does not create a duplicate match when one already exists', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const chatService = new InMemoryChatConversationService();
    const likesRepository = new InMemoryLikesRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    const sender = usersService.seedUser({ id: 'student_9' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });
    const existingMatch = matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: target.id,
      status: PrismaMatchStatus.ACTIVE,
    });
    chatService.seedConversation({
      matchId: existingMatch.id,
    });
    const service = createLikesService({
      chatService,
      likesRepository,
      matchesRepository,
      profilesRepository,
      usersService,
    });

    const result = await service.createForCurrentUser(toCurrentUser(sender), {
      likedUserId: target.id,
    });

    expect(result).toMatchObject({
      matchCreated: false,
      match: null,
    });
    expect(matchesRepository.countActiveMatches()).toBe(1);
    expect(chatService.countConversations()).toBe(1);
  });

  it('creates a missing conversation for an existing active match without duplicating the match', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const chatService = new InMemoryChatConversationService();
    const likesRepository = new InMemoryLikesRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    const sender = usersService.seedUser({ id: 'student_20' });
    const target = usersService.seedUser({ id: 'student_21' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });
    const existingMatch = matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: target.id,
      status: PrismaMatchStatus.ACTIVE,
    });
    const service = createLikesService({
      chatService,
      likesRepository,
      matchesRepository,
      profilesRepository,
      usersService,
    });

    const result = await service.createForCurrentUser(toCurrentUser(sender), {
      likedUserId: target.id,
    });

    expect(result).toMatchObject({
      matchCreated: false,
      match: null,
    });
    expect(matchesRepository.countActiveMatches()).toBe(1);
    expect(chatService.findConversationByMatchId(existingMatch.id)).toMatchObject({
      matchId: existingMatch.id,
    });
    expect(chatService.countConversations()).toBe(1);
  });

  it('does not create a match when the sender profile is incomplete', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const likesRepository = new InMemoryLikesRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id, isComplete: false });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });
    const service = createLikesService({
      likesRepository,
      matchesRepository,
      profilesRepository,
      usersService,
    });

    const result = await service.createForCurrentUser(toCurrentUser(sender), {
      likedUserId: target.id,
    });

    expect(result).toMatchObject({
      matchCreated: false,
      match: null,
    });
    expect(matchesRepository.countActiveMatches()).toBe(0);
  });

  it('blocks non-student senders', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });
    const service = createLikesService({ usersService, profilesRepository });

    await expect(
      service.createForCurrentUser(toCurrentUser(admin), {
        likedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      name: HttpError.name,
      statusCode: 403,
      message: 'Only STUDENT users can send likes.',
    });
  });

  it('prevents a user from liking themselves', async () => {
    const usersService = new InMemoryUsersService();
    const sender = usersService.seedUser({ id: 'student_1' });
    const service = createLikesService({ usersService });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        likedUserId: sender.id,
      }),
    ).rejects.toMatchObject({
      name: HttpError.name,
      statusCode: 400,
      message: 'Users cannot like themselves.',
    });
  });

  it('prevents duplicate likes for the same user pair', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const likesRepository = new InMemoryLikesRepository();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: sender.id,
      likedUserId: target.id,
    });
    const service = createLikesService({ likesRepository, profilesRepository, usersService });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        likedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      name: HttpError.name,
      statusCode: 409,
      message: 'Like already exists between these users.',
    });
  });

  it('rejects targets from another gym unit', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const sender = usersService.seedUser({ id: 'student_1', gymId: 'gym_1', gymUnitId: 'unit_1' });
    const target = usersService.seedUser({ id: 'student_2', gymId: 'gym_1', gymUnitId: 'unit_2' });
    profilesRepository.seedProfile({ userId: target.id });
    const service = createLikesService({ usersService, profilesRepository });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        likedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      name: HttpError.name,
      statusCode: 400,
      message: 'Users can only like students from the same gym unit.',
    });
  });

  it('rejects inactive, banned, suspended and deleted targets', async () => {
    const statuses = [
      { id: 'student_suspended', status: PrismaUserStatus.SUSPENDED, deletedAt: null },
      { id: 'student_banned', status: PrismaUserStatus.BANNED, deletedAt: null },
      { id: 'student_pending', status: PrismaUserStatus.PENDING, deletedAt: null },
      {
        id: 'student_deleted',
        status: PrismaUserStatus.ACTIVE,
        deletedAt: new Date('2026-05-09T12:00:00.000Z'),
      },
    ] as const;

    for (const targetState of statuses) {
      const usersService = new InMemoryUsersService();
      const profilesRepository = new InMemoryProfilesRepository();
      const sender = usersService.seedUser({ id: 'student_1' });
      const target = usersService.seedUser({
        id: targetState.id,
        status: targetState.status,
        deletedAt: targetState.deletedAt,
      });
      profilesRepository.seedProfile({ userId: target.id });
      const service = createLikesService({ usersService, profilesRepository });

      await expect(
        service.createForCurrentUser(toCurrentUser(sender), {
          likedUserId: target.id,
        }),
      ).rejects.toMatchObject({
        name: HttpError.name,
        statusCode: 400,
      });
    }
  });

  it('rejects incomplete profiles and profiles without photo', async () => {
    const cases = [
      {
        profile: { isComplete: false },
        expectedMessage: 'Liked user profile is incomplete.',
      },
      {
        profile: { profilePhotoUrl: null },
        expectedMessage: 'Liked user must have a profile photo.',
      },
      {
        profile: { profilePhotoUrl: '   ' },
        expectedMessage: 'Liked user must have a profile photo.',
      },
    ] as const;

    for (const testCase of cases) {
      const usersService = new InMemoryUsersService();
      const profilesRepository = new InMemoryProfilesRepository();
      const sender = usersService.seedUser({ id: 'student_1' });
      const target = usersService.seedUser({ id: 'student_2' });
      const profileInput: SeedProfileInput = {
        userId: target.id,
        ...('isComplete' in testCase.profile ? { isComplete: testCase.profile.isComplete } : {}),
        ...('profilePhotoUrl' in testCase.profile
          ? { profilePhotoUrl: testCase.profile.profilePhotoUrl }
          : {}),
      };
      profilesRepository.seedProfile(profileInput);
      const service = createLikesService({ usersService, profilesRepository });

      await expect(
        service.createForCurrentUser(toCurrentUser(sender), {
          likedUserId: target.id,
        }),
      ).rejects.toMatchObject({
        name: HttpError.name,
        statusCode: 400,
        message: testCase.expectedMessage,
      });
    }
  });

  it('enforces the centralized free plan daily like limit', async () => {
    const usersService = new InMemoryUsersService();
    const profilesRepository = new InMemoryProfilesRepository();
    const likesRepository = new InMemoryLikesRepository();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });

    for (let index = 0; index < FREE_PLAN_DAILY_LIKE_LIMIT; index += 1) {
      likesRepository.seedLike({
        likedByUserId: sender.id,
        likedUserId: `student_${index + 10}`,
      });
    }

    const service = createLikesService({
      likesRepository,
      profilesRepository,
      usersService,
      now: () => FIXED_NOW,
    });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        likedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      name: HttpError.name,
      statusCode: 403,
      message: `Free plan daily like limit reached. Limit: ${FREE_PLAN_DAILY_LIKE_LIMIT} likes per day.`,
    });
  });

  it('finds likes by pair and by sender or receiver', async () => {
    const likesRepository = new InMemoryLikesRepository();
    const service = createLikesService({ likesRepository });

    await service.createLike({
      likedByUserId: 'student_1',
      likedUserId: 'student_2',
    });
    await service.createLike({
      likedByUserId: 'student_1',
      likedUserId: 'student_3',
    });
    await service.createLike({
      likedByUserId: 'student_4',
      likedUserId: 'student_2',
    });

    const likeBetweenUsers = await service.findLikeBetweenUsers('student_1', 'student_2');
    const likesSentByUser = await service.findLikesSentByUser('student_1');
    const likesReceivedByUser = await service.findLikesReceivedByUser('student_2');

    expect(likeBetweenUsers).not.toBeNull();
    expect(likesSentByUser).toHaveLength(2);
    expect(likesReceivedByUser).toHaveLength(2);
  });
});
