import type { PrismaClient } from '@prisma/client';
import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  MatchStatus as PrismaMatchStatus,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { BlocksServiceContract } from '../blocks/blocks.types.js';
import type { ChatServiceContract, ConversationRecord } from '../chat/chat.types.js';
import { FREE_PLAN_ACTIVE_MATCH_LIMIT } from '../common/constants/plans.js';
import { buildConfig } from '../config/env.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import type { CreateMatchInput, MatchRecord } from '../matches/matches.types.js';
import { MatchConflictError, MatchSelfMatchError } from '../matches/matches.types.js';
import { ProfilesRepository } from '../profiles/profiles.repository.js';
import type { ProfileRecord } from '../profiles/profiles.types.js';
import type { SafeUser } from '../users/users.types.js';
import { LikesRepository } from './likes.repository.js';
import { FREE_PLAN_DAILY_LIKE_LIMIT, LikesService } from './likes.service.js';
import type { CreateLikeInput, LikeRecord } from './likes.types.js';
import { LikeConflictError, LikeSelfLikeError } from './likes.types.js';

const FIXED_NOW = new Date('2026-05-10T15:00:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

interface SeedProfileInput {
  deletedAt?: Date | null;
  isComplete?: boolean;
  profilePhotoUrl?: string | null;
  userId: string;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryProfilesRepository {
  private readonly profiles: ProfileRecord[] = [];

  seedProfile(input: SeedProfileInput): ProfileRecord {
    const profile: ProfileRecord = {
      id: `profile_${this.profiles.length + 1}`,
      userId: input.userId,
      birthDate: new Date('1998-01-15T00:00:00.000Z'),
      gender: PrismaProfileGender.WOMAN,
      sexualOrientation: PrismaSexualOrientation.BISEXUAL,
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      availablePeriods: [PrismaAvailablePeriod.MORNING],
      preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl:
        input.profilePhotoUrl === undefined
          ? 'https://cdn.gymmatch.test/profile.jpg'
          : input.profilePhotoUrl,
      isComplete: input.isComplete ?? true,
      bio: null,
      showSexualOrientation: false,
      showAvailablePeriods: true,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.profiles.push(profile);

    return profile;
  }

  async findActiveProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.profiles.find((profile) => profile.userId === userId && profile.deletedAt === null) ?? null;
  }
}

class InMemoryLikesRepository {
  private readonly likes: LikeRecord[] = [];
  private nextId = 1;

  async createLike(input: CreateLikeInput): Promise<LikeRecord> {
    if (input.likedByUserId === input.likedUserId) {
      throw new LikeSelfLikeError();
    }

    const existingLike = this.likes.find(
      (like) =>
        like.likedByUserId === input.likedByUserId &&
        like.likedUserId === input.likedUserId &&
        like.deletedAt === null,
    );

    if (existingLike) {
      throw new LikeConflictError('userPair');
    }

    const like: LikeRecord = {
      id: `like_${this.nextId++}`,
      likedByUserId: input.likedByUserId,
      likedUserId: input.likedUserId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.likes.push(like);

    return like;
  }

  async findActiveLikeBetweenUsers(
    likedByUserId: string,
    likedUserId: string,
  ): Promise<LikeRecord | null> {
    return (
      this.likes.find(
        (like) =>
          like.likedByUserId === likedByUserId &&
          like.likedUserId === likedUserId &&
          like.deletedAt === null,
      ) ?? null
    );
  }

  async findActiveLikesSentByUser(likedByUserId: string): Promise<LikeRecord[]> {
    return this.likes.filter(
      (like) => like.likedByUserId === likedByUserId && like.deletedAt === null,
    );
  }

  async findActiveLikesReceivedByUser(likedUserId: string): Promise<LikeRecord[]> {
    return this.likes.filter((like) => like.likedUserId === likedUserId && like.deletedAt === null);
  }

  async countActiveLikesSentByUserBetween(
    likedByUserId: string,
    rangeStart: Date,
    rangeEnd: Date,
  ): Promise<number> {
    return this.likes.filter(
      (like) =>
        like.likedByUserId === likedByUserId &&
        like.deletedAt === null &&
        like.createdAt >= rangeStart &&
        like.createdAt < rangeEnd,
    ).length;
  }

  seedLike(input: CreateLikeInput): LikeRecord {
    const like: LikeRecord = {
      id: `like_${this.nextId++}`,
      likedByUserId: input.likedByUserId,
      likedUserId: input.likedUserId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.likes.push(like);

    return like;
  }
}

class InMemoryChatConversationService {
  private readonly conversations: ConversationRecord[] = [];
  private nextConversationId = 1;

  async getOrCreateConversation(input: { matchId: string }): Promise<ConversationRecord> {
    const existingConversation = this.conversations.find(
      (conversation) => conversation.matchId === input.matchId,
    );

    if (existingConversation) {
      return existingConversation;
    }

    const conversation: ConversationRecord = {
      id: `conversation_${this.nextConversationId++}`,
      matchId: input.matchId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
    };

    this.conversations.push(conversation);

    return conversation;
  }
}

class InMemoryBlocksService {
  async blockExistsBetweenUsers(): Promise<boolean> {
    return false;
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async createMatch(input: CreateMatchInput): Promise<MatchRecord> {
    if (input.userAId === input.userBId) {
      throw new MatchSelfMatchError();
    }

    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const existingMatch = this.matches.find(
      (match) =>
        match.userAId === normalizedPair.userAId &&
        match.userBId === normalizedPair.userBId &&
        match.deletedAt === null,
    );

    if (existingMatch) {
      throw new MatchConflictError('userPair');
    }

    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  async findActiveMatchBetweenUsers(firstUserId: string, secondUserId: string): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (match) =>
          match.userAId === normalizedPair.userAId &&
          match.userBId === normalizedPair.userBId &&
          match.deletedAt === null,
      ) ?? null
    );
  }

  async countActiveMatchesForUser(userId: string, now: Date): Promise<number> {
    return this.matches.filter(
      (match) =>
        match.deletedAt === null &&
        match.status === PrismaMatchStatus.ACTIVE &&
        (match.userAId === userId || match.userBId === userId) &&
        (match.expiresAt === null || match.expiresAt.getTime() > now.getTime()),
    ).length;
  }

  seedMatch(input: CreateMatchInput): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  countActiveMatches(): number {
    return this.matches.filter((match) => match.deletedAt === null).length;
  }
}

function normalizeUserPair(firstUserId: string, secondUserId: string): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function createTestApp() {
  const blocksService = new InMemoryBlocksService();
  const usersService = new InMemoryUsersService();
  const chatService = new InMemoryChatConversationService();
  const profilesRepository = new InMemoryProfilesRepository();
  const likesRepository = new InMemoryLikesRepository();
  const matchesRepository = new InMemoryMatchesRepository();
  const likesService = new LikesService({} as PrismaClient, {
    blocksService: blocksService as unknown as Pick<
      BlocksServiceContract,
      'blockExistsBetweenUsers'
    >,
    chatService: chatService as unknown as Pick<ChatServiceContract, 'getOrCreateConversation'>,
    likesRepository: likesRepository as unknown as LikesRepository,
    matchesRepository: matchesRepository as unknown as MatchesRepository,
    profilesRepository: profilesRepository as unknown as ProfilesRepository,
    usersService: usersService as unknown as AuthUsersServiceContract,
    now: () => FIXED_NOW,
  });
  const app = buildApp({
    config,
    services: {
      likesService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    likesRepository,
    matchesRepository,
    profilesRepository,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('POST /likes', () => {
  it('creates a like for an authenticated student', async () => {
    const { app, profilesRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      like: {
        likedByUserId: sender.id,
        likedUserId: target.id,
        deletedAt: null,
      },
      matchCreated: false,
      match: null,
    });
  });

  it('returns match information when the like is mutual', async () => {
    const { app, likesRepository, matchesRepository, profilesRepository, usersService } =
      createTestApp();
    const sender = usersService.seedUser({ id: 'student_9' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      like: {
        likedByUserId: sender.id,
        likedUserId: target.id,
      },
      matchCreated: true,
      match: {
        userAId: target.id,
        userBId: sender.id,
        status: 'ACTIVE',
        deletedAt: null,
      },
    });
    expect(matchesRepository.countActiveMatches()).toBe(1);
  });

  it('returns a clear error when a mutual like would exceed the free plan active match limit', async () => {
    const { app, likesRepository, matchesRepository, profilesRepository, usersService } =
      createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: sender.id });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: target.id,
      likedUserId: sender.id,
    });

    for (let index = 0; index < FREE_PLAN_ACTIVE_MATCH_LIMIT; index += 1) {
      matchesRepository.seedMatch({
        userAId: target.id,
        userBId: `student_limit_${index}`,
        status: PrismaMatchStatus.ACTIVE,
      });
    }

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: `Cannot create a new match because one of the users has reached the free plan limit of active matches. Limit: ${FREE_PLAN_ACTIVE_MATCH_LIMIT} active matches.`,
    });
    await expect(likesRepository.findActiveLikeBetweenUsers(sender.id, target.id)).resolves.toBeNull();
    expect(matchesRepository.countActiveMatches()).toBe(FREE_PLAN_ACTIVE_MATCH_LIMIT);
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      payload: {
        likedUserId: 'student_2',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from liking profiles', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        likedUserId: 'student_2',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('prevents liking yourself', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: sender.id,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Users cannot like themselves.',
    });
  });

  it('prevents duplicate likes', async () => {
    const { app, likesRepository, profilesRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });
    likesRepository.seedLike({
      likedByUserId: sender.id,
      likedUserId: target.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Like already exists between these users.',
    });
  });

  it('rejects targets from another gym unit', async () => {
    const { app, profilesRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1', gymId: 'gym_1', gymUnitId: 'unit_1' });
    const target = usersService.seedUser({ id: 'student_2', gymId: 'gym_1', gymUnitId: 'unit_2' });
    profilesRepository.seedProfile({ userId: target.id });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Users can only like students from the same gym unit.',
    });
  });

  it('rejects incomplete profiles and profiles without photo', async () => {
    const testCases = [
      {
        profile: { isComplete: false },
        expectedMessage: 'Liked user profile is incomplete.',
      },
      {
        profile: { profilePhotoUrl: null },
        expectedMessage: 'Liked user must have a profile photo.',
      },
    ] as const;

    for (const testCase of testCases) {
      const { app, profilesRepository, usersService } = createTestApp();
      const sender = usersService.seedUser({ id: 'student_1' });
      const target = usersService.seedUser({ id: 'student_2' });
      const profileInput: SeedProfileInput = {
        userId: target.id,
        ...('isComplete' in testCase.profile ? { isComplete: testCase.profile.isComplete } : {}),
        ...('profilePhotoUrl' in testCase.profile
          ? { profilePhotoUrl: testCase.profile.profilePhotoUrl }
          : {}),
      };
      profilesRepository.seedProfile(profileInput);

      await app.ready();

      const response = await app.inject({
        method: 'POST',
        url: '/likes',
        headers: {
          authorization: `Bearer ${signAccessToken(app, sender)}`,
        },
        payload: {
          likedUserId: target.id,
        },
      });

      expect(response.statusCode).toBe(400);
      expect(response.json()).toEqual({
        statusCode: 400,
        error: 'Bad Request',
        message: testCase.expectedMessage,
      });
    }
  });

  it('rejects inactive and deleted targets', async () => {
    const testCases = [
      {
        user: {
          status: PrismaUserStatus.SUSPENDED,
          deletedAt: null,
        },
        expectedMessage: 'Liked user is not active.',
      },
      {
        user: {
          status: PrismaUserStatus.ACTIVE,
          deletedAt: new Date('2026-05-09T00:00:00.000Z'),
        },
        expectedMessage: 'Liked user has been deleted.',
      },
    ] as const;

    for (const testCase of testCases) {
      const { app, profilesRepository, usersService } = createTestApp();
      const sender = usersService.seedUser({ id: 'student_1' });
      const target = usersService.seedUser({
        id: 'student_2',
        status: testCase.user.status,
        deletedAt: testCase.user.deletedAt,
      });
      profilesRepository.seedProfile({ userId: target.id });

      await app.ready();

      const response = await app.inject({
        method: 'POST',
        url: '/likes',
        headers: {
          authorization: `Bearer ${signAccessToken(app, sender)}`,
        },
        payload: {
          likedUserId: target.id,
        },
      });

      expect(response.statusCode).toBe(400);
      expect(response.json()).toEqual({
        statusCode: 400,
        error: 'Bad Request',
        message: testCase.expectedMessage,
      });
    }
  });

  it('enforces the centralized free plan daily like limit', async () => {
    const { app, likesRepository, profilesRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    profilesRepository.seedProfile({ userId: target.id });

    for (let index = 0; index < FREE_PLAN_DAILY_LIKE_LIMIT; index += 1) {
      likesRepository.seedLike({
        likedByUserId: sender.id,
        likedUserId: `student_${index + 10}`,
      });
    }

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/likes',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        likedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: `Free plan daily like limit reached. Limit: ${FREE_PLAN_DAILY_LIKE_LIMIT} likes per day.`,
    });
  });
});
