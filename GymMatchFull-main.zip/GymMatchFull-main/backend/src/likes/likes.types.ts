import type { Like } from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';
import type { SafeMatch } from '../matches/matches.types.js';

export interface CreateLikeInput {
  likedByUserId: string;
  likedUserId: string;
  deletedAt?: Date;
}

export interface CreateLikeForCurrentUserInput {
  likedUserId: string;
}

export type LikeRecord = Like;
export type SafeLike = LikeRecord;

export interface CreateLikeForCurrentUserResult {
  like: SafeLike;
  matchCreated: boolean;
  match: SafeMatch | null;
}

export interface LikesServiceContract {
  createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateLikeForCurrentUserInput,
  ): Promise<CreateLikeForCurrentUserResult>;
  createLike(input: CreateLikeInput): Promise<SafeLike>;
  findLikeBetweenUsers(likedByUserId: string, likedUserId: string): Promise<SafeLike | null>;
  findLikesSentByUser(likedByUserId: string): Promise<SafeLike[]>;
  findLikesReceivedByUser(likedUserId: string): Promise<SafeLike[]>;
}

export class LikeConflictError extends Error {
  readonly field: 'userPair' | 'unknown';

  constructor(field: 'userPair' | 'unknown') {
    const fieldLabel = field === 'userPair' ? 'user like pair' : 'unique like field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'LikeConflictError';
    this.field = field;
  }
}

export class LikeSelfLikeError extends Error {
  constructor() {
    super('A user cannot like themselves.');
    this.name = 'LikeSelfLikeError';
  }
}
