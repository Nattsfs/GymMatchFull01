import {
  MatchStatus as PrismaMatchStatus,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  type PrismaClient,
} from '@prisma/client';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { BlocksService } from '../blocks/blocks.service.js';
import type { BlocksServiceContract } from '../blocks/blocks.types.js';
import { ChatService } from '../chat/chat.service.js';
import type { ChatServiceContract } from '../chat/chat.types.js';
import { HttpError } from '../common/errors/http-error.js';
import { FREE_PLAN_ACTIVE_MATCH_LIMIT } from '../common/constants/plans.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import { MatchConflictError, MatchSelfMatchError } from '../matches/matches.types.js';
import type { SafeMatch } from '../matches/matches.types.js';
import { ProfilesRepository } from '../profiles/profiles.repository.js';
import type { ProfileRecord } from '../profiles/profiles.types.js';
import { UsersService } from '../users/users.service.js';
import type { SafeUser } from '../users/users.types.js';
import { LikesRepository } from './likes.repository.js';
import type {
  CreateLikeForCurrentUserInput,
  CreateLikeForCurrentUserResult,
  CreateLikeInput,
  LikesServiceContract,
  SafeLike,
} from './likes.types.js';
import { LikeConflictError, LikeSelfLikeError } from './likes.types.js';

const DUPLICATE_LIKE_MESSAGE = 'Like already exists between these users.';
const SELF_LIKE_MESSAGE = 'Users cannot like themselves.';
const LIKES_STUDENT_ONLY_MESSAGE = 'Only STUDENT users can send likes.';
const LIKE_TARGET_NOT_FOUND_MESSAGE = 'Liked user not found.';
const LIKE_TARGET_ROLE_MESSAGE = 'Only STUDENT users can receive likes.';
const LIKE_TARGET_STATUS_MESSAGE = 'Liked user is not active.';
const LIKE_TARGET_DELETED_MESSAGE = 'Liked user has been deleted.';
const LIKE_TARGET_PROFILE_INCOMPLETE_MESSAGE = 'Liked user profile is incomplete.';
const LIKE_TARGET_PROFILE_PHOTO_MESSAGE = 'Liked user must have a profile photo.';
const LIKE_TARGET_GYM_UNIT_MESSAGE = 'Users can only like students from the same gym unit.';
const LIKE_SENDER_MEMBERSHIP_MESSAGE = 'Only active students linked to a gym unit can send likes.';
const LIKE_BLOCK_EXISTS_MESSAGE = 'Users cannot like each other when a block exists between them.';
const FREE_PLAN_DAILY_LIKE_LIMIT_MESSAGE = 'Free plan daily like limit reached.';
const FREE_PLAN_ACTIVE_MATCH_LIMIT_MESSAGE =
  'Cannot create a new match because one of the users has reached the free plan limit of active matches.';
const SELF_MATCH_MESSAGE = 'Users cannot match with themselves.';

export const FREE_PLAN_DAILY_LIKE_LIMIT = 10;

type LikesUsersReader = Pick<AuthUsersServiceContract, 'findUserById'>;
type LikesBlocksReader = Pick<BlocksServiceContract, 'blockExistsBetweenUsers'>;
type LikesProfilesReader = Pick<ProfilesRepository, 'findActiveProfileByUserId'>;
type LikesWriter = Pick<LikesRepository, 'createLike' | 'findActiveLikeBetweenUsers'>;
type LikesChatConversationManager = Pick<ChatServiceContract, 'getOrCreateConversation'>;
type MatchesWriter = Pick<
  MatchesRepository,
  'createMatch' | 'findActiveMatchBetweenUsers' | 'countActiveMatchesForUser'
>;
type LikesTransactionRunner = <T>(
  callback: (dependencies: {
    likesRepository: LikesWriter;
    matchesRepository: MatchesWriter;
    chatService: LikesChatConversationManager;
  }) => Promise<T>,
) => Promise<T>;

interface LikesServiceDependencies {
  blocksService?: LikesBlocksReader;
  chatService?: LikesChatConversationManager;
  likesRepository?: LikesRepository;
  matchesRepository?: MatchesRepository;
  profilesRepository?: LikesProfilesReader;
  transactionRunner?: LikesTransactionRunner;
  usersService?: LikesUsersReader;
  now?: () => Date;
}

export class LikesService implements LikesServiceContract {
  private readonly blocksService: LikesBlocksReader;
  private readonly chatService: LikesChatConversationManager;
  private readonly likesRepository: LikesRepository;
  private readonly matchesRepository: MatchesRepository;
  private readonly profilesRepository: LikesProfilesReader;
  private readonly transactionRunner: LikesTransactionRunner;
  private readonly usersService: LikesUsersReader;
  private readonly now: () => Date;

  constructor(prisma: PrismaClient, dependencies: LikesServiceDependencies = {}) {
    this.blocksService = dependencies.blocksService ?? new BlocksService(prisma);
    this.chatService = dependencies.chatService ?? new ChatService(prisma);
    this.likesRepository = dependencies.likesRepository ?? new LikesRepository(prisma);
    this.matchesRepository = dependencies.matchesRepository ?? new MatchesRepository(prisma);
    this.profilesRepository = dependencies.profilesRepository ?? new ProfilesRepository(prisma);
    this.usersService = dependencies.usersService ?? new UsersService(prisma);
    const hasCustomRepositories =
      dependencies.chatService !== undefined ||
      dependencies.likesRepository !== undefined ||
      dependencies.matchesRepository !== undefined;
    this.transactionRunner =
      dependencies.transactionRunner ??
      (hasCustomRepositories || typeof prisma.$transaction !== 'function'
        ? async (callback) =>
            callback({
              chatService: this.chatService,
              likesRepository: this.likesRepository,
              matchesRepository: this.matchesRepository,
            })
        : async (callback) =>
            prisma.$transaction(async (transaction) =>
              callback({
                chatService: new ChatService(transaction),
                likesRepository: new LikesRepository(transaction),
                matchesRepository: new MatchesRepository(transaction),
              }),
            ));
    this.now = dependencies.now ?? (() => new Date());
  }

  async createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateLikeForCurrentUserInput,
  ): Promise<CreateLikeForCurrentUserResult> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, LIKES_STUDENT_ONLY_MESSAGE);
    }

    if (currentUser.id === input.likedUserId) {
      throw new HttpError(400, SELF_LIKE_MESSAGE);
    }

    const likedByUser = await this.usersService.findUserById(currentUser.id);

    if (!likedByUser) {
      throw new HttpError(401, 'Invalid access token.');
    }

    this.ensureLikeSenderCanSendLikes(likedByUser);

    const likedUser = await this.usersService.findUserById(input.likedUserId);

    if (!likedUser) {
      throw new HttpError(404, LIKE_TARGET_NOT_FOUND_MESSAGE);
    }

    this.ensureLikeTargetCanReceiveLikes(likedByUser, likedUser);

    const blockExistsBetweenUsers = await this.blocksService.blockExistsBetweenUsers(
      currentUser.id,
      input.likedUserId,
    );

    if (blockExistsBetweenUsers) {
      throw new HttpError(409, LIKE_BLOCK_EXISTS_MESSAGE);
    }

    const likedUserProfile = await this.profilesRepository.findActiveProfileByUserId(input.likedUserId);

    this.ensureLikeTargetHasEligibleProfile(likedUserProfile);

    const currentTimestamp = this.now();
    const [currentDayStart, nextDayStart] = getLocalDayRange(currentTimestamp);
    const likesSentToday = await this.likesRepository.countActiveLikesSentByUserBetween(
      currentUser.id,
      currentDayStart,
      nextDayStart,
    );

    if (likesSentToday >= FREE_PLAN_DAILY_LIKE_LIMIT) {
      throw new HttpError(
        403,
        `${FREE_PLAN_DAILY_LIKE_LIMIT_MESSAGE} Limit: ${FREE_PLAN_DAILY_LIKE_LIMIT} likes per day.`,
      );
    }

    let currentUserProfile: ProfileRecord | null = null;
    const preExistingInverseLike = await this.likesRepository.findActiveLikeBetweenUsers(
      input.likedUserId,
      currentUser.id,
    );

    if (preExistingInverseLike) {
      currentUserProfile = await this.profilesRepository.findActiveProfileByUserId(currentUser.id);

      if (
        this.hasEligibleProfileForMatch(currentUserProfile) &&
        this.hasEligibleProfileForMatch(likedUserProfile)
      ) {
        const existingMatch = await this.matchesRepository.findActiveMatchBetweenUsers(
          currentUser.id,
          input.likedUserId,
        );

        if (!existingMatch) {
          await this.ensureUsersCanCreateMatch(this.matchesRepository, [likedByUser, likedUser], currentTimestamp);
        }
      }
    }

    return this.transactionRunner(async ({ likesRepository, matchesRepository, chatService }) => {
      const like = await this.createLikeWithRepository(likesRepository, {
        likedByUserId: currentUser.id,
        likedUserId: input.likedUserId,
      });
      const inverseLike = await likesRepository.findActiveLikeBetweenUsers(
        input.likedUserId,
        currentUser.id,
      );

      if (!inverseLike) {
        return {
          like,
          matchCreated: false,
          match: null,
        };
      }

      currentUserProfile ??= await this.profilesRepository.findActiveProfileByUserId(currentUser.id);

      if (
        !this.hasEligibleProfileForMatch(currentUserProfile) ||
        !this.hasEligibleProfileForMatch(likedUserProfile)
      ) {
        return {
          like,
          matchCreated: false,
          match: null,
        };
      }

      const existingMatch = await matchesRepository.findActiveMatchBetweenUsers(
        currentUser.id,
        input.likedUserId,
      );

      if (existingMatch) {
        await this.ensureConversationForActiveMatch(chatService, existingMatch);

        return {
          like,
          matchCreated: false,
          match: null,
        };
      }

      await this.ensureUsersCanCreateMatch(matchesRepository, [likedByUser, likedUser], currentTimestamp);

      const match = await this.createMatchWithRepository(matchesRepository, {
        userAId: currentUser.id,
        userBId: input.likedUserId,
        status: PrismaMatchStatus.ACTIVE,
      });

      if (match) {
        await this.ensureConversationForActiveMatch(chatService, match);
      } else {
        const concurrentMatch = await matchesRepository.findActiveMatchBetweenUsers(
          currentUser.id,
          input.likedUserId,
        );

        if (concurrentMatch) {
          await this.ensureConversationForActiveMatch(chatService, concurrentMatch);
        }
      }

      return {
        like,
        matchCreated: match !== null,
        match,
      };
    });
  }

  async createLike(input: CreateLikeInput): Promise<SafeLike> {
    if (input.likedByUserId === input.likedUserId) {
      throw new HttpError(400, SELF_LIKE_MESSAGE);
    }

    return this.createLikeWithRepository(this.likesRepository, input);
  }

  findLikeBetweenUsers(likedByUserId: string, likedUserId: string): Promise<SafeLike | null> {
    return this.likesRepository.findActiveLikeBetweenUsers(likedByUserId, likedUserId);
  }

  findLikesSentByUser(likedByUserId: string): Promise<SafeLike[]> {
    return this.likesRepository.findActiveLikesSentByUser(likedByUserId);
  }

  findLikesReceivedByUser(likedUserId: string): Promise<SafeLike[]> {
    return this.likesRepository.findActiveLikesReceivedByUser(likedUserId);
  }

  private async createLikeWithRepository(
    likesRepository: LikesWriter,
    input: CreateLikeInput,
  ): Promise<SafeLike> {
    try {
      return await likesRepository.createLike(input);
    } catch (error) {
      if (error instanceof LikeSelfLikeError) {
        throw new HttpError(400, SELF_LIKE_MESSAGE);
      }

      if (error instanceof LikeConflictError && error.field === 'userPair') {
        throw new HttpError(409, DUPLICATE_LIKE_MESSAGE);
      }

      throw error;
    }
  }

  private async ensureUsersCanCreateMatch(
    matchesRepository: MatchesWriter,
    users: SafeUser[],
    now: Date,
  ): Promise<void> {
    const limitedUsers = users
      .map((user) => ({
        userId: user.id,
        limit: this.getActiveMatchLimitForUser(user),
      }))
      .filter((entry): entry is { userId: string; limit: number } => entry.limit !== null);

    if (limitedUsers.length === 0) {
      return;
    }

    const activeMatchCounts = await Promise.all(
      limitedUsers.map((entry) => matchesRepository.countActiveMatchesForUser(entry.userId, now)),
    );

    const hasReachedLimit = activeMatchCounts.some((count, index) => {
      const limitedUser = limitedUsers[index];

      return limitedUser !== undefined && count >= limitedUser.limit;
    });

    if (hasReachedLimit) {
      throw new HttpError(
        403,
        `${FREE_PLAN_ACTIVE_MATCH_LIMIT_MESSAGE} Limit: ${FREE_PLAN_ACTIVE_MATCH_LIMIT} active matches.`,
      );
    }
  }

  private getActiveMatchLimitForUser(_user: SafeUser): number | null {
    // Until subscriptions are implemented, every student is treated as a free-plan user.
    return FREE_PLAN_ACTIVE_MATCH_LIMIT;
  }

  private async createMatchWithRepository(
    matchesRepository: MatchesWriter,
    input: {
      userAId: string;
      userBId: string;
      status: PrismaMatchStatus;
    },
  ): Promise<SafeMatch | null> {
    try {
      return await matchesRepository.createMatch(input);
    } catch (error) {
      if (error instanceof MatchSelfMatchError) {
        throw new HttpError(400, SELF_MATCH_MESSAGE);
      }

      if (error instanceof MatchConflictError && error.field === 'userPair') {
        return null;
      }

      throw error;
    }
  }

  private async ensureConversationForActiveMatch(
    chatService: LikesChatConversationManager,
    match: SafeMatch,
  ): Promise<void> {
    if (match.deletedAt !== null || match.status !== PrismaMatchStatus.ACTIVE) {
      return;
    }

    await chatService.getOrCreateConversation({
      matchId: match.id,
    });
  }

  private ensureLikeSenderCanSendLikes(user: SafeUser): void {
    if (
      user.role !== PrismaUserRole.STUDENT ||
      user.status !== PrismaUserStatus.ACTIVE ||
      user.deletedAt !== null ||
      !user.gymId ||
      !user.gymUnitId
    ) {
      throw new HttpError(403, LIKE_SENDER_MEMBERSHIP_MESSAGE);
    }
  }

  private ensureLikeTargetCanReceiveLikes(likedByUser: SafeUser, likedUser: SafeUser): void {
    if (likedUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(400, LIKE_TARGET_ROLE_MESSAGE);
    }

    if (likedUser.deletedAt !== null || likedUser.status === PrismaUserStatus.DELETED) {
      throw new HttpError(400, LIKE_TARGET_DELETED_MESSAGE);
    }

    if (likedUser.status !== PrismaUserStatus.ACTIVE) {
      throw new HttpError(400, LIKE_TARGET_STATUS_MESSAGE);
    }

    if (likedByUser.gymId !== likedUser.gymId || likedByUser.gymUnitId !== likedUser.gymUnitId) {
      throw new HttpError(400, LIKE_TARGET_GYM_UNIT_MESSAGE);
    }
  }

  private ensureLikeTargetHasEligibleProfile(profile: ProfileRecord | null): void {
    if (!profile || !profile.isComplete) {
      throw new HttpError(400, LIKE_TARGET_PROFILE_INCOMPLETE_MESSAGE);
    }

    if (!hasNonEmptyString(profile.profilePhotoUrl)) {
      throw new HttpError(400, LIKE_TARGET_PROFILE_PHOTO_MESSAGE);
    }
  }

  private hasEligibleProfileForMatch(profile: ProfileRecord | null): boolean {
    return profile !== null && profile.isComplete && hasNonEmptyString(profile.profilePhotoUrl);
  }
}

function getLocalDayRange(now: Date): [Date, Date] {
  const currentDayStart = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    0,
    0,
    0,
    0,
  );
  const nextDayStart = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + 1,
    0,
    0,
    0,
    0,
  );

  return [currentDayStart, nextDayStart];
}

function hasNonEmptyString(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}
