import { Prisma } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';

import type { CreateLikeInput, LikeRecord } from './likes.types.js';
import { LikeConflictError, LikeSelfLikeError } from './likes.types.js';

const LIKE_ORDER_BY: Prisma.LikeOrderByWithRelationInput[] = [{ createdAt: 'desc' }, { id: 'asc' }];
type DatabaseClient = PrismaClient | Prisma.TransactionClient;

function getConflictField(error: Prisma.PrismaClientKnownRequestError): LikeConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('likedByUserId') && target.includes('likedUserId')) {
    return 'userPair';
  }

  return 'unknown';
}

function isSelfLikeConstraintError(error: Prisma.PrismaClientKnownRequestError): boolean {
  if (error.code !== 'P2004') {
    return false;
  }

  return String(error.meta?.database_error ?? '').includes('Like_likedByUserId_likedUserId_check');
}

export class LikesRepository {
  constructor(private readonly prisma: DatabaseClient) {}

  async createLike(input: CreateLikeInput): Promise<LikeRecord> {
    if (input.likedByUserId === input.likedUserId) {
      throw new LikeSelfLikeError();
    }

    const data: Prisma.LikeCreateInput = {
      likedByUser: {
        connect: {
          id: input.likedByUserId,
        },
      },
      likedUser: {
        connect: {
          id: input.likedUserId,
        },
      },
    };

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.like.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new LikeConflictError(getConflictField(error));
      }

      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        isSelfLikeConstraintError(error)
      ) {
        throw new LikeSelfLikeError();
      }

      throw error;
    }
  }

  findActiveLikeBetweenUsers(
    likedByUserId: string,
    likedUserId: string,
  ): Promise<LikeRecord | null> {
    return this.prisma.like.findFirst({
      where: {
        likedByUserId,
        likedUserId,
        deletedAt: null,
      },
    });
  }

  findActiveLikesSentByUser(likedByUserId: string): Promise<LikeRecord[]> {
    return this.prisma.like.findMany({
      where: {
        likedByUserId,
        deletedAt: null,
      },
      orderBy: LIKE_ORDER_BY,
    });
  }

  findActiveLikesReceivedByUser(likedUserId: string): Promise<LikeRecord[]> {
    return this.prisma.like.findMany({
      where: {
        likedUserId,
        deletedAt: null,
      },
      orderBy: LIKE_ORDER_BY,
    });
  }

  countActiveLikesSentByUserBetween(
    likedByUserId: string,
    rangeStart: Date,
    rangeEnd: Date,
  ): Promise<number> {
    return this.prisma.like.count({
      where: {
        likedByUserId,
        deletedAt: null,
        createdAt: {
          gte: rangeStart,
          lt: rangeEnd,
        },
      },
    });
  }
}
