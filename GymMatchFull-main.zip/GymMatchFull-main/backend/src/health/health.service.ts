import type { AppConfig } from '../config/index.js';

export interface HealthCheckResponse {
  status: 'ok';
  service: string;
  environment: AppConfig['nodeEnv'];
  timestamp: string;
  uptime: number;
}

export function createHealthCheckResponse(
  appConfig: Pick<AppConfig, 'name' | 'nodeEnv'>,
): HealthCheckResponse {
  return {
    status: 'ok',
    service: appConfig.name,
    environment: appConfig.nodeEnv,
    timestamp: new Date().toISOString(),
    uptime: Number(process.uptime().toFixed(3)),
  };
}
