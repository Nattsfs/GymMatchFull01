import type { FastifyPluginAsync } from 'fastify';

import type { AppConfig } from '../config/index.js';
import { createHealthCheckResponse } from './health.service.js';

interface HealthRoutesOptions {
  appConfig: Pick<AppConfig, 'name' | 'nodeEnv'>;
}

export const healthRoutes: FastifyPluginAsync<HealthRoutesOptions> = async (app, options) => {
  app.get('/health', async () => {
    return createHealthCheckResponse(options.appConfig);
  });
};
