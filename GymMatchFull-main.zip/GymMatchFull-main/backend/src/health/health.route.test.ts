import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import { buildConfig } from '../config/env.js';

const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('GET /health', () => {
  it('returns HTTP 200 with a safe health payload', async () => {
    const app = buildApp({ config });
    appsToClose.push(app);

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/health',
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();

    expect(body).toMatchObject({
      status: 'ok',
      service: 'GymMatch API',
      environment: 'test',
    });
    expect(typeof body.timestamp).toBe('string');
    expect(typeof body.uptime).toBe('number');
    expect(body).not.toHaveProperty('databaseUrl');
    expect(body).not.toHaveProperty('jwtSecret');
    expect(body).not.toHaveProperty('refreshTokenSecret');
    expect(body).not.toHaveProperty('auth');
    expect(body).not.toHaveProperty('database');
  });

  it('returns a standardized 404 payload for unknown routes', async () => {
    const app = buildApp({ config });
    appsToClose.push(app);

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/missing-route',
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Route GET /missing-route not found.',
    });
  });
});
