import { config as loadDotEnv } from 'dotenv';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const allowedNodeEnvs = ['development', 'test', 'production'] as const;
const configDirectory = dirname(fileURLToPath(import.meta.url));
const repositoryRoot = resolve(configDirectory, '../../../');
const repositoryEnvFile = resolve(repositoryRoot, '.env');

export type NodeEnv = (typeof allowedNodeEnvs)[number];

export interface AppConfig {
  name: string;
  nodeEnv: NodeEnv;
  port: number;
  baseUrl?: string;
  mobileAppUrl?: string;
  adminWebUrl?: string;
}

export interface DatabaseConfig {
  url: string;
}

export interface AuthConfig {
  jwtSecret: string;
  jwtExpiresIn: string;
  refreshTokenSecret: string;
  refreshTokenExpiresIn: string;
  passwordResetTokenExpiresInMinutes: number;
}

export interface SmsConfig {
  provider?: string;
  apiKey?: string;
  from?: string;
}

export interface EmailConfig {
  provider?: string;
  host?: string;
  port?: number;
  user?: string;
  password?: string;
  from?: string;
}

export interface StorageConfig {
  provider?: string;
  bucket?: string;
  region?: string;
  accessKeyId?: string;
  secretAccessKey?: string;
}

export interface StripeConfig {
  secretKey?: string;
  webhookSecret?: string;
  premiumPriceId?: string;
}

export interface CorsConfig {
  origin: string;
}

export interface LogsConfig {
  level: string;
}

export interface Config {
  app: AppConfig;
  database: DatabaseConfig;
  auth: AuthConfig;
  sms: SmsConfig;
  email: EmailConfig;
  storage: StorageConfig;
  stripe: StripeConfig;
  cors: CorsConfig;
  logs: LogsConfig;
}

export class EnvValidationError extends Error {
  readonly issues: string[];

  constructor(issues: string[]) {
    super(
      ['Invalid environment configuration:', ...issues.map((issue) => `- ${issue}`)].join('\n'),
    );
    this.name = 'EnvValidationError';
    this.issues = issues;
  }
}

type EnvSource = Record<string, string | undefined>;

function normalizeOptionalString(value: string | undefined): string | undefined {
  const normalizedValue = value?.trim();

  return normalizedValue ? normalizedValue : undefined;
}

function readRequiredString(source: EnvSource, key: string, issues: string[]): string {
  const value = normalizeOptionalString(source[key]);

  if (!value) {
    issues.push(`${key} is required.`);
    return '';
  }

  return value;
}

function parseNodeEnv(value: string, issues: string[]): NodeEnv {
  if ((allowedNodeEnvs as readonly string[]).includes(value)) {
    return value as NodeEnv;
  }

  issues.push(`NODE_ENV must be one of: ${allowedNodeEnvs.join(', ')}.`);
  return 'development';
}

function parseRequiredPositiveInteger(value: string, key: string, issues: string[]): number {
  const parsedValue = Number.parseInt(value, 10);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    issues.push(`${key} must be a positive integer.`);
    return 0;
  }

  return parsedValue;
}

function parseOptionalPositiveInteger(
  value: string | undefined,
  key: string,
  issues: string[],
): number | undefined {
  if (!value) {
    return undefined;
  }

  const parsedValue = Number.parseInt(value, 10);

  if (!Number.isInteger(parsedValue) || parsedValue <= 0) {
    issues.push(`${key} must be a positive integer when provided.`);
    return undefined;
  }

  return parsedValue;
}

export function loadEnvironmentFiles(): void {
  loadDotEnv({ path: repositoryEnvFile });
}

export function buildConfig(source: EnvSource = process.env): Config {
  const issues: string[] = [];

  const nodeEnvInput = readRequiredString(source, 'NODE_ENV', issues);
  const apiPortInput = readRequiredString(source, 'API_PORT', issues);
  const databaseUrl = readRequiredString(source, 'DATABASE_URL', issues);
  const jwtSecret = readRequiredString(source, 'JWT_SECRET', issues);
  const jwtExpiresIn = readRequiredString(source, 'JWT_EXPIRES_IN', issues);
  const refreshTokenSecret = readRequiredString(source, 'REFRESH_TOKEN_SECRET', issues);
  const refreshTokenExpiresIn = readRequiredString(source, 'REFRESH_TOKEN_EXPIRES_IN', issues);
  const corsOrigin = readRequiredString(source, 'CORS_ORIGIN', issues);
  const passwordResetTokenExpiresInMinutes =
    parseOptionalPositiveInteger(
      normalizeOptionalString(source.PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES),
      'PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES',
      issues,
    ) ?? 30;
  const emailPort = parseOptionalPositiveInteger(
    normalizeOptionalString(source.EMAIL_PORT),
    'EMAIL_PORT',
    issues,
  );
  const appBaseUrl = normalizeOptionalString(source.API_BASE_URL);
  const mobileAppUrl = normalizeOptionalString(source.MOBILE_APP_URL);
  const adminWebUrl = normalizeOptionalString(source.ADMIN_WEB_URL);
  const smsProvider = normalizeOptionalString(source.SMS_PROVIDER);
  const smsApiKey = normalizeOptionalString(source.SMS_API_KEY);
  const smsFrom = normalizeOptionalString(source.SMS_FROM);
  const emailProvider = normalizeOptionalString(source.EMAIL_PROVIDER);
  const emailHost = normalizeOptionalString(source.EMAIL_HOST);
  const emailUser = normalizeOptionalString(source.EMAIL_USER);
  const emailPassword = normalizeOptionalString(source.EMAIL_PASSWORD);
  const emailFrom = normalizeOptionalString(source.EMAIL_FROM);
  const storageProvider = normalizeOptionalString(source.STORAGE_PROVIDER);
  const storageBucket = normalizeOptionalString(source.STORAGE_BUCKET);
  const storageRegion = normalizeOptionalString(source.STORAGE_REGION);
  const storageAccessKeyId = normalizeOptionalString(source.STORAGE_ACCESS_KEY_ID);
  const storageSecretAccessKey = normalizeOptionalString(source.STORAGE_SECRET_ACCESS_KEY);
  const stripeSecretKey = normalizeOptionalString(source.STRIPE_SECRET_KEY);
  const stripeWebhookSecret = normalizeOptionalString(source.STRIPE_WEBHOOK_SECRET);
  const stripePremiumPriceId = normalizeOptionalString(source.STRIPE_PRICE_ID_PREMIUM);
  const nodeEnv = nodeEnvInput ? parseNodeEnv(nodeEnvInput, issues) : 'development';
  const port = apiPortInput ? parseRequiredPositiveInteger(apiPortInput, 'API_PORT', issues) : 0;

  if (issues.length > 0) {
    throw new EnvValidationError(issues);
  }

  return {
    app: {
      name: normalizeOptionalString(source.APP_NAME) ?? 'GymMatch API',
      nodeEnv,
      port,
      ...(appBaseUrl ? { baseUrl: appBaseUrl } : {}),
      ...(mobileAppUrl ? { mobileAppUrl } : {}),
      ...(adminWebUrl ? { adminWebUrl } : {}),
    },
    database: {
      url: databaseUrl,
    },
    auth: {
      jwtSecret,
      jwtExpiresIn,
      refreshTokenSecret,
      refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes,
    },
    sms: {
      ...(smsProvider ? { provider: smsProvider } : {}),
      ...(smsApiKey ? { apiKey: smsApiKey } : {}),
      ...(smsFrom ? { from: smsFrom } : {}),
    },
    email: {
      ...(emailProvider ? { provider: emailProvider } : {}),
      ...(emailHost ? { host: emailHost } : {}),
      ...(emailPort !== undefined ? { port: emailPort } : {}),
      ...(emailUser ? { user: emailUser } : {}),
      ...(emailPassword ? { password: emailPassword } : {}),
      ...(emailFrom ? { from: emailFrom } : {}),
    },
    storage: {
      ...(storageProvider ? { provider: storageProvider } : {}),
      ...(storageBucket ? { bucket: storageBucket } : {}),
      ...(storageRegion ? { region: storageRegion } : {}),
      ...(storageAccessKeyId ? { accessKeyId: storageAccessKeyId } : {}),
      ...(storageSecretAccessKey ? { secretAccessKey: storageSecretAccessKey } : {}),
    },
    stripe: {
      ...(stripeSecretKey ? { secretKey: stripeSecretKey } : {}),
      ...(stripeWebhookSecret ? { webhookSecret: stripeWebhookSecret } : {}),
      ...(stripePremiumPriceId ? { premiumPriceId: stripePremiumPriceId } : {}),
    },
    cors: {
      origin: corsOrigin,
    },
    logs: {
      level: normalizeOptionalString(source.LOG_LEVEL) ?? 'info',
    },
  };
}
