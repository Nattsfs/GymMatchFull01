import { describe, expect, it } from 'vitest';

import { EnvValidationError, buildConfig } from './env.js';

const requiredEnvironment = {
  NODE_ENV: 'development',
  APP_NAME: 'GymMatch',
  API_PORT: '3000',
  API_BASE_URL: 'http://localhost:3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  CORS_ORIGIN: 'http://localhost:3001',
} satisfies Record<string, string>;

function getErrorMessage(source: Record<string, string | undefined>): string {
  try {
    buildConfig(source);
    return '';
  } catch (error) {
    if (error instanceof Error) {
      return error.message;
    }

    throw error;
  }
}

describe('buildConfig', () => {
  it('loads configuration when required variables exist', () => {
    const config = buildConfig(requiredEnvironment);

    expect(config.app.name).toBe('GymMatch');
    expect(config.app.nodeEnv).toBe('development');
    expect(config.app.port).toBe(3000);
    expect(config.app.baseUrl).toBe('http://localhost:3000');
    expect(config.database.url).toBe(requiredEnvironment.DATABASE_URL);
    expect(config.auth.jwtSecret).toBe(requiredEnvironment.JWT_SECRET);
    expect(config.auth.passwordResetTokenExpiresInMinutes).toBe(30);
    expect(config.cors.origin).toBe(requiredEnvironment.CORS_ORIGIN);
  });

  it('fails with a clear message when DATABASE_URL is missing', () => {
    const message = getErrorMessage({
      ...requiredEnvironment,
      DATABASE_URL: '',
    });

    expect(message).toContain('Invalid environment configuration:');
    expect(message).toContain('DATABASE_URL is required.');
  });

  it('fails with a clear message when JWT_SECRET is missing', () => {
    const message = getErrorMessage({
      ...requiredEnvironment,
      JWT_SECRET: '',
    });

    expect(message).toContain('JWT_SECRET is required.');
  });

  it('converts API_PORT to a number', () => {
    const config = buildConfig({
      ...requiredEnvironment,
      API_PORT: '3333',
    });

    expect(config.app.port).toBe(3333);
    expect(typeof config.app.port).toBe('number');
  });

  it('accepts only the expected NODE_ENV values', () => {
    expect(() =>
      buildConfig({
        ...requiredEnvironment,
        NODE_ENV: 'staging',
      }),
    ).toThrowError(EnvValidationError);

    const message = getErrorMessage({
      ...requiredEnvironment,
      NODE_ENV: 'staging',
    });

    expect(message).toContain('NODE_ENV must be one of: development, test, production.');
  });

  it('normalizes empty optional values to undefined', () => {
    const config = buildConfig({
      ...requiredEnvironment,
      API_BASE_URL: '',
      MOBILE_APP_URL: '',
      ADMIN_WEB_URL: '',
      SMS_PROVIDER: '',
      EMAIL_PORT: '',
      STORAGE_BUCKET: '',
    });

    expect(config.app.baseUrl).toBeUndefined();
    expect(config.app.mobileAppUrl).toBeUndefined();
    expect(config.app.adminWebUrl).toBeUndefined();
    expect(config.sms.provider).toBeUndefined();
    expect(config.email.port).toBeUndefined();
    expect(config.storage.bucket).toBeUndefined();
  });

  it('accepts a custom password reset token expiration in minutes', () => {
    const config = buildConfig({
      ...requiredEnvironment,
      PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '20',
    });

    expect(config.auth.passwordResetTokenExpiresInMinutes).toBe(20);
  });
});
