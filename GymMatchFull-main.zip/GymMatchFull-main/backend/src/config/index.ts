import { buildConfig, loadEnvironmentFiles } from './env.js';

loadEnvironmentFiles();

export const config = buildConfig();

export { EnvValidationError, buildConfig, loadEnvironmentFiles } from './env.js';
export type {
  AppConfig,
  AuthConfig,
  Config,
  CorsConfig,
  DatabaseConfig,
  EmailConfig,
  LogsConfig,
  NodeEnv,
  SmsConfig,
  StorageConfig,
  StripeConfig,
} from './env.js';
