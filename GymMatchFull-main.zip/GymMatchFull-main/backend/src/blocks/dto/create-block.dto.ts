import { HttpError } from '../../common/errors/http-error.js';
import type { CreateBlockForCurrentUserInput } from '../blocks.types.js';

interface CreateBlockRequestBody {
  blockedUserId?: unknown;
}

export function parseCreateBlockInput(payload: unknown): CreateBlockForCurrentUserInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as CreateBlockRequestBody;
  const blockedUserId = parseRequiredString(body.blockedUserId, 'blockedUserId');

  return {
    blockedUserId,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseRequiredString(value: unknown, field: string): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} is required and must be a string.`);
  }

  const normalizedValue = value.trim();

  if (normalizedValue.length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return normalizedValue;
}
