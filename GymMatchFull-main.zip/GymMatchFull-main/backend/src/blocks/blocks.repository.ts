import { Prisma } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';

import type { BlockRecord, CreateBlockInput } from './blocks.types.js';
import { BlockConflictError, BlockSelfBlockError } from './blocks.types.js';

type DatabaseClient = PrismaClient | Prisma.TransactionClient;

const BLOCK_ORDER_BY: Prisma.BlockOrderByWithRelationInput[] = [
  { createdAt: 'desc' },
  { id: 'asc' },
];

function getConflictField(
  error: Prisma.PrismaClientKnownRequestError,
): BlockConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('blockedByUserId') && target.includes('blockedUserId')) {
    return 'userPair';
  }

  return 'unknown';
}

function isSelfBlockConstraintError(error: Prisma.PrismaClientKnownRequestError): boolean {
  if (error.code !== 'P2004') {
    return false;
  }

  return String(error.meta?.database_error ?? '').includes(
    'Block_blockedByUserId_blockedUserId_check',
  );
}

export class BlocksRepository {
  constructor(private readonly prisma: DatabaseClient) {}

  async createBlock(input: CreateBlockInput): Promise<BlockRecord> {
    if (input.blockedByUserId === input.blockedUserId) {
      throw new BlockSelfBlockError();
    }

    const data: Prisma.BlockCreateInput = {
      blockedByUser: {
        connect: {
          id: input.blockedByUserId,
        },
      },
      blockedUser: {
        connect: {
          id: input.blockedUserId,
        },
      },
    };

    if (input.reason !== undefined) {
      data.reason = input.reason ?? null;
    }

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.block.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new BlockConflictError(getConflictField(error));
      }

      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        isSelfBlockConstraintError(error)
      ) {
        throw new BlockSelfBlockError();
      }

      throw error;
    }
  }

  findActiveBlockBetweenUsers(
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<BlockRecord | null> {
    return this.prisma.block.findFirst({
      where: {
        blockedByUserId,
        blockedUserId,
        deletedAt: null,
      },
    });
  }

  async existsActiveBlockBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    if (firstUserId === secondUserId) {
      return false;
    }

    const count = await this.prisma.block.count({
      where: {
        deletedAt: null,
        OR: [
          {
            blockedByUserId: firstUserId,
            blockedUserId: secondUserId,
          },
          {
            blockedByUserId: secondUserId,
            blockedUserId: firstUserId,
          },
        ],
      },
    });

    return count > 0;
  }

  findActiveBlocksSentByUser(blockedByUserId: string): Promise<BlockRecord[]> {
    return this.prisma.block.findMany({
      where: {
        blockedByUserId,
        deletedAt: null,
      },
      orderBy: BLOCK_ORDER_BY,
    });
  }
}
