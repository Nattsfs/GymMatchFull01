import type { PrismaClient } from '@prisma/client';
import {
  MatchStatus as PrismaMatchStatus,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import type { CreateMatchInput, MatchRecord } from '../matches/matches.types.js';
import type { SafeUser } from '../users/users.types.js';
import { BlocksRepository } from './blocks.repository.js';
import { BlocksService } from './blocks.service.js';
import type { BlockRecord, CreateBlockInput } from './blocks.types.js';
import { BlockConflictError, BlockSelfBlockError } from './blocks.types.js';
import { MatchesRepository } from '../matches/matches.repository.js';

const FIXED_NOW = new Date('2026-05-10T21:00:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryBlocksRepository {
  private readonly blocks: BlockRecord[] = [];
  private nextId = 1;

  async createBlock(input: CreateBlockInput): Promise<BlockRecord> {
    if (input.blockedByUserId === input.blockedUserId) {
      throw new BlockSelfBlockError();
    }

    const existingBlock = this.blocks.find(
      (block) =>
        block.blockedByUserId === input.blockedByUserId &&
        block.blockedUserId === input.blockedUserId &&
        block.deletedAt === null,
    );

    if (existingBlock) {
      throw new BlockConflictError('userPair');
    }

    const block: BlockRecord = {
      id: `block_${this.nextId++}`,
      blockedByUserId: input.blockedByUserId,
      blockedUserId: input.blockedUserId,
      reason: input.reason ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.blocks.push(block);

    return block;
  }

  async findActiveBlockBetweenUsers(
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<BlockRecord | null> {
    return (
      this.blocks.find(
        (block) =>
          block.blockedByUserId === blockedByUserId &&
          block.blockedUserId === blockedUserId &&
          block.deletedAt === null,
      ) ?? null
    );
  }

  async existsActiveBlockBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    if (firstUserId === secondUserId) {
      return false;
    }

    return this.blocks.some(
      (block) =>
        block.deletedAt === null &&
        ((block.blockedByUserId === firstUserId && block.blockedUserId === secondUserId) ||
          (block.blockedByUserId === secondUserId && block.blockedUserId === firstUserId)),
    );
  }

  async findActiveBlocksSentByUser(blockedByUserId: string): Promise<BlockRecord[]> {
    return this.blocks.filter(
      (block) => block.blockedByUserId === blockedByUserId && block.deletedAt === null,
    );
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async updateMatchStatusBetweenUsers(
    firstUserId: string,
    secondUserId: string,
    status: PrismaMatchStatus,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);
    const match = this.matches.find(
      (item) =>
        item.userAId === normalizedPair.userAId &&
        item.userBId === normalizedPair.userBId &&
        item.deletedAt === null,
    );

    if (!match) {
      return null;
    }

    match.status = status;
    match.updatedAt = FIXED_NOW;

    return match;
  }

  seedMatch(input: CreateMatchInput): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  findMatchBetweenUsers(firstUserId: string, secondUserId: string): MatchRecord | null {
    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (item) =>
          item.userAId === normalizedPair.userAId &&
          item.userBId === normalizedPair.userBId &&
          item.deletedAt === null,
      ) ?? null
    );
  }
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const blocksRepository = new InMemoryBlocksRepository();
  const matchesRepository = new InMemoryMatchesRepository();
  const blocksService = new BlocksService({} as PrismaClient, {
    blocksRepository: blocksRepository as unknown as BlocksRepository,
    matchesRepository: matchesRepository as unknown as MatchesRepository,
    usersService: usersService as unknown as AuthUsersServiceContract,
  });
  const app = buildApp({
    config,
    services: {
      blocksService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    blocksRepository,
    matchesRepository,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('POST /blocks', () => {
  it('creates a block for an authenticated student and blocks an existing match', async () => {
    const { app, matchesRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    matchesRepository.seedMatch({
      userAId: sender.id,
      userBId: target.id,
      status: PrismaMatchStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/blocks',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        blockedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      blockedByUserId: sender.id,
      blockedUserId: target.id,
      deletedAt: null,
    });
    expect(matchesRepository.findMatchBetweenUsers(sender.id, target.id)).toMatchObject({
      status: PrismaMatchStatus.BLOCKED,
    });
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/blocks',
      payload: {
        blockedUserId: 'student_2',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from creating blocks through the student endpoint', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/blocks',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        blockedUserId: 'student_2',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('rejects self block attempts', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/blocks',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        blockedUserId: sender.id,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Users cannot block themselves.',
    });
  });

  it('rejects duplicate blocks for the same user pair', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });

    await app.ready();

    const firstResponse = await app.inject({
      method: 'POST',
      url: '/blocks',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        blockedUserId: target.id,
      },
    });

    expect(firstResponse.statusCode).toBe(201);

    const secondResponse = await app.inject({
      method: 'POST',
      url: '/blocks',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        blockedUserId: target.id,
      },
    });

    expect(secondResponse.statusCode).toBe(409);
    expect(secondResponse.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Block already exists between these users.',
    });
  });

  it('rejects requests when the target user does not exist', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/blocks',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        blockedUserId: 'student_missing',
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Blocked user not found.',
    });
  });
});
