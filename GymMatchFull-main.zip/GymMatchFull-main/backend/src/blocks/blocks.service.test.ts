import type { PrismaClient } from '@prisma/client';
import { MatchStatus as PrismaMatchStatus, UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import type { CreateMatchInput, MatchRecord } from '../matches/matches.types.js';
import type { SafeUser } from '../users/users.types.js';
import { BlocksRepository } from './blocks.repository.js';
import { BlocksService } from './blocks.service.js';
import type { BlockRecord, CreateBlockInput } from './blocks.types.js';
import { BlockConflictError, BlockSelfBlockError } from './blocks.types.js';

const FIXED_NOW = new Date('2026-05-10T20:30:00.000Z');

class InMemoryBlocksRepository {
  private readonly blocks: BlockRecord[] = [];
  private nextId = 1;

  async createBlock(input: CreateBlockInput): Promise<BlockRecord> {
    if (input.blockedByUserId === input.blockedUserId) {
      throw new BlockSelfBlockError();
    }

    const existingBlock = this.blocks.find(
      (block) =>
        block.blockedByUserId === input.blockedByUserId &&
        block.blockedUserId === input.blockedUserId &&
        block.deletedAt === null,
    );

    if (existingBlock) {
      throw new BlockConflictError('userPair');
    }

    const block: BlockRecord = {
      id: `block_${this.nextId++}`,
      blockedByUserId: input.blockedByUserId,
      blockedUserId: input.blockedUserId,
      reason: input.reason ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.blocks.push(block);

    return block;
  }

  async findActiveBlockBetweenUsers(
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<BlockRecord | null> {
    return (
      this.blocks.find(
        (block) =>
          block.blockedByUserId === blockedByUserId &&
          block.blockedUserId === blockedUserId &&
          block.deletedAt === null,
      ) ?? null
    );
  }

  async existsActiveBlockBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    if (firstUserId === secondUserId) {
      return false;
    }

    return this.blocks.some(
      (block) =>
        block.deletedAt === null &&
        ((block.blockedByUserId === firstUserId && block.blockedUserId === secondUserId) ||
          (block.blockedByUserId === secondUserId && block.blockedUserId === firstUserId)),
    );
  }

  async findActiveBlocksSentByUser(blockedByUserId: string): Promise<BlockRecord[]> {
    return this.blocks.filter(
      (block) => block.blockedByUserId === blockedByUserId && block.deletedAt === null,
    );
  }

  seedBlock(input: CreateBlockInput & { createdAt?: Date; updatedAt?: Date }): BlockRecord {
    const block: BlockRecord = {
      id: `block_${this.nextId++}`,
      blockedByUserId: input.blockedByUserId,
      blockedUserId: input.blockedUserId,
      reason: input.reason ?? null,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.blocks.push(block);

    return block;
  }
}

class InMemoryUsersService {
  constructor(private readonly users: SafeUser[]) {}

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryMatchesRepository {
  private readonly matches: MatchRecord[] = [];
  private nextId = 1;

  async updateMatchStatusBetweenUsers(
    firstUserId: string,
    secondUserId: string,
    status: PrismaMatchStatus,
  ): Promise<MatchRecord | null> {
    if (firstUserId === secondUserId) {
      return null;
    }

    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);
    const match = this.matches.find(
      (item) =>
        item.userAId === normalizedPair.userAId &&
        item.userBId === normalizedPair.userBId &&
        item.deletedAt === null,
    );

    if (!match) {
      return null;
    }

    match.status = status;
    match.updatedAt = FIXED_NOW;

    return match;
  }

  seedMatch(input: CreateMatchInput): MatchRecord {
    const normalizedPair = normalizeUserPair(input.userAId, input.userBId);
    const match: MatchRecord = {
      id: `match_${this.nextId++}`,
      userAId: normalizedPair.userAId,
      userBId: normalizedPair.userBId,
      status: input.status ?? PrismaMatchStatus.ACTIVE,
      expiresAt: input.expiresAt ?? null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.matches.push(match);

    return match;
  }

  findMatchBetweenUsers(firstUserId: string, secondUserId: string): MatchRecord | null {
    const normalizedPair = normalizeUserPair(firstUserId, secondUserId);

    return (
      this.matches.find(
        (item) =>
          item.userAId === normalizedPair.userAId &&
          item.userBId === normalizedPair.userBId &&
          item.deletedAt === null,
      ) ?? null
    );
  }
}

function normalizeUserPair(
  firstUserId: string,
  secondUserId: string,
): {
  userAId: string;
  userBId: string;
} {
  return firstUserId < secondUserId
    ? {
        userAId: firstUserId,
        userBId: secondUserId,
      }
    : {
        userAId: secondUserId,
        userBId: firstUserId,
      };
}

function makeCurrentUser(overrides: Partial<CurrentUserContext> = {}): CurrentUserContext {
  return {
    id: 'user_1',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    ...overrides,
  };
}

function makeSafeUser(overrides: Partial<SafeUser> = {}): SafeUser {
  return {
    id: 'user_1',
    name: 'Aluno 1',
    email: 'aluno1@example.com',
    phone: '11999999991',
    cpf: '12345678901',
    gymId: 'gym_1',
    gymUnitId: 'unit_1',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    emailVerifiedAt: null,
    phoneVerifiedAt: null,
    termsAcceptedAt: null,
    lastLoginAt: null,
    createdAt: FIXED_NOW,
    updatedAt: FIXED_NOW,
    deletedAt: null,
    ...overrides,
  };
}

function createBlocksService(
  options: {
    blocksRepository?: InMemoryBlocksRepository;
    matchesRepository?: InMemoryMatchesRepository;
    usersService?: InMemoryUsersService;
  } = {},
): BlocksService {
  return new BlocksService({} as PrismaClient, {
    blocksRepository: (options.blocksRepository ??
      new InMemoryBlocksRepository()) as unknown as BlocksRepository,
    matchesRepository: (options.matchesRepository ??
      new InMemoryMatchesRepository()) as unknown as MatchesRepository,
    usersService:
      (options.usersService ?? new InMemoryUsersService([])) as unknown as AuthUsersServiceContract,
  });
}

describe('BlocksService', () => {
  it('creates a block between two distinct users with an optional reason', async () => {
    const blocksRepository = new InMemoryBlocksRepository();
    const service = createBlocksService({ blocksRepository });

    const block = await service.createBlock({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_2',
      reason: 'unwanted contact',
    });

    expect(block).toMatchObject({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_2',
      reason: 'unwanted contact',
      deletedAt: null,
    });
    await expect(service.findBlockBetweenUsers('user_1', 'user_2')).resolves.toEqual(block);
  });

  it('rejects duplicate blocks for the same user pair', async () => {
    const blocksRepository = new InMemoryBlocksRepository();
    blocksRepository.seedBlock({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_2',
    });
    const service = createBlocksService({ blocksRepository });

    await expect(
      service.createBlock({
        blockedByUserId: 'user_1',
        blockedUserId: 'user_2',
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Block already exists between these users.',
    });
  });

  it('rejects self block attempts', async () => {
    const service = createBlocksService();

    await expect(
      service.createBlock({
        blockedByUserId: 'user_1',
        blockedUserId: 'user_1',
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Users cannot block themselves.',
    });
  });

  it('allows reverse-direction blocks because the action is unilateral', async () => {
    const blocksRepository = new InMemoryBlocksRepository();
    blocksRepository.seedBlock({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_2',
    });
    const service = createBlocksService({ blocksRepository });

    const reverseBlock = await service.createBlock({
      blockedByUserId: 'user_2',
      blockedUserId: 'user_1',
    });

    expect(reverseBlock).toMatchObject({
      blockedByUserId: 'user_2',
      blockedUserId: 'user_1',
    });
  });

  it('reports a block when it exists in either direction', async () => {
    const blocksRepository = new InMemoryBlocksRepository();
    blocksRepository.seedBlock({
      blockedByUserId: 'user_3',
      blockedUserId: 'user_7',
    });
    const service = createBlocksService({ blocksRepository });

    await expect(service.blockExistsBetweenUsers('user_3', 'user_7')).resolves.toBe(true);
    await expect(service.blockExistsBetweenUsers('user_7', 'user_3')).resolves.toBe(true);
    await expect(service.blockExistsBetweenUsers('user_7', 'user_8')).resolves.toBe(false);
    await expect(service.blockExistsBetweenUsers('user_3', 'user_3')).resolves.toBe(false);
  });

  it('lists only active blocks created by a user', async () => {
    const blocksRepository = new InMemoryBlocksRepository();
    const activeBlockA = blocksRepository.seedBlock({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_2',
    });
    const activeBlockB = blocksRepository.seedBlock({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_3',
      reason: 'spam',
    });
    blocksRepository.seedBlock({
      blockedByUserId: 'user_2',
      blockedUserId: 'user_1',
    });
    blocksRepository.seedBlock({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_4',
      deletedAt: FIXED_NOW,
    });
    const service = createBlocksService({ blocksRepository });

    await expect(service.findBlocksSentByUser('user_1')).resolves.toEqual([
      activeBlockA,
      activeBlockB,
    ]);
  });

  it('creates a block for the authenticated student and marks an existing match as blocked', async () => {
    const blocksRepository = new InMemoryBlocksRepository();
    const matchesRepository = new InMemoryMatchesRepository();
    matchesRepository.seedMatch({
      userAId: 'user_1',
      userBId: 'user_2',
      status: PrismaMatchStatus.ACTIVE,
    });
    const usersService = new InMemoryUsersService([
      makeSafeUser({ id: 'user_1' }),
      makeSafeUser({ id: 'user_2', email: 'aluno2@example.com', phone: '11999999992', cpf: '12345678902' }),
    ]);
    const service = createBlocksService({ blocksRepository, matchesRepository, usersService });

    const block = await service.createForCurrentUser(makeCurrentUser({ id: 'user_1' }), {
      blockedUserId: 'user_2',
    });

    expect(block).toMatchObject({
      blockedByUserId: 'user_1',
      blockedUserId: 'user_2',
    });
    expect(matchesRepository.findMatchBetweenUsers('user_1', 'user_2')).toMatchObject({
      status: PrismaMatchStatus.BLOCKED,
    });
  });

  it('rejects block creation for non-student users', async () => {
    const service = createBlocksService();

    await expect(
      service.createForCurrentUser(makeCurrentUser({ role: PrismaUserRole.ADMIN }), {
        blockedUserId: 'user_2',
      }),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only STUDENT users can block other users.',
    });
  });

  it('rejects block creation when the access token user no longer exists', async () => {
    const usersService = new InMemoryUsersService([makeSafeUser({ id: 'user_2' })]);
    const service = createBlocksService({ usersService });

    await expect(
      service.createForCurrentUser(makeCurrentUser({ id: 'user_missing' }), {
        blockedUserId: 'user_2',
      }),
    ).rejects.toMatchObject({
      statusCode: 401,
      message: 'Invalid access token.',
    });
  });

  it('rejects block creation when the target user does not exist', async () => {
    const usersService = new InMemoryUsersService([makeSafeUser({ id: 'user_1' })]);
    const service = createBlocksService({ usersService });

    await expect(
      service.createForCurrentUser(makeCurrentUser({ id: 'user_1' }), {
        blockedUserId: 'user_missing',
      }),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Blocked user not found.',
    });
  });
});
