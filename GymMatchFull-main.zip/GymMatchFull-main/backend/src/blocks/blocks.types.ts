import type { Block } from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';

export interface CreateBlockInput {
  blockedByUserId: string;
  blockedUserId: string;
  reason?: string | null;
  deletedAt?: Date;
}

export interface CreateBlockForCurrentUserInput {
  blockedUserId: string;
}

export type BlockRecord = Block;
export type SafeBlock = BlockRecord;

export interface BlocksServiceContract {
  createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateBlockForCurrentUserInput,
  ): Promise<SafeBlock>;
  createBlock(input: CreateBlockInput): Promise<SafeBlock>;
  findBlockBetweenUsers(
    blockedByUserId: string,
    blockedUserId: string,
  ): Promise<SafeBlock | null>;
  blockExistsBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean>;
  findBlocksSentByUser(blockedByUserId: string): Promise<SafeBlock[]>;
}

export class BlockConflictError extends Error {
  readonly field: 'userPair' | 'unknown';

  constructor(field: 'userPair' | 'unknown') {
    const fieldLabel = field === 'userPair' ? 'user block pair' : 'unique block field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'BlockConflictError';
    this.field = field;
  }
}

export class BlockSelfBlockError extends Error {
  constructor() {
    super('A user cannot block themselves.');
    this.name = 'BlockSelfBlockError';
  }
}
