import { MatchStatus as PrismaMatchStatus, UserRole as PrismaUserRole, type PrismaClient } from '@prisma/client';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { HttpError } from '../common/errors/http-error.js';
import { MatchesRepository } from '../matches/matches.repository.js';
import { UsersService } from '../users/users.service.js';
import { BlocksRepository } from './blocks.repository.js';
import type {
  BlockRecord,
  BlocksServiceContract,
  CreateBlockForCurrentUserInput,
  CreateBlockInput,
  SafeBlock,
} from './blocks.types.js';
import { BlockConflictError, BlockSelfBlockError } from './blocks.types.js';

const DUPLICATE_BLOCK_MESSAGE = 'Block already exists between these users.';
const SELF_BLOCK_MESSAGE = 'Users cannot block themselves.';
const BLOCKS_STUDENT_ONLY_MESSAGE = 'Only STUDENT users can block other users.';
const BLOCK_TARGET_NOT_FOUND_MESSAGE = 'Blocked user not found.';
const INVALID_ACCESS_TOKEN_MESSAGE = 'Invalid access token.';

type BlocksRepositoryContract = Pick<
  BlocksRepository,
  | 'createBlock'
  | 'findActiveBlockBetweenUsers'
  | 'existsActiveBlockBetweenUsers'
  | 'findActiveBlocksSentByUser'
>;
type BlocksUsersReader = Pick<AuthUsersServiceContract, 'findUserById'>;
type BlocksMatchesWriter = Pick<MatchesRepository, 'updateMatchStatusBetweenUsers'>;
type BlocksTransactionRunner = <T>(
  callback: (dependencies: {
    blocksRepository: BlocksRepositoryContract;
    matchesRepository: BlocksMatchesWriter;
  }) => Promise<T>,
) => Promise<T>;

interface BlocksServiceDependencies {
  blocksRepository?: BlocksRepositoryContract;
  matchesRepository?: BlocksMatchesWriter;
  transactionRunner?: BlocksTransactionRunner;
  usersService?: BlocksUsersReader;
}

export class BlocksService implements BlocksServiceContract {
  private readonly blocksRepository: BlocksRepositoryContract;
  private readonly matchesRepository: BlocksMatchesWriter;
  private readonly transactionRunner: BlocksTransactionRunner;
  private readonly usersService: BlocksUsersReader;

  constructor(prisma: PrismaClient, dependencies: BlocksServiceDependencies = {}) {
    this.blocksRepository = dependencies.blocksRepository ?? new BlocksRepository(prisma);
    this.matchesRepository = dependencies.matchesRepository ?? new MatchesRepository(prisma);
    this.usersService = dependencies.usersService ?? new UsersService(prisma);
    const hasCustomDataAccess =
      dependencies.blocksRepository !== undefined || dependencies.matchesRepository !== undefined;
    this.transactionRunner =
      dependencies.transactionRunner ??
      (hasCustomDataAccess || typeof prisma.$transaction !== 'function'
        ? async (callback) =>
            callback({
              blocksRepository: this.blocksRepository,
              matchesRepository: this.matchesRepository,
            })
        : async (callback) =>
            prisma.$transaction(async (transaction) =>
              callback({
                blocksRepository: new BlocksRepository(transaction),
                matchesRepository: new MatchesRepository(transaction),
              }),
            ));
  }

  async createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateBlockForCurrentUserInput,
  ): Promise<SafeBlock> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, BLOCKS_STUDENT_ONLY_MESSAGE);
    }

    if (currentUser.id === input.blockedUserId) {
      throw new HttpError(400, SELF_BLOCK_MESSAGE);
    }

    const blockedByUser = await this.usersService.findUserById(currentUser.id);

    if (!blockedByUser) {
      throw new HttpError(401, INVALID_ACCESS_TOKEN_MESSAGE);
    }

    const blockedUser = await this.usersService.findUserById(input.blockedUserId);

    if (!blockedUser) {
      throw new HttpError(404, BLOCK_TARGET_NOT_FOUND_MESSAGE);
    }

    return this.transactionRunner(async ({ blocksRepository, matchesRepository }) => {
      const block = await this.createBlockWithRepository(blocksRepository, {
        blockedByUserId: currentUser.id,
        blockedUserId: input.blockedUserId,
      });

      await matchesRepository.updateMatchStatusBetweenUsers(
        currentUser.id,
        input.blockedUserId,
        PrismaMatchStatus.BLOCKED,
      );

      return block;
    });
  }

  async createBlock(input: CreateBlockInput): Promise<SafeBlock> {
    if (input.blockedByUserId === input.blockedUserId) {
      throw new HttpError(400, SELF_BLOCK_MESSAGE);
    }

    return this.createBlockWithRepository(this.blocksRepository, input);
  }

  findBlockBetweenUsers(blockedByUserId: string, blockedUserId: string): Promise<SafeBlock | null> {
    return this.blocksRepository.findActiveBlockBetweenUsers(blockedByUserId, blockedUserId);
  }

  blockExistsBetweenUsers(firstUserId: string, secondUserId: string): Promise<boolean> {
    return this.blocksRepository.existsActiveBlockBetweenUsers(firstUserId, secondUserId);
  }

  findBlocksSentByUser(blockedByUserId: string): Promise<BlockRecord[]> {
    return this.blocksRepository.findActiveBlocksSentByUser(blockedByUserId);
  }

  private async createBlockWithRepository(
    blocksRepository: BlocksRepositoryContract,
    input: CreateBlockInput,
  ): Promise<SafeBlock> {
    try {
      return await blocksRepository.createBlock(input);
    } catch (error) {
      if (error instanceof BlockSelfBlockError) {
        throw new HttpError(400, SELF_BLOCK_MESSAGE);
      }

      if (error instanceof BlockConflictError && error.field === 'userPair') {
        throw new HttpError(409, DUPLICATE_BLOCK_MESSAGE);
      }

      throw error;
    }
  }
}
