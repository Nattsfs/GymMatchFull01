import { PrismaClient } from '@prisma/client';
import type { Prisma } from '@prisma/client';
import type { FastifyInstance, RawServerBase } from 'fastify';

import type { Config } from '../config/index.js';

export type DatabaseRuntimeConfig = Pick<Config, 'app' | 'database'>;

type GlobalDatabaseState = typeof globalThis & {
  __gymmatchPrisma?: PrismaClient;
};

type PrismaLogConfig = Exclude<Prisma.PrismaClientOptions['log'], undefined>;

function resolvePrismaLogLevel(config: DatabaseRuntimeConfig): PrismaLogConfig {
  if (config.app.nodeEnv === 'development') {
    return ['warn', 'error'];
  }

  return ['error'];
}

function createPrismaClient(config: DatabaseRuntimeConfig): PrismaClient {
  return new PrismaClient({
    datasources: {
      db: {
        url: config.database.url,
      },
    },
    log: resolvePrismaLogLevel(config),
  });
}

export function getDatabaseClient(config: DatabaseRuntimeConfig): PrismaClient {
  const globalDatabaseState = globalThis as GlobalDatabaseState;

  if (!globalDatabaseState.__gymmatchPrisma) {
    globalDatabaseState.__gymmatchPrisma = createPrismaClient(config);
  }

  return globalDatabaseState.__gymmatchPrisma;
}

export async function disconnectDatabase(client?: PrismaClient): Promise<void> {
  const globalDatabaseState = globalThis as GlobalDatabaseState;
  const activeClient = client ?? globalDatabaseState.__gymmatchPrisma;

  if (!activeClient) {
    return;
  }

  await activeClient.$disconnect();

  if (globalDatabaseState.__gymmatchPrisma === activeClient) {
    delete globalDatabaseState.__gymmatchPrisma;
  }
}

declare module 'fastify' {
  interface FastifyInstance {
    prisma: PrismaClient;
  }
}

export function registerDatabase<TServer extends RawServerBase>(
  app: FastifyInstance<TServer>,
  config: DatabaseRuntimeConfig,
): PrismaClient {
  const prisma = getDatabaseClient(config);

  app.decorate('prisma', prisma);
  app.addHook('onClose', async () => {
    await disconnectDatabase(prisma);
  });

  return prisma;
}
