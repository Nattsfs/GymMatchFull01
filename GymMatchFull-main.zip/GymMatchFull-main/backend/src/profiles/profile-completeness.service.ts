import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';

import { isAtLeastAge } from '../common/validators/birth-date.validator.js';
import type {
  ProfileCompletenessCandidate,
  ProfileCompletenessUser,
} from './profiles.types.js';

export const MINIMUM_COMPLETE_PROFILE_AGE = 18;

interface CalculateProfileCompletenessInput {
  user: ProfileCompletenessUser;
  profile: ProfileCompletenessCandidate | null;
}

export function calculateProfileCompleteness(
  input: CalculateProfileCompletenessInput,
): boolean {
  const { user, profile } = input;

  if (!profile) {
    return false;
  }

  if (user.role !== PrismaUserRole.STUDENT || user.status !== PrismaUserStatus.ACTIVE) {
    return false;
  }

  if (user.deletedAt) {
    return false;
  }

  if (profile.deletedAt) {
    return false;
  }

  if (!profile.birthDate || !isAtLeastAge(profile.birthDate, MINIMUM_COMPLETE_PROFILE_AGE)) {
    return false;
  }

  if (!profile.gender || !profile.appGoal || !profile.trainingLevel || !profile.workoutSplit) {
    return false;
  }

  if (profile.availablePeriods.length === 0 || profile.preferredModalities.length === 0) {
    return false;
  }

  if (
    Object.hasOwn(profile, 'profilePhotoUrl') &&
    !hasNonEmptyString(profile.profilePhotoUrl)
  ) {
    return false;
  }

  return true;
}

function hasNonEmptyString(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}
