import { Prisma } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';

import type {
  ProfileComputedFields,
  CreateProfileInput,
  ProfileRecord,
  UpdateStudentProfileInput,
} from './profiles.types.js';
import { ProfileConflictError } from './profiles.types.js';

function getConflictField(
  error: Prisma.PrismaClientKnownRequestError,
): ProfileConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('userId')) {
    return 'userId';
  }

  return 'unknown';
}

export class ProfilesRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async createProfile(
    userId: string,
    input: CreateProfileInput,
    computedFields: ProfileComputedFields,
  ): Promise<ProfileRecord> {
    const data: Prisma.ProfileCreateInput = {
      user: {
        connect: {
          id: userId,
        },
      },
      birthDate: input.birthDate,
      gender: input.gender,
      sexualOrientation: input.sexualOrientation,
      appGoal: input.appGoal,
      trainingLevel: input.trainingLevel,
      availablePeriods: input.availablePeriods,
      preferredModalities: input.preferredModalities,
      workoutSplit: input.workoutSplit,
      isComplete: computedFields.isComplete,
      showSexualOrientation: input.showSexualOrientation,
      showAvailablePeriods: input.showAvailablePeriods,
    };

    if (input.bio !== undefined) {
      data.bio = input.bio;
    }

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.profile.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ProfileConflictError(getConflictField(error));
      }

      throw error;
    }
  }

  findProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.prisma.profile.findUnique({
      where: { userId },
    });
  }

  findActiveProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.prisma.profile.findFirst({
      where: {
        userId,
        deletedAt: null,
      },
    });
  }

  updateProfile(
    userId: string,
    input: UpdateStudentProfileInput,
    computedFields: ProfileComputedFields,
  ): Promise<ProfileRecord> {
    const data: Prisma.ProfileUpdateInput = {};

    if (input.appGoal !== undefined) {
      data.appGoal = input.appGoal;
    }

    if (input.trainingLevel !== undefined) {
      data.trainingLevel = input.trainingLevel;
    }

    if (input.availablePeriods !== undefined) {
      data.availablePeriods = {
        set: input.availablePeriods,
      };
    }

    if (input.preferredModalities !== undefined) {
      data.preferredModalities = {
        set: input.preferredModalities,
      };
    }

    if (input.workoutSplit !== undefined) {
      data.workoutSplit = input.workoutSplit;
    }

    if (input.bio !== undefined) {
      data.bio = input.bio;
    }

    if (input.showSexualOrientation !== undefined) {
      data.showSexualOrientation = input.showSexualOrientation;
    }

    if (input.showAvailablePeriods !== undefined) {
      data.showAvailablePeriods = input.showAvailablePeriods;
    }

    data.isComplete = computedFields.isComplete;

    return this.prisma.profile.update({
      where: { userId },
      data,
    });
  }

  updateProfilePhoto(
    userId: string,
    profilePhotoUrl: string,
    computedFields: ProfileComputedFields,
  ): Promise<ProfileRecord> {
    return this.prisma.profile.update({
      where: { userId },
      data: {
        profilePhotoUrl,
        isComplete: computedFields.isComplete,
      },
    });
  }
}
