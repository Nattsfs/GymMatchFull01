import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import { calculateProfileCompleteness } from './profile-completeness.service.js';
import type {
  ProfileCompletenessCandidate,
  ProfileCompletenessUser,
} from './profiles.types.js';

function createBirthDateYearsAgo(years: number): Date {
  const date = new Date();
  date.setUTCHours(0, 0, 0, 0);
  date.setUTCFullYear(date.getUTCFullYear() - years);

  return date;
}

function makeUser(
  overrides: Partial<ProfileCompletenessUser> = {},
): ProfileCompletenessUser {
  return {
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    ...overrides,
  };
}

function makeProfile(
  overrides: Partial<ProfileCompletenessCandidate> = {},
): ProfileCompletenessCandidate {
  return {
    birthDate: createBirthDateYearsAgo(24),
    gender: PrismaProfileGender.WOMAN,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
    workoutSplit: PrismaWorkoutSplit.ABC,
    profilePhotoUrl: 'https://cdn.gymmatch.test/profile.jpg',
    deletedAt: null,
    ...overrides,
  };
}

describe('calculateProfileCompleteness', () => {
  it('returns true when the active student has all required profile fields and a photo', () => {
    const isComplete = calculateProfileCompleteness({
      user: makeUser(),
      profile: makeProfile(),
    });

    expect(isComplete).toBe(true);
  });

  it('returns false when the profile photo field exists but is empty', () => {
    const isComplete = calculateProfileCompleteness({
      user: makeUser(),
      profile: makeProfile({
        profilePhotoUrl: null,
      }),
    });

    expect(isComplete).toBe(false);
  });

  it('returns false when the user is not active or the student is underage', () => {
    const inactiveStudent = calculateProfileCompleteness({
      user: makeUser({
        status: PrismaUserStatus.SUSPENDED,
      }),
      profile: makeProfile(),
    });
    const underageStudent = calculateProfileCompleteness({
      user: makeUser(),
      profile: makeProfile({
        birthDate: createBirthDateYearsAgo(17),
      }),
    });

    expect(inactiveStudent).toBe(false);
    expect(underageStudent).toBe(false);
  });
});
