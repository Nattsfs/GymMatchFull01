import type { PublicStudentProfileDto } from './dto/public-student-profile.dto.js';
import type { ProfileRecord, SafeProfile } from './profiles.types.js';

export interface PublicStudentProfileSourceUser {
  id: string;
  name: string;
  email?: string | null;
  phone?: string | null;
  cpf?: string | null;
  password?: string | null;
  passwordHash?: string | null;
  refreshTokenHash?: string | null;
  passwordResetTokenHash?: string | null;
  passwordResetTokenExpiresAt?: Date | null;
  role?: string;
  status?: string;
  deletedAt?: Date | null;
  gym?:
    | {
        id: string;
        name: string;
      }
    | null;
  gymUnit?:
    | {
        id: string;
        name: string;
        city: string | null;
        state: string | null;
      }
    | null;
}

export interface PublicStudentProfileSource extends ProfileRecord {
  user: PublicStudentProfileSourceUser;
}

interface SerializePublicStudentProfileOptions {
  now?: Date;
}

export function serializeProfile(profile: ProfileRecord): SafeProfile {
  return profile;
}

export function serializePublicStudentProfile(
  profile: PublicStudentProfileSource,
  options: SerializePublicStudentProfileOptions = {},
): PublicStudentProfileDto {
  return {
    id: profile.user.id,
    name: profile.user.name,
    age: calculateAge(profile.birthDate, options.now),
    gender: profile.gender,
    appGoal: profile.appGoal,
    trainingLevel: profile.trainingLevel,
    preferredModalities: [...profile.preferredModalities],
    workoutSplit: profile.workoutSplit,
    profilePhotoUrl: profile.profilePhotoUrl,
    bio: profile.bio,
    ...(profile.showSexualOrientation
      ? { sexualOrientation: profile.sexualOrientation }
      : {}),
    ...(profile.showAvailablePeriods
      ? { availablePeriods: [...profile.availablePeriods] }
      : {}),
    ...(profile.user.gym
      ? {
          gym: {
            id: profile.user.gym.id,
            name: profile.user.gym.name,
          },
        }
      : {}),
    ...(profile.user.gymUnit
      ? {
          gymUnit: {
            id: profile.user.gymUnit.id,
            name: profile.user.gymUnit.name,
            city: profile.user.gymUnit.city,
            state: profile.user.gymUnit.state,
          },
        }
      : {}),
  };
}

function calculateAge(birthDate: Date, now = new Date()): number {
  const birthYear = birthDate.getUTCFullYear();
  const birthMonth = birthDate.getUTCMonth();
  const birthDay = birthDate.getUTCDate();
  const currentYear = now.getUTCFullYear();
  const currentMonth = now.getUTCMonth();
  const currentDay = now.getUTCDate();

  let age = currentYear - birthYear;

  if (currentMonth < birthMonth || (currentMonth === birthMonth && currentDay < birthDay)) {
    age -= 1;
  }

  return age;
}
