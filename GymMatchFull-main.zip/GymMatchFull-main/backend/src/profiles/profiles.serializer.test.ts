import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import {
  serializePublicStudentProfile,
  type PublicStudentProfileSource,
} from './profiles.serializer.js';

function makePublicStudentProfileSource(
  overrides: Partial<PublicStudentProfileSource> = {},
): PublicStudentProfileSource {
  return {
    id: 'profile_1',
    userId: 'user_1',
    birthDate: new Date('1998-05-11T00:00:00.000Z'),
    gender: PrismaProfileGender.WOMAN,
    sexualOrientation: PrismaSexualOrientation.BISEXUAL,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [
      PrismaWorkoutModality.BODYBUILDING,
      PrismaWorkoutModality.FUNCTIONAL_TRAINING,
    ],
    workoutSplit: PrismaWorkoutSplit.ABC,
    profilePhotoUrl: 'https://cdn.gymmatch.test/profile-1.jpg',
    isComplete: true,
    bio: 'Procuro parceria para treinar depois do trabalho.',
    showSexualOrientation: true,
    showAvailablePeriods: true,
    createdAt: new Date('2026-05-09T10:00:00.000Z'),
    updatedAt: new Date('2026-05-10T10:00:00.000Z'),
    deletedAt: null,
    user: {
      id: 'user_1',
      name: 'Ana Silva',
      email: 'ana@example.com',
      phone: '11999999999',
      cpf: '12345678901',
      password: 'plain-password',
      passwordHash: 'hashed-password',
      refreshTokenHash: 'hashed-refresh-token',
      passwordResetTokenHash: 'hashed-reset-token',
      passwordResetTokenExpiresAt: new Date('2026-05-11T10:00:00.000Z'),
      role: 'STUDENT',
      status: 'ACTIVE',
      deletedAt: null,
      gym: {
        id: 'gym_1',
        name: 'GymMatch Academia',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Centro',
        city: 'Sao Paulo',
        state: 'SP',
      },
    },
    ...overrides,
  };
}

describe('serializePublicStudentProfile', () => {
  it('returns only safe discovery fields for a public profile', () => {
    const publicProfile = serializePublicStudentProfile(makePublicStudentProfileSource(), {
      now: new Date('2026-05-10T12:00:00.000Z'),
    });

    expect(publicProfile).toEqual({
      id: 'user_1',
      name: 'Ana Silva',
      age: 27,
      gender: PrismaProfileGender.WOMAN,
      sexualOrientation: PrismaSexualOrientation.BISEXUAL,
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
      preferredModalities: [
        PrismaWorkoutModality.BODYBUILDING,
        PrismaWorkoutModality.FUNCTIONAL_TRAINING,
      ],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl: 'https://cdn.gymmatch.test/profile-1.jpg',
      bio: 'Procuro parceria para treinar depois do trabalho.',
      gym: {
        id: 'gym_1',
        name: 'GymMatch Academia',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Centro',
        city: 'Sao Paulo',
        state: 'SP',
      },
    });

    expect(publicProfile).not.toHaveProperty('userId');
    expect(publicProfile).not.toHaveProperty('birthDate');
    expect(publicProfile).not.toHaveProperty('isComplete');
    expect(publicProfile).not.toHaveProperty('showSexualOrientation');
    expect(publicProfile).not.toHaveProperty('showAvailablePeriods');
    expect(publicProfile).not.toHaveProperty('createdAt');
    expect(publicProfile).not.toHaveProperty('updatedAt');
    expect(publicProfile).not.toHaveProperty('deletedAt');
    expect(publicProfile).not.toHaveProperty('email');
    expect(publicProfile).not.toHaveProperty('phone');
    expect(publicProfile).not.toHaveProperty('cpf');
    expect(publicProfile).not.toHaveProperty('password');
    expect(publicProfile).not.toHaveProperty('passwordHash');
    expect(publicProfile).not.toHaveProperty('refreshTokenHash');
    expect(publicProfile).not.toHaveProperty('passwordResetTokenHash');
    expect(publicProfile).not.toHaveProperty('role');
    expect(publicProfile).not.toHaveProperty('status');
  });

  it('omits sexual orientation and available periods when profile visibility disables them', () => {
    const publicProfile = serializePublicStudentProfile(
      makePublicStudentProfileSource({
        showSexualOrientation: false,
        showAvailablePeriods: false,
      }),
      {
        now: new Date('2026-05-10T12:00:00.000Z'),
      },
    );

    expect(publicProfile).not.toHaveProperty('sexualOrientation');
    expect(publicProfile).not.toHaveProperty('availablePeriods');
  });

  it('keeps gym and unit optional when public location context is unavailable', () => {
    const publicProfile = serializePublicStudentProfile(
      makePublicStudentProfileSource({
        user: {
          id: 'user_1',
          name: 'Ana Silva',
          gym: null,
          gymUnit: null,
        },
      }),
      {
        now: new Date('2026-05-10T12:00:00.000Z'),
      },
    );

    expect(publicProfile.gym).toBeUndefined();
    expect(publicProfile.gymUnit).toBeUndefined();
  });
});
