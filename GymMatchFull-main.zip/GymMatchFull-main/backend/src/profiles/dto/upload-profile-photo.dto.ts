import { HttpError } from '../../common/errors/http-error.js';
import type { UploadProfilePhotoInput } from '../profiles.types.js';

const IMAGE_SIGNATURE_JPEG = [0xff, 0xd8, 0xff] as const;
const IMAGE_SIGNATURE_PNG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a] as const;

const MIME_TYPE_ALIASES = {
  'image/jpg': 'image/jpeg',
  'image/jpeg': 'image/jpeg',
  'image/png': 'image/png',
  'image/webp': 'image/webp',
} as const;

export const PROFILE_PHOTO_FORM_FIELD_NAME = 'photo';
export const MAX_PROFILE_PHOTO_FILE_SIZE_BYTES = 5 * 1024 * 1024;
export const PROFILE_PHOTO_INVALID_TYPE_MESSAGE =
  'photo must be a JPG, JPEG, PNG, or WEBP image.';

interface ParseProfilePhotoUploadInput {
  fieldName: string;
  mimeType: string;
  buffer: Buffer;
}

type SupportedProfilePhotoMimeType = keyof typeof MIME_TYPE_ALIASES;

interface DetectedImageType {
  extension: 'jpg' | 'png' | 'webp';
  mimeType: Exclude<SupportedProfilePhotoMimeType, 'image/jpg'>;
}

export function parseProfilePhotoUpload(
  input: ParseProfilePhotoUploadInput,
): UploadProfilePhotoInput {
  if (input.fieldName !== PROFILE_PHOTO_FORM_FIELD_NAME) {
    throw new HttpError(
      400,
      `Profile photo must be sent using the "${PROFILE_PHOTO_FORM_FIELD_NAME}" form field.`,
    );
  }

  if (input.buffer.length === 0) {
    throw new HttpError(400, 'photo file cannot be empty.');
  }

  const normalizedMimeType = normalizeMimeType(input.mimeType);
  const detectedImageType = detectImageType(input.buffer);

  if (!normalizedMimeType || !detectedImageType || detectedImageType.mimeType !== normalizedMimeType) {
    throw new HttpError(400, PROFILE_PHOTO_INVALID_TYPE_MESSAGE);
  }

  return {
    data: input.buffer,
    contentType: detectedImageType.mimeType,
    extension: detectedImageType.extension,
  };
}

function normalizeMimeType(value: string): DetectedImageType['mimeType'] | null {
  const normalizedValue = value.trim().toLowerCase() as SupportedProfilePhotoMimeType;
  const normalizedMimeType = MIME_TYPE_ALIASES[normalizedValue];

  return normalizedMimeType ?? null;
}

function detectImageType(buffer: Buffer): DetectedImageType | null {
  if (hasSignature(buffer, IMAGE_SIGNATURE_JPEG)) {
    return {
      extension: 'jpg',
      mimeType: 'image/jpeg',
    };
  }

  if (hasSignature(buffer, IMAGE_SIGNATURE_PNG)) {
    return {
      extension: 'png',
      mimeType: 'image/png',
    };
  }

  if (
    buffer.length >= 12 &&
    buffer.toString('ascii', 0, 4) === 'RIFF' &&
    buffer.toString('ascii', 8, 12) === 'WEBP'
  ) {
    return {
      extension: 'webp',
      mimeType: 'image/webp',
    };
  }

  return null;
}

function hasSignature(buffer: Buffer, signature: readonly number[]): boolean {
  return signature.every((value, index) => buffer[index] === value);
}
