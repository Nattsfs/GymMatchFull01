import type {
  AppGoal,
  AvailablePeriod,
  ProfileGender,
  SexualOrientation,
  TrainingLevel,
  WorkoutModality,
  WorkoutSplit,
} from '@prisma/client';

export interface PublicStudentProfileGymDto {
  id: string;
  name: string;
}

export interface PublicStudentProfileGymUnitDto {
  id: string;
  name: string;
  city: string | null;
  state: string | null;
}

export interface PublicStudentProfileDto {
  id: string;
  name: string;
  age: number;
  gender: ProfileGender;
  appGoal: AppGoal;
  trainingLevel: TrainingLevel;
  preferredModalities: WorkoutModality[];
  workoutSplit: WorkoutSplit;
  profilePhotoUrl: string | null;
  bio: string | null;
  sexualOrientation?: SexualOrientation;
  availablePeriods?: AvailablePeriod[];
  gym?: PublicStudentProfileGymDto;
  gymUnit?: PublicStudentProfileGymUnitDto;
}
