import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import { parseDateOnly } from '../../common/validators/birth-date.validator.js';
import type { CreateProfileInput } from '../profiles.types.js';

interface CreateProfileRequestBody {
  birthDate?: unknown;
  gender?: unknown;
  sexualOrientation?: unknown;
  appGoal?: unknown;
  trainingLevel?: unknown;
  availablePeriods?: unknown;
  preferredModalities?: unknown;
  workoutSplit?: unknown;
  bio?: unknown;
  showSexualOrientation?: unknown;
  showAvailablePeriods?: unknown;
}

const PROFILE_GENDERS = [
  PrismaProfileGender.MAN,
  PrismaProfileGender.WOMAN,
  PrismaProfileGender.NON_BINARY,
  PrismaProfileGender.OTHER,
  PrismaProfileGender.PREFER_NOT_TO_SAY,
] as const;

const SEXUAL_ORIENTATIONS = [
  PrismaSexualOrientation.STRAIGHT,
  PrismaSexualOrientation.GAY,
  PrismaSexualOrientation.LESBIAN,
  PrismaSexualOrientation.BISEXUAL,
  PrismaSexualOrientation.PANSEXUAL,
  PrismaSexualOrientation.ASEXUAL,
  PrismaSexualOrientation.OTHER,
  PrismaSexualOrientation.PREFER_NOT_TO_SAY,
] as const;

const APP_GOALS = [
  PrismaAppGoal.TRAINING_PARTNER,
  PrismaAppGoal.FRIENDSHIP,
  PrismaAppGoal.NETWORKING,
  PrismaAppGoal.DATING,
] as const;

const TRAINING_LEVELS = [
  PrismaTrainingLevel.BEGINNER,
  PrismaTrainingLevel.INTERMEDIATE,
  PrismaTrainingLevel.ADVANCED,
] as const;

const AVAILABLE_PERIODS = [
  PrismaAvailablePeriod.EARLY_MORNING,
  PrismaAvailablePeriod.MORNING,
  PrismaAvailablePeriod.AFTERNOON,
  PrismaAvailablePeriod.EVENING,
  PrismaAvailablePeriod.NIGHT,
] as const;

const WORKOUT_MODALITIES = [
  PrismaWorkoutModality.BODYBUILDING,
  PrismaWorkoutModality.CROSSFIT,
  PrismaWorkoutModality.FUNCTIONAL_TRAINING,
  PrismaWorkoutModality.CARDIO,
  PrismaWorkoutModality.FIGHT_SPORTS,
  PrismaWorkoutModality.RUNNING,
  PrismaWorkoutModality.YOGA,
  PrismaWorkoutModality.PILATES,
  PrismaWorkoutModality.SWIMMING,
  PrismaWorkoutModality.OTHER,
] as const;

const WORKOUT_SPLITS = [
  PrismaWorkoutSplit.FULL_BODY,
  PrismaWorkoutSplit.UPPER_LOWER,
  PrismaWorkoutSplit.PUSH_PULL_LEGS,
  PrismaWorkoutSplit.ABC,
  PrismaWorkoutSplit.ABCD,
  PrismaWorkoutSplit.BRO_SPLIT,
  PrismaWorkoutSplit.OTHER,
] as const;

export function parseCreateProfileInput(payload: unknown): CreateProfileInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as CreateProfileRequestBody;
  const birthDate = parseBirthDate(body.birthDate);
  const gender = parseEnum(body.gender, 'gender', PROFILE_GENDERS);
  const sexualOrientation = parseEnum(
    body.sexualOrientation,
    'sexualOrientation',
    SEXUAL_ORIENTATIONS,
  );
  const appGoal = parseEnum(body.appGoal, 'appGoal', APP_GOALS);
  const trainingLevel = parseEnum(body.trainingLevel, 'trainingLevel', TRAINING_LEVELS);
  const availablePeriods = parseEnumArray(
    body.availablePeriods,
    'availablePeriods',
    AVAILABLE_PERIODS,
  );
  const preferredModalities = parseEnumArray(
    body.preferredModalities,
    'preferredModalities',
    WORKOUT_MODALITIES,
  );
  const workoutSplit = parseEnum(body.workoutSplit, 'workoutSplit', WORKOUT_SPLITS);
  const bio = parseOptionalBio(body.bio);
  const showSexualOrientation = parseBoolean(body.showSexualOrientation, 'showSexualOrientation');
  const showAvailablePeriods = parseBoolean(body.showAvailablePeriods, 'showAvailablePeriods');

  return {
    birthDate,
    gender,
    sexualOrientation,
    appGoal,
    trainingLevel,
    availablePeriods,
    preferredModalities,
    workoutSplit,
    ...(bio !== undefined ? { bio } : {}),
    showSexualOrientation,
    showAvailablePeriods,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseBirthDate(value: unknown): Date {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'birthDate is required and must be a string in YYYY-MM-DD format.');
  }

  const normalizedBirthDate = value.trim();
  const birthDate = parseDateOnly(normalizedBirthDate);

  if (!birthDate) {
    throw new HttpError(400, 'birthDate must be a valid date in YYYY-MM-DD format.');
  }

  return birthDate;
}

function parseBoolean(value: unknown, field: string): boolean {
  if (typeof value !== 'boolean') {
    throw new HttpError(400, `${field} is required and must be a boolean.`);
  }

  return value;
}

function parseOptionalBio(value: unknown): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'bio must be a string when provided.');
  }

  const normalizedBio = value.trim();

  if (normalizedBio.length === 0) {
    return undefined;
  }

  if (normalizedBio.length > 500) {
    throw new HttpError(400, 'bio must be at most 500 characters long.');
  }

  return normalizedBio;
}

function parseEnum<TValue extends string>(
  value: unknown,
  field: string,
  allowedValues: readonly TValue[],
): TValue {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} is required and must be a string.`);
  }

  const normalizedValue = value.trim().toUpperCase();
  const matchedValue = allowedValues.find((allowedValue) => allowedValue === normalizedValue);

  if (!matchedValue) {
    throw new HttpError(400, `${field} must be one of: ${allowedValues.join(', ')}.`);
  }

  return matchedValue;
}

function parseEnumArray<TValue extends string>(
  value: unknown,
  field: string,
  allowedValues: readonly TValue[],
): TValue[] {
  if (!Array.isArray(value)) {
    throw new HttpError(400, `${field} is required and must be an array.`);
  }

  if (value.length === 0) {
    throw new HttpError(400, `${field} must contain at least one value.`);
  }

  const normalizedValues = value.map((item) => parseEnum(item, field, allowedValues));

  return [...new Set(normalizedValues)];
}
