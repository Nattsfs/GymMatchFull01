import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  TrainingLevel as PrismaTrainingLevel,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import type { UpdateStudentProfileInput } from '../profiles.types.js';

interface UpdateStudentProfileRequestBody {
  appGoal?: unknown;
  trainingLevel?: unknown;
  availablePeriods?: unknown;
  preferredModalities?: unknown;
  workoutSplit?: unknown;
  bio?: unknown;
  showSexualOrientation?: unknown;
  showAvailablePeriods?: unknown;
}

const UPDATABLE_FIELDS = new Set([
  'appGoal',
  'trainingLevel',
  'availablePeriods',
  'preferredModalities',
  'workoutSplit',
  'bio',
  'showSexualOrientation',
  'showAvailablePeriods',
]);

const APP_GOALS = [
  PrismaAppGoal.TRAINING_PARTNER,
  PrismaAppGoal.FRIENDSHIP,
  PrismaAppGoal.NETWORKING,
  PrismaAppGoal.DATING,
] as const;

const TRAINING_LEVELS = [
  PrismaTrainingLevel.BEGINNER,
  PrismaTrainingLevel.INTERMEDIATE,
  PrismaTrainingLevel.ADVANCED,
] as const;

const AVAILABLE_PERIODS = [
  PrismaAvailablePeriod.EARLY_MORNING,
  PrismaAvailablePeriod.MORNING,
  PrismaAvailablePeriod.AFTERNOON,
  PrismaAvailablePeriod.EVENING,
  PrismaAvailablePeriod.NIGHT,
] as const;

const WORKOUT_MODALITIES = [
  PrismaWorkoutModality.BODYBUILDING,
  PrismaWorkoutModality.CROSSFIT,
  PrismaWorkoutModality.FUNCTIONAL_TRAINING,
  PrismaWorkoutModality.CARDIO,
  PrismaWorkoutModality.FIGHT_SPORTS,
  PrismaWorkoutModality.RUNNING,
  PrismaWorkoutModality.YOGA,
  PrismaWorkoutModality.PILATES,
  PrismaWorkoutModality.SWIMMING,
  PrismaWorkoutModality.OTHER,
] as const;

const WORKOUT_SPLITS = [
  PrismaWorkoutSplit.FULL_BODY,
  PrismaWorkoutSplit.UPPER_LOWER,
  PrismaWorkoutSplit.PUSH_PULL_LEGS,
  PrismaWorkoutSplit.ABC,
  PrismaWorkoutSplit.ABCD,
  PrismaWorkoutSplit.BRO_SPLIT,
  PrismaWorkoutSplit.OTHER,
] as const;

export function parseUpdateStudentProfileInput(payload: unknown): UpdateStudentProfileInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as UpdateStudentProfileRequestBody & Record<string, unknown>;

  for (const key of Object.keys(body)) {
    if (!UPDATABLE_FIELDS.has(key)) {
      throw new HttpError(400, `${key} cannot be updated.`);
    }
  }

  const updateInput: UpdateStudentProfileInput = {};

  if ('appGoal' in body) {
    updateInput.appGoal = parseEnum(body.appGoal, 'appGoal', APP_GOALS);
  }

  if ('trainingLevel' in body) {
    updateInput.trainingLevel = parseEnum(body.trainingLevel, 'trainingLevel', TRAINING_LEVELS);
  }

  if ('availablePeriods' in body) {
    updateInput.availablePeriods = parseEnumArray(
      body.availablePeriods,
      'availablePeriods',
      AVAILABLE_PERIODS,
    );
  }

  if ('preferredModalities' in body) {
    updateInput.preferredModalities = parseEnumArray(
      body.preferredModalities,
      'preferredModalities',
      WORKOUT_MODALITIES,
    );
  }

  if ('workoutSplit' in body) {
    updateInput.workoutSplit = parseEnum(body.workoutSplit, 'workoutSplit', WORKOUT_SPLITS);
  }

  if ('bio' in body) {
    updateInput.bio = parseOptionalNullableBio(body.bio);
  }

  if ('showSexualOrientation' in body) {
    updateInput.showSexualOrientation = parseBoolean(
      body.showSexualOrientation,
      'showSexualOrientation',
    );
  }

  if ('showAvailablePeriods' in body) {
    updateInput.showAvailablePeriods = parseBoolean(
      body.showAvailablePeriods,
      'showAvailablePeriods',
    );
  }

  if (Object.keys(updateInput).length === 0) {
    throw new HttpError(400, 'At least one updatable field must be provided.');
  }

  return updateInput;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseBoolean(value: unknown, field: string): boolean {
  if (typeof value !== 'boolean') {
    throw new HttpError(400, `${field} must be a boolean when provided.`);
  }

  return value;
}

function parseOptionalNullableBio(value: unknown): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'bio must be a string or null when provided.');
  }

  const normalizedBio = value.trim();

  if (normalizedBio.length === 0) {
    return null;
  }

  if (normalizedBio.length > 500) {
    throw new HttpError(400, 'bio must be at most 500 characters long.');
  }

  return normalizedBio;
}

function parseEnum<TValue extends string>(
  value: unknown,
  field: string,
  allowedValues: readonly TValue[],
): TValue {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string when provided.`);
  }

  const normalizedValue = value.trim().toUpperCase();
  const matchedValue = allowedValues.find((allowedValue) => allowedValue === normalizedValue);

  if (!matchedValue) {
    throw new HttpError(400, `${field} must be one of: ${allowedValues.join(', ')}.`);
  }

  return matchedValue;
}

function parseEnumArray<TValue extends string>(
  value: unknown,
  field: string,
  allowedValues: readonly TValue[],
): TValue[] {
  if (!Array.isArray(value)) {
    throw new HttpError(400, `${field} must be an array when provided.`);
  }

  if (value.length === 0) {
    throw new HttpError(400, `${field} must contain at least one value.`);
  }

  const normalizedValues = value.map((item) => parseEnum(item, field, allowedValues));

  return [...new Set(normalizedValues)];
}
