import type { PrismaClient } from '@prisma/client';
import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import { buildConfig } from '../config/env.js';
import type { MailServiceContract, PasswordResetMailInput } from '../mail/mail.service.js';
import type { StorageServiceContract } from '../storage/storage.service.js';
import { serializeUser } from '../users/users.serializer.js';
import type { CreateUserInput, SafeUser, UserRecord } from '../users/users.types.js';
import { UserConflictError } from '../users/users.types.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import {
  MAX_PROFILE_PHOTO_FILE_SIZE_BYTES,
  PROFILE_PHOTO_FORM_FIELD_NAME,
  PROFILE_PHOTO_INVALID_TYPE_MESSAGE,
} from './dto/upload-profile-photo.dto.js';
import type {
  CreateProfileInput,
  ProfileRecord,
  UpdateStudentProfileInput,
} from './profiles.types.js';
import { ProfileConflictError } from './profiles.types.js';
import { ProfilesRepository } from './profiles.repository.js';
import { ProfilesService } from './profiles.service.js';

const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  name?: string;
  email?: string;
  cpf?: string;
  phone?: string;
  gymId?: string | null;
  gymUnitId?: string | null;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
  deletedAt?: Date | null;
}

class InMemoryUsersService implements AuthUsersServiceContract {
  readonly createdUsers: UserRecord[] = [];
  private nextId = 1;

  async createUser(input: CreateUserInput): Promise<SafeUser> {
    if (this.createdUsers.some((user) => user.email === input.email)) {
      throw new UserConflictError('email');
    }

    if (this.createdUsers.some((user) => user.cpf === input.cpf)) {
      throw new UserConflictError('cpf');
    }

    if (this.createdUsers.some((user) => user.phone === input.phone)) {
      throw new UserConflictError('phone');
    }

    const now = new Date();
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name,
      email: input.email,
      phone: input.phone,
      cpf: input.cpf,
      passwordHash: input.passwordHash,
      gymId: input.gymId ?? null,
      gymUnitId: input.gymUnitId ?? null,
      refreshTokenHash: input.refreshTokenHash ?? null,
      passwordResetTokenHash: null,
      passwordResetTokenExpiresAt: null,
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: input.emailVerifiedAt ?? null,
      phoneVerifiedAt: input.phoneVerifiedAt ?? null,
      termsAcceptedAt: input.termsAcceptedAt ?? null,
      lastLoginAt: input.lastLoginAt ?? null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.createdUsers.push(user);

    return serializeUser(user);
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    return user ? serializeUser(user) : null;
  }

  async findUserByEmail(email: string): Promise<SafeUser | null> {
    const user = this.createdUsers.find((storedUser) => storedUser.email === email);

    return user ? serializeUser(user) : null;
  }

  async findUserByIdWithRefreshToken(id: string): Promise<UserRecord | null> {
    return this.createdUsers.find((user) => user.id === id) ?? null;
  }

  async findUserByEmailWithPassword(email: string): Promise<UserRecord | null> {
    return this.createdUsers.find((user) => user.email === email) ?? null;
  }

  async findUserByPasswordResetTokenHash(
    _passwordResetTokenHash: string,
  ): Promise<UserRecord | null> {
    return null;
  }

  async updateLastLoginAt(id: string, lastLoginAt: Date): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.lastLoginAt = lastLoginAt;
      user.updatedAt = lastLoginAt;
    }
  }

  async updateRefreshTokenHash(id: string, refreshTokenHash: string | null): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.refreshTokenHash = refreshTokenHash;
      user.updatedAt = new Date();
    }
  }

  async updatePasswordResetToken(
    id: string,
    passwordResetTokenHash: string | null,
    passwordResetTokenExpiresAt: Date | null,
  ): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.passwordResetTokenHash = passwordResetTokenHash;
      user.passwordResetTokenExpiresAt = passwordResetTokenExpiresAt;
      user.updatedAt = new Date();
    }
  }

  async updatePasswordAfterReset(id: string, passwordHash: string): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.passwordHash = passwordHash;
      user.refreshTokenHash = null;
      user.passwordResetTokenHash = null;
      user.passwordResetTokenExpiresAt = null;
      user.updatedAt = new Date();
    }
  }

  seedUser(input: SeedUserInput = {}): UserRecord {
    const now = new Date();
    const role = input.role ?? PrismaUserRole.STUDENT;
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name ?? 'Aluno Teste',
      email: input.email ?? `user_${this.nextId}@example.com`,
      cpf: input.cpf ?? `1234567890${this.nextId}`,
      phone: input.phone ?? `1199999999${this.nextId}`,
      passwordHash: 'hashed-password',
      gymId: input.gymId ?? (role === PrismaUserRole.STUDENT ? 'gym_1' : null),
      gymUnitId: input.gymUnitId ?? (role === PrismaUserRole.STUDENT ? 'unit_1' : null),
      refreshTokenHash: null,
      passwordResetTokenHash: null,
      passwordResetTokenExpiresAt: null,
      role,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.createdUsers.push(user);

    return user;
  }
}

class InMemoryProfilesRepository {
  private readonly profiles: ProfileRecord[] = [];
  private nextId = 1;

  async createProfile(
    userId: string,
    input: Parameters<ProfilesRepository['createProfile']>[1],
    computedFields: Parameters<ProfilesRepository['createProfile']>[2],
  ) {
    if (this.profiles.some((profile) => profile.userId === userId)) {
      throw new ProfileConflictError('userId');
    }

    const now = new Date();
    const profile: ProfileRecord = {
      id: `profile_${this.nextId++}`,
      userId,
      birthDate: input.birthDate,
      gender: input.gender,
      sexualOrientation: input.sexualOrientation,
      appGoal: input.appGoal,
      trainingLevel: input.trainingLevel,
      availablePeriods: [...input.availablePeriods],
      preferredModalities: [...input.preferredModalities],
      workoutSplit: input.workoutSplit,
      profilePhotoUrl: null,
      isComplete: computedFields.isComplete,
      bio: input.bio ?? null,
      showSexualOrientation: input.showSexualOrientation,
      showAvailablePeriods: input.showAvailablePeriods,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.profiles.push(profile);

    return profile;
  }

  async findProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.profiles.find((profile) => profile.userId === userId) ?? null;
  }

  async findActiveProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.profiles.find((profile) => profile.userId === userId && profile.deletedAt === null) ?? null;
  }

  async updateProfile(
    userId: string,
    input: UpdateStudentProfileInput,
    computedFields: Parameters<ProfilesRepository['updateProfile']>[2],
  ): Promise<ProfileRecord> {
    const profileIndex = this.profiles.findIndex((profile) => profile.userId === userId);

    if (profileIndex === -1) {
      throw new Error('Profile not found in test repository.');
    }

    const currentProfile = this.profiles[profileIndex]!;
    const updatedProfile: ProfileRecord = {
      ...currentProfile,
      ...(input.appGoal !== undefined ? { appGoal: input.appGoal } : {}),
      ...(input.trainingLevel !== undefined ? { trainingLevel: input.trainingLevel } : {}),
      ...(input.availablePeriods !== undefined ? { availablePeriods: [...input.availablePeriods] } : {}),
      ...(input.preferredModalities !== undefined
        ? { preferredModalities: [...input.preferredModalities] }
        : {}),
      ...(input.workoutSplit !== undefined ? { workoutSplit: input.workoutSplit } : {}),
      ...(input.bio !== undefined ? { bio: input.bio } : {}),
      ...(input.showSexualOrientation !== undefined
        ? { showSexualOrientation: input.showSexualOrientation }
        : {}),
      ...(input.showAvailablePeriods !== undefined
        ? { showAvailablePeriods: input.showAvailablePeriods }
        : {}),
      isComplete: computedFields.isComplete,
      updatedAt: new Date(),
    };

    this.profiles[profileIndex] = updatedProfile;

    return updatedProfile;
  }

  async updateProfilePhoto(
    userId: string,
    profilePhotoUrl: string,
    computedFields: { isComplete: boolean },
  ): Promise<ProfileRecord> {
    const profileIndex = this.profiles.findIndex((profile) => profile.userId === userId);

    if (profileIndex === -1) {
      throw new Error('Profile not found in test repository.');
    }

    const currentProfile = this.profiles[profileIndex]!;
    const updatedProfile: ProfileRecord = {
      ...currentProfile,
      profilePhotoUrl,
      isComplete: computedFields.isComplete,
      updatedAt: new Date(),
    };

    this.profiles[profileIndex] = updatedProfile;

    return updatedProfile;
  }

  setProfilePhotoUrl(userId: string, profilePhotoUrl: string | null): void {
    const profile = this.profiles.find((storedProfile) => storedProfile.userId === userId);

    if (!profile) {
      throw new Error('Profile not found in test repository.');
    }

    profile.profilePhotoUrl = profilePhotoUrl;
    profile.updatedAt = new Date();
  }
}

class InMemoryStorageService implements StorageServiceContract {
  readonly savedFiles: Array<{
    key: string;
    contentType: string;
    data: Buffer;
  }> = [];
  readonly deletedPublicUrls: string[] = [];

  async saveFile(input: {
    key: string;
    contentType: string;
    data: Buffer;
  }): Promise<{ key: string; publicUrl: string }> {
    this.savedFiles.push({
      key: input.key,
      contentType: input.contentType,
      data: input.data,
    });

    return {
      key: input.key,
      publicUrl: `/storage/${input.key}`,
    };
  }

  async deleteFileByPublicUrl(publicUrl: string): Promise<void> {
    this.deletedPublicUrls.push(publicUrl);
  }
}

class InMemoryMailService implements MailServiceContract {
  async sendPasswordResetEmail(_input: PasswordResetMailInput): Promise<void> {}
}

class InMemoryGymsService {
  async createGym() {
    throw new Error('Not implemented in this test.');
  }

  async findGymById() {
    throw new Error('Not implemented in this test.');
  }

  async getGymById() {
    throw new Error('Not implemented in this test.');
  }

  async listGyms() {
    throw new Error('Not implemented in this test.');
  }

  async updateGym() {
    throw new Error('Not implemented in this test.');
  }

  async createGymUnit() {
    throw new Error('Not implemented in this test.');
  }

  async findGymUnitById() {
    throw new Error('Not implemented in this test.');
  }

  async getGymUnitById() {
    throw new Error('Not implemented in this test.');
  }

  async listGymUnits() {
    throw new Error('Not implemented in this test.');
  }

  async listUnitsByGymId() {
    throw new Error('Not implemented in this test.');
  }

  async updateGymUnit() {
    throw new Error('Not implemented in this test.');
  }

  async validateGymUnitQrCodeToken() {
    throw new Error('Not implemented in this test.');
  }

  async activateGym() {
    throw new Error('Not implemented in this test.');
  }

  async deactivateGym() {
    throw new Error('Not implemented in this test.');
  }

  async activateGymUnit() {
    throw new Error('Not implemented in this test.');
  }

  async deactivateGymUnit() {
    throw new Error('Not implemented in this test.');
  }
}

function createBirthDateYearsAgo(years: number): string {
  const date = new Date();
  date.setUTCHours(0, 0, 0, 0);
  date.setUTCFullYear(date.getUTCFullYear() - years);

  return date.toISOString().slice(0, 10);
}

function makeCreateProfilePayload(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    birthDate: createBirthDateYearsAgo(24),
    gender: PrismaProfileGender.WOMAN,
    sexualOrientation: PrismaSexualOrientation.BISEXUAL,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [
      PrismaWorkoutModality.BODYBUILDING,
      PrismaWorkoutModality.FUNCTIONAL_TRAINING,
    ],
    workoutSplit: PrismaWorkoutSplit.ABC,
    bio: 'Buscando parceria para treinar no fim do dia.',
    showSexualOrientation: false,
    showAvailablePeriods: true,
    ...overrides,
  };
}

function makeCreateProfileInput(overrides: Partial<CreateProfileInput> = {}): CreateProfileInput {
  return {
    birthDate: new Date(`${createBirthDateYearsAgo(24)}T00:00:00.000Z`),
    gender: PrismaProfileGender.WOMAN,
    sexualOrientation: PrismaSexualOrientation.BISEXUAL,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [
      PrismaWorkoutModality.BODYBUILDING,
      PrismaWorkoutModality.FUNCTIONAL_TRAINING,
    ],
    workoutSplit: PrismaWorkoutSplit.ABC,
    bio: 'Buscando parceria para treinar no fim do dia.',
    showSexualOrientation: false,
    showAvailablePeriods: true,
    ...overrides,
  };
}

function makeUpdateProfilePayload(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    appGoal: PrismaAppGoal.DATING,
    availablePeriods: [PrismaAvailablePeriod.NIGHT],
    bio: '  Ajustando o perfil para treinos noturnos.  ',
    showSexualOrientation: true,
    ...overrides,
  };
}

function createMultipartPayload(
  parts: Array<
    | {
        type: 'file';
        fieldName: string;
        fileName: string;
        contentType: string;
        data: Buffer;
      }
    | {
        type: 'field';
        fieldName: string;
        value: string;
      }
  >,
): { boundary: string; body: Buffer } {
  const boundary = '----GymMatchBoundary7MA4YWxkTrZu0gW';
  const chunks: Buffer[] = [];

  for (const part of parts) {
    chunks.push(Buffer.from(`--${boundary}\r\n`, 'utf8'));

    if (part.type === 'field') {
      chunks.push(
        Buffer.from(
          `Content-Disposition: form-data; name="${part.fieldName}"\r\n\r\n${part.value}\r\n`,
          'utf8',
        ),
      );
      continue;
    }

    chunks.push(
      Buffer.from(
        `Content-Disposition: form-data; name="${part.fieldName}"; filename="${part.fileName}"\r\n`,
        'utf8',
      ),
    );
    chunks.push(Buffer.from(`Content-Type: ${part.contentType}\r\n\r\n`, 'utf8'));
    chunks.push(part.data);
    chunks.push(Buffer.from('\r\n', 'utf8'));
  }

  chunks.push(Buffer.from(`--${boundary}--\r\n`, 'utf8'));

  return {
    boundary,
    body: Buffer.concat(chunks),
  };
}

function makeJpegBuffer(): Buffer {
  return Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43, 0x00, 0x08]);
}

function makePngBuffer(): Buffer {
  return Buffer.from([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d,
  ]);
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const profilesRepository = new InMemoryProfilesRepository();
  const storageService = new InMemoryStorageService();
  const profilesService = new ProfilesService(
    {} as PrismaClient,
    profilesRepository as unknown as ProfilesRepository,
    storageService,
  );
  const gymsService = new InMemoryGymsService();
  const mailService = new InMemoryMailService();
  const app = buildApp({
    config,
    services: {
      gymsService: gymsService as never,
      mailService,
      profilesService,
      usersService,
    },
  });

  appsToClose.push(app);

  return { app, usersService, profilesRepository, storageService };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<UserRecord, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('POST /profiles/me', () => {
  it('creates a profile for an authenticated student', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeCreateProfilePayload(),
    });

    expect(response.statusCode).toBe(201);

    const body = response.json();
    const storedProfile = await profilesRepository.findProfileByUserId(student.id);

    expect(body).toMatchObject({
      userId: student.id,
      gender: PrismaProfileGender.WOMAN,
      sexualOrientation: PrismaSexualOrientation.BISEXUAL,
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
      preferredModalities: [
        PrismaWorkoutModality.BODYBUILDING,
        PrismaWorkoutModality.FUNCTIONAL_TRAINING,
      ],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl: null,
      isComplete: false,
      bio: 'Buscando parceria para treinar no fim do dia.',
      showSexualOrientation: false,
      showAvailablePeriods: true,
    });
    expect(typeof body.id).toBe('string');
    expect(typeof body.createdAt).toBe('string');
    expect(typeof body.updatedAt).toBe('string');
    expect(body).not.toHaveProperty('cpf');
    expect(body).not.toHaveProperty('phone');
    expect(body).not.toHaveProperty('passwordHash');
    expect(storedProfile?.userId).toBe(student.id);
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      payload: makeCreateProfilePayload(),
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('rejects admin users', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: makeCreateProfilePayload(),
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Only STUDENT users can create a student profile.',
    });
  });

  it('rejects users younger than 18 years old', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeCreateProfilePayload({
        birthDate: createBirthDateYearsAgo(17),
      }),
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Student profile requires the user to be at least 18 years old.',
    });
  });

  it('rejects requests with missing required fields', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const payload = makeCreateProfilePayload();
    delete payload.gender;

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'gender is required and must be a string.',
    });
  });

  it('rejects invalid enum values', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeCreateProfilePayload({
        trainingLevel: 'expert',
      }),
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'trainingLevel must be one of: BEGINNER, INTERMEDIATE, ADVANCED.',
    });
  });

  it('prevents duplicate profiles for the same user', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const accessToken = signAccessToken(app, student);

    const firstResponse = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${accessToken}`,
      },
      payload: makeCreateProfilePayload(),
    });

    const secondResponse = await app.inject({
      method: 'POST',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${accessToken}`,
      },
      payload: makeCreateProfilePayload(),
    });

    expect(firstResponse.statusCode).toBe(201);
    expect(secondResponse.statusCode).toBe(409);
    expect(secondResponse.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Student profile already exists for this user.',
    });
  });
});

describe('PATCH /profiles/me', () => {
  it('updates only the authenticated student profile fields allowed by the endpoint', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const student = usersService.seedUser();
    const existingProfile = await profilesRepository.createProfile(
      student.id,
      makeCreateProfileInput(),
      { isComplete: false },
    );

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeUpdateProfilePayload(),
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();
    const storedProfile = await profilesRepository.findProfileByUserId(student.id);

    expect(body).toMatchObject({
      userId: student.id,
      appGoal: PrismaAppGoal.DATING,
      availablePeriods: [PrismaAvailablePeriod.NIGHT],
      bio: 'Ajustando o perfil para treinos noturnos.',
      showSexualOrientation: true,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      preferredModalities: [
        PrismaWorkoutModality.BODYBUILDING,
        PrismaWorkoutModality.FUNCTIONAL_TRAINING,
      ],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl: null,
      isComplete: false,
      showAvailablePeriods: true,
    });
    expect(body.birthDate).toBe(existingProfile.birthDate.toISOString());
    expect(body).not.toHaveProperty('cpf');
    expect(body).not.toHaveProperty('phone');
    expect(body).not.toHaveProperty('email');
    expect(body).not.toHaveProperty('passwordHash');
    expect(storedProfile).toMatchObject({
      appGoal: PrismaAppGoal.DATING,
      availablePeriods: [PrismaAvailablePeriod.NIGHT],
      bio: 'Ajustando o perfil para treinos noturnos.',
      showSexualOrientation: true,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      workoutSplit: PrismaWorkoutSplit.ABC,
      isComplete: false,
      showAvailablePeriods: true,
    });
  });

  it('recalculates isComplete after update when the profile already has a photo', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const student = usersService.seedUser();

    await profilesRepository.createProfile(student.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    profilesRepository.setProfilePhotoUrl(student.id, 'https://cdn.gymmatch.test/profile.jpg');
    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeUpdateProfilePayload(),
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      userId: student.id,
      profilePhotoUrl: 'https://cdn.gymmatch.test/profile.jpg',
      isComplete: true,
    });

    const storedProfile = await profilesRepository.findProfileByUserId(student.id);

    expect(storedProfile?.isComplete).toBe(true);
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      payload: makeUpdateProfilePayload(),
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('rejects admin users', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: makeUpdateProfilePayload(),
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Only STUDENT users can update their own student profile.',
    });
  });

  it('returns not found when the authenticated student has no profile', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeUpdateProfilePayload(),
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Student profile not found.',
    });
  });

  it.each(['cpf', 'phone', 'email', 'age', 'birthDate', 'gender', 'sexualOrientation'])(
    'rejects attempts to update %s directly',
    async (field) => {
      const { app, usersService } = createTestApp();
      const student = usersService.seedUser();

      await app.ready();

      const response = await app.inject({
        method: 'PATCH',
        url: '/profiles/me',
        headers: {
          authorization: `Bearer ${signAccessToken(app, student)}`,
        },
        payload: {
          [field]: 'forbidden-value',
        },
      });

      expect(response.statusCode).toBe(400);
      expect(response.json()).toEqual({
        statusCode: 400,
        error: 'Bad Request',
        message: `${field} cannot be updated.`,
      });
    },
  );

  it('rejects empty update payloads', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: {},
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'At least one updatable field must be provided.',
    });
  });

  it('rejects invalid enum values', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const student = usersService.seedUser();

    await profilesRepository.createProfile(student.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: '/profiles/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
      payload: makeUpdateProfilePayload({
        trainingLevel: 'expert',
      }),
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'trainingLevel must be one of: BEGINNER, INTERMEDIATE, ADVANCED.',
    });
  });
});

describe('POST /profiles/me/photo', () => {
  it('uploads a valid profile photo for the authenticated student', async () => {
    const { app, usersService, profilesRepository, storageService } = createTestApp();
    const student = usersService.seedUser();

    await profilesRepository.createProfile(student.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    await app.ready();

    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: PROFILE_PHOTO_FORM_FIELD_NAME,
        fileName: 'profile.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me/photo',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();
    const storedProfile = await profilesRepository.findProfileByUserId(student.id);

    expect(body).toMatchObject({
      userId: student.id,
      isComplete: true,
    });
    expect(body.profilePhotoUrl).toMatch(/^\/storage\/profile-photos\/.+\.jpg$/);
    expect(body).not.toHaveProperty('cpf');
    expect(body).not.toHaveProperty('phone');
    expect(body).not.toHaveProperty('email');
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.savedFiles[0]).toMatchObject({
      contentType: 'image/jpeg',
      data: makeJpegBuffer(),
    });
    expect(storedProfile?.profilePhotoUrl).toBe(body.profilePhotoUrl);
    expect(storedProfile?.isComplete).toBe(true);
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: PROFILE_PHOTO_FORM_FIELD_NAME,
        fileName: 'profile.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me/photo',
      headers: {
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('rejects admin users', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const admin = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await profilesRepository.createProfile(admin.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    await app.ready();

    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: PROFILE_PHOTO_FORM_FIELD_NAME,
        fileName: 'profile.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me/photo',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Only STUDENT users can upload their own profile photo.',
    });
  });

  it('returns not found when the authenticated student has no profile', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser();

    await app.ready();

    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: PROFILE_PHOTO_FORM_FIELD_NAME,
        fileName: 'profile.jpg',
        contentType: 'image/jpeg',
        data: makeJpegBuffer(),
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me/photo',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Student profile not found.',
    });
  });

  it('rejects files with invalid content types', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const student = usersService.seedUser();

    await profilesRepository.createProfile(student.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    await app.ready();

    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: PROFILE_PHOTO_FORM_FIELD_NAME,
        fileName: 'profile.txt',
        contentType: 'text/plain',
        data: Buffer.from('not-an-image', 'utf8'),
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me/photo',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: PROFILE_PHOTO_INVALID_TYPE_MESSAGE,
    });
  });

  it('rejects files that exceed the maximum size', async () => {
    const { app, usersService, profilesRepository } = createTestApp();
    const student = usersService.seedUser();

    await profilesRepository.createProfile(student.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    await app.ready();

    const oversizedPhoto = Buffer.concat([
      makePngBuffer(),
      Buffer.alloc(MAX_PROFILE_PHOTO_FILE_SIZE_BYTES + 1),
    ]);
    const multipartPayload = createMultipartPayload([
      {
        type: 'file',
        fieldName: PROFILE_PHOTO_FORM_FIELD_NAME,
        fileName: 'profile.png',
        contentType: 'image/png',
        data: oversizedPhoto,
      },
    ]);

    const response = await app.inject({
      method: 'POST',
      url: '/profiles/me/photo',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
        'content-type': `multipart/form-data; boundary=${multipartPayload.boundary}`,
      },
      payload: multipartPayload.body,
    });

    expect(response.statusCode).toBe(413);
    expect(response.json()).toEqual({
      statusCode: 413,
      error: 'Payload Too Large',
      message: `photo must be at most ${MAX_PROFILE_PHOTO_FILE_SIZE_BYTES} bytes.`,
    });
  });
});
