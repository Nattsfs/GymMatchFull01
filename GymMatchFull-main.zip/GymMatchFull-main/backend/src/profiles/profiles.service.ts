import { randomUUID } from 'node:crypto';

import type { PrismaClient } from '@prisma/client';
import { UserRole as PrismaUserRole } from '@prisma/client';

import { HttpError } from '../common/errors/http-error.js';
import { isAtLeastAge } from '../common/validators/birth-date.validator.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { LocalStorageService } from '../storage/local-storage.service.js';
import type { StorageServiceContract } from '../storage/storage.service.js';
import {
  calculateProfileCompleteness,
  MINIMUM_COMPLETE_PROFILE_AGE,
} from './profile-completeness.service.js';
import { ProfilesRepository } from './profiles.repository.js';
import { serializeProfile } from './profiles.serializer.js';
import type {
  CreateProfileInput,
  ProfileCompletenessCandidate,
  ProfilesServiceContract,
  SafeProfile,
  UploadProfilePhotoInput,
  UpdateStudentProfileInput,
} from './profiles.types.js';
import { ProfileConflictError } from './profiles.types.js';

const DUPLICATE_PROFILE_MESSAGE = 'Student profile already exists for this user.';
const CREATE_INVALID_ROLE_MESSAGE = 'Only STUDENT users can create a student profile.';
const UPDATE_INVALID_ROLE_MESSAGE = 'Only STUDENT users can update their own student profile.';
const UPLOAD_INVALID_ROLE_MESSAGE = 'Only STUDENT users can upload their own profile photo.';
const PROFILE_NOT_FOUND_MESSAGE = 'Student profile not found.';
const UNDERAGE_MESSAGE = `Student profile requires the user to be at least ${MINIMUM_COMPLETE_PROFILE_AGE} years old.`;

export class ProfilesService implements ProfilesServiceContract {
  private readonly profilesRepository: ProfilesRepository;
  private readonly storageService: StorageServiceContract;

  constructor(
    prisma: PrismaClient,
    profilesRepository?: ProfilesRepository,
    storageService?: StorageServiceContract,
  ) {
    this.profilesRepository = profilesRepository ?? new ProfilesRepository(prisma);
    this.storageService = storageService ?? new LocalStorageService();
  }

  async createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateProfileInput,
  ): Promise<SafeProfile> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, CREATE_INVALID_ROLE_MESSAGE);
    }

    if (!isAtLeastAge(input.birthDate, MINIMUM_COMPLETE_PROFILE_AGE)) {
      throw new HttpError(400, UNDERAGE_MESSAGE);
    }

    const existingProfile = await this.profilesRepository.findProfileByUserId(currentUser.id);

    if (existingProfile) {
      throw new HttpError(409, DUPLICATE_PROFILE_MESSAGE);
    }

    try {
      const computedFields = {
        isComplete: calculateProfileCompleteness({
          user: currentUser,
          profile: buildCreateProfileCompletenessCandidate(input),
        }),
      };
      const profile = await this.profilesRepository.createProfile(
        currentUser.id,
        input,
        computedFields,
      );

      return serializeProfile(profile);
    } catch (error) {
      if (error instanceof ProfileConflictError && error.field === 'userId') {
        throw new HttpError(409, DUPLICATE_PROFILE_MESSAGE);
      }

      throw error;
    }
  }

  async updateForCurrentUser(
    currentUser: CurrentUserContext,
    input: UpdateStudentProfileInput,
  ): Promise<SafeProfile> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, UPDATE_INVALID_ROLE_MESSAGE);
    }

    const existingProfile = await this.profilesRepository.findActiveProfileByUserId(currentUser.id);

    if (!existingProfile) {
      throw new HttpError(404, PROFILE_NOT_FOUND_MESSAGE);
    }

    const computedFields = {
      isComplete: calculateProfileCompleteness({
        user: currentUser,
        profile: buildUpdatedProfileCompletenessCandidate(existingProfile, input),
      }),
    };
    const profile = await this.profilesRepository.updateProfile(
      currentUser.id,
      input,
      computedFields,
    );

    return serializeProfile(profile);
  }

  async uploadPhotoForCurrentUser(
    currentUser: CurrentUserContext,
    input: UploadProfilePhotoInput,
  ): Promise<SafeProfile> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, UPLOAD_INVALID_ROLE_MESSAGE);
    }

    const existingProfile = await this.profilesRepository.findActiveProfileByUserId(currentUser.id);

    if (!existingProfile) {
      throw new HttpError(404, PROFILE_NOT_FOUND_MESSAGE);
    }

    const storedFile = await this.storageService.saveFile({
      key: buildProfilePhotoStorageKey(currentUser.id, input.extension),
      contentType: input.contentType,
      data: input.data,
    });

    try {
      const updatedProfile = await this.profilesRepository.updateProfilePhoto(
        currentUser.id,
        storedFile.publicUrl,
        {
          isComplete: calculateProfileCompleteness({
            user: currentUser,
            profile: {
              ...existingProfile,
              profilePhotoUrl: storedFile.publicUrl,
            },
          }),
        },
      );

      if (
        existingProfile.profilePhotoUrl &&
        existingProfile.profilePhotoUrl !== storedFile.publicUrl
      ) {
        await this.storageService
          .deleteFileByPublicUrl(existingProfile.profilePhotoUrl)
          .catch(() => undefined);
      }

      return serializeProfile(updatedProfile);
    } catch (error) {
      await this.storageService.deleteFileByPublicUrl(storedFile.publicUrl).catch(() => undefined);
      throw error;
    }
  }
}

function buildCreateProfileCompletenessCandidate(
  input: CreateProfileInput,
): ProfileCompletenessCandidate {
  return {
    birthDate: input.birthDate,
    gender: input.gender,
    appGoal: input.appGoal,
    trainingLevel: input.trainingLevel,
    availablePeriods: input.availablePeriods,
    preferredModalities: input.preferredModalities,
    workoutSplit: input.workoutSplit,
    profilePhotoUrl: null,
    ...(input.deletedAt !== undefined ? { deletedAt: input.deletedAt } : {}),
  };
}

function buildUpdatedProfileCompletenessCandidate(
  existingProfile: ProfileCompletenessCandidate,
  input: UpdateStudentProfileInput,
): ProfileCompletenessCandidate {
  return {
    birthDate: existingProfile.birthDate,
    gender: existingProfile.gender,
    appGoal: input.appGoal ?? existingProfile.appGoal,
    trainingLevel: input.trainingLevel ?? existingProfile.trainingLevel,
    availablePeriods: input.availablePeriods ?? existingProfile.availablePeriods,
    preferredModalities: input.preferredModalities ?? existingProfile.preferredModalities,
    workoutSplit: input.workoutSplit ?? existingProfile.workoutSplit,
    ...(existingProfile.profilePhotoUrl !== undefined
      ? { profilePhotoUrl: existingProfile.profilePhotoUrl }
      : {}),
    ...(existingProfile.deletedAt !== undefined ? { deletedAt: existingProfile.deletedAt } : {}),
  };
}

function buildProfilePhotoStorageKey(
  userId: string,
  extension: UploadProfilePhotoInput['extension'],
): string {
  return `profile-photos/${userId}/${randomUUID()}.${extension}`;
}
