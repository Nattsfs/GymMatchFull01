import type { FastifyInstance, FastifyPluginAsync, FastifyRequest } from 'fastify';

import { HttpError } from '../common/errors/http-error.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { AuthService } from '../auth/auth.service.js';
import type { AuthServiceContract, AuthUsersServiceContract } from '../auth/auth.types.js';
import { getCurrentUserContext } from '../auth/current-user.js';
import { createJwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import { parseCreateProfileInput } from './dto/create-profile.dto.js';
import {
  MAX_PROFILE_PHOTO_FILE_SIZE_BYTES,
  parseProfilePhotoUpload,
} from './dto/upload-profile-photo.dto.js';
import { parseUpdateStudentProfileInput } from './dto/update-student-profile.dto.js';
import { ProfilesService } from './profiles.service.js';
import type { ProfilesServiceContract } from './profiles.types.js';

interface ProfilesRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  profilesService?: ProfilesServiceContract;
  usersService?: AuthUsersServiceContract;
}

export const profilesRoutes: FastifyPluginAsync<ProfilesRoutesOptions> = async (app, options) => {
  const usersService = options.usersService ?? new UsersService(app.prisma);
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const profilesService = options.profilesService ?? new ProfilesService(app.prisma);
  const authenticate = createJwtAuthGuard(authService);

  app.post('/profiles/me', { preHandler: authenticate }, async (request, reply) => {
    const input = parseCreateProfileInput(request.body);
    const currentUser = getCurrentUserContext(request);
    const profile = await profilesService.createForCurrentUser(currentUser, input);

    return reply.status(201).send(profile);
  });

  app.patch('/profiles/me', { preHandler: authenticate }, async (request, reply) => {
    const input = parseUpdateStudentProfileInput(request.body);
    const currentUser = getCurrentUserContext(request);
    const profile = await profilesService.updateForCurrentUser(currentUser, input);

    return reply.send(profile);
  });

  app.post('/profiles/me/photo', { preHandler: authenticate }, async (request, reply) => {
    const input = await parseProfilePhotoInput(request, app);
    const currentUser = getCurrentUserContext(request);
    const profile = await profilesService.uploadPhotoForCurrentUser(currentUser, input);

    return reply.send(profile);
  });
};

async function parseProfilePhotoInput(
  request: FastifyRequest,
  app: FastifyInstance,
) {
  try {
    const file = await request.file({
      limits: {
        files: 1,
        fields: 0,
        parts: 1,
        fileSize: MAX_PROFILE_PHOTO_FILE_SIZE_BYTES,
      },
    });

    if (!file) {
      throw new HttpError(400, 'photo is required and must be a file.');
    }

    return parseProfilePhotoUpload({
      fieldName: file.fieldname,
      mimeType: file.mimetype,
      buffer: await file.toBuffer(),
    });
  } catch (error) {
    if (error instanceof HttpError) {
      throw error;
    }

    if (error instanceof app.multipartErrors.RequestFileTooLargeError) {
      throw new HttpError(
        413,
        `photo must be at most ${MAX_PROFILE_PHOTO_FILE_SIZE_BYTES} bytes.`,
      );
    }

    if (
      error instanceof app.multipartErrors.FilesLimitError ||
      error instanceof app.multipartErrors.FieldsLimitError ||
      error instanceof app.multipartErrors.PartsLimitError
    ) {
      throw new HttpError(400, 'Only one profile photo file may be uploaded.');
    }

    if (error instanceof app.multipartErrors.InvalidMultipartContentTypeError) {
      throw new HttpError(400, 'Request must use multipart/form-data.');
    }

    throw error;
  }
}
