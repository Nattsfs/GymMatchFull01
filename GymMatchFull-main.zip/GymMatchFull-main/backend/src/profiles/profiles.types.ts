import type {
  AppGoal,
  AvailablePeriod,
  Profile,
  ProfileGender,
  SexualOrientation,
  TrainingLevel,
  UserRole,
  UserStatus,
  WorkoutModality,
  WorkoutSplit,
} from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';

export interface CreateProfileInput {
  birthDate: Date;
  gender: ProfileGender;
  sexualOrientation: SexualOrientation;
  appGoal: AppGoal;
  trainingLevel: TrainingLevel;
  availablePeriods: AvailablePeriod[];
  preferredModalities: WorkoutModality[];
  workoutSplit: WorkoutSplit;
  bio?: string;
  showSexualOrientation: boolean;
  showAvailablePeriods: boolean;
  deletedAt?: Date;
}

export interface UpdateStudentProfileInput {
  appGoal?: AppGoal;
  trainingLevel?: TrainingLevel;
  availablePeriods?: AvailablePeriod[];
  preferredModalities?: WorkoutModality[];
  workoutSplit?: WorkoutSplit;
  bio?: string | null;
  showSexualOrientation?: boolean;
  showAvailablePeriods?: boolean;
}

export interface UploadProfilePhotoInput {
  data: Buffer;
  contentType: 'image/jpeg' | 'image/png' | 'image/webp';
  extension: 'jpg' | 'png' | 'webp';
}

export type ProfileRecord = Profile;
export type SafeProfile = ProfileRecord;

export interface ProfileCompletenessUser {
  role: UserRole;
  status: UserStatus;
  deletedAt?: Date | null;
}

export interface ProfileCompletenessCandidate {
  birthDate: Date | null;
  gender: ProfileGender | null;
  appGoal: AppGoal | null;
  trainingLevel: TrainingLevel | null;
  availablePeriods: AvailablePeriod[];
  preferredModalities: WorkoutModality[];
  workoutSplit: WorkoutSplit | null;
  profilePhotoUrl?: string | null;
  deletedAt?: Date | null;
}

export interface ProfileComputedFields {
  isComplete: boolean;
}

export interface ProfilesServiceContract {
  createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateProfileInput,
  ): Promise<SafeProfile>;
  updateForCurrentUser(
    currentUser: CurrentUserContext,
    input: UpdateStudentProfileInput,
  ): Promise<SafeProfile>;
  uploadPhotoForCurrentUser(
    currentUser: CurrentUserContext,
    input: UploadProfilePhotoInput,
  ): Promise<SafeProfile>;
}

export class ProfileConflictError extends Error {
  readonly field: 'userId' | 'unknown';

  constructor(field: 'userId' | 'unknown') {
    const fieldLabel = field === 'userId' ? 'user profile' : 'unique profile field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'ProfileConflictError';
    this.field = field;
  }
}
