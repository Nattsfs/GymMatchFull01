import type { PrismaClient } from '@prisma/client';
import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { CurrentUserContext } from '../auth/current-user.js';
import type { StorageServiceContract } from '../storage/storage.service.js';
import type {
  CreateProfileInput,
  ProfileRecord,
  UpdateStudentProfileInput,
  UploadProfilePhotoInput,
} from './profiles.types.js';
import { ProfileConflictError } from './profiles.types.js';
import { ProfilesRepository } from './profiles.repository.js';
import { ProfilesService } from './profiles.service.js';

class InMemoryProfilesRepository {
  private readonly profiles: ProfileRecord[] = [];
  private nextId = 1;

  async createProfile(
    userId: string,
    input: CreateProfileInput,
    computedFields: { isComplete: boolean },
  ): Promise<ProfileRecord> {
    if (this.profiles.some((profile) => profile.userId === userId)) {
      throw new ProfileConflictError('userId');
    }

    const now = new Date();
    const profile: ProfileRecord = {
      id: `profile_${this.nextId++}`,
      userId,
      birthDate: input.birthDate,
      gender: input.gender,
      sexualOrientation: input.sexualOrientation,
      appGoal: input.appGoal,
      trainingLevel: input.trainingLevel,
      availablePeriods: [...input.availablePeriods],
      preferredModalities: [...input.preferredModalities],
      workoutSplit: input.workoutSplit,
      profilePhotoUrl: null,
      isComplete: computedFields.isComplete,
      bio: input.bio ?? null,
      showSexualOrientation: input.showSexualOrientation,
      showAvailablePeriods: input.showAvailablePeriods,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.profiles.push(profile);

    return profile;
  }

  async findProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.profiles.find((profile) => profile.userId === userId) ?? null;
  }

  async findActiveProfileByUserId(userId: string): Promise<ProfileRecord | null> {
    return this.profiles.find((profile) => profile.userId === userId && profile.deletedAt === null) ?? null;
  }

  async updateProfile(
    userId: string,
    input: UpdateStudentProfileInput,
    computedFields: { isComplete: boolean },
  ): Promise<ProfileRecord> {
    const profileIndex = this.profiles.findIndex((profile) => profile.userId === userId);

    if (profileIndex === -1) {
      throw new Error('Profile not found in test repository.');
    }

    const currentProfile = this.profiles[profileIndex]!;
    const updatedProfile: ProfileRecord = {
      ...currentProfile,
      ...(input.appGoal !== undefined ? { appGoal: input.appGoal } : {}),
      ...(input.trainingLevel !== undefined ? { trainingLevel: input.trainingLevel } : {}),
      ...(input.availablePeriods !== undefined ? { availablePeriods: [...input.availablePeriods] } : {}),
      ...(input.preferredModalities !== undefined
        ? { preferredModalities: [...input.preferredModalities] }
        : {}),
      ...(input.workoutSplit !== undefined ? { workoutSplit: input.workoutSplit } : {}),
      ...(input.bio !== undefined ? { bio: input.bio } : {}),
      ...(input.showSexualOrientation !== undefined
        ? { showSexualOrientation: input.showSexualOrientation }
        : {}),
      ...(input.showAvailablePeriods !== undefined
        ? { showAvailablePeriods: input.showAvailablePeriods }
        : {}),
      isComplete: computedFields.isComplete,
      updatedAt: new Date(),
    };

    this.profiles[profileIndex] = updatedProfile;

    return updatedProfile;
  }

  async updateProfilePhoto(
    userId: string,
    profilePhotoUrl: string,
    computedFields: { isComplete: boolean },
  ): Promise<ProfileRecord> {
    const profileIndex = this.profiles.findIndex((profile) => profile.userId === userId);

    if (profileIndex === -1) {
      throw new Error('Profile not found in test repository.');
    }

    const currentProfile = this.profiles[profileIndex]!;
    const updatedProfile: ProfileRecord = {
      ...currentProfile,
      profilePhotoUrl,
      isComplete: computedFields.isComplete,
      updatedAt: new Date(),
    };

    this.profiles[profileIndex] = updatedProfile;

    return updatedProfile;
  }

  setProfilePhotoUrl(userId: string, profilePhotoUrl: string | null): void {
    const profile = this.profiles.find((storedProfile) => storedProfile.userId === userId);

    if (!profile) {
      throw new Error('Profile not found in test repository.');
    }

    profile.profilePhotoUrl = profilePhotoUrl;
    profile.updatedAt = new Date();
  }
}

class InMemoryStorageService implements StorageServiceContract {
  readonly savedFiles: Array<{
    key: string;
    contentType: string;
    data: Buffer;
  }> = [];
  readonly deletedPublicUrls: string[] = [];

  async saveFile(input: {
    key: string;
    contentType: string;
    data: Buffer;
  }): Promise<{ key: string; publicUrl: string }> {
    this.savedFiles.push({
      key: input.key,
      contentType: input.contentType,
      data: input.data,
    });

    return {
      key: input.key,
      publicUrl: `/storage/${input.key}`,
    };
  }

  async deleteFileByPublicUrl(publicUrl: string): Promise<void> {
    this.deletedPublicUrls.push(publicUrl);
  }
}

function createProfilesService(
  repository: InMemoryProfilesRepository,
  storageService = new InMemoryStorageService(),
): ProfilesService {
  return new ProfilesService(
    {} as PrismaClient,
    repository as unknown as ProfilesRepository,
    storageService,
  );
}

function makeCurrentUser(overrides: Partial<CurrentUserContext> = {}): CurrentUserContext {
  return {
    id: 'user_1',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    ...overrides,
  };
}

function createBirthDateYearsAgo(years: number): Date {
  const date = new Date();
  date.setUTCHours(0, 0, 0, 0);
  date.setUTCFullYear(date.getUTCFullYear() - years);

  return date;
}

function makeCreateProfileInput(overrides: Partial<CreateProfileInput> = {}): CreateProfileInput {
  return {
    birthDate: createBirthDateYearsAgo(24),
    gender: PrismaProfileGender.WOMAN,
    sexualOrientation: PrismaSexualOrientation.BISEXUAL,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [
      PrismaWorkoutModality.BODYBUILDING,
      PrismaWorkoutModality.FUNCTIONAL_TRAINING,
    ],
    workoutSplit: PrismaWorkoutSplit.ABC,
    bio: 'Perfil criado para encontrar companhia de treino.',
    showSexualOrientation: false,
    showAvailablePeriods: true,
    ...overrides,
  };
}

function makeUpdateStudentProfileInput(
  overrides: Partial<UpdateStudentProfileInput> = {},
): UpdateStudentProfileInput {
  return {
    appGoal: PrismaAppGoal.DATING,
    availablePeriods: [PrismaAvailablePeriod.NIGHT],
    bio: 'Perfil atualizado para treinos noturnos.',
    showSexualOrientation: true,
    ...overrides,
  };
}

function makeUploadProfilePhotoInput(
  overrides: Partial<UploadProfilePhotoInput> = {},
): UploadProfilePhotoInput {
  return {
    data: Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43]),
    contentType: 'image/jpeg',
    extension: 'jpg',
    ...overrides,
  };
}

describe('ProfilesService', () => {
  it('creates a student profile linked to the authenticated user', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);
    const currentUser = makeCurrentUser({ id: 'student_123' });
    const input = makeCreateProfileInput();

    const profile = await service.createForCurrentUser(currentUser, input);

    expect(profile.userId).toBe('student_123');
    expect(profile.gender).toBe(PrismaProfileGender.WOMAN);
    expect(profile.availablePeriods).toEqual([
      PrismaAvailablePeriod.MORNING,
      PrismaAvailablePeriod.EVENING,
    ]);
    expect(profile.preferredModalities).toEqual([
      PrismaWorkoutModality.BODYBUILDING,
      PrismaWorkoutModality.FUNCTIONAL_TRAINING,
    ]);
    expect(profile.showSexualOrientation).toBe(false);
    expect(profile.showAvailablePeriods).toBe(true);
    expect(profile.profilePhotoUrl).toBeNull();
    expect(profile.isComplete).toBe(false);
  });

  it('rejects profile creation for admin users', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);

    await expect(
      service.createForCurrentUser(
        makeCurrentUser({ role: PrismaUserRole.ADMIN }),
        makeCreateProfileInput(),
      ),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only STUDENT users can create a student profile.',
    });
  });

  it('rejects users younger than 18 years old', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);

    await expect(
      service.createForCurrentUser(
        makeCurrentUser(),
        makeCreateProfileInput({
          birthDate: createBirthDateYearsAgo(17),
        }),
      ),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Student profile requires the user to be at least 18 years old.',
    });
  });

  it('prevents duplicate profiles for the same user', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);
    const currentUser = makeCurrentUser();
    const input = makeCreateProfileInput();

    await service.createForCurrentUser(currentUser, input);

    await expect(service.createForCurrentUser(currentUser, input)).rejects.toMatchObject({
      statusCode: 409,
      message: 'Student profile already exists for this user.',
    });
  });

  it('updates only the authenticated student profile fields allowed by the endpoint', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);
    const currentUser = makeCurrentUser({ id: 'student_123' });

    await repository.createProfile(currentUser.id, makeCreateProfileInput(), {
      isComplete: false,
    });

    const updatedProfile = await service.updateForCurrentUser(
      currentUser,
      makeUpdateStudentProfileInput(),
    );

    expect(updatedProfile.userId).toBe('student_123');
    expect(updatedProfile.appGoal).toBe(PrismaAppGoal.DATING);
    expect(updatedProfile.availablePeriods).toEqual([PrismaAvailablePeriod.NIGHT]);
    expect(updatedProfile.bio).toBe('Perfil atualizado para treinos noturnos.');
    expect(updatedProfile.showSexualOrientation).toBe(true);
    expect(updatedProfile.trainingLevel).toBe(PrismaTrainingLevel.INTERMEDIATE);
    expect(updatedProfile.workoutSplit).toBe(PrismaWorkoutSplit.ABC);
    expect(updatedProfile.isComplete).toBe(false);
  });

  it('recalculates profile completeness after updating an existing profile', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);
    const currentUser = makeCurrentUser({ id: 'student_456' });

    await repository.createProfile(currentUser.id, makeCreateProfileInput(), {
      isComplete: false,
    });
    repository.setProfilePhotoUrl(currentUser.id, 'https://cdn.gymmatch.test/profile.jpg');

    const updatedProfile = await service.updateForCurrentUser(
      currentUser,
      makeUpdateStudentProfileInput(),
    );

    expect(updatedProfile.profilePhotoUrl).toBe('https://cdn.gymmatch.test/profile.jpg');
    expect(updatedProfile.isComplete).toBe(true);
  });

  it('rejects profile updates for admin users', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);

    await expect(
      service.updateForCurrentUser(
        makeCurrentUser({ role: PrismaUserRole.ADMIN }),
        makeUpdateStudentProfileInput(),
      ),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only STUDENT users can update their own student profile.',
    });
  });

  it('rejects profile updates when the student profile does not exist', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);

    await expect(
      service.updateForCurrentUser(makeCurrentUser(), makeUpdateStudentProfileInput()),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Student profile not found.',
    });
  });

  it('uploads a profile photo, stores the reference, and recalculates completeness', async () => {
    const repository = new InMemoryProfilesRepository();
    const storageService = new InMemoryStorageService();
    const service = createProfilesService(repository, storageService);
    const currentUser = makeCurrentUser({ id: 'student_789' });

    await repository.createProfile(currentUser.id, makeCreateProfileInput(), {
      isComplete: false,
    });

    const updatedProfile = await service.uploadPhotoForCurrentUser(
      currentUser,
      makeUploadProfilePhotoInput(),
    );

    expect(updatedProfile.profilePhotoUrl).toMatch(/^\/storage\/profile-photos\/student_789\/.+\.jpg$/);
    expect(updatedProfile.isComplete).toBe(true);
    expect(storageService.savedFiles).toHaveLength(1);
    expect(storageService.savedFiles[0]).toMatchObject({
      contentType: 'image/jpeg',
      data: Buffer.from([0xff, 0xd8, 0xff, 0xdb, 0x00, 0x43]),
    });
  });

  it('replaces the previous profile photo reference when a new photo is uploaded', async () => {
    const repository = new InMemoryProfilesRepository();
    const storageService = new InMemoryStorageService();
    const service = createProfilesService(repository, storageService);
    const currentUser = makeCurrentUser({ id: 'student_987' });

    await repository.createProfile(currentUser.id, makeCreateProfileInput(), {
      isComplete: true,
    });
    repository.setProfilePhotoUrl(currentUser.id, '/storage/profile-photos/student_987/old.jpg');

    const updatedProfile = await service.uploadPhotoForCurrentUser(
      currentUser,
      makeUploadProfilePhotoInput({
        data: Buffer.from([0x89, 0x50, 0x4e, 0x47]),
        contentType: 'image/png',
        extension: 'png',
      }),
    );

    expect(updatedProfile.profilePhotoUrl).toMatch(/^\/storage\/profile-photos\/student_987\/.+\.png$/);
    expect(storageService.deletedPublicUrls).toEqual([
      '/storage/profile-photos/student_987/old.jpg',
    ]);
  });

  it('rejects profile photo uploads for admin users', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);

    await expect(
      service.uploadPhotoForCurrentUser(
        makeCurrentUser({ role: PrismaUserRole.ADMIN }),
        makeUploadProfilePhotoInput(),
      ),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only STUDENT users can upload their own profile photo.',
    });
  });

  it('rejects profile photo uploads when the student profile does not exist', async () => {
    const repository = new InMemoryProfilesRepository();
    const service = createProfilesService(repository);

    await expect(
      service.uploadPhotoForCurrentUser(makeCurrentUser(), makeUploadProfilePhotoInput()),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Student profile not found.',
    });
  });
});
