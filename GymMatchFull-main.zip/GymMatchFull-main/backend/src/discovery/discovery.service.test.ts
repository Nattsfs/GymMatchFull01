import type { PrismaClient } from '@prisma/client';
import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { CurrentUserContext } from '../auth/current-user.js';
import type { PublicStudentProfileSource } from '../profiles/profiles.serializer.js';
import type { SafeUser } from '../users/users.types.js';
import { DiscoveryRepository } from './discovery.repository.js';
import { DiscoveryService } from './discovery.service.js';
import type { DiscoveryProfileQueryOptions, EligibleDiscoveryProfilesInput } from './discovery.types.js';

class InMemoryUsersService {
  constructor(private readonly users: SafeUser[]) {}

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryDiscoveryRepository {
  lastInput?: {
    currentUserId: string;
    gymId: string;
    gymUnitId: string;
  };
  private readonly blockedByCurrentUserIds: Set<string>;
  private readonly usersBlockingCurrentUserIds: Set<string>;

  constructor(
    private readonly profiles: PublicStudentProfileSource[],
    private readonly currentStudentProfile:
      | {
          userId: string;
          appGoal: PublicStudentProfileSource['appGoal'];
        }
      | null = {
      userId: 'student_current',
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
    },
    blockedByCurrentUserIds: Iterable<string> = [],
    usersBlockingCurrentUserIds: Iterable<string> = [],
  ) {
    this.blockedByCurrentUserIds = new Set(blockedByCurrentUserIds);
    this.usersBlockingCurrentUserIds = new Set(usersBlockingCurrentUserIds);
  }

  async findActiveProfileByUserId(
    userId: string,
  ): Promise<Pick<PublicStudentProfileSource, 'appGoal'> | null> {
    if (!this.currentStudentProfile || this.currentStudentProfile.userId !== userId) {
      return null;
    }

    return {
      appGoal: this.currentStudentProfile.appGoal,
    };
  }

  async findEligibleProfilesForStudent(
    input: EligibleDiscoveryProfilesInput,
    options: DiscoveryProfileQueryOptions = {},
  ): Promise<PublicStudentProfileSource[]> {
    this.lastInput = input;

    return applyInMemoryPagination(
      filterEligibleProfiles(this.profiles, input, options).filter(
        (profile) =>
          !this.blockedByCurrentUserIds.has(profile.user.id) &&
          !this.usersBlockingCurrentUserIds.has(profile.user.id),
      ),
      options,
    );
  }

  async countEligibleProfilesForStudent(
    input: EligibleDiscoveryProfilesInput,
    options: DiscoveryProfileQueryOptions = {},
  ): Promise<number> {
    this.lastInput = input;

    return filterEligibleProfiles(this.profiles, input, options).filter(
      (profile) =>
        !this.blockedByCurrentUserIds.has(profile.user.id) &&
        !this.usersBlockingCurrentUserIds.has(profile.user.id),
    ).length;
  }
}

function createDiscoveryService(
  usersService: InMemoryUsersService,
  repository: InMemoryDiscoveryRepository,
): DiscoveryService {
  return new DiscoveryService(
    {} as PrismaClient,
    usersService,
    repository as unknown as DiscoveryRepository,
  );
}

function makeCurrentUser(overrides: Partial<CurrentUserContext> = {}): CurrentUserContext {
  return {
    id: 'student_current',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    ...overrides,
  };
}

function makeSafeUser(overrides: Partial<SafeUser> = {}): SafeUser {
  const now = new Date('2026-05-10T00:00:00.000Z');

  return {
    id: 'student_current',
    name: 'Aluno Atual',
    email: 'atual@example.com',
    phone: '11999999999',
    cpf: '12345678909',
    gymId: 'gym_1',
    gymUnitId: 'unit_1',
    role: PrismaUserRole.STUDENT,
    status: PrismaUserStatus.ACTIVE,
    emailVerifiedAt: null,
    phoneVerifiedAt: null,
    termsAcceptedAt: null,
    lastLoginAt: null,
    createdAt: now,
    updatedAt: now,
    deletedAt: null,
    ...overrides,
  };
}

function makePublicStudentProfileSource(
  overrides: Partial<PublicStudentProfileSource> & {
    user?: Partial<PublicStudentProfileSource['user']>;
  } = {},
): PublicStudentProfileSource {
  const { user: userOverrides, ...profileOverrides } = overrides;
  const createdAt = new Date('2026-05-10T00:00:00.000Z');
  const updatedAt = new Date('2026-05-10T00:00:00.000Z');
  const birthDate = new Date('1998-01-15T00:00:00.000Z');

  return {
    id: 'profile_candidate',
    userId: 'student_candidate',
    birthDate,
    gender: PrismaProfileGender.WOMAN,
    sexualOrientation: PrismaSexualOrientation.BISEXUAL,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
    workoutSplit: PrismaWorkoutSplit.ABC,
    profilePhotoUrl: 'https://cdn.gymmatch.test/profile.jpg',
    isComplete: true,
    bio: 'Treino no fim do dia e procuro companhia.',
    showSexualOrientation: false,
    showAvailablePeriods: true,
    createdAt,
    updatedAt,
    deletedAt: null,
    user: {
      id: 'student_candidate',
      name: 'Maria Silva',
      role: PrismaUserRole.STUDENT,
      status: PrismaUserStatus.ACTIVE,
      deletedAt: null,
      gym: {
        id: 'gym_1',
        name: 'Academia Centro',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Paulista',
        city: 'Sao Paulo',
        state: 'SP',
      },
      ...userOverrides,
    },
    ...profileOverrides,
  };
}

function filterEligibleProfiles(
  profiles: PublicStudentProfileSource[],
  input: EligibleDiscoveryProfilesInput,
  options: DiscoveryProfileQueryOptions = {},
): PublicStudentProfileSource[] {
  return profiles
    .filter(
      (profile) =>
        profile.user.id !== input.currentUserId &&
        profile.user.role === PrismaUserRole.STUDENT &&
        profile.user.status === PrismaUserStatus.ACTIVE &&
        profile.user.deletedAt === null &&
        profile.deletedAt === null &&
        profile.isComplete &&
        hasNonEmptyString(profile.profilePhotoUrl) &&
        profile.user.gym?.id === input.gymId &&
        profile.user.gymUnit?.id === input.gymUnitId &&
        matchesGoalFilter(profile, options),
    )
    .sort(compareProfilesByDiscoveryOrder);
}

function applyInMemoryPagination(
  profiles: PublicStudentProfileSource[],
  options: DiscoveryProfileQueryOptions,
): PublicStudentProfileSource[] {
  const skip = options.skip ?? 0;
  const take = options.take ?? profiles.length;

  return profiles.slice(skip, skip + take);
}

function matchesGoalFilter(
  profile: PublicStudentProfileSource,
  options: DiscoveryProfileQueryOptions,
): boolean {
  if (!options.appGoal || !options.goalMatch) {
    return true;
  }

  return options.goalMatch === 'same'
    ? profile.appGoal === options.appGoal
    : profile.appGoal !== options.appGoal;
}

function compareProfilesByDiscoveryOrder(
  left: PublicStudentProfileSource,
  right: PublicStudentProfileSource,
): number {
  const updatedAtComparison = right.updatedAt.getTime() - left.updatedAt.getTime();

  if (updatedAtComparison !== 0) {
    return updatedAtComparison;
  }

  return left.id.localeCompare(right.id);
}

function hasNonEmptyString(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}

describe('DiscoveryService', () => {
  it('returns only eligible public profiles from the same gym unit', async () => {
    const usersService = new InMemoryUsersService([makeSafeUser()]);
    const repository = new InMemoryDiscoveryRepository([
      makePublicStudentProfileSource(),
      makePublicStudentProfileSource({
        id: 'profile_self',
        userId: 'student_current',
        user: {
          id: 'student_current',
          name: 'Aluno Atual',
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_other_unit',
        userId: 'student_other_unit',
        user: {
          id: 'student_other_unit',
          name: 'Aluno Outra Unidade',
          gymUnit: {
            id: 'unit_2',
            name: 'Unidade Vila Mariana',
            city: 'Sao Paulo',
            state: 'SP',
          },
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_other_gym',
        userId: 'student_other_gym',
        user: {
          id: 'student_other_gym',
          name: 'Aluno Outra Academia',
          gym: {
            id: 'gym_2',
            name: 'Academia Zona Sul',
          },
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_admin',
        userId: 'admin_candidate',
        user: {
          id: 'admin_candidate',
          name: 'Admin Candidato',
          role: PrismaUserRole.ADMIN,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_suspended',
        userId: 'student_suspended',
        user: {
          id: 'student_suspended',
          name: 'Aluno Suspenso',
          status: PrismaUserStatus.SUSPENDED,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_banned',
        userId: 'student_banned',
        user: {
          id: 'student_banned',
          name: 'Aluno Banido',
          status: PrismaUserStatus.BANNED,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_deleted_status',
        userId: 'student_deleted_status',
        user: {
          id: 'student_deleted_status',
          name: 'Aluno Status Deletado',
          status: PrismaUserStatus.DELETED,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_deleted_user',
        userId: 'student_deleted',
        user: {
          id: 'student_deleted',
          name: 'Aluno Deletado',
          deletedAt: new Date('2026-05-09T00:00:00.000Z'),
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_incomplete',
        userId: 'student_incomplete',
        isComplete: false,
        user: {
          id: 'student_incomplete',
          name: 'Aluno Incompleto',
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_without_photo',
        userId: 'student_without_photo',
        profilePhotoUrl: null,
        user: {
          id: 'student_without_photo',
          name: 'Aluno Sem Foto',
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_deleted_profile',
        userId: 'student_deleted_profile',
        deletedAt: new Date('2026-05-09T00:00:00.000Z'),
        user: {
          id: 'student_deleted_profile',
          name: 'Aluno Perfil Deletado',
        },
      }),
    ]);
    const service = createDiscoveryService(usersService, repository);

    const result = await service.listEligibleProfiles(makeCurrentUser(), {
      page: 1,
      limit: 10,
    });

    expect(repository.lastInput).toEqual({
      currentUserId: 'student_current',
      gymId: 'gym_1',
      gymUnitId: 'unit_1',
    });
    expect(result.pagination).toEqual({
      page: 1,
      limit: 10,
      total: 1,
      totalPages: 1,
    });
    expect(result.data).toHaveLength(1);
    expect(result.data[0]).toMatchObject({
      id: 'student_candidate',
      name: 'Maria Silva',
      gender: PrismaProfileGender.WOMAN,
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl: 'https://cdn.gymmatch.test/profile.jpg',
      bio: 'Treino no fim do dia e procuro companhia.',
      availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
      gym: {
        id: 'gym_1',
        name: 'Academia Centro',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Paulista',
        city: 'Sao Paulo',
        state: 'SP',
      },
    });
    expect(typeof result.data[0]?.age).toBe('number');
    expect(result.data[0]).not.toHaveProperty('email');
    expect(result.data[0]).not.toHaveProperty('phone');
    expect(result.data[0]).not.toHaveProperty('cpf');
    expect(result.data[0]).not.toHaveProperty('passwordHash');
    expect(result.data[0]).not.toHaveProperty('refreshTokenHash');
    expect(result.data[0]).not.toHaveProperty('sexualOrientation');
  });

  it('excludes users blocked by the current student and users that blocked the current student', async () => {
    const usersService = new InMemoryUsersService([makeSafeUser()]);
    const repository = new InMemoryDiscoveryRepository(
      [
        makePublicStudentProfileSource({
          id: 'profile_visible',
          userId: 'student_visible',
          user: {
            id: 'student_visible',
            name: 'Visivel',
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_blocked_by_current',
          userId: 'student_blocked_by_current',
          user: {
            id: 'student_blocked_by_current',
            name: 'Bloqueado pelo atual',
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_blocking_current',
          userId: 'student_blocking_current',
          user: {
            id: 'student_blocking_current',
            name: 'Bloqueou o atual',
          },
        }),
      ],
      null,
      ['student_blocked_by_current'],
      ['student_blocking_current'],
    );
    const service = createDiscoveryService(usersService, repository);

    const result = await service.listEligibleProfiles(makeCurrentUser(), {
      page: 1,
      limit: 10,
    });

    expect(result.data).toHaveLength(1);
    expect(result.data[0]?.id).toBe('student_visible');
    expect(result.pagination.total).toBe(1);
  });

  it('rejects discovery access for admin users', async () => {
    const usersService = new InMemoryUsersService([makeSafeUser()]);
    const repository = new InMemoryDiscoveryRepository([]);
    const service = createDiscoveryService(usersService, repository);

    await expect(
      service.listEligibleProfiles(
        makeCurrentUser({
          role: PrismaUserRole.ADMIN,
        }),
        {
          page: 1,
          limit: 10,
        },
      ),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only STUDENT users can access discovery.',
    });
  });

  it('returns an empty list when the authenticated student has no gym unit association', async () => {
    const usersService = new InMemoryUsersService([
      makeSafeUser({
        gymId: null,
        gymUnitId: null,
      }),
    ]);
    const repository = new InMemoryDiscoveryRepository([
      makePublicStudentProfileSource(),
    ]);
    const service = createDiscoveryService(usersService, repository);

    const result = await service.listEligibleProfiles(makeCurrentUser(), {
      page: 1,
      limit: 10,
    });

    expect(result).toEqual({
      data: [],
      pagination: {
        page: 1,
        limit: 10,
        total: 0,
        totalPages: 1,
      },
    });
    expect(repository.lastInput).toBeUndefined();
  });

  it('paginates compatible app goals first and keeps hidden orientation private for dating profiles', async () => {
    const usersService = new InMemoryUsersService([makeSafeUser()]);
    const repository = new InMemoryDiscoveryRepository(
      [
        makePublicStudentProfileSource({
          id: 'profile_friendship',
          userId: 'student_friendship',
          appGoal: PrismaAppGoal.FRIENDSHIP,
          updatedAt: new Date('2026-05-10T12:00:00.000Z'),
          user: {
            id: 'student_friendship',
            name: 'Aluno Amizade',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_dating',
          userId: 'student_dating',
          appGoal: PrismaAppGoal.DATING,
          sexualOrientation: PrismaSexualOrientation.STRAIGHT,
          showSexualOrientation: false,
          updatedAt: new Date('2026-05-10T14:00:00.000Z'),
          user: {
            id: 'student_dating',
            name: 'Aluno Relacionamento',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_networking',
          userId: 'student_networking',
          appGoal: PrismaAppGoal.NETWORKING,
          updatedAt: new Date('2026-05-10T10:00:00.000Z'),
          user: {
            id: 'student_networking',
            name: 'Aluno Networking',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_dating_older',
          userId: 'student_dating_older',
          appGoal: PrismaAppGoal.DATING,
          updatedAt: new Date('2026-05-10T08:00:00.000Z'),
          user: {
            id: 'student_dating_older',
            name: 'Aluno Relacionamento 2',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
      ],
      {
        userId: 'student_current',
        appGoal: PrismaAppGoal.DATING,
      },
    );
    const service = createDiscoveryService(usersService, repository);

    const firstPage = await service.listEligibleProfiles(makeCurrentUser(), {
      page: 1,
      limit: 2,
    });

    expect(firstPage.pagination).toEqual({
      page: 1,
      limit: 2,
      total: 4,
      totalPages: 2,
    });
    expect(firstPage.data.map((profile) => profile.id)).toEqual([
      'student_dating',
      'student_dating_older',
    ]);
    expect(firstPage.data[0]).toMatchObject({
      id: 'student_dating',
      appGoal: PrismaAppGoal.DATING,
    });
    expect(firstPage.data[0]).not.toHaveProperty('sexualOrientation');

    const secondPage = await service.listEligibleProfiles(makeCurrentUser(), {
      page: 2,
      limit: 2,
    });

    expect(secondPage.pagination).toEqual({
      page: 2,
      limit: 2,
      total: 4,
      totalPages: 2,
    });
    expect(secondPage.data.map((profile) => profile.id)).toEqual([
      'student_friendship',
      'student_networking',
    ]);
  });
});
