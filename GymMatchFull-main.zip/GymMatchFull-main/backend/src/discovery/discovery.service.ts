import {
  AppGoal as PrismaAppGoal,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  type PrismaClient,
} from '@prisma/client';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { HttpError } from '../common/errors/http-error.js';
import type { PublicStudentProfileSource } from '../profiles/profiles.serializer.js';
import { serializePublicStudentProfile } from '../profiles/profiles.serializer.js';
import { UsersService } from '../users/users.service.js';
import { DiscoveryRepository } from './discovery.repository.js';
import type {
  DiscoveryServiceContract,
  EligibleDiscoveryProfilesInput,
  ListDiscoveryProfilesQueryInput,
  ListDiscoveryProfilesResult,
} from './discovery.types.js';

const DISCOVERY_INVALID_ROLE_MESSAGE = 'Only STUDENT users can access discovery.';
const INVALID_ACCESS_TOKEN_MESSAGE = 'Invalid access token.';
const DISCOVERABLE_USER_STATUSES = new Set<PrismaUserStatus>([PrismaUserStatus.ACTIVE]);

type DiscoveryUsersReader = Pick<AuthUsersServiceContract, 'findUserById'>;

export class DiscoveryService implements DiscoveryServiceContract {
  private readonly discoveryRepository: DiscoveryRepository;
  private readonly usersService: DiscoveryUsersReader;

  constructor(
    prisma: PrismaClient,
    usersService?: DiscoveryUsersReader,
    discoveryRepository?: DiscoveryRepository,
  ) {
    this.usersService = usersService ?? new UsersService(prisma);
    this.discoveryRepository = discoveryRepository ?? new DiscoveryRepository(prisma);
  }

  async listEligibleProfiles(
    currentUser: CurrentUserContext,
    query: ListDiscoveryProfilesQueryInput,
  ): Promise<ListDiscoveryProfilesResult> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, DISCOVERY_INVALID_ROLE_MESSAGE);
    }

    const authenticatedUser = await this.usersService.findUserById(currentUser.id);

    if (!authenticatedUser) {
      throw new HttpError(401, INVALID_ACCESS_TOKEN_MESSAGE);
    }

    if (!authenticatedUser.gymId || !authenticatedUser.gymUnitId) {
      return buildDiscoveryPaginationResult(query, [], 0);
    }

    const discoveryInput: EligibleDiscoveryProfilesInput = {
      currentUserId: currentUser.id,
      gymId: authenticatedUser.gymId,
      gymUnitId: authenticatedUser.gymUnitId,
    };
    const currentUserProfile = await this.discoveryRepository.findActiveProfileByUserId(
      currentUser.id,
    );
    const { profiles, total } = currentUserProfile?.appGoal
      ? await this.listGoalPrioritizedProfiles(discoveryInput, query, currentUserProfile.appGoal)
      : await this.listChronologicalProfiles(discoveryInput, query);

    return buildDiscoveryPaginationResult(
      query,
      profiles
        .filter((profile) => isEligibleDiscoveryProfile(profile, discoveryInput))
        .map((profile) => serializePublicStudentProfile(profile)),
      total,
    );
  }

  private async listChronologicalProfiles(
    input: EligibleDiscoveryProfilesInput,
    query: ListDiscoveryProfilesQueryInput,
  ): Promise<{
    profiles: PublicStudentProfileSource[];
    total: number;
  }> {
    const skip = calculateSkip(query);

    const [profiles, total] = await Promise.all([
      this.discoveryRepository.findEligibleProfilesForStudent(input, {
        skip,
        take: query.limit,
      }),
      this.discoveryRepository.countEligibleProfilesForStudent(input),
    ]);

    return {
      profiles,
      total,
    };
  }

  private async listGoalPrioritizedProfiles(
    input: EligibleDiscoveryProfilesInput,
    query: ListDiscoveryProfilesQueryInput,
    appGoal: PrismaAppGoal,
  ): Promise<{
    profiles: PublicStudentProfileSource[];
    total: number;
  }> {
    const [total, compatibleProfilesTotal] = await Promise.all([
      this.discoveryRepository.countEligibleProfilesForStudent(input),
      this.discoveryRepository.countEligibleProfilesForStudent(input, {
        appGoal,
        goalMatch: 'same',
      }),
    ]);
    const skip = calculateSkip(query);

    if (skip >= compatibleProfilesTotal) {
      const profiles = await this.discoveryRepository.findEligibleProfilesForStudent(input, {
        skip: skip - compatibleProfilesTotal,
        take: query.limit,
        appGoal,
        goalMatch: 'different',
      });

      return {
        profiles,
        total,
      };
    }

    const compatibleProfiles = await this.discoveryRepository.findEligibleProfilesForStudent(input, {
      skip,
      take: query.limit,
      appGoal,
      goalMatch: 'same',
    });

    if (compatibleProfiles.length >= query.limit) {
      return {
        profiles: compatibleProfiles,
        total,
      };
    }

    const remainingSlots = query.limit - compatibleProfiles.length;
    const otherProfiles = await this.discoveryRepository.findEligibleProfilesForStudent(input, {
      skip: 0,
      take: remainingSlots,
      appGoal,
      goalMatch: 'different',
    });

    return {
      profiles: [...compatibleProfiles, ...otherProfiles],
      total,
    };
  }
}

function isEligibleDiscoveryProfile(
  profile: PublicStudentProfileSource,
  input: {
    currentUserId: string;
    gymId: string;
    gymUnitId: string;
  },
): boolean {
  return (
    profile.user.id !== input.currentUserId &&
    profile.user.role === PrismaUserRole.STUDENT &&
    hasDiscoverableStatus(profile.user.status) &&
    profile.user.deletedAt === null &&
    profile.deletedAt === null &&
    profile.isComplete &&
    hasNonEmptyString(profile.profilePhotoUrl) &&
    profile.user.gym?.id === input.gymId &&
    profile.user.gymUnit?.id === input.gymUnitId
  );
}

function hasDiscoverableStatus(status: string | null | undefined): boolean {
  return typeof status === 'string' && DISCOVERABLE_USER_STATUSES.has(status as PrismaUserStatus);
}

function hasNonEmptyString(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}

function calculateSkip(query: ListDiscoveryProfilesQueryInput): number {
  return (query.page - 1) * query.limit;
}

function buildDiscoveryPaginationResult(
  query: ListDiscoveryProfilesQueryInput,
  data: ListDiscoveryProfilesResult['data'],
  total: number,
): ListDiscoveryProfilesResult {
  return {
    data,
    pagination: {
      page: query.page,
      limit: query.limit,
      total,
      totalPages: Math.max(1, Math.ceil(total / query.limit)),
    },
  };
}
