import {
  type Prisma,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  type PrismaClient,
} from '@prisma/client';

import type { PublicStudentProfileSource } from '../profiles/profiles.serializer.js';
import type {
  DiscoveryProfileQueryOptions,
  EligibleDiscoveryProfilesInput,
} from './discovery.types.js';

const DISCOVERABLE_USER_STATUSES = [PrismaUserStatus.ACTIVE] as const;
const DISCOVERY_ORDER_BY: Prisma.ProfileOrderByWithRelationInput[] = [
  { updatedAt: 'desc' },
  { id: 'asc' },
];

export class DiscoveryRepository {
  constructor(private readonly prisma: PrismaClient) {}

  findActiveProfileByUserId(
    userId: string,
  ): Promise<Pick<PublicStudentProfileSource, 'appGoal'> | null> {
    return this.prisma.profile.findFirst({
      where: {
        userId,
        deletedAt: null,
      },
      select: {
        appGoal: true,
      },
    });
  }

  findEligibleProfilesForStudent(
    input: EligibleDiscoveryProfilesInput,
    options: DiscoveryProfileQueryOptions = {},
  ): Promise<PublicStudentProfileSource[]> {
    return this.prisma.profile.findMany({
      where: buildEligibleDiscoveryProfileWhere(input, options),
      select: {
        id: true,
        userId: true,
        birthDate: true,
        gender: true,
        sexualOrientation: true,
        appGoal: true,
        trainingLevel: true,
        availablePeriods: true,
        preferredModalities: true,
        workoutSplit: true,
        profilePhotoUrl: true,
        isComplete: true,
        bio: true,
        showSexualOrientation: true,
        showAvailablePeriods: true,
        createdAt: true,
        updatedAt: true,
        deletedAt: true,
        user: {
          select: {
            id: true,
            name: true,
            role: true,
            status: true,
            deletedAt: true,
            gym: {
              select: {
                id: true,
                name: true,
              },
            },
            gymUnit: {
              select: {
                id: true,
                name: true,
                city: true,
                state: true,
              },
            },
          },
        },
      },
      orderBy: DISCOVERY_ORDER_BY,
      ...(options.skip !== undefined ? { skip: options.skip } : {}),
      ...(options.take !== undefined ? { take: options.take } : {}),
    });
  }

  countEligibleProfilesForStudent(
    input: EligibleDiscoveryProfilesInput,
    options: DiscoveryProfileQueryOptions = {},
  ): Promise<number> {
    return this.prisma.profile.count({
      where: buildEligibleDiscoveryProfileWhere(input, options),
    });
  }
}

function buildEligibleDiscoveryProfileWhere(
  input: EligibleDiscoveryProfilesInput,
  options: DiscoveryProfileQueryOptions = {},
): Prisma.ProfileWhereInput {
  return {
    deletedAt: null,
    isComplete: true,
    profilePhotoUrl: {
      not: null,
    },
    NOT: [{ profilePhotoUrl: '' }],
    ...buildAppGoalFilter(options),
    user: buildEligibleDiscoveryUserWhere(input),
  };
}

function buildAppGoalFilter(
  options: DiscoveryProfileQueryOptions,
): Partial<Pick<Prisma.ProfileWhereInput, 'appGoal'>> {
  if (!options.appGoal || !options.goalMatch) {
    return {};
  }

  return {
    appGoal:
      options.goalMatch === 'same'
        ? options.appGoal
        : {
            not: options.appGoal,
          },
  };
}

function buildEligibleDiscoveryUserWhere(
  input: EligibleDiscoveryProfilesInput,
): Prisma.UserWhereInput {
  return {
    id: {
      not: input.currentUserId,
    },
    role: PrismaUserRole.STUDENT,
    status: {
      in: [...DISCOVERABLE_USER_STATUSES],
    },
    deletedAt: null,
    gymId: input.gymId,
    gymUnitId: input.gymUnitId,
    ...buildDiscoveryInteractionVisibilityFilter(input),
  };
}

function buildDiscoveryInteractionVisibilityFilter(
  input: Pick<EligibleDiscoveryProfilesInput, 'currentUserId'>,
): Partial<Prisma.UserWhereInput> {
  return {
    blocksReceived: {
      none: {
        blockedByUserId: input.currentUserId,
        deletedAt: null,
      },
    },
    blocksSent: {
      none: {
        blockedUserId: input.currentUserId,
        deletedAt: null,
      },
    },
    rejectionsReceived: {
      none: {
        rejectedByUserId: input.currentUserId,
        deletedAt: null,
      },
    },
  };
}
