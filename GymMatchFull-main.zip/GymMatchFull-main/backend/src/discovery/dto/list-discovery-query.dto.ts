import { HttpError } from '../../common/errors/http-error.js';
import type { ListDiscoveryProfilesQueryInput } from '../discovery.types.js';

interface ListDiscoveryProfilesQuery {
  page?: unknown;
  limit?: unknown;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 50;

export function parseListDiscoveryProfilesQuery(
  payload: unknown,
): ListDiscoveryProfilesQueryInput {
  if (!isObject(payload)) {
    return {
      page: DEFAULT_PAGE,
      limit: DEFAULT_LIMIT,
    };
  }

  const query = payload as ListDiscoveryProfilesQuery;
  const page = parsePositiveInteger(query.page, 'page', DEFAULT_PAGE);
  const limit = parsePositiveInteger(query.limit, 'limit', DEFAULT_LIMIT, MAX_LIMIT);

  return {
    page,
    limit,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parsePositiveInteger(
  value: unknown,
  field: string,
  fallback: number,
  max?: number,
): number {
  if (value === undefined) {
    return fallback;
  }

  const stringValue = typeof value === 'number' ? String(value) : value;

  if (typeof stringValue !== 'string') {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const normalizedValue = stringValue.trim();

  if (!/^[1-9]\d*$/.test(normalizedValue)) {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    throw new HttpError(400, `${field} must be less than or equal to ${max}.`);
  }

  return parsedValue;
}
