import type { PrismaClient } from '@prisma/client';
import {
  AppGoal as PrismaAppGoal,
  AvailablePeriod as PrismaAvailablePeriod,
  ProfileGender as PrismaProfileGender,
  SexualOrientation as PrismaSexualOrientation,
  TrainingLevel as PrismaTrainingLevel,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  WorkoutModality as PrismaWorkoutModality,
  WorkoutSplit as PrismaWorkoutSplit,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import type { PublicStudentProfileSource } from '../profiles/profiles.serializer.js';
import type { SafeUser } from '../users/users.types.js';
import { DiscoveryRepository } from './discovery.repository.js';
import { DiscoveryService } from './discovery.service.js';
import type {
  DiscoveryProfileQueryOptions,
  EligibleDiscoveryProfilesInput,
} from './discovery.types.js';

const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(overrides: Partial<SafeUser> = {}): SafeUser {
    const now = new Date('2026-05-10T00:00:00.000Z');
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: 'gym_1',
      gymUnitId: 'unit_1',
      role: PrismaUserRole.STUDENT,
      status: PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      ...overrides,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryDiscoveryRepository {
  private readonly rejectedUserIds: Set<string>;

  constructor(
    private readonly profiles: PublicStudentProfileSource[],
    private readonly currentStudentProfile: {
      userId: string;
      appGoal: PublicStudentProfileSource['appGoal'];
    } | null = {
      userId: 'user_1',
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
    },
    rejectedUserIds: Iterable<string> = [],
  ) {
    this.rejectedUserIds = new Set(rejectedUserIds);
  }

  async findActiveProfileByUserId(
    userId: string,
  ): Promise<Pick<PublicStudentProfileSource, 'appGoal'> | null> {
    if (!this.currentStudentProfile || this.currentStudentProfile.userId !== userId) {
      return null;
    }

    return {
      appGoal: this.currentStudentProfile.appGoal,
    };
  }

  async findEligibleProfilesForStudent(
    input: EligibleDiscoveryProfilesInput,
    options: DiscoveryProfileQueryOptions = {},
  ): Promise<PublicStudentProfileSource[]> {
    return applyInMemoryPagination(
      filterEligibleProfiles(this.profiles, input, options).filter(
        (profile) => !this.rejectedUserIds.has(profile.user.id),
      ),
      options,
    );
  }

  async countEligibleProfilesForStudent(
    input: EligibleDiscoveryProfilesInput,
    options: DiscoveryProfileQueryOptions = {},
  ): Promise<number> {
    return filterEligibleProfiles(this.profiles, input, options).filter(
      (profile) => !this.rejectedUserIds.has(profile.user.id),
    ).length;
  }
}

function makePublicStudentProfileSource(
  overrides: Partial<PublicStudentProfileSource> & {
    user?: Partial<PublicStudentProfileSource['user']>;
  } = {},
): PublicStudentProfileSource {
  const createdAt = new Date('2026-05-10T00:00:00.000Z');
  const updatedAt = new Date('2026-05-10T00:00:00.000Z');
  const birthDate = new Date('1998-01-15T00:00:00.000Z');

  return {
    id: 'profile_candidate',
    userId: 'candidate_user',
    birthDate,
    gender: PrismaProfileGender.WOMAN,
    sexualOrientation: PrismaSexualOrientation.BISEXUAL,
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
    trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
    availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
    preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
    workoutSplit: PrismaWorkoutSplit.ABC,
    profilePhotoUrl: 'https://cdn.gymmatch.test/profile.jpg',
    isComplete: true,
    bio: 'Procuro parceria para treinar no fim do dia.',
    showSexualOrientation: false,
    showAvailablePeriods: true,
    createdAt,
    updatedAt,
    deletedAt: null,
    user: {
      id: 'candidate_user',
      name: 'Maria Silva',
      role: PrismaUserRole.STUDENT,
      status: PrismaUserStatus.ACTIVE,
      deletedAt: null,
      gym: {
        id: 'gym_1',
        name: 'Academia Centro',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Paulista',
        city: 'Sao Paulo',
        state: 'SP',
      },
      ...overrides.user,
    },
    ...overrides,
  };
}

function createTestApp(
  profiles: PublicStudentProfileSource[] = [],
  currentStudentProfile: {
    userId: string;
    appGoal: PublicStudentProfileSource['appGoal'];
  } | null = {
    userId: 'user_1',
    appGoal: PrismaAppGoal.TRAINING_PARTNER,
  },
  rejectedUserIds: Iterable<string> = [],
) {
  const usersService = new InMemoryUsersService();
  const discoveryRepository = new InMemoryDiscoveryRepository(
    profiles,
    currentStudentProfile,
    rejectedUserIds,
  );
  const discoveryService = new DiscoveryService(
    {} as PrismaClient,
    usersService,
    discoveryRepository as unknown as DiscoveryRepository,
  );
  const app = buildApp({
    config,
    services: {
      discoveryService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return { app, usersService };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

function filterEligibleProfiles(
  profiles: PublicStudentProfileSource[],
  input: EligibleDiscoveryProfilesInput,
  options: DiscoveryProfileQueryOptions = {},
): PublicStudentProfileSource[] {
  return profiles
    .filter(
      (profile) =>
        profile.user.id !== input.currentUserId &&
        profile.user.role === PrismaUserRole.STUDENT &&
        profile.user.status === PrismaUserStatus.ACTIVE &&
        profile.user.deletedAt === null &&
        profile.deletedAt === null &&
        profile.isComplete &&
        hasNonEmptyString(profile.profilePhotoUrl) &&
        profile.user.gym?.id === input.gymId &&
        profile.user.gymUnit?.id === input.gymUnitId &&
        matchesGoalFilter(profile, options),
    )
    .sort(compareProfilesByDiscoveryOrder);
}

function applyInMemoryPagination(
  profiles: PublicStudentProfileSource[],
  options: DiscoveryProfileQueryOptions,
): PublicStudentProfileSource[] {
  const skip = options.skip ?? 0;
  const take = options.take ?? profiles.length;

  return profiles.slice(skip, skip + take);
}

function matchesGoalFilter(
  profile: PublicStudentProfileSource,
  options: DiscoveryProfileQueryOptions,
): boolean {
  if (!options.appGoal || !options.goalMatch) {
    return true;
  }

  return options.goalMatch === 'same'
    ? profile.appGoal === options.appGoal
    : profile.appGoal !== options.appGoal;
}

function compareProfilesByDiscoveryOrder(
  left: PublicStudentProfileSource,
  right: PublicStudentProfileSource,
): number {
  const updatedAtComparison = right.updatedAt.getTime() - left.updatedAt.getTime();

  if (updatedAtComparison !== 0) {
    return updatedAtComparison;
  }

  return left.id.localeCompare(right.id);
}

function hasNonEmptyString(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('GET /discovery/profiles', () => {
  it('returns only eligible public profiles for the authenticated student', async () => {
    const { app, usersService } = createTestApp([
      makePublicStudentProfileSource(),
      makePublicStudentProfileSource({
        id: 'profile_self',
        userId: 'user_1',
        user: {
          id: 'user_1',
          name: 'Aluno 1',
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_other_unit',
        userId: 'user_other_unit',
        user: {
          id: 'user_other_unit',
          name: 'Aluno Outra Unidade',
          gymUnit: {
            id: 'unit_2',
            name: 'Unidade Vila Mariana',
            city: 'Sao Paulo',
            state: 'SP',
          },
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_other_gym',
        userId: 'user_other_gym',
        user: {
          id: 'user_other_gym',
          name: 'Aluno Outra Academia',
          gym: {
            id: 'gym_2',
            name: 'Academia Zona Sul',
          },
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_incomplete',
        userId: 'user_incomplete',
        isComplete: false,
        user: {
          id: 'user_incomplete',
          name: 'Aluno Incompleto',
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_without_photo',
        userId: 'user_without_photo',
        profilePhotoUrl: null,
        user: {
          id: 'user_without_photo',
          name: 'Aluno Sem Foto',
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_inactive',
        userId: 'user_inactive',
        user: {
          id: 'user_inactive',
          name: 'Aluno Inativo',
          status: PrismaUserStatus.SUSPENDED,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_banned',
        userId: 'user_banned',
        user: {
          id: 'user_banned',
          name: 'Aluno Banido',
          status: PrismaUserStatus.BANNED,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_deleted_status',
        userId: 'user_deleted_status',
        user: {
          id: 'user_deleted_status',
          name: 'Aluno Status Deletado',
          status: PrismaUserStatus.DELETED,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_deleted_user',
        userId: 'user_deleted',
        user: {
          id: 'user_deleted',
          name: 'Aluno Deletado',
          deletedAt: new Date('2026-05-09T00:00:00.000Z'),
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_admin',
        userId: 'admin_1',
        user: {
          id: 'admin_1',
          name: 'Admin Candidato',
          role: PrismaUserRole.ADMIN,
        },
      }),
      makePublicStudentProfileSource({
        id: 'profile_deleted_profile',
        userId: 'user_deleted_profile',
        deletedAt: new Date('2026-05-09T00:00:00.000Z'),
        user: {
          id: 'user_deleted_profile',
          name: 'Aluno Perfil Deletado',
        },
      }),
    ]);
    const student = usersService.seedUser({
      id: 'user_1',
      name: 'Aluno 1',
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/discovery/profiles',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();

    expect(body).toMatchObject({
      pagination: {
        page: 1,
        limit: 10,
        total: 1,
        totalPages: 1,
      },
    });
    expect(body.data).toHaveLength(1);
    expect(body.data[0]).toMatchObject({
      id: 'candidate_user',
      name: 'Maria Silva',
      gender: PrismaProfileGender.WOMAN,
      appGoal: PrismaAppGoal.TRAINING_PARTNER,
      trainingLevel: PrismaTrainingLevel.INTERMEDIATE,
      preferredModalities: [PrismaWorkoutModality.BODYBUILDING],
      workoutSplit: PrismaWorkoutSplit.ABC,
      profilePhotoUrl: 'https://cdn.gymmatch.test/profile.jpg',
      availablePeriods: [PrismaAvailablePeriod.MORNING, PrismaAvailablePeriod.EVENING],
      gym: {
        id: 'gym_1',
        name: 'Academia Centro',
      },
      gymUnit: {
        id: 'unit_1',
        name: 'Unidade Paulista',
        city: 'Sao Paulo',
        state: 'SP',
      },
    });
    expect(typeof body.data[0].age).toBe('number');
    expect(body.data[0]).not.toHaveProperty('email');
    expect(body.data[0]).not.toHaveProperty('phone');
    expect(body.data[0]).not.toHaveProperty('cpf');
    expect(body.data[0]).not.toHaveProperty('passwordHash');
    expect(body.data[0]).not.toHaveProperty('refreshTokenHash');
    expect(body.data[0]).not.toHaveProperty('sexualOrientation');
  });

  it('hides previously rejected profiles and keeps other eligible profiles discoverable', async () => {
    const { app, usersService } = createTestApp(
      [
        makePublicStudentProfileSource({
          id: 'profile_rejected',
          userId: 'user_rejected',
          user: {
            id: 'user_rejected',
            name: 'Aluno Recusado',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_visible',
          userId: 'user_visible',
          updatedAt: new Date('2026-05-10T11:00:00.000Z'),
          user: {
            id: 'user_visible',
            name: 'Aluno Elegivel',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
      ],
      {
        userId: 'user_1',
        appGoal: PrismaAppGoal.TRAINING_PARTNER,
      },
      ['user_rejected'],
    );
    const student = usersService.seedUser({
      id: 'user_1',
      name: 'Aluno 1',
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/discovery/profiles',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    const body = response.json();

    expect(body.pagination).toMatchObject({
      page: 1,
      limit: 10,
      total: 1,
      totalPages: 1,
    });
    expect(body.data).toHaveLength(1);
    expect(body.data[0]).toMatchObject({
      id: 'user_visible',
      name: 'Aluno Elegivel',
    });
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/discovery/profiles',
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from discovery', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/discovery/profiles',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('prioritizes profiles with the same app goal and keeps hidden dating orientation private', async () => {
    const { app, usersService } = createTestApp(
      [
        makePublicStudentProfileSource({
          id: 'profile_friendship',
          userId: 'user_friendship',
          appGoal: PrismaAppGoal.FRIENDSHIP,
          updatedAt: new Date('2026-05-10T12:00:00.000Z'),
          user: {
            id: 'user_friendship',
            name: 'Aluno Amizade',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_dating',
          userId: 'user_dating',
          appGoal: PrismaAppGoal.DATING,
          sexualOrientation: PrismaSexualOrientation.STRAIGHT,
          showSexualOrientation: false,
          updatedAt: new Date('2026-05-10T14:00:00.000Z'),
          user: {
            id: 'user_dating',
            name: 'Aluno Relacionamento',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_networking',
          userId: 'user_networking',
          appGoal: PrismaAppGoal.NETWORKING,
          updatedAt: new Date('2026-05-10T10:00:00.000Z'),
          user: {
            id: 'user_networking',
            name: 'Aluno Networking',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
        makePublicStudentProfileSource({
          id: 'profile_dating_older',
          userId: 'user_dating_older',
          appGoal: PrismaAppGoal.DATING,
          updatedAt: new Date('2026-05-10T08:00:00.000Z'),
          user: {
            id: 'user_dating_older',
            name: 'Aluno Relacionamento 2',
            role: PrismaUserRole.STUDENT,
            status: PrismaUserStatus.ACTIVE,
            deletedAt: null,
            gym: {
              id: 'gym_1',
              name: 'Academia Centro',
            },
            gymUnit: {
              id: 'unit_1',
              name: 'Unidade Paulista',
              city: 'Sao Paulo',
              state: 'SP',
            },
          },
        }),
      ],
      {
        userId: 'user_1',
        appGoal: PrismaAppGoal.DATING,
      },
    );
    const student = usersService.seedUser({
      id: 'user_1',
      name: 'Aluno 1',
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/discovery/profiles?page=1&limit=2',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();

    expect(body).toMatchObject({
      pagination: {
        page: 1,
        limit: 2,
        total: 4,
        totalPages: 2,
      },
    });
    expect(body.data.map((profile: { id: string }) => profile.id)).toEqual([
      'user_dating',
      'user_dating_older',
    ]);
    expect(body.data[0]).toMatchObject({
      id: 'user_dating',
      appGoal: PrismaAppGoal.DATING,
    });
    expect(body.data[0]).not.toHaveProperty('sexualOrientation');

    const secondPageResponse = await app.inject({
      method: 'GET',
      url: '/discovery/profiles?page=2&limit=2',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(secondPageResponse.statusCode).toBe(200);

    const secondPageBody = secondPageResponse.json();

    expect(secondPageBody).toMatchObject({
      pagination: {
        page: 2,
        limit: 2,
        total: 4,
        totalPages: 2,
      },
    });
    expect(secondPageBody.data.map((profile: { id: string }) => profile.id)).toEqual([
      'user_friendship',
      'user_networking',
    ]);
  });

  it('rejects invalid discovery pagination query params', async () => {
    const { app, usersService } = createTestApp();
    const student = usersService.seedUser({
      id: 'user_1',
      name: 'Aluno 1',
    });

    await app.ready();

    const invalidPageResponse = await app.inject({
      method: 'GET',
      url: '/discovery/profiles?page=0',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(invalidPageResponse.statusCode).toBe(400);
    expect(invalidPageResponse.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'page must be a positive integer when provided.',
    });

    const invalidLimitResponse = await app.inject({
      method: 'GET',
      url: '/discovery/profiles?limit=51',
      headers: {
        authorization: `Bearer ${signAccessToken(app, student)}`,
      },
    });

    expect(invalidLimitResponse.statusCode).toBe(400);
    expect(invalidLimitResponse.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'limit must be less than or equal to 50.',
    });
  });
});
