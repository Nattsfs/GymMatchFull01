import type { AppGoal } from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';
import type { PublicStudentProfileDto } from '../profiles/dto/public-student-profile.dto.js';

export interface EligibleDiscoveryProfilesInput {
  currentUserId: string;
  gymId: string;
  gymUnitId: string;
}

export interface ListDiscoveryProfilesQueryInput {
  page: number;
  limit: number;
}

export interface DiscoveryPaginationResult {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface ListDiscoveryProfilesResult {
  data: PublicStudentProfileDto[];
  pagination: DiscoveryPaginationResult;
}

export type DiscoveryProfileGoalMatch = 'same' | 'different';

export interface DiscoveryProfileQueryOptions {
  skip?: number;
  take?: number;
  appGoal?: AppGoal;
  goalMatch?: DiscoveryProfileGoalMatch;
}

export interface DiscoveryServiceContract {
  listEligibleProfiles(
    currentUser: CurrentUserContext,
    query: ListDiscoveryProfilesQueryInput,
  ): Promise<ListDiscoveryProfilesResult>;
}
