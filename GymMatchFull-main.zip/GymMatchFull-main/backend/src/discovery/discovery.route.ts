import { UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync } from 'fastify';

import { AuthService } from '../auth/auth.service.js';
import type { AuthServiceContract, AuthUsersServiceContract } from '../auth/auth.types.js';
import { getCurrentUserContext } from '../auth/current-user.js';
import { createJwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { createRolesGuard } from '../auth/roles.guard.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import { parseListDiscoveryProfilesQuery } from './dto/list-discovery-query.dto.js';
import { DiscoveryService } from './discovery.service.js';
import type { DiscoveryServiceContract } from './discovery.types.js';

interface DiscoveryRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  discoveryService?: DiscoveryServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  usersService?: AuthUsersServiceContract;
}

export const discoveryRoutes: FastifyPluginAsync<DiscoveryRoutesOptions> = async (
  app,
  options,
) => {
  const usersService = options.usersService ?? new UsersService(app.prisma);
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const discoveryService = options.discoveryService ?? new DiscoveryService(app.prisma, usersService);
  const authenticate = createJwtAuthGuard(authService);
  const requireStudent = createRolesGuard([PrismaUserRole.STUDENT]);

  app.get(
    '/discovery/profiles',
    { preHandler: [authenticate, requireStudent] },
    async (request) => {
      const query = parseListDiscoveryProfilesQuery(request.query);

      return discoveryService.listEligibleProfiles(getCurrentUserContext(request), query);
    },
  );
};
