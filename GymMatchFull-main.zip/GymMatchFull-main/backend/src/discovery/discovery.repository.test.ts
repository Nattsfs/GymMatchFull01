import type { PrismaClient } from '@prisma/client';
import { describe, expect, it, vi } from 'vitest';

import { DiscoveryRepository } from './discovery.repository.js';

describe('DiscoveryRepository', () => {
  it('filters out profiles rejected or blocked around the current user when listing discovery candidates', async () => {
    const findMany = vi.fn().mockResolvedValue([]);
    const prisma = {
      profile: {
        count: vi.fn().mockResolvedValue(0),
        findFirst: vi.fn().mockResolvedValue(null),
        findMany,
      },
    } as unknown as PrismaClient;
    const repository = new DiscoveryRepository(prisma);

    await repository.findEligibleProfilesForStudent({
      currentUserId: 'student_1',
      gymId: 'gym_1',
      gymUnitId: 'unit_1',
    });

    expect(findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          user: expect.objectContaining({
            blocksReceived: {
              none: {
                blockedByUserId: 'student_1',
                deletedAt: null,
              },
            },
            blocksSent: {
              none: {
                blockedUserId: 'student_1',
                deletedAt: null,
              },
            },
            rejectionsReceived: {
              none: {
                rejectedByUserId: 'student_1',
                deletedAt: null,
              },
            },
          }),
        }),
      }),
    );
  });
});
