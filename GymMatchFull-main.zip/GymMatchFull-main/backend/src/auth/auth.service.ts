import { randomUUID } from 'node:crypto';

import { compare, hash } from 'bcryptjs';
import {
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
  type UserStatus,
} from '@prisma/client';

import { HttpError } from '../common/errors/http-error.js';
import type {
  GymsServiceContract,
  PublicGymQrSummary,
  PublicGymUnitQrSummary,
} from '../gyms/gyms.types.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import type { SafeUser, UserConflictError, UserRecord } from '../users/users.types.js';
import type {
  AccessTokenPayload,
  AuthServiceContract,
  AuthUsersServiceContract,
  AuthenticatedUserResponse,
  ForgotPasswordInput,
  ForgotPasswordResponse,
  LoginInput,
  LoginResponse,
  LogoutResponse,
  RefreshInput,
  RefreshResponse,
  RefreshTokenPayload,
  RegisterInput,
  RegisteredUserResponse,
  ResetPasswordInput,
  ResetPasswordResponse,
} from './auth.types.js';
import { generatePasswordResetToken, hashPasswordResetToken } from './password-reset-token.js';

const PASSWORD_SALT_ROUNDS = 8;
const PASSWORD_RESET_SUCCESS_MESSAGE = 'Password reset completed successfully.';
const PASSWORD_RESET_REQUEST_MESSAGE =
  'If the email is registered, recovery instructions will be sent.';

interface TokenService {
  signAccessToken(payload: AccessTokenPayload): Promise<string> | string;
  signRefreshToken(payload: RefreshTokenPayload): Promise<string> | string;
  verifyRefreshToken(token: string): Promise<RefreshTokenPayload> | RefreshTokenPayload;
}

interface PasswordResetConfig {
  tokenExpiresInMinutes: number;
  baseUrl?: string;
  mobileAppUrl?: string;
  adminWebUrl?: string;
}

export class AuthService implements AuthServiceContract {
  constructor(
    private readonly usersService: AuthUsersServiceContract,
    private readonly gymsService: GymsServiceContract,
    private readonly tokenService: TokenService,
    private readonly mailService: MailServiceContract,
    private readonly passwordResetConfig: PasswordResetConfig,
  ) {}

  async register(input: RegisterInput): Promise<RegisteredUserResponse> {
    if (input.role === PrismaUserRole.ADMIN) {
      throw new HttpError(403, 'Public registration for ADMIN users is not allowed.');
    }

    const registrationContext = await this.resolveStudentRegistrationContext(input.qrCodeToken);
    const passwordHash = await hash(input.password, PASSWORD_SALT_ROUNDS);
    const user = await this.createUser({
      ...input,
      passwordHash,
      gymId: registrationContext.gym.id,
      gymUnitId: registrationContext.unit.id,
    });

    return createRegisteredUserResponse(user, registrationContext);
  }

  async login(input: LoginInput): Promise<LoginResponse> {
    const user = await this.usersService.findUserByEmailWithPassword(input.email);

    if (!user) {
      throw new HttpError(401, 'Invalid email or password.');
    }

    const passwordMatches = await compare(input.password, user.passwordHash);

    if (!passwordMatches) {
      throw new HttpError(401, 'Invalid email or password.');
    }

    ensureUserCanAuthenticate(user.status, user.deletedAt);

    const tokenPair = await this.issueTokenPair(user);
    const loginTimestamp = new Date();

    await Promise.all([
      this.usersService.updateLastLoginAt(user.id, loginTimestamp),
      this.usersService.updateRefreshTokenHash(user.id, tokenPair.refreshTokenHash),
    ]);

    return {
      accessToken: tokenPair.accessToken,
      refreshToken: tokenPair.refreshToken,
      user: createAuthenticatedUserResponse(user),
    };
  }

  async forgotPassword(input: ForgotPasswordInput): Promise<ForgotPasswordResponse> {
    const user = await this.usersService.findUserByEmail(input.email);

    if (!user || user.deletedAt !== null || user.status === PrismaUserStatus.DELETED) {
      return {
        message: PASSWORD_RESET_REQUEST_MESSAGE,
      };
    }

    const token = generatePasswordResetToken();
    const tokenHash = hashPasswordResetToken(token);
    const expiresAt = new Date(
      Date.now() + this.passwordResetConfig.tokenExpiresInMinutes * 60 * 1000,
    );

    await this.usersService.updatePasswordResetToken(user.id, tokenHash, expiresAt);
    await this.mailService.sendPasswordResetEmail({
      to: user.email,
      name: user.name,
      token,
      resetUrl: buildPasswordResetUrl(this.passwordResetConfig, token),
      expiresInMinutes: this.passwordResetConfig.tokenExpiresInMinutes,
    });

    return {
      message: PASSWORD_RESET_REQUEST_MESSAGE,
    };
  }

  async resetPassword(input: ResetPasswordInput): Promise<ResetPasswordResponse> {
    const tokenHash = hashPasswordResetToken(input.token);
    const user = await this.usersService.findUserByPasswordResetTokenHash(tokenHash);

    if (!user || user.passwordResetTokenHash !== tokenHash || !user.passwordResetTokenExpiresAt) {
      throw new HttpError(400, 'Invalid or expired password reset token.');
    }

    if (user.deletedAt !== null || user.status === PrismaUserStatus.DELETED) {
      await this.usersService.updatePasswordResetToken(user.id, null, null);
      throw new HttpError(400, 'Invalid or expired password reset token.');
    }

    if (user.passwordResetTokenExpiresAt.getTime() < Date.now()) {
      await this.usersService.updatePasswordResetToken(user.id, null, null);
      throw new HttpError(400, 'Invalid or expired password reset token.');
    }

    const passwordHash = await hash(input.password, PASSWORD_SALT_ROUNDS);

    await this.usersService.updatePasswordAfterReset(user.id, passwordHash);

    return {
      message: PASSWORD_RESET_SUCCESS_MESSAGE,
    };
  }

  async refresh(input: RefreshInput): Promise<RefreshResponse> {
    const refreshTokenPayload = await this.verifyRefreshToken(input.refreshToken);
    const user = await this.usersService.findUserByIdWithRefreshToken(refreshTokenPayload.sub);

    if (!user || !user.refreshTokenHash) {
      throw new HttpError(401, 'Invalid or expired refresh token.');
    }

    ensureUserCanAuthenticate(user.status, user.deletedAt);

    const refreshTokenMatches = await compare(input.refreshToken, user.refreshTokenHash);

    if (!refreshTokenMatches) {
      throw new HttpError(401, 'Invalid or expired refresh token.');
    }

    const tokenPair = await this.issueTokenPair(user);

    await this.usersService.updateRefreshTokenHash(user.id, tokenPair.refreshTokenHash);

    return {
      accessToken: tokenPair.accessToken,
      refreshToken: tokenPair.refreshToken,
    };
  }

  async logout(userId: string): Promise<LogoutResponse> {
    await this.usersService.updateRefreshTokenHash(userId, null);

    return {
      message: 'Logout completed successfully.',
    };
  }

  async getCurrentUser(userId: string): Promise<AuthenticatedUserResponse> {
    const user = await this.usersService.findUserById(userId);

    if (!user) {
      throw new HttpError(401, 'Invalid access token.');
    }

    ensureUserCanAuthenticate(user.status, user.deletedAt);

    return createAuthenticatedUserResponse(user);
  }

  private async createUser(input: RegisterUserInput): Promise<SafeUser> {
    try {
      return await this.usersService.createUser({
        name: input.name,
        email: input.email,
        cpf: input.cpf,
        phone: input.phone,
        passwordHash: input.passwordHash,
        gymId: input.gymId,
        gymUnitId: input.gymUnitId,
        role: PrismaUserRole.STUDENT,
        status: PrismaUserStatus.ACTIVE,
      });
    } catch (error) {
      if (isUserConflictError(error)) {
        throw new HttpError(409, getConflictMessage(error.field));
      }

      throw error;
    }
  }

  private async resolveStudentRegistrationContext(
    qrCodeToken: string | undefined,
  ): Promise<StudentRegistrationContext> {
    if (!qrCodeToken) {
      throw new HttpError(400, 'qrCodeToken is required for student registration.');
    }

    const validation = await this.gymsService.validateGymUnitQrCodeToken(qrCodeToken);

    if (!validation.valid) {
      throw new HttpError(400, validation.message);
    }

    return {
      gym: validation.gym,
      unit: validation.unit,
    };
  }

  private async issueTokenPair(
    user: Pick<UserRecord, 'id' | 'role' | 'status'>,
  ): Promise<{ accessToken: string; refreshToken: string; refreshTokenHash: string }> {
    const accessToken = await this.tokenService.signAccessToken({
      sub: user.id,
      role: user.role,
      status: user.status,
    });
    const refreshToken = await this.tokenService.signRefreshToken({
      sub: user.id,
      jti: randomUUID(),
    });
    const refreshTokenHash = await hash(refreshToken, PASSWORD_SALT_ROUNDS);

    return {
      accessToken,
      refreshToken,
      refreshTokenHash,
    };
  }

  private async verifyRefreshToken(refreshToken: string): Promise<RefreshTokenPayload> {
    try {
      const payload = await this.tokenService.verifyRefreshToken(refreshToken);

      if (isRefreshTokenPayload(payload)) {
        return payload;
      }
    } catch {
      // Keep the error mapping below stable and safe.
    }

    throw new HttpError(401, 'Invalid or expired refresh token.');
  }
}

function buildPasswordResetUrl(config: PasswordResetConfig, token: string): string {
  const baseUrl =
    config.mobileAppUrl ?? config.adminWebUrl ?? config.baseUrl ?? 'http://localhost:3000';
  const resetUrl = new URL('/reset-password', baseUrl);

  resetUrl.searchParams.set('token', token);

  return resetUrl.toString();
}

function createRegisteredUserResponse(
  user: SafeUser,
  registrationContext: StudentRegistrationContext,
): RegisteredUserResponse {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    status: user.status,
    gym: registrationContext.gym,
    unit: registrationContext.unit,
    createdAt: user.createdAt,
  };
}

function createAuthenticatedUserResponse(
  user: Pick<SafeUser, 'id' | 'name' | 'email' | 'role' | 'status'>,
): AuthenticatedUserResponse {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    status: user.status,
  };
}

function isUserConflictError(error: unknown): error is UserConflictError {
  return (
    typeof error === 'object' &&
    error !== null &&
    'name' in error &&
    error.name === 'UserConflictError' &&
    'field' in error
  );
}

function getConflictMessage(field: UserConflictError['field']): string {
  switch (field) {
    case 'email':
      return 'A user with this email already exists.';
    case 'cpf':
      return 'A user with this cpf already exists.';
    case 'phone':
      return 'A user with this phone already exists.';
    default:
      return 'A user with the same unique field already exists.';
  }
}

function ensureUserCanAuthenticate(
  status: UserStatus,
  deletedAt: Date | null,
): asserts status is typeof PrismaUserStatus.ACTIVE {
  if (deletedAt !== null || status === PrismaUserStatus.DELETED) {
    throw new HttpError(403, 'This account has been deleted.');
  }

  switch (status) {
    case PrismaUserStatus.ACTIVE:
      return;
    case PrismaUserStatus.SUSPENDED:
      throw new HttpError(403, 'This account is suspended.');
    case PrismaUserStatus.BANNED:
      throw new HttpError(403, 'This account is banned.');
    case PrismaUserStatus.PENDING:
      throw new HttpError(403, 'This account is pending activation.');
    default:
      throw new HttpError(403, 'This account is not allowed to log in.');
  }
}

function isRefreshTokenPayload(value: unknown): value is RefreshTokenPayload {
  return (
    typeof value === 'object' &&
    value !== null &&
    'sub' in value &&
    typeof value.sub === 'string' &&
    value.sub.length > 0 &&
    'jti' in value &&
    typeof value.jti === 'string' &&
    value.jti.length > 0
  );
}

interface StudentRegistrationContext {
  gym: PublicGymQrSummary;
  unit: PublicGymUnitQrSummary;
}

interface RegisterUserInput extends RegisterInput {
  passwordHash: string;
  gymId: string;
  gymUnitId: string;
}
