import type { UserRole } from '@prisma/client';
import type { FastifyReply, FastifyRequest, preHandlerAsyncHookHandler } from 'fastify';

import { HttpError } from '../common/errors/http-error.js';
import { getCurrentUserContext } from './current-user.js';

export function createRolesGuard(allowedRoles: UserRole[]): preHandlerAsyncHookHandler {
  return async function rolesGuard(request: FastifyRequest, _reply: FastifyReply): Promise<void> {
    const currentUser = getCurrentUserContext(request);

    if (!allowedRoles.includes(currentUser.role)) {
      throw new HttpError(403, 'Insufficient permissions.');
    }
  };
}
