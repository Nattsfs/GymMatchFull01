import { UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync } from 'fastify';

import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { GymsService } from '../gyms/gyms.service.js';
import type { GymsServiceContract } from '../gyms/gyms.types.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import { AuthService } from './auth.service.js';
import { getCurrentUser, getCurrentUserContext } from './current-user.js';
import { parseForgotPasswordInput } from './dto/forgot-password.dto.js';
import { parseLoginInput } from './dto/login.dto.js';
import { parseRefreshInput } from './dto/refresh-token.dto.js';
import { parseRegisterInput } from './dto/register.dto.js';
import { parseResetPasswordInput } from './dto/reset-password.dto.js';
import { createJwtAuthGuard } from './jwt-auth.guard.js';
import { createRolesGuard } from './roles.guard.js';
import type { AuthServiceContract, AuthUsersServiceContract } from './auth.types.js';

interface AuthRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  usersService?: AuthUsersServiceContract;
}

export const authRoutes: FastifyPluginAsync<AuthRoutesOptions> = async (app, options) => {
  app.decorateRequest('authTokenPayload', null);
  app.decorateRequest('currentUser', null);

  const usersService = options.usersService ?? new UsersService(app.prisma);
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const authenticate = createJwtAuthGuard(authService);
  const requireAdmin = createRolesGuard([PrismaUserRole.ADMIN]);

  app.post('/auth/register', async (request, reply) => {
    const input = parseRegisterInput(request.body);
    const user = await authService.register(input);

    return reply.status(201).send(user);
  });

  app.post('/auth/login', async (request) => {
    const input = parseLoginInput(request.body);

    return authService.login(input);
  });

  app.post('/auth/forgot-password', async (request) => {
    const input = parseForgotPasswordInput(request.body);

    return authService.forgotPassword(input);
  });

  app.post('/auth/reset-password', async (request) => {
    const input = parseResetPasswordInput(request.body);

    return authService.resetPassword(input);
  });

  app.post('/auth/refresh', async (request) => {
    const input = parseRefreshInput(request.body);

    return authService.refresh(input);
  });

  app.post('/auth/logout', { preHandler: authenticate }, async (request) => {
    return authService.logout(getCurrentUserContext(request).id);
  });

  app.get('/auth/me', { preHandler: authenticate }, async (request) => {
    return getCurrentUser(request);
  });

  app.get('/auth/admin-check', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    return {
      status: 'ok',
      message: 'Admin access granted.',
      user: getCurrentUserContext(request),
    };
  });
};
