import type { FastifyReply, FastifyRequest, preHandlerAsyncHookHandler } from 'fastify';

import { HttpError } from '../common/errors/http-error.js';
import type { AccessTokenPayload, AuthServiceContract } from './auth.types.js';

declare module 'fastify' {
  interface FastifyRequest {
    authTokenPayload: AccessTokenPayload | null;
    currentUser: import('./auth.types.js').AuthenticatedUserResponse | null;
  }
}

type CurrentUserReader = Pick<AuthServiceContract, 'getCurrentUser'>;

export function createJwtAuthGuard(authService: CurrentUserReader): preHandlerAsyncHookHandler {
  return async function jwtAuthGuard(request: FastifyRequest, _reply: FastifyReply): Promise<void> {
    const tokenPayload = await verifyAccessToken(request);

    request.authTokenPayload = tokenPayload;
    request.currentUser = await authService.getCurrentUser(tokenPayload.sub);
  };
}

async function verifyAccessToken(request: FastifyRequest): Promise<AccessTokenPayload> {
  try {
    return await request.jwtVerify<AccessTokenPayload>();
  } catch {
    throw new HttpError(401, 'Invalid or missing access token.');
  }
}
