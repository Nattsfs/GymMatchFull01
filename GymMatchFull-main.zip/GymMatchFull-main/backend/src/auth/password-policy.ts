import { HttpError } from '../common/errors/http-error.js';

const passwordLetterPattern = /[A-Za-z]/;
const passwordDigitPattern = /\d/;

export function parseStrongPassword(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'password is required and must be a string.');
  }

  if (value.length < 8) {
    throw new HttpError(400, 'password must be at least 8 characters long.');
  }

  if (!passwordLetterPattern.test(value) || !passwordDigitPattern.test(value)) {
    throw new HttpError(400, 'password must contain at least one letter and one number.');
  }

  return value;
}
