import { compare, hash } from 'bcryptjs';
import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import { buildConfig } from '../config/env.js';
import type {
  GymsServiceContract,
  PublicGymUnitQrValidationResponse,
} from '../gyms/gyms.types.js';
import type { MailServiceContract, PasswordResetMailInput } from '../mail/mail.service.js';
import { serializeUser } from '../users/users.serializer.js';
import type { CreateUserInput, SafeUser, UserRecord } from '../users/users.types.js';
import { UserConflictError } from '../users/users.types.js';
import type {
  AccessTokenPayload,
  AuthUsersServiceContract,
  RefreshTokenPayload,
} from './auth.types.js';
import { hashPasswordResetToken } from './password-reset-token.js';

const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  name?: string;
  email?: string;
  cpf?: string;
  phone?: string;
  password?: string;
  gymId?: string | null;
  gymUnitId?: string | null;
  refreshTokenHash?: string | null;
  passwordResetTokenHash?: string | null;
  passwordResetTokenExpiresAt?: Date | null;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
  deletedAt?: Date | null;
}

class InMemoryUsersService implements AuthUsersServiceContract {
  readonly createdUsers: UserRecord[] = [];
  lastCreateUserInput?: CreateUserInput;
  lastUpdatedLoginAt?: { userId: string; lastLoginAt: Date };
  lastUpdatedRefreshTokenHash?: { userId: string; refreshTokenHash: string | null };
  lastUpdatedPasswordResetToken?: {
    userId: string;
    passwordResetTokenHash: string | null;
    passwordResetTokenExpiresAt: Date | null;
  };
  lastUpdatedPasswordAfterReset?: { userId: string; passwordHash: string };
  private nextId = 1;

  async createUser(input: CreateUserInput): Promise<SafeUser> {
    this.lastCreateUserInput = input;

    if (this.createdUsers.some((user) => user.email === input.email)) {
      throw new UserConflictError('email');
    }

    if (this.createdUsers.some((user) => user.cpf === input.cpf)) {
      throw new UserConflictError('cpf');
    }

    if (this.createdUsers.some((user) => user.phone === input.phone)) {
      throw new UserConflictError('phone');
    }

    const now = new Date();
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name,
      email: input.email,
      phone: input.phone,
      cpf: input.cpf,
      passwordHash: input.passwordHash,
      gymId: input.gymId ?? null,
      gymUnitId: input.gymUnitId ?? null,
      refreshTokenHash: input.refreshTokenHash ?? null,
      passwordResetTokenHash: null,
      passwordResetTokenExpiresAt: null,
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: input.emailVerifiedAt ?? null,
      phoneVerifiedAt: input.phoneVerifiedAt ?? null,
      termsAcceptedAt: input.termsAcceptedAt ?? null,
      lastLoginAt: input.lastLoginAt ?? null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.createdUsers.push(user);

    return serializeUser(user);
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    return user ? serializeUser(user) : null;
  }

  async findUserByEmail(email: string): Promise<SafeUser | null> {
    const user = this.createdUsers.find((storedUser) => storedUser.email === email);

    return user ? serializeUser(user) : null;
  }

  async findUserByIdWithRefreshToken(id: string): Promise<UserRecord | null> {
    return this.createdUsers.find((user) => user.id === id) ?? null;
  }

  async findUserByEmailWithPassword(email: string): Promise<UserRecord | null> {
    return this.createdUsers.find((user) => user.email === email) ?? null;
  }

  async findUserByPasswordResetTokenHash(
    passwordResetTokenHash: string,
  ): Promise<UserRecord | null> {
    return (
      this.createdUsers.find((user) => user.passwordResetTokenHash === passwordResetTokenHash) ??
      null
    );
  }

  async updateLastLoginAt(id: string, lastLoginAt: Date): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (!user) {
      return;
    }

    user.lastLoginAt = lastLoginAt;
    user.updatedAt = lastLoginAt;
    this.lastUpdatedLoginAt = { userId: id, lastLoginAt };
  }

  async updateRefreshTokenHash(id: string, refreshTokenHash: string | null): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (!user) {
      return;
    }

    user.refreshTokenHash = refreshTokenHash;
    user.updatedAt = new Date();
    this.lastUpdatedRefreshTokenHash = { userId: id, refreshTokenHash };
  }

  async updatePasswordResetToken(
    id: string,
    passwordResetTokenHash: string | null,
    passwordResetTokenExpiresAt: Date | null,
  ): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (!user) {
      return;
    }

    user.passwordResetTokenHash = passwordResetTokenHash;
    user.passwordResetTokenExpiresAt = passwordResetTokenExpiresAt;
    user.updatedAt = new Date();
    this.lastUpdatedPasswordResetToken = {
      userId: id,
      passwordResetTokenHash,
      passwordResetTokenExpiresAt,
    };
  }

  async updatePasswordAfterReset(id: string, passwordHash: string): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (!user) {
      return;
    }

    user.passwordHash = passwordHash;
    user.refreshTokenHash = null;
    user.passwordResetTokenHash = null;
    user.passwordResetTokenExpiresAt = null;
    user.updatedAt = new Date();
    this.lastUpdatedPasswordAfterReset = { userId: id, passwordHash };
  }

  async seedUser(input: SeedUserInput = {}): Promise<UserRecord> {
    const password = input.password ?? 'Senha123';
    const role = input.role ?? PrismaUserRole.STUDENT;
    const now = new Date();
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name ?? 'Aluno Teste',
      email: input.email ?? 'aluno@example.com',
      cpf: input.cpf ?? '12345678909',
      phone: input.phone ?? '11999999999',
      passwordHash: await hash(password, 8),
      gymId: input.gymId ?? (role === PrismaUserRole.STUDENT ? 'gym_1' : null),
      gymUnitId: input.gymUnitId ?? (role === PrismaUserRole.STUDENT ? 'unit_1' : null),
      refreshTokenHash: input.refreshTokenHash ?? null,
      passwordResetTokenHash: input.passwordResetTokenHash ?? null,
      passwordResetTokenExpiresAt: input.passwordResetTokenExpiresAt ?? null,
      role,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.createdUsers.push(user);

    return user;
  }

  getUserById(id: string): UserRecord | undefined {
    return this.createdUsers.find((user) => user.id === id);
  }
}

class InMemoryMailService implements MailServiceContract {
  readonly sentPasswordResetEmails: PasswordResetMailInput[] = [];

  async sendPasswordResetEmail(input: PasswordResetMailInput): Promise<void> {
    this.sentPasswordResetEmails.push(input);
  }
}

class InMemoryGymsService {
  readonly validationResponses = new Map<string, PublicGymUnitQrValidationResponse>([
    [
      'qr-token-active',
      {
        valid: true,
        gym: {
          id: 'gym_1',
          name: 'Academia Exemplo',
        },
        unit: {
          id: 'unit_1',
          name: 'Unidade Centro',
          city: 'Sao Paulo',
          state: 'SP',
        },
      },
    ],
  ]);

  lastValidatedToken?: string;

  setValidationResponse(token: string, response: PublicGymUnitQrValidationResponse): void {
    this.validationResponses.set(token, response);
  }

  async createGym() {
    throw new Error('Not implemented in this test.');
  }

  async findGymById() {
    throw new Error('Not implemented in this test.');
  }

  async getGymById() {
    throw new Error('Not implemented in this test.');
  }

  async listGyms() {
    throw new Error('Not implemented in this test.');
  }

  async updateGym() {
    throw new Error('Not implemented in this test.');
  }

  async createGymUnit() {
    throw new Error('Not implemented in this test.');
  }

  async findGymUnitById() {
    throw new Error('Not implemented in this test.');
  }

  async getGymUnitById() {
    throw new Error('Not implemented in this test.');
  }

  async listGymUnits() {
    throw new Error('Not implemented in this test.');
  }

  async listUnitsByGymId() {
    throw new Error('Not implemented in this test.');
  }

  async updateGymUnit() {
    throw new Error('Not implemented in this test.');
  }

  async validateGymUnitQrCodeToken(token: string): Promise<PublicGymUnitQrValidationResponse> {
    this.lastValidatedToken = token;

    return (
      this.validationResponses.get(token) ?? {
        valid: false,
        message: 'QR Code invalido ou indisponivel.',
      }
    );
  }

  async activateGym() {
    throw new Error('Not implemented in this test.');
  }

  async deactivateGym() {
    throw new Error('Not implemented in this test.');
  }

  async activateGymUnit() {
    throw new Error('Not implemented in this test.');
  }

  async deactivateGymUnit() {
    throw new Error('Not implemented in this test.');
  }
}

const unavailableQrCodeResponse: PublicGymUnitQrValidationResponse = {
  valid: false,
  message: 'QR Code invalido ou indisponivel.',
};

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const gymsService = new InMemoryGymsService();
  const mailService = new InMemoryMailService();
  const app = buildApp({
    config,
    services: {
      gymsService: gymsService as unknown as GymsServiceContract,
      mailService,
      usersService,
    },
  });

  appsToClose.push(app);

  return { app, usersService, gymsService, mailService };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<UserRecord, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

function signRefreshToken(
  app: ReturnType<typeof buildApp>,
  userId: string,
  expiresIn: string | number = config.auth.refreshTokenExpiresIn,
): string {
  return app.jwt.sign(
    {
      sub: userId,
      jti: `refresh-${userId}-${Date.now()}`,
    },
    {
      key: config.auth.refreshTokenSecret,
      expiresIn,
    },
  );
}

async function persistRefreshToken(
  app: ReturnType<typeof buildApp>,
  usersService: InMemoryUsersService,
  userId: string,
  expiresIn: string | number = config.auth.refreshTokenExpiresIn,
): Promise<string> {
  const refreshToken = signRefreshToken(app, userId, expiresIn);
  const refreshTokenHash = await hash(refreshToken, 8);

  await usersService.updateRefreshTokenHash(userId, refreshTokenHash);

  return refreshToken;
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('POST /auth/register', () => {
  it('registers a valid student user and stores a hashed password', async () => {
    const { app, gymsService, usersService } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: '  Aluno Teste  ',
        email: 'ALUNO@EXAMPLE.COM',
        cpf: '123.456.789-09',
        phone: '(11) 99999-9999',
        password: 'Senha123',
        qrCodeToken: 'qr-token-active',
        role: 'student',
      },
    });

    expect(response.statusCode).toBe(201);

    const body = response.json();

    expect(body).toMatchObject({
      id: 'user_1',
      name: 'Aluno Teste',
      email: 'aluno@example.com',
      role: 'STUDENT',
      status: 'ACTIVE',
      gym: {
        id: 'gym_1',
        name: 'Academia Exemplo',
      },
      unit: {
        id: 'unit_1',
        name: 'Unidade Centro',
        city: 'Sao Paulo',
        state: 'SP',
      },
    });
    expect(typeof body.createdAt).toBe('string');
    expect(body).not.toHaveProperty('passwordHash');
    expect(body).not.toHaveProperty('refreshTokenHash');
    expect(body).not.toHaveProperty('cpf');
    expect(body).not.toHaveProperty('phone');
    expect(gymsService.lastValidatedToken).toBe('qr-token-active');
    expect(usersService.lastCreateUserInput?.passwordHash).toBeDefined();
    expect(usersService.lastCreateUserInput?.passwordHash).not.toBe('Senha123');
    expect(usersService.lastCreateUserInput?.gymId).toBe('gym_1');
    expect(usersService.lastCreateUserInput?.gymUnitId).toBe('unit_1');
    expect(await compare('Senha123', usersService.lastCreateUserInput?.passwordHash ?? '')).toBe(
      true,
    );
  });

  it('uses STUDENT as the default role when role is omitted', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Sem Role',
        email: 'sem-role@example.com',
        cpf: '11144477735',
        phone: '11988887777',
        password: 'Senha123',
        qrCodeToken: 'qr-token-active',
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      role: 'STUDENT',
      status: 'ACTIVE',
    });
  });

  it('requires qrCodeToken for public student registration', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Sem Token',
        email: 'sem-token@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'qrCodeToken is required for student registration.',
    });
  });

  it('rejects an invalid qrCodeToken', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Token Invalido',
        email: 'token-invalido@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
        qrCodeToken: 'qr-token-invalid',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('rejects registration when the gym unit is inactive', async () => {
    const { app, gymsService } = createTestApp();

    gymsService.setValidationResponse('qr-token-unit-inactive', unavailableQrCodeResponse);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Unidade Inativa',
        email: 'unidade-inativa@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
        qrCodeToken: 'qr-token-unit-inactive',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('rejects registration when the gym unit is soft deleted', async () => {
    const { app, gymsService } = createTestApp();

    gymsService.setValidationResponse('qr-token-unit-deleted', unavailableQrCodeResponse);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Unidade Excluida',
        email: 'unidade-excluida@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
        qrCodeToken: 'qr-token-unit-deleted',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('rejects registration when the gym is inactive', async () => {
    const { app, gymsService } = createTestApp();

    gymsService.setValidationResponse('qr-token-gym-inactive', unavailableQrCodeResponse);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Academia Inativa',
        email: 'academia-inativa@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
        qrCodeToken: 'qr-token-gym-inactive',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('rejects registration when the gym is soft deleted', async () => {
    const { app, gymsService } = createTestApp();

    gymsService.setValidationResponse('qr-token-gym-deleted', unavailableQrCodeResponse);

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Academia Excluida',
        email: 'academia-excluida@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
        qrCodeToken: 'qr-token-gym-deleted',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('ignores manual gymId and gymUnitId values and uses the QR code association', async () => {
    const { app, usersService } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Com Payload Malicioso',
        email: 'payload-malicioso@example.com',
        cpf: '52998224725',
        phone: '11977776666',
        password: 'Senha123',
        qrCodeToken: 'qr-token-active',
        gymId: 'gym-forcado',
        gymUnitId: 'unit-forcada',
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      gym: {
        id: 'gym_1',
      },
      unit: {
        id: 'unit_1',
      },
    });
    expect(usersService.lastCreateUserInput?.gymId).toBe('gym_1');
    expect(usersService.lastCreateUserInput?.gymUnitId).toBe('unit_1');
  });

  it('rejects duplicate email', async () => {
    const { app } = createTestApp();

    await app.ready();

    const firstPayload = {
      name: 'Aluno Teste',
      email: 'duplicado@example.com',
      cpf: '12345678909',
      phone: '11999999999',
      password: 'Senha123',
      qrCodeToken: 'qr-token-active',
    };

    await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: firstPayload,
    });

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        ...firstPayload,
        cpf: '11144477735',
        phone: '11988887777',
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'A user with this email already exists.',
    });
  });

  it('rejects duplicate cpf', async () => {
    const { app } = createTestApp();

    await app.ready();

    const firstPayload = {
      name: 'Aluno Teste',
      email: 'primeiro@example.com',
      cpf: '12345678909',
      phone: '11999999999',
      password: 'Senha123',
      qrCodeToken: 'qr-token-active',
    };

    await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: firstPayload,
    });

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        ...firstPayload,
        email: 'segundo@example.com',
        phone: '11988887777',
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'A user with this cpf already exists.',
    });
  });

  it('rejects duplicate phone', async () => {
    const { app } = createTestApp();

    await app.ready();

    const firstPayload = {
      name: 'Aluno Teste',
      email: 'primeiro@example.com',
      cpf: '12345678909',
      phone: '11999999999',
      password: 'Senha123',
      qrCodeToken: 'qr-token-active',
    };

    await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: firstPayload,
    });

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        ...firstPayload,
        email: 'segundo@example.com',
        cpf: '11144477735',
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'A user with this phone already exists.',
    });
  });

  it('rejects an invalid CPF', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Teste',
        email: 'aluno@example.com',
        cpf: '12345678900',
        phone: '11999999999',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'cpf must be a valid CPF.',
    });
  });

  it('rejects an invalid email', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Teste',
        email: 'email-invalido',
        cpf: '12345678909',
        phone: '11999999999',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'email must be a valid email address.',
    });
  });

  it('rejects a weak password', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Teste',
        email: 'aluno@example.com',
        cpf: '12345678909',
        phone: '11999999999',
        password: 'abcdefghi',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'password must contain at least one letter and one number.',
    });
  });

  it('rejects an invalid role', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Aluno Teste',
        email: 'aluno@example.com',
        cpf: '12345678909',
        phone: '11999999999',
        password: 'Senha123',
        role: 'MODERATOR',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'role must be either STUDENT or ADMIN when provided.',
    });
  });

  it('rejects public ADMIN registration', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: 'Admin Teste',
        email: 'admin@example.com',
        cpf: '12345678909',
        phone: '11999999999',
        password: 'Senha123',
        role: 'ADMIN',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Public registration for ADMIN users is not allowed.',
    });
  });

  it('rejects a name made only of spaces', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/register',
      payload: {
        name: '   ',
        email: 'aluno@example.com',
        cpf: '12345678909',
        phone: '11999999999',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'name must be at least 3 characters long.',
    });
  });
});

describe('POST /auth/login', () => {
  it('returns accessToken, refreshToken and a safe user payload for valid credentials', async () => {
    const { app, usersService } = createTestApp();
    const seededUser = await usersService.seedUser({
      email: 'aluno@example.com',
      password: 'Senha123',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'ALUNO@EXAMPLE.COM',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(200);

    const body = response.json();

    expect(body.user).toEqual({
      id: seededUser.id,
      name: seededUser.name,
      email: seededUser.email,
      role: seededUser.role,
      status: seededUser.status,
    });
    expect(typeof body.accessToken).toBe('string');
    expect(typeof body.refreshToken).toBe('string');
    expect(body).not.toHaveProperty('passwordHash');
    expect(body).not.toHaveProperty('refreshTokenHash');
    expect(usersService.lastUpdatedLoginAt?.userId).toBe(seededUser.id);
    expect(usersService.lastUpdatedRefreshTokenHash?.userId).toBe(seededUser.id);
    expect(usersService.lastUpdatedRefreshTokenHash?.refreshTokenHash).toBeDefined();
    expect(usersService.lastUpdatedRefreshTokenHash?.refreshTokenHash).not.toBe(body.refreshToken);
    expect(
      await compare(
        body.refreshToken,
        usersService.lastUpdatedRefreshTokenHash?.refreshTokenHash ?? '',
      ),
    ).toBe(true);

    const accessTokenPayload = app.jwt.verify<AccessTokenPayload>(body.accessToken);
    const refreshTokenPayload = app.jwt.verify<RefreshTokenPayload>(body.refreshToken, {
      key: config.auth.refreshTokenSecret,
    });

    expect(accessTokenPayload).toMatchObject({
      sub: seededUser.id,
      role: 'STUDENT',
      status: 'ACTIVE',
    });
    expect(accessTokenPayload).not.toHaveProperty('email');
    expect(accessTokenPayload).not.toHaveProperty('cpf');
    expect(accessTokenPayload).not.toHaveProperty('phone');
    expect(accessTokenPayload).not.toHaveProperty('passwordHash');
    expect(refreshTokenPayload.sub).toBe(seededUser.id);
    expect(typeof refreshTokenPayload.jti).toBe('string');
    expect(refreshTokenPayload).not.toHaveProperty('email');
    expect(refreshTokenPayload).not.toHaveProperty('cpf');
    expect(refreshTokenPayload).not.toHaveProperty('phone');
    expect(refreshTokenPayload).not.toHaveProperty('passwordHash');
  });

  it('rejects invalid password', async () => {
    const { app, usersService } = createTestApp();
    await usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'aluno@example.com',
        password: 'SenhaErrada123',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid email or password.',
    });
  });

  it('rejects nonexistent email', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'naoexiste@example.com',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid email or password.',
    });
  });

  it('rejects suspended users', async () => {
    const { app, usersService } = createTestApp();
    await usersService.seedUser({
      email: 'suspenso@example.com',
      password: 'Senha123',
      status: PrismaUserStatus.SUSPENDED,
      cpf: '11144477735',
      phone: '11988887777',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'suspenso@example.com',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'This account is suspended.',
    });
  });

  it('rejects banned users', async () => {
    const { app, usersService } = createTestApp();
    await usersService.seedUser({
      email: 'banido@example.com',
      password: 'Senha123',
      status: PrismaUserStatus.BANNED,
      cpf: '98765432100',
      phone: '11977776666',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'banido@example.com',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'This account is banned.',
    });
  });

  it('rejects deleted users', async () => {
    const { app, usersService } = createTestApp();
    await usersService.seedUser({
      email: 'deletado@example.com',
      password: 'Senha123',
      status: PrismaUserStatus.DELETED,
      cpf: '39053344705',
      phone: '11966665555',
      deletedAt: new Date('2026-05-09T00:00:00.000Z'),
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'deletado@example.com',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'This account has been deleted.',
    });
  });

  it('rejects invalid login email format', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'email-invalido',
        password: 'Senha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'email must be a valid email address.',
    });
  });
});

describe('POST /auth/forgot-password', () => {
  it('returns the same generic response for existing and nonexistent emails without exposing sensitive data', async () => {
    const { app, usersService, mailService } = createTestApp();
    const seededUser = await usersService.seedUser({
      email: 'aluno@example.com',
    });

    await app.ready();

    const existingEmailResponse = await app.inject({
      method: 'POST',
      url: '/auth/forgot-password',
      payload: {
        email: 'ALUNO@EXAMPLE.COM',
      },
    });
    const missingEmailResponse = await app.inject({
      method: 'POST',
      url: '/auth/forgot-password',
      payload: {
        email: 'naoexiste@example.com',
      },
    });

    expect(existingEmailResponse.statusCode).toBe(200);
    expect(missingEmailResponse.statusCode).toBe(200);
    expect(existingEmailResponse.json()).toEqual({
      message: 'If the email is registered, recovery instructions will be sent.',
    });
    expect(missingEmailResponse.json()).toEqual(existingEmailResponse.json());
    expect(existingEmailResponse.json()).not.toHaveProperty('token');
    expect(existingEmailResponse.json()).not.toHaveProperty('passwordResetTokenHash');
    expect(mailService.sentPasswordResetEmails).toHaveLength(1);

    const sentEmail = mailService.sentPasswordResetEmails[0];
    const storedUser = usersService.getUserById(seededUser.id);

    expect(sentEmail).toBeDefined();

    if (!sentEmail) {
      throw new Error('Expected a simulated password reset email to be captured.');
    }

    expect(sentEmail.to).toBe(seededUser.email);
    expect(sentEmail.resetUrl).toContain('/reset-password?token=');
    expect(sentEmail.resetUrl.startsWith(`${config.app.mobileAppUrl ?? ''}/reset-password`)).toBe(
      true,
    );
    expect(usersService.lastUpdatedPasswordResetToken?.userId).toBe(seededUser.id);
    expect(usersService.lastUpdatedPasswordResetToken?.passwordResetTokenHash).toBeDefined();
    expect(usersService.lastUpdatedPasswordResetToken?.passwordResetTokenHash).toBe(
      hashPasswordResetToken(sentEmail.token),
    );
    expect(usersService.lastUpdatedPasswordResetToken?.passwordResetTokenHash).not.toBe(
      sentEmail.token,
    );
    expect(storedUser?.passwordResetTokenHash).toBe(hashPasswordResetToken(sentEmail.token));
    expect(storedUser?.passwordResetTokenHash).not.toBe(sentEmail.token);
    expect(storedUser?.passwordResetTokenExpiresAt).toBeInstanceOf(Date);
  });
});

describe('POST /auth/reset-password', () => {
  it('resets the password with a valid token, invalidates the token and revokes the previous refresh token', async () => {
    const { app, usersService, mailService } = createTestApp();
    await usersService.seedUser({
      email: 'aluno@example.com',
      password: 'Senha123',
    });

    await app.ready();

    const loginBeforeResetResponse = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'aluno@example.com',
        password: 'Senha123',
      },
    });
    expect(loginBeforeResetResponse.statusCode).toBe(200);

    const refreshTokenBeforeReset = loginBeforeResetResponse.json().refreshToken;

    await app.inject({
      method: 'POST',
      url: '/auth/forgot-password',
      payload: {
        email: 'aluno@example.com',
      },
    });

    const resetToken = mailService.sentPasswordResetEmails[0]?.token;

    expect(resetToken).toBeDefined();

    if (!resetToken) {
      throw new Error('Expected a simulated password reset token to be captured.');
    }

    const response = await app.inject({
      method: 'POST',
      url: '/auth/reset-password',
      payload: {
        token: resetToken,
        password: 'NovaSenha123',
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({
      message: 'Password reset completed successfully.',
    });
    expect(response.json()).not.toHaveProperty('passwordHash');
    expect(response.json()).not.toHaveProperty('passwordResetTokenHash');

    const refreshedSessionResponse = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken: refreshTokenBeforeReset,
      },
    });
    const oldPasswordLoginResponse = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'aluno@example.com',
        password: 'Senha123',
      },
    });
    const newPasswordLoginResponse = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'ALUNO@EXAMPLE.COM',
        password: 'NovaSenha123',
      },
    });
    const newPasswordLoginBody = newPasswordLoginResponse.json();

    expect(refreshedSessionResponse.statusCode).toBe(401);
    expect(oldPasswordLoginResponse.statusCode).toBe(401);
    expect(newPasswordLoginResponse.statusCode).toBe(200);
    expect(usersService.lastUpdatedPasswordAfterReset?.passwordHash).toBeDefined();
    expect(usersService.lastUpdatedPasswordAfterReset?.passwordHash).not.toBe('NovaSenha123');
    expect(
      await compare('NovaSenha123', usersService.lastUpdatedPasswordAfterReset?.passwordHash ?? ''),
    ).toBe(true);

    const storedUser = usersService.createdUsers.find((user) => user.email === 'aluno@example.com');

    expect(storedUser?.passwordResetTokenHash).toBeNull();
    expect(storedUser?.passwordResetTokenExpiresAt).toBeNull();
    expect(storedUser?.refreshTokenHash).toBeDefined();
    expect(storedUser?.refreshTokenHash).not.toBe(refreshTokenBeforeReset);
    expect(
      await compare(newPasswordLoginBody.refreshToken, storedUser?.refreshTokenHash ?? ''),
    ).toBe(true);
  });

  it('rejects an invalid password reset token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/reset-password',
      payload: {
        token: 'invalid-token',
        password: 'NovaSenha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Invalid or expired password reset token.',
    });
  });

  it('rejects an expired password reset token', async () => {
    const { app, usersService } = createTestApp();
    const expiredToken = 'expired-token';

    await usersService.seedUser({
      email: 'expirado@example.com',
      cpf: '11144477735',
      phone: '11988887777',
      passwordResetTokenHash: hashPasswordResetToken(expiredToken),
      passwordResetTokenExpiresAt: new Date(Date.now() - 60_000),
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/reset-password',
      payload: {
        token: expiredToken,
        password: 'NovaSenha123',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Invalid or expired password reset token.',
    });
  });

  it('rejects a weak new password', async () => {
    const { app, usersService } = createTestApp();
    const validToken = 'valid-token';

    await usersService.seedUser({
      email: 'fraca@example.com',
      cpf: '98765432100',
      phone: '11977776666',
      passwordResetTokenHash: hashPasswordResetToken(validToken),
      passwordResetTokenExpiresAt: new Date(Date.now() + 15 * 60_000),
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/reset-password',
      payload: {
        token: validToken,
        password: 'abcdefghi',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'password must contain at least one letter and one number.',
    });
  });

  it('does not allow password reset token reuse', async () => {
    const { app, usersService, mailService } = createTestApp();
    await usersService.seedUser({
      email: 'reuso@example.com',
      cpf: '39053344705',
      phone: '11966665555',
    });

    await app.ready();

    await app.inject({
      method: 'POST',
      url: '/auth/forgot-password',
      payload: {
        email: 'reuso@example.com',
      },
    });

    const token = mailService.sentPasswordResetEmails[0]?.token;

    expect(token).toBeDefined();

    if (!token) {
      throw new Error('Expected a simulated password reset token to be captured.');
    }

    await app.inject({
      method: 'POST',
      url: '/auth/reset-password',
      payload: {
        token,
        password: 'NovaSenha123',
      },
    });

    const reusedResponse = await app.inject({
      method: 'POST',
      url: '/auth/reset-password',
      payload: {
        token,
        password: 'OutraSenha123',
      },
    });

    expect(reusedResponse.statusCode).toBe(400);
    expect(reusedResponse.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Invalid or expired password reset token.',
    });
  });
});

describe('POST /auth/refresh', () => {
  it('returns a new accessToken and a rotated refreshToken for a valid refresh token', async () => {
    const { app, usersService } = createTestApp();
    await usersService.seedUser();

    await app.ready();

    const loginResponse = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'aluno@example.com',
        password: 'Senha123',
      },
    });

    const loginBody = loginResponse.json();

    const refreshResponse = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken: loginBody.refreshToken,
      },
    });

    expect(refreshResponse.statusCode).toBe(200);

    const refreshBody = refreshResponse.json();

    expect(typeof refreshBody.accessToken).toBe('string');
    expect(typeof refreshBody.refreshToken).toBe('string');
    expect(refreshBody).not.toHaveProperty('passwordHash');
    expect(refreshBody).not.toHaveProperty('refreshTokenHash');
    expect(refreshBody.refreshToken).not.toBe(loginBody.refreshToken);
    expect(usersService.lastUpdatedRefreshTokenHash?.refreshTokenHash).toBeDefined();
    expect(
      await compare(
        refreshBody.refreshToken,
        usersService.lastUpdatedRefreshTokenHash?.refreshTokenHash ?? '',
      ),
    ).toBe(true);

    const accessTokenPayload = app.jwt.verify<AccessTokenPayload>(refreshBody.accessToken);
    const refreshTokenPayload = app.jwt.verify<RefreshTokenPayload>(refreshBody.refreshToken, {
      key: config.auth.refreshTokenSecret,
    });

    expect(accessTokenPayload.sub).toBe('user_1');
    expect(refreshTokenPayload.sub).toBe('user_1');
    expect(typeof refreshTokenPayload.jti).toBe('string');
  });

  it('rejects refresh token reuse after rotation', async () => {
    const { app, usersService } = createTestApp();
    await usersService.seedUser();

    await app.ready();

    const loginResponse = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'aluno@example.com',
        password: 'Senha123',
      },
    });
    const loginBody = loginResponse.json();

    const firstRefreshResponse = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken: loginBody.refreshToken,
      },
    });

    expect(firstRefreshResponse.statusCode).toBe(200);

    const reusedResponse = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken: loginBody.refreshToken,
      },
    });

    expect(reusedResponse.statusCode).toBe(401);
    expect(reusedResponse.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or expired refresh token.',
    });
  });

  it('rejects an invalid refresh token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken: 'invalid-token',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or expired refresh token.',
    });
  });

  it('rejects a refresh token for a nonexistent user', async () => {
    const { app } = createTestApp();

    await app.ready();

    const refreshToken = signRefreshToken(app, 'missing-user');
    const response = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken,
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or expired refresh token.',
    });
  });

  it('rejects suspended users during refresh', async () => {
    const { app, usersService } = createTestApp();
    const user = await usersService.seedUser({
      email: 'suspenso@example.com',
      status: PrismaUserStatus.SUSPENDED,
      cpf: '11144477735',
      phone: '11988887777',
    });

    await app.ready();

    const refreshToken = await persistRefreshToken(app, usersService, user.id);
    const response = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'This account is suspended.',
    });
  });

  it('rejects banned users during refresh', async () => {
    const { app, usersService } = createTestApp();
    const user = await usersService.seedUser({
      email: 'banido@example.com',
      status: PrismaUserStatus.BANNED,
      cpf: '98765432100',
      phone: '11977776666',
    });

    await app.ready();

    const refreshToken = await persistRefreshToken(app, usersService, user.id);
    const response = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'This account is banned.',
    });
  });

  it('rejects deleted users during refresh', async () => {
    const { app, usersService } = createTestApp();
    const user = await usersService.seedUser({
      email: 'deletado@example.com',
      status: PrismaUserStatus.DELETED,
      cpf: '39053344705',
      phone: '11966665555',
      deletedAt: new Date('2026-05-09T00:00:00.000Z'),
    });

    await app.ready();

    const refreshToken = await persistRefreshToken(app, usersService, user.id);
    const response = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'This account has been deleted.',
    });
  });
});

describe('POST /auth/logout', () => {
  it('invalidates the stored refresh token on logout', async () => {
    const { app, usersService } = createTestApp();
    const user = await usersService.seedUser();

    await app.ready();

    const loginResponse = await app.inject({
      method: 'POST',
      url: '/auth/login',
      payload: {
        email: 'aluno@example.com',
        password: 'Senha123',
      },
    });
    const loginBody = loginResponse.json();

    const logoutResponse = await app.inject({
      method: 'POST',
      url: '/auth/logout',
      headers: {
        authorization: `Bearer ${signAccessToken(app, user)}`,
      },
    });

    expect(logoutResponse.statusCode).toBe(200);
    expect(logoutResponse.json()).toEqual({
      message: 'Logout completed successfully.',
    });
    expect(usersService.getUserById(user.id)?.refreshTokenHash).toBeNull();

    const refreshResponse = await app.inject({
      method: 'POST',
      url: '/auth/refresh',
      payload: {
        refreshToken: loginBody.refreshToken,
      },
    });

    expect(refreshResponse.statusCode).toBe(401);
    expect(refreshResponse.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or expired refresh token.',
    });
  });
});

describe('GET /auth/me', () => {
  it('returns the authenticated user with a valid token', async () => {
    const { app, usersService } = createTestApp();
    const seededUser = await usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/me',
      headers: {
        authorization: `Bearer ${signAccessToken(app, seededUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({
      id: seededUser.id,
      name: seededUser.name,
      email: seededUser.email,
      role: seededUser.role,
      status: seededUser.status,
    });
  });

  it('rejects requests without a token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/me',
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('rejects requests with an invalid token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/me',
      headers: {
        authorization: 'Bearer invalid-token',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('rejects requests for a nonexistent authenticated user', async () => {
    const { app } = createTestApp();

    await app.ready();

    const accessToken = app.jwt.sign({
      sub: 'missing-user',
      role: PrismaUserRole.STUDENT,
      status: PrismaUserStatus.ACTIVE,
    });

    const response = await app.inject({
      method: 'GET',
      url: '/auth/me',
      headers: {
        authorization: `Bearer ${accessToken}`,
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid access token.',
    });
  });
});

describe('GET /auth/admin-check', () => {
  it('allows ADMIN users to access the admin route', async () => {
    const { app, usersService } = createTestApp();
    const seededUser = await usersService.seedUser({
      email: 'admin@example.com',
      role: PrismaUserRole.ADMIN,
      cpf: '98765432100',
      phone: '11988887777',
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/admin-check',
      headers: {
        authorization: `Bearer ${signAccessToken(app, seededUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({
      status: 'ok',
      message: 'Admin access granted.',
      user: {
        id: seededUser.id,
        role: seededUser.role,
        status: seededUser.status,
      },
    });
  });

  it('blocks STUDENT users from the admin route', async () => {
    const { app, usersService } = createTestApp();
    const seededUser = await usersService.seedUser();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/admin-check',
      headers: {
        authorization: `Bearer ${signAccessToken(app, seededUser)}`,
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks requests without a token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/admin-check',
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks requests with an invalid token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/auth/admin-check',
      headers: {
        authorization: 'Bearer invalid-token',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks a token that references a nonexistent user', async () => {
    const { app } = createTestApp();

    await app.ready();

    const accessToken = app.jwt.sign({
      sub: 'missing-admin',
      role: PrismaUserRole.ADMIN,
      status: PrismaUserStatus.ACTIVE,
    });

    const response = await app.inject({
      method: 'GET',
      url: '/auth/admin-check',
      headers: {
        authorization: `Bearer ${accessToken}`,
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid access token.',
    });
  });
});
