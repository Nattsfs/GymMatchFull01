import type { FastifyRequest } from 'fastify';

import { HttpError } from '../common/errors/http-error.js';
import type { AuthenticatedUserResponse } from './auth.types.js';

export type CurrentUserContext = Pick<AuthenticatedUserResponse, 'id' | 'role' | 'status'>;

export function getCurrentUser(request: FastifyRequest): AuthenticatedUserResponse {
  if (!request.currentUser) {
    throw new HttpError(401, 'Invalid or missing access token.');
  }

  return request.currentUser;
}

export function getCurrentUserContext(request: FastifyRequest): CurrentUserContext {
  const currentUser = getCurrentUser(request);

  return {
    id: currentUser.id,
    role: currentUser.role,
    status: currentUser.status,
  };
}
