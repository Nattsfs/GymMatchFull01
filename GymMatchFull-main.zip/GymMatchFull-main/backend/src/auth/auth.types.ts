import type { UserRole, UserStatus } from '@prisma/client';

import type { PublicGymQrSummary, PublicGymUnitQrSummary } from '../gyms/gyms.types.js';
import type { CreateUserInput, SafeUser, UserRecord } from '../users/users.types.js';

export interface RegisterInput {
  name: string;
  email: string;
  cpf: string;
  phone: string;
  password: string;
  qrCodeToken?: string;
  role?: UserRole;
}

export interface RegisteredUserResponse {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  gym: PublicGymQrSummary;
  unit: PublicGymUnitQrSummary;
  createdAt: Date;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface ForgotPasswordInput {
  email: string;
}

export interface ForgotPasswordResponse {
  message: string;
}

export interface ResetPasswordInput {
  token: string;
  password: string;
}

export interface ResetPasswordResponse {
  message: string;
}

export interface AuthenticatedUserResponse {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  user: AuthenticatedUserResponse;
}

export interface AccessTokenPayload {
  sub: string;
  role: UserRole;
  status: UserStatus;
}

export interface RefreshTokenPayload {
  sub: string;
  jti: string;
}

export interface RefreshInput {
  refreshToken: string;
}

export interface RefreshResponse {
  accessToken: string;
  refreshToken: string;
}

export interface LogoutResponse {
  message: string;
}

export interface AuthUsersServiceContract {
  createUser(input: CreateUserInput): Promise<SafeUser>;
  findUserById(id: string): Promise<SafeUser | null>;
  findUserByEmail(email: string): Promise<SafeUser | null>;
  findUserByIdWithRefreshToken(id: string): Promise<UserRecord | null>;
  findUserByEmailWithPassword(email: string): Promise<UserRecord | null>;
  findUserByPasswordResetTokenHash(passwordResetTokenHash: string): Promise<UserRecord | null>;
  updateLastLoginAt(id: string, lastLoginAt: Date): Promise<void>;
  updateRefreshTokenHash(id: string, refreshTokenHash: string | null): Promise<void>;
  updatePasswordResetToken(
    id: string,
    passwordResetTokenHash: string | null,
    passwordResetTokenExpiresAt: Date | null,
  ): Promise<void>;
  updatePasswordAfterReset(id: string, passwordHash: string): Promise<void>;
}

export interface AuthServiceContract {
  register(input: RegisterInput): Promise<RegisteredUserResponse>;
  login(input: LoginInput): Promise<LoginResponse>;
  forgotPassword(input: ForgotPasswordInput): Promise<ForgotPasswordResponse>;
  resetPassword(input: ResetPasswordInput): Promise<ResetPasswordResponse>;
  refresh(input: RefreshInput): Promise<RefreshResponse>;
  logout(userId: string): Promise<LogoutResponse>;
  getCurrentUser(userId: string): Promise<AuthenticatedUserResponse>;
}
