import { HttpError } from '../../common/errors/http-error.js';
import { isValidEmail, normalizeEmail } from '../../common/validators/email.validator.js';
import type { LoginInput } from '../auth.types.js';

interface LoginRequestBody {
  email?: unknown;
  password?: unknown;
}

export function parseLoginInput(payload: unknown): LoginInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as LoginRequestBody;
  const email = parseEmail(body.email);
  const password = parsePassword(body.password);

  return {
    email,
    password,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseEmail(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'email is required and must be a string.');
  }

  const normalizedEmail = normalizeEmail(value);

  if (!isValidEmail(normalizedEmail)) {
    throw new HttpError(400, 'email must be a valid email address.');
  }

  return normalizedEmail;
}

function parsePassword(value: unknown): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new HttpError(400, 'password is required and must be a non-empty string.');
  }

  return value;
}
