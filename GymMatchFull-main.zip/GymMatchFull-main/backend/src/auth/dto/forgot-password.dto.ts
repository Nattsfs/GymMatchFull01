import { HttpError } from '../../common/errors/http-error.js';
import { isValidEmail, normalizeEmail } from '../../common/validators/email.validator.js';
import type { ForgotPasswordInput } from '../auth.types.js';

interface ForgotPasswordRequestBody {
  email?: unknown;
}

export function parseForgotPasswordInput(payload: unknown): ForgotPasswordInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as ForgotPasswordRequestBody;
  const email = parseEmail(body.email);

  return {
    email,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseEmail(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'email is required and must be a string.');
  }

  const normalizedEmail = normalizeEmail(value);

  if (!isValidEmail(normalizedEmail)) {
    throw new HttpError(400, 'email must be a valid email address.');
  }

  return normalizedEmail;
}
