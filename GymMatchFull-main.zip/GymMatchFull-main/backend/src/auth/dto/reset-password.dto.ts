import { HttpError } from '../../common/errors/http-error.js';
import type { ResetPasswordInput } from '../auth.types.js';
import { parseStrongPassword } from '../password-policy.js';

interface ResetPasswordRequestBody {
  token?: unknown;
  password?: unknown;
}

export function parseResetPasswordInput(payload: unknown): ResetPasswordInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as ResetPasswordRequestBody;
  const token = parseToken(body.token);
  const password = parseStrongPassword(body.password);

  return {
    token,
    password,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseToken(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'token is required and must be a string.');
  }

  const normalizedToken = value.trim();

  if (normalizedToken.length === 0) {
    throw new HttpError(400, 'token is required and must be a non-empty string.');
  }

  return normalizedToken;
}
