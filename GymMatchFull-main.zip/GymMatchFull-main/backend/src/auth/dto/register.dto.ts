import { UserRole as PrismaUserRole, type UserRole } from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import { isValidCpf, normalizeCpf } from '../../common/validators/cpf.validator.js';
import { isValidEmail, normalizeEmail } from '../../common/validators/email.validator.js';
import { isValidPhone, normalizePhone } from '../../common/validators/phone.validator.js';
import type { RegisterInput } from '../auth.types.js';
import { parseStrongPassword } from '../password-policy.js';

interface RegisterRequestBody {
  name?: unknown;
  email?: unknown;
  cpf?: unknown;
  phone?: unknown;
  password?: unknown;
  qrCodeToken?: unknown;
  role?: unknown;
}

export function parseRegisterInput(payload: unknown): RegisterInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as RegisterRequestBody;
  const name = parseName(body.name);
  const email = parseEmail(body.email);
  const cpf = parseCpf(body.cpf);
  const phone = parsePhone(body.phone);
  const password = parsePassword(body.password);
  const role = parseRole(body.role);
  const qrCodeToken = parseQrCodeToken(body.qrCodeToken);

  return {
    name,
    email,
    cpf,
    phone,
    password,
    ...(qrCodeToken !== undefined ? { qrCodeToken } : {}),
    ...(role !== undefined ? { role } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseName(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'name is required and must be a string.');
  }

  const normalizedName = value.trim();

  if (normalizedName.length < 3) {
    throw new HttpError(400, 'name must be at least 3 characters long.');
  }

  return normalizedName;
}

function parseEmail(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'email is required and must be a string.');
  }

  const normalizedEmail = normalizeEmail(value);

  if (!isValidEmail(normalizedEmail)) {
    throw new HttpError(400, 'email must be a valid email address.');
  }

  return normalizedEmail;
}

function parseCpf(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'cpf is required and must be a string.');
  }

  const normalizedCpf = normalizeCpf(value);

  if (!isValidCpf(normalizedCpf)) {
    throw new HttpError(400, 'cpf must be a valid CPF.');
  }

  return normalizedCpf;
}

function parsePhone(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'phone is required and must be a string.');
  }

  const normalizedPhone = normalizePhone(value);

  if (!isValidPhone(normalizedPhone)) {
    throw new HttpError(400, 'phone must be a valid phone number.');
  }

  return normalizedPhone;
}

function parsePassword(value: unknown): string {
  return parseStrongPassword(value);
}

function parseQrCodeToken(value: unknown): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'qrCodeToken must be a string when provided.');
  }

  const normalizedToken = value.trim();

  if (normalizedToken.length === 0) {
    throw new HttpError(400, 'qrCodeToken must not be empty when provided.');
  }

  return normalizedToken;
}

function parseRole(value: unknown): UserRole | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'role must be a string when provided.');
  }

  const normalizedRole = value.trim().toUpperCase();

  if (normalizedRole === PrismaUserRole.STUDENT || normalizedRole === PrismaUserRole.ADMIN) {
    return normalizedRole;
  }

  throw new HttpError(400, 'role must be either STUDENT or ADMIN when provided.');
}
