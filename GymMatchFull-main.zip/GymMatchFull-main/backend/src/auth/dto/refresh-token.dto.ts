import { HttpError } from '../../common/errors/http-error.js';
import type { RefreshInput } from '../auth.types.js';

interface RefreshTokenRequestBody {
  refreshToken?: unknown;
}

export function parseRefreshInput(payload: unknown): RefreshInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as RefreshTokenRequestBody;

  if (typeof body.refreshToken !== 'string' || body.refreshToken.trim().length === 0) {
    throw new HttpError(400, 'refreshToken is required and must be a non-empty string.');
  }

  return {
    refreshToken: body.refreshToken.trim(),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
