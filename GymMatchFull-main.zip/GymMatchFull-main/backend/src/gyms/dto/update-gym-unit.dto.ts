import { HttpError } from '../../common/errors/http-error.js';
import type { UpdateGymUnitInput } from '../gyms.types.js';

interface UpdateGymUnitRequestBody {
  name?: unknown;
  addressLine?: unknown;
  number?: unknown;
  complement?: unknown;
  neighborhood?: unknown;
  city?: unknown;
  state?: unknown;
  zipCode?: unknown;
  latitude?: unknown;
  longitude?: unknown;
}

const forbiddenFields = new Set(['id', 'gymId', 'createdAt', 'updatedAt', 'deletedAt', 'status']);

export function parseUpdateGymUnitInput(payload: unknown): UpdateGymUnitInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as UpdateGymUnitRequestBody & Record<string, unknown>;

  for (const key of Object.keys(body)) {
    if (forbiddenFields.has(key)) {
      throw new HttpError(400, `${key} cannot be updated.`);
    }
  }

  const updateInput: UpdateGymUnitInput = {};

  if ('name' in body) {
    updateInput.name = parseName(body.name);
  }

  if ('addressLine' in body) {
    updateInput.addressLine = parseOptionalNullableString(body.addressLine, 'addressLine');
  }

  if ('number' in body) {
    updateInput.number = parseOptionalNullableString(body.number, 'number');
  }

  if ('complement' in body) {
    updateInput.complement = parseOptionalNullableString(body.complement, 'complement');
  }

  if ('neighborhood' in body) {
    updateInput.neighborhood = parseOptionalNullableString(body.neighborhood, 'neighborhood');
  }

  if ('city' in body) {
    updateInput.city = parseOptionalNullableString(body.city, 'city');
  }

  if ('state' in body) {
    updateInput.state = parseOptionalNullableState(body.state);
  }

  if ('zipCode' in body) {
    updateInput.zipCode = parseOptionalNullableZipCode(body.zipCode);
  }

  if ('latitude' in body) {
    updateInput.latitude = parseOptionalNullableCoordinate(body.latitude, 'latitude', -90, 90);
  }

  if ('longitude' in body) {
    updateInput.longitude = parseOptionalNullableCoordinate(body.longitude, 'longitude', -180, 180);
  }

  if (Object.keys(updateInput).length === 0) {
    throw new HttpError(400, 'At least one updatable field must be provided.');
  }

  return updateInput;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseName(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'name must be a string when provided.');
  }

  const normalizedName = value.trim();

  if (normalizedName.length < 3) {
    throw new HttpError(400, 'name must be at least 3 characters long.');
  }

  return normalizedName;
}

function parseOptionalNullableString(value: unknown, field: string): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string or null when provided.`);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : null;
}

function parseOptionalNullableState(value: unknown): string | null {
  const normalizedState = parseOptionalNullableString(value, 'state');

  if (normalizedState === null) {
    return null;
  }

  const upperCasedState = normalizedState.toUpperCase();

  if (!/^[A-Z]{2}$/.test(upperCasedState)) {
    throw new HttpError(400, 'state must be a 2-letter code when provided.');
  }

  return upperCasedState;
}

function parseOptionalNullableZipCode(value: unknown): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'zipCode must be a string or null when provided.');
  }

  const normalizedZipCode = value.replace(/\D/g, '');

  if (normalizedZipCode.length === 0) {
    return null;
  }

  if (normalizedZipCode.length !== 8) {
    throw new HttpError(400, 'zipCode must contain 8 digits when provided.');
  }

  return normalizedZipCode;
}

function parseOptionalNullableCoordinate(
  value: unknown,
  field: 'latitude' | 'longitude',
  min: number,
  max: number,
): number | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new HttpError(400, `${field} must be a finite number or null when provided.`);
  }

  if (value < min || value > max) {
    throw new HttpError(400, `${field} must be between ${min} and ${max}.`);
  }

  return value;
}
