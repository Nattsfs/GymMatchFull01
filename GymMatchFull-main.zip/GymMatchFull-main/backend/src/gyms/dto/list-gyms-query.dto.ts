import { GymStatus as PrismaGymStatus } from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import type { ListGymsQueryInput } from '../gyms.types.js';

interface ListGymsQuery {
  page?: unknown;
  limit?: unknown;
  search?: unknown;
  status?: unknown;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 50;

export function parseListGymsQuery(payload: unknown): ListGymsQueryInput {
  if (!isObject(payload)) {
    return {
      page: DEFAULT_PAGE,
      limit: DEFAULT_LIMIT,
    };
  }

  const query = payload as ListGymsQuery;
  const page = parsePositiveInteger(query.page, 'page', DEFAULT_PAGE);
  const limit = parsePositiveInteger(query.limit, 'limit', DEFAULT_LIMIT, MAX_LIMIT);
  const search = parseOptionalSearch(query.search);
  const status = parseOptionalStatus(query.status);

  return {
    page,
    limit,
    ...(search !== undefined ? { search } : {}),
    ...(status !== undefined ? { status } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parsePositiveInteger(
  value: unknown,
  field: string,
  fallback: number,
  max?: number,
): number {
  if (value === undefined) {
    return fallback;
  }

  const stringValue = typeof value === 'number' ? String(value) : value;

  if (typeof stringValue !== 'string') {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const normalizedValue = stringValue.trim();

  if (!/^[1-9]\d*$/.test(normalizedValue)) {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    throw new HttpError(400, `${field} must be less than or equal to ${max}.`);
  }

  return parsedValue;
}

function parseOptionalSearch(value: unknown): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'search must be a string when provided.');
  }

  const normalizedSearch = value.trim();

  return normalizedSearch.length > 0 ? normalizedSearch : undefined;
}

function parseOptionalStatus(value: unknown): PrismaGymStatus | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'status must be a string when provided.');
  }

  const normalizedStatus = value.trim().toUpperCase();

  if (
    normalizedStatus === PrismaGymStatus.ACTIVE ||
    normalizedStatus === PrismaGymStatus.INACTIVE ||
    normalizedStatus === PrismaGymStatus.DELETED
  ) {
    return normalizedStatus;
  }

  throw new HttpError(400, 'status must be one of: ACTIVE, INACTIVE, DELETED.');
}
