import { HttpError } from '../../common/errors/http-error.js';
import { isValidEmail, normalizeEmail } from '../../common/validators/email.validator.js';
import { isValidPhone, normalizePhone } from '../../common/validators/phone.validator.js';
import type { CreateGymInput } from '../gyms.types.js';

interface CreateGymRequestBody {
  name?: unknown;
  legalName?: unknown;
  document?: unknown;
  email?: unknown;
  phone?: unknown;
}

export function parseCreateGymInput(payload: unknown): CreateGymInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as CreateGymRequestBody;
  const name = parseName(body.name);
  const legalName = parseOptionalString(body.legalName, 'legalName');
  const document = parseOptionalString(body.document, 'document');
  const email = parseOptionalEmail(body.email);
  const phone = parseOptionalPhone(body.phone);

  return {
    name,
    ...(legalName !== undefined ? { legalName } : {}),
    ...(document !== undefined ? { document } : {}),
    ...(email !== undefined ? { email } : {}),
    ...(phone !== undefined ? { phone } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseName(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'name is required and must be a string.');
  }

  const normalizedName = value.trim();

  if (normalizedName.length < 3) {
    throw new HttpError(400, 'name must be at least 3 characters long.');
  }

  return normalizedName;
}

function parseOptionalString(value: unknown, field: string): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string when provided.`);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : undefined;
}

function parseOptionalEmail(value: unknown): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'email must be a string when provided.');
  }

  const normalizedEmail = normalizeEmail(value);

  if (!isValidEmail(normalizedEmail)) {
    throw new HttpError(400, 'email must be a valid email address.');
  }

  return normalizedEmail;
}

function parseOptionalPhone(value: unknown): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'phone must be a string when provided.');
  }

  const normalizedPhone = normalizePhone(value);

  if (!isValidPhone(normalizedPhone)) {
    throw new HttpError(400, 'phone must be a valid phone number.');
  }

  return normalizedPhone;
}
