import { HttpError } from '../../common/errors/http-error.js';
import type { CreateGymUnitInput } from '../gyms.types.js';

interface CreateGymUnitRequestBody {
  gymId?: unknown;
  name?: unknown;
  addressLine?: unknown;
  number?: unknown;
  complement?: unknown;
  neighborhood?: unknown;
  city?: unknown;
  state?: unknown;
  zipCode?: unknown;
  latitude?: unknown;
  longitude?: unknown;
}

export function parseCreateGymUnitInput(payload: unknown): CreateGymUnitInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as CreateGymUnitRequestBody;
  const gymId = parseRequiredString(body.gymId, 'gymId');
  const name = parseName(body.name);
  const addressLine = parseOptionalString(body.addressLine, 'addressLine');
  const number = parseOptionalString(body.number, 'number');
  const complement = parseOptionalString(body.complement, 'complement');
  const neighborhood = parseOptionalString(body.neighborhood, 'neighborhood');
  const city = parseOptionalString(body.city, 'city');
  const state = parseOptionalState(body.state);
  const zipCode = parseOptionalZipCode(body.zipCode);
  const latitude = parseOptionalCoordinate(body.latitude, 'latitude', -90, 90);
  const longitude = parseOptionalCoordinate(body.longitude, 'longitude', -180, 180);

  return {
    gymId,
    name,
    ...(addressLine !== undefined ? { addressLine } : {}),
    ...(number !== undefined ? { number } : {}),
    ...(complement !== undefined ? { complement } : {}),
    ...(neighborhood !== undefined ? { neighborhood } : {}),
    ...(city !== undefined ? { city } : {}),
    ...(state !== undefined ? { state } : {}),
    ...(zipCode !== undefined ? { zipCode } : {}),
    ...(latitude !== undefined ? { latitude } : {}),
    ...(longitude !== undefined ? { longitude } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseRequiredString(value: unknown, field: string): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} is required and must be a string.`);
  }

  const normalizedValue = value.trim();

  if (normalizedValue.length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return normalizedValue;
}

function parseName(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'name is required and must be a string.');
  }

  const normalizedName = value.trim();

  if (normalizedName.length < 3) {
    throw new HttpError(400, 'name must be at least 3 characters long.');
  }

  return normalizedName;
}

function parseOptionalString(value: unknown, field: string): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string when provided.`);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : undefined;
}

function parseOptionalState(value: unknown): string | undefined {
  const normalizedState = parseOptionalString(value, 'state');

  if (normalizedState === undefined) {
    return undefined;
  }

  const upperCasedState = normalizedState.toUpperCase();

  if (!/^[A-Z]{2}$/.test(upperCasedState)) {
    throw new HttpError(400, 'state must be a 2-letter code when provided.');
  }

  return upperCasedState;
}

function parseOptionalZipCode(value: unknown): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'zipCode must be a string when provided.');
  }

  const normalizedZipCode = value.replace(/\D/g, '');

  if (normalizedZipCode.length === 0) {
    return undefined;
  }

  if (normalizedZipCode.length !== 8) {
    throw new HttpError(400, 'zipCode must contain 8 digits when provided.');
  }

  return normalizedZipCode;
}

function parseOptionalCoordinate(
  value: unknown,
  field: 'latitude' | 'longitude',
  min: number,
  max: number,
): number | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new HttpError(400, `${field} must be a finite number when provided.`);
  }

  if (value < min || value > max) {
    throw new HttpError(400, `${field} must be between ${min} and ${max}.`);
  }

  return value;
}
