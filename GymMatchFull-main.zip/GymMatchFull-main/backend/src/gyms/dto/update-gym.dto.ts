import { HttpError } from '../../common/errors/http-error.js';
import { isValidEmail, normalizeEmail } from '../../common/validators/email.validator.js';
import { isValidPhone, normalizePhone } from '../../common/validators/phone.validator.js';
import type { UpdateGymInput } from '../gyms.types.js';

interface UpdateGymRequestBody {
  name?: unknown;
  legalName?: unknown;
  document?: unknown;
  email?: unknown;
  phone?: unknown;
}

const forbiddenFields = new Set(['id', 'createdAt', 'updatedAt', 'deletedAt', 'status']);

export function parseUpdateGymInput(payload: unknown): UpdateGymInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as UpdateGymRequestBody & Record<string, unknown>;

  for (const key of Object.keys(body)) {
    if (forbiddenFields.has(key)) {
      throw new HttpError(400, `${key} cannot be updated.`);
    }
  }

  const updateInput: UpdateGymInput = {};

  if ('name' in body) {
    updateInput.name = parseName(body.name);
  }

  if ('legalName' in body) {
    updateInput.legalName = parseOptionalNullableString(body.legalName, 'legalName');
  }

  if ('document' in body) {
    updateInput.document = parseOptionalNullableString(body.document, 'document');
  }

  if ('email' in body) {
    updateInput.email = parseOptionalNullableEmail(body.email);
  }

  if ('phone' in body) {
    updateInput.phone = parseOptionalNullablePhone(body.phone);
  }

  if (Object.keys(updateInput).length === 0) {
    throw new HttpError(400, 'At least one updatable field must be provided.');
  }

  return updateInput;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseName(value: unknown): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, 'name must be a string when provided.');
  }

  const normalizedName = value.trim();

  if (normalizedName.length < 3) {
    throw new HttpError(400, 'name must be at least 3 characters long.');
  }

  return normalizedName;
}

function parseOptionalNullableString(value: unknown, field: string): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string or null when provided.`);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : null;
}

function parseOptionalNullableEmail(value: unknown): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'email must be a string or null when provided.');
  }

  const normalizedEmail = normalizeEmail(value);

  if (!isValidEmail(normalizedEmail)) {
    throw new HttpError(400, 'email must be a valid email address.');
  }

  return normalizedEmail;
}

function parseOptionalNullablePhone(value: unknown): string | null {
  if (value === null) {
    return null;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'phone must be a string or null when provided.');
  }

  const normalizedPhone = normalizePhone(value);

  if (!isValidPhone(normalizedPhone)) {
    throw new HttpError(400, 'phone must be a valid phone number.');
  }

  return normalizedPhone;
}
