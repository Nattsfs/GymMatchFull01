import { GymUnitStatus as PrismaGymUnitStatus } from '@prisma/client';

import { HttpError } from '../../common/errors/http-error.js';
import type { ListGymUnitsQueryInput } from '../gyms.types.js';

interface ListGymUnitsQuery {
  page?: unknown;
  limit?: unknown;
  search?: unknown;
  status?: unknown;
  gymId?: unknown;
  city?: unknown;
  state?: unknown;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 50;

export function parseListGymUnitsQuery(payload: unknown): ListGymUnitsQueryInput {
  if (!isObject(payload)) {
    return {
      page: DEFAULT_PAGE,
      limit: DEFAULT_LIMIT,
    };
  }

  const query = payload as ListGymUnitsQuery;
  const page = parsePositiveInteger(query.page, 'page', DEFAULT_PAGE);
  const limit = parsePositiveInteger(query.limit, 'limit', DEFAULT_LIMIT, MAX_LIMIT);
  const search = parseOptionalSearch(query.search, 'search');
  const status = parseOptionalStatus(query.status);
  const gymId = parseOptionalSearch(query.gymId, 'gymId');
  const city = parseOptionalSearch(query.city, 'city');
  const state = parseOptionalState(query.state);

  return {
    page,
    limit,
    ...(search !== undefined ? { search } : {}),
    ...(status !== undefined ? { status } : {}),
    ...(gymId !== undefined ? { gymId } : {}),
    ...(city !== undefined ? { city } : {}),
    ...(state !== undefined ? { state } : {}),
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parsePositiveInteger(
  value: unknown,
  field: string,
  fallback: number,
  max?: number,
): number {
  if (value === undefined) {
    return fallback;
  }

  const stringValue = typeof value === 'number' ? String(value) : value;

  if (typeof stringValue !== 'string') {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const normalizedValue = stringValue.trim();

  if (!/^[1-9]\d*$/.test(normalizedValue)) {
    throw new HttpError(400, `${field} must be a positive integer when provided.`);
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    throw new HttpError(400, `${field} must be less than or equal to ${max}.`);
  }

  return parsedValue;
}

function parseOptionalSearch(value: unknown, field: string): string | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} must be a string when provided.`);
  }

  const normalizedValue = value.trim();

  return normalizedValue.length > 0 ? normalizedValue : undefined;
}

function parseOptionalStatus(value: unknown): PrismaGymUnitStatus | undefined {
  if (value === undefined) {
    return undefined;
  }

  if (typeof value !== 'string') {
    throw new HttpError(400, 'status must be a string when provided.');
  }

  const normalizedStatus = value.trim().toUpperCase();

  if (
    normalizedStatus === PrismaGymUnitStatus.ACTIVE ||
    normalizedStatus === PrismaGymUnitStatus.INACTIVE ||
    normalizedStatus === PrismaGymUnitStatus.DELETED
  ) {
    return normalizedStatus;
  }

  throw new HttpError(400, 'status must be one of: ACTIVE, INACTIVE, DELETED.');
}

function parseOptionalState(value: unknown): string | undefined {
  const normalizedState = parseOptionalSearch(value, 'state');

  if (normalizedState === undefined) {
    return undefined;
  }

  const upperCasedState = normalizedState.toUpperCase();

  if (!/^[A-Z]{2}$/.test(upperCasedState)) {
    throw new HttpError(400, 'state must be a 2-letter code when provided.');
  }

  return upperCasedState;
}
