import type { Gym, GymStatus, GymUnit, GymUnitStatus } from '@prisma/client';

export interface CreateGymInput {
  name: string;
  legalName?: string;
  document?: string;
  email?: string;
  phone?: string;
  status?: GymStatus;
  deletedAt?: Date;
}

export interface UpdateGymInput {
  name?: string;
  legalName?: string | null;
  document?: string | null;
  email?: string | null;
  phone?: string | null;
}

export interface CreateGymUnitInput {
  gymId: string;
  qrCodeToken?: string;
  name: string;
  addressLine?: string;
  number?: string;
  complement?: string;
  neighborhood?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  latitude?: number;
  longitude?: number;
  status?: GymUnitStatus;
  deletedAt?: Date;
}

export interface UpdateGymUnitInput {
  name?: string;
  addressLine?: string | null;
  number?: string | null;
  complement?: string | null;
  neighborhood?: string | null;
  city?: string | null;
  state?: string | null;
  zipCode?: string | null;
  latitude?: number | null;
  longitude?: number | null;
}

export type GymRecord = Gym;
export type GymUnitRecord = GymUnit;
export type GymSummaryRecord = Pick<GymRecord, 'id' | 'name' | 'status'>;
export type GymUnitWithGymSummaryRecord = GymUnitRecord & {
  gym: GymSummaryRecord;
};
export type SafeGym = GymRecord;
export interface SafeGymSummary {
  id: string;
  name: string;
  status: GymStatus;
}
export type SafeGymUnit = Omit<GymUnitRecord, 'latitude' | 'longitude'> & {
  latitude: number | null;
  longitude: number | null;
};
export type SafeAdminGymUnitDetail = SafeGymUnit & {
  gym: SafeGymSummary;
};
export type SafeAdminGymUnitListItem = Omit<SafeAdminGymUnitDetail, 'qrCodeToken'>;

export interface PublicGymQrSummary {
  id: string;
  name: string;
}

export interface PublicGymUnitQrSummary {
  id: string;
  name: string;
  city: string | null;
  state: string | null;
}

export interface PublicGymUnitQrValidationSuccess {
  valid: true;
  gym: PublicGymQrSummary;
  unit: PublicGymUnitQrSummary;
}

export interface PublicGymUnitQrValidationFailure {
  valid: false;
  message: string;
}

export type PublicGymUnitQrValidationResponse =
  | PublicGymUnitQrValidationSuccess
  | PublicGymUnitQrValidationFailure;

export interface ListGymsQueryInput {
  page: number;
  limit: number;
  search?: string;
  status?: GymStatus;
}

export interface PaginationResult {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface ListGymsResult {
  data: SafeGym[];
  pagination: PaginationResult;
}

export interface ListGymUnitsQueryInput {
  page: number;
  limit: number;
  search?: string;
  status?: GymUnitStatus;
  gymId?: string;
  city?: string;
  state?: string;
}

export interface ListGymUnitsResult {
  data: SafeAdminGymUnitListItem[];
  pagination: PaginationResult;
}

export interface GymsServiceContract {
  createGym(input: CreateGymInput): Promise<SafeGym>;
  findGymById(id: string): Promise<SafeGym | null>;
  getGymById(id: string): Promise<SafeGym>;
  listGyms(input: ListGymsQueryInput): Promise<ListGymsResult>;
  updateGym(id: string, input: UpdateGymInput): Promise<SafeGym>;
  createGymUnit(input: CreateGymUnitInput): Promise<SafeAdminGymUnitDetail>;
  findGymUnitById(id: string): Promise<SafeGymUnit | null>;
  getGymUnitById(id: string): Promise<SafeAdminGymUnitDetail>;
  listGymUnits(input: ListGymUnitsQueryInput): Promise<ListGymUnitsResult>;
  listUnitsByGymId(gymId: string): Promise<SafeGymUnit[]>;
  updateGymUnit(id: string, input: UpdateGymUnitInput): Promise<SafeAdminGymUnitDetail>;
  validateGymUnitQrCodeToken(token: string): Promise<PublicGymUnitQrValidationResponse>;
  activateGym(id: string): Promise<SafeGym>;
  deactivateGym(id: string): Promise<SafeGym>;
  activateGymUnit(id: string): Promise<SafeAdminGymUnitDetail>;
  deactivateGymUnit(id: string): Promise<SafeAdminGymUnitDetail>;
}

export class GymConflictError extends Error {
  readonly field: 'document' | 'unitName' | 'qrCodeToken' | 'unknown';

  constructor(field: 'document' | 'unitName' | 'qrCodeToken' | 'unknown') {
    const fieldLabel =
      field === 'document'
        ? 'gym document'
        : field === 'unitName'
          ? 'gym unit name within the same gym'
          : field === 'qrCodeToken'
            ? 'gym unit QR code token'
          : 'unique gym field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'GymConflictError';
    this.field = field;
  }
}

export class GymNotFoundError extends Error {
  constructor() {
    super('Gym not found.');
    this.name = 'GymNotFoundError';
  }
}

export class GymUnitNotFoundError extends Error {
  constructor() {
    super('Gym unit not found.');
    this.name = 'GymUnitNotFoundError';
  }
}

export class GymUnavailableError extends Error {
  constructor() {
    super('Gym must be active to create or activate units.');
    this.name = 'GymUnavailableError';
  }
}
