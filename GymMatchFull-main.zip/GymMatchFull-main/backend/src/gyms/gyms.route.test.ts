import { Prisma } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';
import {
  GymStatus as PrismaGymStatus,
  GymUnitStatus as PrismaGymUnitStatus,
  UserRole as PrismaUserRole,
  UserStatus as PrismaUserStatus,
} from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import { buildConfig } from '../config/env.js';
import type { MailServiceContract, PasswordResetMailInput } from '../mail/mail.service.js';
import { serializeUser } from '../users/users.serializer.js';
import type { CreateUserInput, SafeUser, UserRecord } from '../users/users.types.js';
import { UserConflictError } from '../users/users.types.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { GymsRepository } from './gyms.repository.js';
import { GymsService } from './gyms.service.js';
import type {
  CreateGymInput,
  CreateGymUnitInput,
  GymRecord,
  GymUnitRecord,
  GymUnitWithGymSummaryRecord,
  ListGymUnitsQueryInput,
  ListGymsQueryInput,
  UpdateGymInput,
  UpdateGymUnitInput,
} from './gyms.types.js';
import { GymConflictError, GymNotFoundError, GymUnitNotFoundError } from './gyms.types.js';

const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  name?: string;
  email?: string;
  cpf?: string;
  phone?: string;
  gymId?: string | null;
  gymUnitId?: string | null;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
  deletedAt?: Date | null;
}

class InMemoryUsersService implements AuthUsersServiceContract {
  readonly createdUsers: UserRecord[] = [];
  private nextId = 1;

  async createUser(input: CreateUserInput): Promise<SafeUser> {
    if (this.createdUsers.some((user) => user.email === input.email)) {
      throw new UserConflictError('email');
    }

    if (this.createdUsers.some((user) => user.cpf === input.cpf)) {
      throw new UserConflictError('cpf');
    }

    if (this.createdUsers.some((user) => user.phone === input.phone)) {
      throw new UserConflictError('phone');
    }

    const now = new Date();
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name,
      email: input.email,
      phone: input.phone,
      cpf: input.cpf,
      passwordHash: input.passwordHash,
      gymId: input.gymId ?? null,
      gymUnitId: input.gymUnitId ?? null,
      refreshTokenHash: input.refreshTokenHash ?? null,
      passwordResetTokenHash: null,
      passwordResetTokenExpiresAt: null,
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: input.emailVerifiedAt ?? null,
      phoneVerifiedAt: input.phoneVerifiedAt ?? null,
      termsAcceptedAt: input.termsAcceptedAt ?? null,
      lastLoginAt: input.lastLoginAt ?? null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.createdUsers.push(user);

    return serializeUser(user);
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    return user ? serializeUser(user) : null;
  }

  async findUserByEmail(email: string): Promise<SafeUser | null> {
    const user = this.createdUsers.find((storedUser) => storedUser.email === email);

    return user ? serializeUser(user) : null;
  }

  async findUserByIdWithRefreshToken(id: string): Promise<UserRecord | null> {
    return this.createdUsers.find((user) => user.id === id) ?? null;
  }

  async findUserByEmailWithPassword(email: string): Promise<UserRecord | null> {
    return this.createdUsers.find((user) => user.email === email) ?? null;
  }

  async findUserByPasswordResetTokenHash(
    _passwordResetTokenHash: string,
  ): Promise<UserRecord | null> {
    return null;
  }

  async updateLastLoginAt(id: string, lastLoginAt: Date): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.lastLoginAt = lastLoginAt;
      user.updatedAt = lastLoginAt;
    }
  }

  async updateRefreshTokenHash(id: string, refreshTokenHash: string | null): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.refreshTokenHash = refreshTokenHash;
      user.updatedAt = new Date();
    }
  }

  async updatePasswordResetToken(
    id: string,
    passwordResetTokenHash: string | null,
    passwordResetTokenExpiresAt: Date | null,
  ): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.passwordResetTokenHash = passwordResetTokenHash;
      user.passwordResetTokenExpiresAt = passwordResetTokenExpiresAt;
      user.updatedAt = new Date();
    }
  }

  async updatePasswordAfterReset(id: string, passwordHash: string): Promise<void> {
    const user = this.createdUsers.find((storedUser) => storedUser.id === id);

    if (user) {
      user.passwordHash = passwordHash;
      user.refreshTokenHash = null;
      user.passwordResetTokenHash = null;
      user.passwordResetTokenExpiresAt = null;
      user.updatedAt = new Date();
    }
  }

  seedUser(input: SeedUserInput = {}): UserRecord {
    const now = new Date();
    const role = input.role ?? PrismaUserRole.STUDENT;
    const user: UserRecord = {
      id: `user_${this.nextId++}`,
      name: input.name ?? 'Usuario Teste',
      email: input.email ?? `user_${this.nextId}@example.com`,
      cpf: input.cpf ?? `1234567890${this.nextId}`,
      phone: input.phone ?? `1199999999${this.nextId}`,
      passwordHash: 'hashed-password',
      gymId: input.gymId ?? (role === PrismaUserRole.STUDENT ? 'gym_1' : null),
      gymUnitId: input.gymUnitId ?? (role === PrismaUserRole.STUDENT ? 'unit_1' : null),
      refreshTokenHash: null,
      passwordResetTokenHash: null,
      passwordResetTokenExpiresAt: null,
      role,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.createdUsers.push(user);

    return user;
  }
}

class InMemoryMailService implements MailServiceContract {
  async sendPasswordResetEmail(_input: PasswordResetMailInput): Promise<void> {}
}

class InMemoryGymsRepository {
  readonly gyms: GymRecord[] = [];
  readonly gymUnits: GymUnitRecord[] = [];
  lastCreateGymInput?: CreateGymInput;
  lastUpdateGymInput?: { id: string; input: UpdateGymInput };
  lastListGymsQuery?: ListGymsQueryInput;
  lastCreateGymUnitInput?: CreateGymUnitInput;
  lastUpdateGymUnitInput?: { id: string; input: UpdateGymUnitInput };
  lastListGymUnitsQuery?: ListGymUnitsQueryInput;
  private nextGymId = 1;
  private nextGymUnitId = 1;

  async createGym(input: CreateGymInput): Promise<GymRecord> {
    this.lastCreateGymInput = input;

    if (input.document && this.gyms.some((gym) => gym.document === input.document)) {
      throw new GymConflictError('document');
    }

    const timestamp = new Date(2026, 0, 1, 0, 0, this.nextGymId);
    const gym: GymRecord = {
      id: `gym_${this.nextGymId++}`,
      name: input.name,
      legalName: input.legalName ?? null,
      document: input.document ?? null,
      email: input.email ?? null,
      phone: input.phone ?? null,
      status: input.status ?? PrismaGymStatus.ACTIVE,
      createdAt: timestamp,
      updatedAt: timestamp,
      deletedAt: input.deletedAt ?? null,
    };

    this.gyms.push(gym);

    return cloneGym(gym);
  }

  async findGymById(id: string): Promise<GymRecord | null> {
    const gym = this.gyms.find((storedGym) => storedGym.id === id && storedGym.deletedAt === null);

    return gym ? cloneGym(gym) : null;
  }

  async listGyms(input: ListGymsQueryInput): Promise<{ data: GymRecord[]; total: number }> {
    this.lastListGymsQuery = input;

    let data = [...this.gyms].filter((gym) => gym.deletedAt === null);

    if (input.status) {
      data = data.filter((gym) => gym.status === input.status);
    }

    if (input.search) {
      const normalizedSearch = input.search.toLowerCase();

      data = data.filter((gym) => {
        const name = gym.name.toLowerCase();
        const legalName = gym.legalName?.toLowerCase() ?? '';

        return name.includes(normalizedSearch) || legalName.includes(normalizedSearch);
      });
    }

    data.sort((left, right) => right.createdAt.getTime() - left.createdAt.getTime());

    const total = data.length;
    const paginatedData = data
      .slice((input.page - 1) * input.limit, (input.page - 1) * input.limit + input.limit)
      .map(cloneGym);

    return {
      data: paginatedData,
      total,
    };
  }

  async updateGym(id: string, input: UpdateGymInput): Promise<GymRecord> {
    this.lastUpdateGymInput = { id, input };

    const gym = this.gyms.find((storedGym) => storedGym.id === id);

    if (!gym) {
      throw new GymNotFoundError();
    }

    if (
      'document' in input &&
      input.document &&
      this.gyms.some((storedGym) => storedGym.id !== id && storedGym.document === input.document)
    ) {
      throw new GymConflictError('document');
    }

    if ('name' in input) {
      gym.name = input.name ?? gym.name;
    }

    if ('legalName' in input) {
      gym.legalName = input.legalName ?? null;
    }

    if ('document' in input) {
      gym.document = input.document ?? null;
    }

    if ('email' in input) {
      gym.email = input.email ?? null;
    }

    if ('phone' in input) {
      gym.phone = input.phone ?? null;
    }

    gym.updatedAt = new Date();

    return cloneGym(gym);
  }

  async createGymUnit(input: CreateGymUnitInput): Promise<GymUnitWithGymSummaryRecord> {
    this.lastCreateGymUnitInput = input;

    if (
      this.gymUnits.some((gymUnit) => gymUnit.gymId === input.gymId && gymUnit.name === input.name)
    ) {
      throw new GymConflictError('unitName');
    }

    const qrCodeToken = input.qrCodeToken ?? `seed_qr_token_${this.nextGymUnitId}`;

    if (this.gymUnits.some((gymUnit) => gymUnit.qrCodeToken === qrCodeToken)) {
      throw new GymConflictError('qrCodeToken');
    }

    const gymSummary = this.getGymSummaryById(input.gymId);

    if (!gymSummary) {
      throw new GymNotFoundError();
    }

    const timestamp = new Date(2026, 0, 1, 0, 10, this.nextGymUnitId);
    const gymUnit: GymUnitRecord = {
      id: `gym_unit_${this.nextGymUnitId++}`,
      gymId: input.gymId,
      qrCodeToken,
      name: input.name,
      addressLine: input.addressLine ?? null,
      number: input.number ?? null,
      complement: input.complement ?? null,
      neighborhood: input.neighborhood ?? null,
      city: input.city ?? null,
      state: input.state ?? null,
      zipCode: input.zipCode ?? null,
      latitude: input.latitude !== undefined ? new Prisma.Decimal(input.latitude) : null,
      longitude: input.longitude !== undefined ? new Prisma.Decimal(input.longitude) : null,
      status: input.status ?? PrismaGymUnitStatus.ACTIVE,
      createdAt: timestamp,
      updatedAt: timestamp,
      deletedAt: input.deletedAt ?? null,
    };

    this.gymUnits.push(gymUnit);

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  async findGymUnitById(id: string): Promise<GymUnitRecord | null> {
    const gymUnit = this.gymUnits.find(
      (storedGymUnit) => storedGymUnit.id === id && storedGymUnit.deletedAt === null,
    );

    if (!gymUnit) {
      return null;
    }

    return this.getGymSummaryById(gymUnit.gymId) ? cloneGymUnit(gymUnit) : null;
  }

  async findGymUnitByIdWithGym(id: string): Promise<GymUnitWithGymSummaryRecord | null> {
    const gymUnit = this.gymUnits.find(
      (storedGymUnit) => storedGymUnit.id === id && storedGymUnit.deletedAt === null,
    );

    if (!gymUnit) {
      return null;
    }

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    return gymSummary ? cloneGymUnitWithGymSummary(gymUnit, gymSummary) : null;
  }

  async findActiveGymUnitByQrCodeToken(token: string): Promise<GymUnitWithGymSummaryRecord | null> {
    const gymUnit = this.gymUnits.find(
      (storedGymUnit) =>
        storedGymUnit.qrCodeToken === token &&
        storedGymUnit.status === PrismaGymUnitStatus.ACTIVE &&
        storedGymUnit.deletedAt === null,
    );

    if (!gymUnit) {
      return null;
    }

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    if (!gymSummary || gymSummary.status !== PrismaGymStatus.ACTIVE) {
      return null;
    }

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  async listGymUnits(
    input: ListGymUnitsQueryInput,
  ): Promise<{ data: GymUnitWithGymSummaryRecord[]; total: number }> {
    this.lastListGymUnitsQuery = input;

    let data = this.gymUnits.filter((gymUnit) => {
      if (gymUnit.deletedAt !== null) {
        return false;
      }

      return this.getGymSummaryById(gymUnit.gymId) !== null;
    });

    if (input.gymId) {
      data = data.filter((gymUnit) => gymUnit.gymId === input.gymId);
    }

    if (input.status) {
      data = data.filter((gymUnit) => gymUnit.status === input.status);
    }

    if (input.search) {
      const normalizedSearch = input.search.toLowerCase();

      data = data.filter((gymUnit) => gymUnit.name.toLowerCase().includes(normalizedSearch));
    }

    if (input.city) {
      const normalizedCity = input.city.toLowerCase();

      data = data.filter((gymUnit) => (gymUnit.city?.toLowerCase() ?? '') === normalizedCity);
    }

    if (input.state) {
      const normalizedState = input.state.toUpperCase();

      data = data.filter((gymUnit) => (gymUnit.state?.toUpperCase() ?? '') === normalizedState);
    }

    data.sort((left, right) => right.createdAt.getTime() - left.createdAt.getTime());

    const total = data.length;

    return {
      data: data
        .slice((input.page - 1) * input.limit, (input.page - 1) * input.limit + input.limit)
        .map((gymUnit) => {
          const gymSummary = this.getGymSummaryById(gymUnit.gymId);

          if (!gymSummary) {
            throw new GymNotFoundError();
          }

          return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
        }),
      total,
    };
  }

  async listUnitsByGymId(gymId: string): Promise<GymUnitRecord[]> {
    return this.gymUnits
      .filter(
        (gymUnit) =>
          gymUnit.gymId === gymId &&
          gymUnit.deletedAt === null &&
          this.getGymSummaryById(gymUnit.gymId) !== null,
      )
      .sort((left, right) => left.createdAt.getTime() - right.createdAt.getTime())
      .map(cloneGymUnit);
  }

  async updateGymUnit(id: string, input: UpdateGymUnitInput): Promise<GymUnitWithGymSummaryRecord> {
    this.lastUpdateGymUnitInput = { id, input };

    const gymUnit = this.gymUnits.find((storedGymUnit) => storedGymUnit.id === id);

    if (!gymUnit) {
      throw new GymUnitNotFoundError();
    }

    if (
      'name' in input &&
      input.name &&
      this.gymUnits.some(
        (storedGymUnit) =>
          storedGymUnit.id !== id &&
          storedGymUnit.gymId === gymUnit.gymId &&
          storedGymUnit.name === input.name,
      )
    ) {
      throw new GymConflictError('unitName');
    }

    if ('name' in input && input.name !== undefined) {
      gymUnit.name = input.name;
    }

    if ('addressLine' in input) {
      gymUnit.addressLine = input.addressLine ?? null;
    }

    if ('number' in input) {
      gymUnit.number = input.number ?? null;
    }

    if ('complement' in input) {
      gymUnit.complement = input.complement ?? null;
    }

    if ('neighborhood' in input) {
      gymUnit.neighborhood = input.neighborhood ?? null;
    }

    if ('city' in input) {
      gymUnit.city = input.city ?? null;
    }

    if ('state' in input) {
      gymUnit.state = input.state ?? null;
    }

    if ('zipCode' in input) {
      gymUnit.zipCode = input.zipCode ?? null;
    }

    if ('latitude' in input) {
      gymUnit.latitude = input.latitude === null ? null : new Prisma.Decimal(input.latitude);
    }

    if ('longitude' in input) {
      gymUnit.longitude = input.longitude === null ? null : new Prisma.Decimal(input.longitude);
    }

    gymUnit.updatedAt = new Date();

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    if (!gymSummary) {
      throw new GymNotFoundError();
    }

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  async updateGymStatus(id: string, status: PrismaGymStatus): Promise<GymRecord> {
    const gym = this.gyms.find((storedGym) => storedGym.id === id);

    if (!gym) {
      throw new GymNotFoundError();
    }

    gym.status = status;
    gym.updatedAt = new Date();

    return cloneGym(gym);
  }

  async updateGymUnitStatus(
    id: string,
    status: PrismaGymUnitStatus,
  ): Promise<GymUnitWithGymSummaryRecord> {
    const gymUnit = this.gymUnits.find((storedGymUnit) => storedGymUnit.id === id);

    if (!gymUnit) {
      throw new GymUnitNotFoundError();
    }

    gymUnit.status = status;
    gymUnit.updatedAt = new Date();

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    if (!gymSummary) {
      throw new GymNotFoundError();
    }

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  softDeleteGym(id: string, deletedAt: Date): void {
    const gym = this.gyms.find((storedGym) => storedGym.id === id);

    if (gym) {
      gym.deletedAt = deletedAt;
      gym.updatedAt = deletedAt;
    }
  }

  softDeleteGymUnit(id: string, deletedAt: Date): void {
    const gymUnit = this.gymUnits.find((storedGymUnit) => storedGymUnit.id === id);

    if (gymUnit) {
      gymUnit.deletedAt = deletedAt;
      gymUnit.updatedAt = deletedAt;
    }
  }

  private getGymSummaryById(gymId: string): Pick<GymRecord, 'id' | 'name' | 'status'> | null {
    const gym = this.gyms.find(
      (storedGym) => storedGym.id === gymId && storedGym.deletedAt === null,
    );

    if (!gym) {
      return null;
    }

    return {
      id: gym.id,
      name: gym.name,
      status: gym.status,
    };
  }
}

function cloneGym(gym: GymRecord): GymRecord {
  return {
    ...gym,
  };
}

function cloneGymUnit(gymUnit: GymUnitRecord): GymUnitRecord {
  return {
    ...gymUnit,
  };
}

function cloneGymUnitWithGymSummary(
  gymUnit: GymUnitRecord,
  gym: Pick<GymRecord, 'id' | 'name' | 'status'>,
): GymUnitWithGymSummaryRecord {
  return {
    ...cloneGymUnit(gymUnit),
    gym: {
      ...gym,
    },
  };
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const gymsRepository = new InMemoryGymsRepository();
  const gymsService = new GymsService(
    {} as PrismaClient,
    gymsRepository as unknown as GymsRepository,
  );
  const app = buildApp({
    config,
    services: {
      gymsService,
      mailService: new InMemoryMailService(),
      usersService,
    },
  });

  appsToClose.push(app);

  return { app, usersService, gymsRepository };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<UserRecord, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('Admin gym routes', () => {
  it('allows ADMIN to create a gym with normalized email and phone', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: '  Academia Exemplo  ',
        legalName: ' Academia Exemplo LTDA ',
        document: '12345678000199',
        email: 'CONTATO@ACADEMIAEXEMPLO.COM',
        phone: '(11) 99999-9999',
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      id: 'gym_1',
      name: 'Academia Exemplo',
      legalName: 'Academia Exemplo LTDA',
      document: '12345678000199',
      email: 'contato@academiaexemplo.com',
      phone: '11999999999',
      status: 'ACTIVE',
    });
    expect(response.json()).not.toHaveProperty('units');
    expect(gymsRepository.lastCreateGymInput).toMatchObject({
      name: 'Academia Exemplo',
      legalName: 'Academia Exemplo LTDA',
      email: 'contato@academiaexemplo.com',
      phone: '11999999999',
      status: 'ACTIVE',
    });
  });

  it('rejects creating a gym without name', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        legalName: 'Academia Sem Nome LTDA',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'name is required and must be a string.',
    });
  });

  it('rejects creating a gym with invalid email', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Exemplo',
        email: 'email-invalido',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'email must be a valid email address.',
    });
  });

  it('blocks STUDENT from creating a gym', async () => {
    const { app, usersService } = createTestApp();
    const studentUser = usersService.seedUser({
      role: PrismaUserRole.STUDENT,
      email: 'student@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, studentUser)}`,
      },
      payload: {
        name: 'Academia Exemplo',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks unauthenticated gym creation', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      payload: {
        name: 'Academia Exemplo',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('lists gyms with pagination for ADMIN', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    for (const name of ['Academia A', 'Academia B', 'Academia C']) {
      await app.inject({
        method: 'POST',
        url: '/admin/gyms',
        headers: {
          authorization: `Bearer ${signAccessToken(app, adminUser)}`,
        },
        payload: {
          name,
          email: `${name.replace(/\s+/g, '').toLowerCase()}@example.com`,
        },
      });
    }

    const response = await app.inject({
      method: 'GET',
      url: '/admin/gyms?page=2&limit=2',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      pagination: {
        page: 2,
        limit: 2,
        total: 3,
        totalPages: 2,
      },
    });
    expect(response.json().data).toHaveLength(1);
    expect(response.json().data[0]).toMatchObject({
      name: 'Academia A',
    });
  });

  it('filters gyms by status and searches by name or legalName', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const alphaCreateResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Alpha Fitness',
        legalName: 'Alpha Fitness LTDA',
        email: 'alpha@example.com',
      },
    });
    const betaCreateResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Beta Club',
        legalName: 'Rede Alpha do Centro',
        email: 'beta@example.com',
      },
    });

    await app.inject({
      method: 'PATCH',
      url: `/admin/gyms/${alphaCreateResponse.json().id}/deactivate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    const response = await app.inject({
      method: 'GET',
      url: '/admin/gyms?status=ACTIVE&search=centro',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(betaCreateResponse.statusCode).toBe(201);
    expect(response.statusCode).toBe(200);
    expect(response.json().data).toHaveLength(1);
    expect(response.json().data[0]).toMatchObject({
      id: betaCreateResponse.json().id,
      name: 'Beta Club',
      status: 'ACTIVE',
    });
  });

  it('returns a gym by id for ADMIN', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const createResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Exemplo',
      },
    });

    const response = await app.inject({
      method: 'GET',
      url: `/admin/gyms/${createResponse.json().id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: createResponse.json().id,
      name: 'Academia Exemplo',
      status: 'ACTIVE',
    });
  });

  it('returns 404 when gym id does not exist', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/gyms/gym_missing',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Gym not found.',
    });
  });

  it('updates a gym and allows clearing nullable fields with null', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const createResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Inicial',
        legalName: 'Academia Inicial LTDA',
        email: 'inicial@example.com',
        phone: '11999999999',
      },
    });

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gyms/${createResponse.json().id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Atualizada',
        legalName: null,
        email: 'NOVO@EXAMPLE.COM',
        phone: '(11) 98888-7777',
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: createResponse.json().id,
      name: 'Academia Atualizada',
      legalName: null,
      email: 'novo@example.com',
      phone: '11988887777',
    });
    expect(gymsRepository.lastUpdateGymInput).toMatchObject({
      id: createResponse.json().id,
      input: {
        name: 'Academia Atualizada',
        legalName: null,
        email: 'novo@example.com',
        phone: '11988887777',
      },
    });
  });

  it('deactivates a gym for ADMIN', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const createResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Exemplo',
      },
    });

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gyms/${createResponse.json().id}/deactivate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: createResponse.json().id,
      status: 'INACTIVE',
    });
  });

  it('activates a gym for ADMIN', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const createResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Exemplo',
      },
    });

    await app.inject({
      method: 'PATCH',
      url: `/admin/gyms/${createResponse.json().id}/deactivate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gyms/${createResponse.json().id}/activate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: createResponse.json().id,
      status: 'ACTIVE',
    });
  });

  it('blocks STUDENT on all main admin gym endpoints', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const studentUser = usersService.seedUser({
      role: PrismaUserRole.STUDENT,
      email: 'student@example.com',
      cpf: '10987654321',
      phone: '11922222222',
    });

    await app.ready();

    const createResponse = await app.inject({
      method: 'POST',
      url: '/admin/gyms',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Academia Exemplo',
      },
    });

    const gymId = createResponse.json().id;
    const headers = {
      authorization: `Bearer ${signAccessToken(app, studentUser)}`,
    };

    const responses = await Promise.all([
      app.inject({
        method: 'GET',
        url: '/admin/gyms',
        headers,
      }),
      app.inject({
        method: 'GET',
        url: `/admin/gyms/${gymId}`,
        headers,
      }),
      app.inject({
        method: 'PATCH',
        url: `/admin/gyms/${gymId}`,
        headers,
        payload: {
          name: 'Academia Bloqueada',
        },
      }),
      app.inject({
        method: 'PATCH',
        url: `/admin/gyms/${gymId}/activate`,
        headers,
      }),
      app.inject({
        method: 'PATCH',
        url: `/admin/gyms/${gymId}/deactivate`,
        headers,
      }),
    ]);

    for (const response of responses) {
      expect(response.statusCode).toBe(403);
      expect(response.json()).toEqual({
        statusCode: 403,
        error: 'Forbidden',
        message: 'Insufficient permissions.',
      });
    }
  });
});

describe('Admin gym unit routes', () => {
  it('allows ADMIN to create a gym unit with normalized fields and gym summary', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        gymId: gym.id,
        name: '  Unidade Centro  ',
        addressLine: ' Rua Exemplo ',
        city: 'Sao Paulo',
        state: 'sp',
        zipCode: '01001-000',
        latitude: -23.55052,
        longitude: -46.633308,
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      id: 'gym_unit_1',
      gymId: gym.id,
      name: 'Unidade Centro',
      addressLine: 'Rua Exemplo',
      city: 'Sao Paulo',
      state: 'SP',
      zipCode: '01001000',
      latitude: -23.55052,
      longitude: -46.633308,
      status: 'ACTIVE',
      gym: {
        id: gym.id,
        name: 'Academia Exemplo',
        status: 'ACTIVE',
      },
    });
    expect(gymsRepository.lastCreateGymUnitInput).toMatchObject({
      gymId: gym.id,
      name: 'Unidade Centro',
      addressLine: 'Rua Exemplo',
      state: 'SP',
      zipCode: '01001000',
      latitude: -23.55052,
      longitude: -46.633308,
    });
  });

  it('rejects creating a gym unit without name', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        gymId: gym.id,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'name is required and must be a string.',
    });
  });

  it('rejects creating a gym unit without gymId', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Unidade Centro',
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'gymId is required and must be a string.',
    });
  });

  it('rejects creating a gym unit for a non-existent gym', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        gymId: 'gym_missing',
        name: 'Unidade Centro',
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Gym not found.',
    });
  });

  it('rejects creating a gym unit for an inactive gym', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Inativa',
      status: PrismaGymStatus.INACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        gymId: gym.id,
        name: 'Unidade Centro',
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Gym must be active to create or activate units.',
    });
  });

  it('rejects duplicate gym unit names inside the same gym', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Centro',
      status: PrismaGymUnitStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        gymId: gym.id,
        name: 'Unidade Centro',
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'A record with the same gym unit name within the same gym already exists.',
    });
  });

  it('blocks STUDENT from creating a gym unit', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const studentUser = usersService.seedUser({
      role: PrismaUserRole.STUDENT,
      email: 'student@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, studentUser)}`,
      },
      payload: {
        gymId: gym.id,
        name: 'Unidade Centro',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('blocks unauthenticated gym unit creation', async () => {
    const { app, gymsRepository } = createTestApp();
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      payload: {
        gymId: gym.id,
        name: 'Unidade Centro',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('lists gym units with pagination for ADMIN', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });

    await app.ready();

    for (const name of ['Unidade A', 'Unidade B', 'Unidade C']) {
      await app.inject({
        method: 'POST',
        url: '/admin/gym-units',
        headers: {
          authorization: `Bearer ${signAccessToken(app, adminUser)}`,
        },
        payload: {
          gymId: gym.id,
          name,
        },
      });
    }

    const response = await app.inject({
      method: 'GET',
      url: '/admin/gym-units?page=2&limit=2',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      pagination: {
        page: 2,
        limit: 2,
        total: 3,
        totalPages: 2,
      },
    });
    expect(response.json().data).toHaveLength(1);
    expect(response.json().data[0]).toMatchObject({
      name: 'Unidade A',
      gym: {
        id: gym.id,
        name: 'Academia Exemplo',
      },
    });
  });

  it('filters gym units by gymId, status, city, state and search', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gymA = await gymsRepository.createGym({
      name: 'Academia A',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymB = await gymsRepository.createGym({
      name: 'Academia B',
      status: PrismaGymStatus.ACTIVE,
    });
    const activeUnit = await gymsRepository.createGymUnit({
      gymId: gymA.id,
      name: 'Centro Prime',
      city: 'Sao Paulo',
      state: 'SP',
      status: PrismaGymUnitStatus.ACTIVE,
    });
    await gymsRepository.createGymUnit({
      gymId: gymA.id,
      name: 'Centro Inativo',
      city: 'Sao Paulo',
      state: 'SP',
      status: PrismaGymUnitStatus.INACTIVE,
    });
    await gymsRepository.createGymUnit({
      gymId: gymB.id,
      name: 'Centro Prime',
      city: 'Campinas',
      state: 'SP',
      status: PrismaGymUnitStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: `/admin/gym-units?gymId=${gymA.id}&status=ACTIVE&city=sao paulo&state=sp&search=prime`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json().data).toHaveLength(1);
    expect(response.json().data[0]).toMatchObject({
      id: activeUnit.id,
      gymId: gymA.id,
      name: 'Centro Prime',
      status: 'ACTIVE',
      gym: {
        id: gymA.id,
        name: 'Academia A',
      },
    });
    expect(gymsRepository.lastListGymUnitsQuery).toMatchObject({
      gymId: gymA.id,
      status: 'ACTIVE',
      city: 'sao paulo',
      state: 'SP',
      search: 'prime',
    });
  });

  it('returns a gym unit by id for ADMIN', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymUnit = await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Centro',
      status: PrismaGymUnitStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: `/admin/gym-units/${gymUnit.id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: gymUnit.id,
      gymId: gym.id,
      name: 'Unidade Centro',
      status: 'ACTIVE',
      gym: {
        id: gym.id,
        name: 'Academia Exemplo',
        status: 'ACTIVE',
      },
    });
  });

  it('returns 404 when gym unit id does not exist', async () => {
    const { app, usersService } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });

    await app.ready();

    const response = await app.inject({
      method: 'GET',
      url: '/admin/gym-units/gym_unit_missing',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Gym unit not found.',
    });
  });

  it('updates a gym unit and allows clearing nullable fields with null', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymUnit = await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Inicial',
      addressLine: 'Rua Inicial',
      complement: 'Sala 1',
      state: 'SP',
      zipCode: '01001000',
      latitude: -23.5,
      longitude: -46.6,
      status: PrismaGymUnitStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gym-units/${gymUnit.id}`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
      payload: {
        name: 'Unidade Atualizada',
        addressLine: null,
        complement: null,
        state: 'rj',
        zipCode: '20040-020',
        latitude: null,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: gymUnit.id,
      name: 'Unidade Atualizada',
      addressLine: null,
      complement: null,
      state: 'RJ',
      zipCode: '20040020',
      latitude: null,
      longitude: -46.6,
    });
    expect(gymsRepository.lastUpdateGymUnitInput).toMatchObject({
      id: gymUnit.id,
      input: {
        name: 'Unidade Atualizada',
        addressLine: null,
        complement: null,
        state: 'RJ',
        zipCode: '20040020',
        latitude: null,
      },
    });
  });

  it('deactivates a gym unit for ADMIN', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymUnit = await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Centro',
      status: PrismaGymUnitStatus.ACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gym-units/${gymUnit.id}/deactivate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: gymUnit.id,
      status: 'INACTIVE',
      gym: {
        id: gym.id,
      },
    });
  });

  it('activates a gym unit for ADMIN when the gym is active', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymUnit = await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Centro',
      status: PrismaGymUnitStatus.INACTIVE,
    });

    await app.ready();

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gym-units/${gymUnit.id}/activate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(200);
    expect(response.json()).toMatchObject({
      id: gymUnit.id,
      status: 'ACTIVE',
      gym: {
        id: gym.id,
        status: 'ACTIVE',
      },
    });
  });

  it('blocks activating a gym unit when the parent gym is inactive', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymUnit = await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Centro',
      status: PrismaGymUnitStatus.INACTIVE,
    });

    await app.ready();

    await app.inject({
      method: 'PATCH',
      url: `/admin/gyms/${gym.id}/deactivate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    const response = await app.inject({
      method: 'PATCH',
      url: `/admin/gym-units/${gymUnit.id}/activate`,
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Gym must be active to create or activate units.',
    });
  });

  it('blocks STUDENT on all main admin gym unit endpoints', async () => {
    const { app, usersService, gymsRepository } = createTestApp();
    const adminUser = usersService.seedUser({
      role: PrismaUserRole.ADMIN,
      email: 'admin@example.com',
      cpf: '12345678901',
      phone: '11911111111',
    });
    const studentUser = usersService.seedUser({
      role: PrismaUserRole.STUDENT,
      email: 'student@example.com',
      cpf: '10987654321',
      phone: '11922222222',
    });
    const gym = await gymsRepository.createGym({
      name: 'Academia Exemplo',
      status: PrismaGymStatus.ACTIVE,
    });
    const gymUnit = await gymsRepository.createGymUnit({
      gymId: gym.id,
      name: 'Unidade Centro',
      status: PrismaGymUnitStatus.ACTIVE,
    });

    await app.ready();

    const headers = {
      authorization: `Bearer ${signAccessToken(app, studentUser)}`,
    };

    const responses = await Promise.all([
      app.inject({
        method: 'GET',
        url: '/admin/gym-units',
        headers,
      }),
      app.inject({
        method: 'GET',
        url: `/admin/gym-units/${gymUnit.id}`,
        headers,
      }),
      app.inject({
        method: 'PATCH',
        url: `/admin/gym-units/${gymUnit.id}`,
        headers,
        payload: {
          name: 'Unidade Bloqueada',
        },
      }),
      app.inject({
        method: 'PATCH',
        url: `/admin/gym-units/${gymUnit.id}/activate`,
        headers,
      }),
      app.inject({
        method: 'PATCH',
        url: `/admin/gym-units/${gymUnit.id}/deactivate`,
        headers,
      }),
    ]);

    for (const response of responses) {
      expect(response.statusCode).toBe(403);
      expect(response.json()).toEqual({
        statusCode: 403,
        error: 'Forbidden',
        message: 'Insufficient permissions.',
      });
    }

    const createResponse = await app.inject({
      method: 'POST',
      url: '/admin/gym-units',
      headers,
      payload: {
        gymId: gym.id,
        name: 'Outra Unidade',
      },
    });

    expect(createResponse.statusCode).toBe(403);
    expect(createResponse.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });

    const adminListResponse = await app.inject({
      method: 'GET',
      url: '/admin/gym-units',
      headers: {
        authorization: `Bearer ${signAccessToken(app, adminUser)}`,
      },
    });

    expect(adminListResponse.statusCode).toBe(200);
  });
});
