import type { PrismaClient } from '@prisma/client';
import { GymStatus as PrismaGymStatus, GymUnitStatus as PrismaGymUnitStatus } from '@prisma/client';

import { HttpError } from '../common/errors/http-error.js';
import { generateGymUnitQrCodeToken } from '../common/utils/token-generator.js';
import {
  serializeAdminGymUnitDetail,
  serializeAdminGymUnitListItem,
  serializeGymUnit,
  serializePublicGymUnitQrValidationSuccess,
} from './gyms.serializer.js';
import { GymsRepository } from './gyms.repository.js';
import {
  GymConflictError,
  GymNotFoundError,
  GymUnavailableError,
  GymUnitNotFoundError,
  type CreateGymInput,
  type CreateGymUnitInput,
  type GymsServiceContract,
  type ListGymUnitsQueryInput,
  type ListGymUnitsResult,
  type ListGymsQueryInput,
  type ListGymsResult,
  type PublicGymUnitQrValidationResponse,
  type SafeAdminGymUnitDetail,
  type SafeGym,
  type SafeGymUnit,
  type UpdateGymInput,
  type UpdateGymUnitInput,
} from './gyms.types.js';

const QR_CODE_TOKEN_GENERATION_MAX_ATTEMPTS = 3;
const INVALID_QR_CODE_MESSAGE = 'QR Code invalido ou indisponivel.';

export class GymsService implements GymsServiceContract {
  private readonly gymsRepository: GymsRepository;

  constructor(prisma: PrismaClient, gymsRepository?: GymsRepository) {
    this.gymsRepository = gymsRepository ?? new GymsRepository(prisma);
  }

  async createGym(input: CreateGymInput): Promise<SafeGym> {
    try {
      return await this.gymsRepository.createGym({
        ...input,
        status: PrismaGymStatus.ACTIVE,
      });
    } catch (error) {
      throw mapGymServiceError(error);
    }
  }

  findGymById(id: string): Promise<SafeGym | null> {
    return this.gymsRepository.findGymById(id);
  }

  async getGymById(id: string): Promise<SafeGym> {
    const gym = await this.gymsRepository.findGymById(id);

    if (!gym) {
      throw new HttpError(404, 'Gym not found.');
    }

    return gym;
  }

  async listGyms(input: ListGymsQueryInput): Promise<ListGymsResult> {
    const { data, total } = await this.gymsRepository.listGyms(input);

    return {
      data,
      pagination: {
        page: input.page,
        limit: input.limit,
        total,
        totalPages: Math.max(1, Math.ceil(total / input.limit)),
      },
    };
  }

  async updateGym(id: string, input: UpdateGymInput): Promise<SafeGym> {
    await this.getGymById(id);

    try {
      return await this.gymsRepository.updateGym(id, input);
    } catch (error) {
      throw mapGymServiceError(error);
    }
  }

  async createGymUnit(input: CreateGymUnitInput): Promise<SafeAdminGymUnitDetail> {
    const gym = await this.gymsRepository.findGymById(input.gymId);

    if (!gym) {
      throw new HttpError(404, 'Gym not found.');
    }

    if (gym.status !== PrismaGymStatus.ACTIVE) {
      throw new HttpError(409, 'Gym must be active to create or activate units.');
    }

    for (let attempt = 1; attempt <= QR_CODE_TOKEN_GENERATION_MAX_ATTEMPTS; attempt += 1) {
      try {
        const gymUnit = await this.gymsRepository.createGymUnit({
          ...input,
          qrCodeToken: generateGymUnitQrCodeToken(),
        });

        return serializeAdminGymUnitDetail(gymUnit);
      } catch (error) {
        if (
          error instanceof GymConflictError &&
          error.field === 'qrCodeToken' &&
          attempt < QR_CODE_TOKEN_GENERATION_MAX_ATTEMPTS
        ) {
          continue;
        }

        throw mapGymServiceError(error);
      }
    }

    throw new HttpError(500, 'Unable to generate a unique gym unit QR code token.');
  }

  async findGymUnitById(id: string): Promise<SafeGymUnit | null> {
    const gymUnit = await this.gymsRepository.findGymUnitById(id);

    return gymUnit ? serializeGymUnit(gymUnit) : null;
  }

  async getGymUnitById(id: string): Promise<SafeAdminGymUnitDetail> {
    const gymUnit = await this.gymsRepository.findGymUnitByIdWithGym(id);

    if (!gymUnit) {
      throw new HttpError(404, 'Gym unit not found.');
    }

    return serializeAdminGymUnitDetail(gymUnit);
  }

  async listGymUnits(input: ListGymUnitsQueryInput): Promise<ListGymUnitsResult> {
    const { data, total } = await this.gymsRepository.listGymUnits(input);

    return {
      data: data.map(serializeAdminGymUnitListItem),
      pagination: {
        page: input.page,
        limit: input.limit,
        total,
        totalPages: Math.max(1, Math.ceil(total / input.limit)),
      },
    };
  }

  async listUnitsByGymId(gymId: string): Promise<SafeGymUnit[]> {
    const gymUnits = await this.gymsRepository.listUnitsByGymId(gymId);

    return gymUnits.map(serializeGymUnit);
  }

  async updateGymUnit(id: string, input: UpdateGymUnitInput): Promise<SafeAdminGymUnitDetail> {
    try {
      await this.ensureGymUnitExists(id);

      const gymUnit = await this.gymsRepository.updateGymUnit(id, input);

      return serializeAdminGymUnitDetail(gymUnit);
    } catch (error) {
      throw mapGymServiceError(error);
    }
  }

  async validateGymUnitQrCodeToken(token: string): Promise<PublicGymUnitQrValidationResponse> {
    const gymUnit = await this.gymsRepository.findActiveGymUnitByQrCodeToken(token);

    if (!gymUnit) {
      return {
        valid: false,
        message: INVALID_QR_CODE_MESSAGE,
      };
    }

    return serializePublicGymUnitQrValidationSuccess(gymUnit);
  }

  async activateGym(id: string): Promise<SafeGym> {
    await this.getGymById(id);

    return this.gymsRepository.updateGymStatus(id, PrismaGymStatus.ACTIVE);
  }

  async deactivateGym(id: string): Promise<SafeGym> {
    await this.getGymById(id);

    return this.gymsRepository.updateGymStatus(id, PrismaGymStatus.INACTIVE);
  }

  async activateGymUnit(id: string): Promise<SafeAdminGymUnitDetail> {
    try {
      const gymUnit = await this.ensureGymUnitExists(id);
      const gym = await this.gymsRepository.findGymById(gymUnit.gymId);

      if (!gym || gym.status !== PrismaGymStatus.ACTIVE) {
        throw new GymUnavailableError();
      }

      const updatedGymUnit = await this.gymsRepository.updateGymUnitStatus(
        id,
        PrismaGymUnitStatus.ACTIVE,
      );

      return serializeAdminGymUnitDetail(updatedGymUnit);
    } catch (error) {
      throw mapGymServiceError(error);
    }
  }

  async deactivateGymUnit(id: string): Promise<SafeAdminGymUnitDetail> {
    try {
      await this.ensureGymUnitExists(id);

      const updatedGymUnit = await this.gymsRepository.updateGymUnitStatus(
        id,
        PrismaGymUnitStatus.INACTIVE,
      );

      return serializeAdminGymUnitDetail(updatedGymUnit);
    } catch (error) {
      throw mapGymServiceError(error);
    }
  }

  private async ensureGymUnitExists(id: string): Promise<SafeGymUnit> {
    const gymUnit = await this.gymsRepository.findGymUnitById(id);

    if (!gymUnit) {
      throw new GymUnitNotFoundError();
    }

    return serializeGymUnit(gymUnit);
  }
}

function mapGymServiceError(error: unknown): HttpError {
  if (error instanceof HttpError) {
    return error;
  }

  if (error instanceof GymConflictError) {
    switch (error.field) {
      case 'document':
        return new HttpError(409, 'A record with the same gym document already exists.');
      case 'unitName':
        return new HttpError(
          409,
          'A record with the same gym unit name within the same gym already exists.',
        );
      case 'qrCodeToken':
        return new HttpError(409, 'A record with the same gym unit QR code token already exists.');
      default:
        return new HttpError(409, 'A record with the same unique gym field already exists.');
    }
  }

  if (error instanceof GymNotFoundError) {
    return new HttpError(404, 'Gym not found.');
  }

  if (error instanceof GymUnitNotFoundError) {
    return new HttpError(404, 'Gym unit not found.');
  }

  if (error instanceof GymUnavailableError) {
    return new HttpError(409, 'Gym must be active to create or activate units.');
  }

  return error instanceof Error
    ? new HttpError(500, error.message)
    : new HttpError(500, 'Internal server error.');
}
