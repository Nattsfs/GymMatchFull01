import type { GymStatus, GymUnit } from '@prisma/client';

import type {
  GymSummaryRecord,
  PublicGymUnitQrValidationSuccess,
  GymUnitRecord,
  GymUnitWithGymSummaryRecord,
  SafeAdminGymUnitDetail,
  SafeAdminGymUnitListItem,
  SafeGymSummary,
  SafeGymUnit,
} from './gyms.types.js';

export function serializeGymSummary(gym: GymSummaryRecord): SafeGymSummary {
  return {
    id: gym.id,
    name: gym.name,
    status: gym.status as GymStatus,
  };
}

export function serializeGymUnit(gymUnit: GymUnitRecord): SafeGymUnit {
  return {
    ...gymUnit,
    latitude: serializeDecimal(gymUnit.latitude),
    longitude: serializeDecimal(gymUnit.longitude),
  };
}

export function serializeAdminGymUnitDetail(
  gymUnit: GymUnitWithGymSummaryRecord,
): SafeAdminGymUnitDetail {
  return {
    ...serializeGymUnit(gymUnit),
    gym: serializeGymSummary(gymUnit.gym),
  };
}

export function serializeAdminGymUnitListItem(
  gymUnit: GymUnitWithGymSummaryRecord,
): SafeAdminGymUnitListItem {
  const { qrCodeToken: _qrCodeToken, ...gymUnitWithoutToken } = serializeGymUnit(gymUnit);

  return {
    ...gymUnitWithoutToken,
    gym: serializeGymSummary(gymUnit.gym),
  };
}

export function serializePublicGymUnitQrValidationSuccess(
  gymUnit: GymUnitWithGymSummaryRecord,
): PublicGymUnitQrValidationSuccess {
  return {
    valid: true,
    gym: {
      id: gymUnit.gym.id,
      name: gymUnit.gym.name,
    },
    unit: {
      id: gymUnit.id,
      name: gymUnit.name,
      city: gymUnit.city,
      state: gymUnit.state,
    },
  };
}

function serializeDecimal(value: GymUnit['latitude']): number | null {
  if (value === null) {
    return null;
  }

  if (typeof value === 'number') {
    return value;
  }

  return value.toNumber();
}
