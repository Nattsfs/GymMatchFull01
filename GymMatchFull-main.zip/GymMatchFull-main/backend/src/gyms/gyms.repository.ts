import { Prisma } from '@prisma/client';
import type { PrismaClient, GymStatus, GymUnitStatus } from '@prisma/client';

import type {
  CreateGymInput,
  CreateGymUnitInput,
  GymRecord,
  GymUnitRecord,
  GymUnitWithGymSummaryRecord,
  ListGymUnitsQueryInput,
  ListGymsQueryInput,
  UpdateGymInput,
  UpdateGymUnitInput,
} from './gyms.types.js';
import { GymConflictError } from './gyms.types.js';

function getConflictField(error: Prisma.PrismaClientKnownRequestError): GymConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('document')) {
    return 'document';
  }

  if (target.includes('qrCodeToken')) {
    return 'qrCodeToken';
  }

  if (target.includes('gymId') && target.includes('name')) {
    return 'unitName';
  }

  return 'unknown';
}

export class GymsRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async createGym(input: CreateGymInput): Promise<GymRecord> {
    const data: Prisma.GymCreateInput = {
      name: input.name,
    };

    if (input.legalName !== undefined) {
      data.legalName = input.legalName;
    }

    if (input.document !== undefined) {
      data.document = input.document;
    }

    if (input.email !== undefined) {
      data.email = input.email;
    }

    if (input.phone !== undefined) {
      data.phone = input.phone;
    }

    if (input.status !== undefined) {
      data.status = input.status;
    }

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.gym.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new GymConflictError(getConflictField(error));
      }

      throw error;
    }
  }

  findGymById(id: string): Promise<GymRecord | null> {
    return this.prisma.gym.findFirst({
      where: {
        id,
        deletedAt: null,
      },
    });
  }

  async listGyms(input: ListGymsQueryInput): Promise<{ data: GymRecord[]; total: number }> {
    const where: Prisma.GymWhereInput = {
      deletedAt: null,
      ...(input.status ? { status: input.status } : {}),
      ...(input.search
        ? {
            OR: [
              {
                name: {
                  contains: input.search,
                  mode: 'insensitive',
                },
              },
              {
                legalName: {
                  contains: input.search,
                  mode: 'insensitive',
                },
              },
            ],
          }
        : {}),
    };

    const [data, total] = await this.prisma.$transaction([
      this.prisma.gym.findMany({
        where,
        orderBy: {
          createdAt: 'desc',
        },
        skip: (input.page - 1) * input.limit,
        take: input.limit,
      }),
      this.prisma.gym.count({
        where,
      }),
    ]);

    return {
      data,
      total,
    };
  }

  async updateGym(id: string, input: UpdateGymInput): Promise<GymRecord> {
    const data: Prisma.GymUpdateInput = {};

    if ('name' in input) {
      data.name = input.name;
    }

    if ('legalName' in input) {
      data.legalName = input.legalName;
    }

    if ('document' in input) {
      data.document = input.document;
    }

    if ('email' in input) {
      data.email = input.email;
    }

    if ('phone' in input) {
      data.phone = input.phone;
    }

    try {
      return await this.prisma.gym.update({
        where: { id },
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new GymConflictError(getConflictField(error));
      }

      throw error;
    }
  }

  async createGymUnit(input: CreateGymUnitInput): Promise<GymUnitWithGymSummaryRecord> {
    if (!input.qrCodeToken) {
      throw new Error('Gym unit QR code token is required.');
    }

    const data: Prisma.GymUnitCreateInput = {
      gym: {
        connect: {
          id: input.gymId,
        },
      },
      qrCodeToken: input.qrCodeToken,
      name: input.name,
    };

    if (input.addressLine !== undefined) {
      data.addressLine = input.addressLine;
    }

    if (input.number !== undefined) {
      data.number = input.number;
    }

    if (input.complement !== undefined) {
      data.complement = input.complement;
    }

    if (input.neighborhood !== undefined) {
      data.neighborhood = input.neighborhood;
    }

    if (input.city !== undefined) {
      data.city = input.city;
    }

    if (input.state !== undefined) {
      data.state = input.state;
    }

    if (input.zipCode !== undefined) {
      data.zipCode = input.zipCode;
    }

    if (input.latitude !== undefined) {
      data.latitude = input.latitude;
    }

    if (input.longitude !== undefined) {
      data.longitude = input.longitude;
    }

    if (input.status !== undefined) {
      data.status = input.status;
    }

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.gymUnit.create({
        data,
        include: {
          gym: {
            select: gymSummarySelect,
          },
        },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new GymConflictError(getConflictField(error));
      }

      throw error;
    }
  }

  findGymUnitById(id: string): Promise<GymUnitRecord | null> {
    return this.prisma.gymUnit.findFirst({
      where: {
        id,
        deletedAt: null,
        gym: {
          is: {
            deletedAt: null,
          },
        },
      },
    });
  }

  findGymUnitByIdWithGym(id: string): Promise<GymUnitWithGymSummaryRecord | null> {
    return this.prisma.gymUnit.findFirst({
      where: {
        id,
        deletedAt: null,
        gym: {
          is: {
            deletedAt: null,
          },
        },
      },
      include: {
        gym: {
          select: gymSummarySelect,
        },
      },
    });
  }

  findActiveGymUnitByQrCodeToken(token: string): Promise<GymUnitWithGymSummaryRecord | null> {
    return this.prisma.gymUnit.findFirst({
      where: {
        qrCodeToken: token,
        status: 'ACTIVE',
        deletedAt: null,
        gym: {
          is: {
            status: 'ACTIVE',
            deletedAt: null,
          },
        },
      },
      include: {
        gym: {
          select: gymSummarySelect,
        },
      },
    });
  }

  async listGymUnits(
    input: ListGymUnitsQueryInput,
  ): Promise<{ data: GymUnitWithGymSummaryRecord[]; total: number }> {
    const where: Prisma.GymUnitWhereInput = {
      deletedAt: null,
      gym: {
        is: {
          deletedAt: null,
        },
      },
      ...(input.gymId ? { gymId: input.gymId } : {}),
      ...(input.status ? { status: input.status } : {}),
      ...(input.search
        ? {
            name: {
              contains: input.search,
              mode: 'insensitive',
            },
          }
        : {}),
      ...(input.city
        ? {
            city: {
              equals: input.city,
              mode: 'insensitive',
            },
          }
        : {}),
      ...(input.state
        ? {
            state: {
              equals: input.state,
              mode: 'insensitive',
            },
          }
        : {}),
    };

    const [data, total] = await this.prisma.$transaction([
      this.prisma.gymUnit.findMany({
        where,
        include: {
          gym: {
            select: gymSummarySelect,
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
        skip: (input.page - 1) * input.limit,
        take: input.limit,
      }),
      this.prisma.gymUnit.count({
        where,
      }),
    ]);

    return {
      data,
      total,
    };
  }

  listUnitsByGymId(gymId: string): Promise<GymUnitRecord[]> {
    return this.prisma.gymUnit.findMany({
      where: {
        gymId,
        deletedAt: null,
        gym: {
          is: {
            deletedAt: null,
          },
        },
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
  }

  async updateGymUnit(id: string, input: UpdateGymUnitInput): Promise<GymUnitWithGymSummaryRecord> {
    const data: Prisma.GymUnitUpdateInput = {};

    if ('name' in input) {
      data.name = input.name;
    }

    if ('addressLine' in input) {
      data.addressLine = input.addressLine;
    }

    if ('number' in input) {
      data.number = input.number;
    }

    if ('complement' in input) {
      data.complement = input.complement;
    }

    if ('neighborhood' in input) {
      data.neighborhood = input.neighborhood;
    }

    if ('city' in input) {
      data.city = input.city;
    }

    if ('state' in input) {
      data.state = input.state;
    }

    if ('zipCode' in input) {
      data.zipCode = input.zipCode;
    }

    if ('latitude' in input) {
      data.latitude = input.latitude;
    }

    if ('longitude' in input) {
      data.longitude = input.longitude;
    }

    try {
      return await this.prisma.gymUnit.update({
        where: { id },
        data,
        include: {
          gym: {
            select: gymSummarySelect,
          },
        },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new GymConflictError(getConflictField(error));
      }

      throw error;
    }
  }

  async updateGymStatus(id: string, status: GymStatus): Promise<GymRecord> {
    return this.prisma.gym.update({
      where: { id },
      data: {
        status,
      },
    });
  }

  async updateGymUnitStatus(
    id: string,
    status: GymUnitStatus,
  ): Promise<GymUnitWithGymSummaryRecord> {
    return this.prisma.gymUnit.update({
      where: { id },
      data: {
        status,
      },
      include: {
        gym: {
          select: gymSummarySelect,
        },
      },
    });
  }
}

const gymSummarySelect = {
  id: true,
  name: true,
  status: true,
} satisfies Prisma.GymSelect;
