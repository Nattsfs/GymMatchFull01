import { UserRole as PrismaUserRole } from '@prisma/client';
import type { FastifyPluginAsync } from 'fastify';

import { AuthService } from '../auth/auth.service.js';
import type { AuthServiceContract, AuthUsersServiceContract } from '../auth/auth.types.js';
import { createJwtAuthGuard } from '../auth/jwt-auth.guard.js';
import { createRolesGuard } from '../auth/roles.guard.js';
import type { AppConfig, AuthConfig, EmailConfig } from '../config/index.js';
import { HttpError } from '../common/errors/http-error.js';
import { MailService } from '../mail/mail.service.js';
import type { MailServiceContract } from '../mail/mail.service.js';
import { UsersService } from '../users/users.service.js';
import { parseCreateGymInput } from './dto/create-gym.dto.js';
import { parseCreateGymUnitInput } from './dto/create-gym-unit.dto.js';
import { parseListGymUnitsQuery } from './dto/list-gym-units-query.dto.js';
import { parseListGymsQuery } from './dto/list-gyms-query.dto.js';
import { parseUpdateGymInput } from './dto/update-gym.dto.js';
import { parseUpdateGymUnitInput } from './dto/update-gym-unit.dto.js';
import { GymsService } from './gyms.service.js';
import type { GymsServiceContract } from './gyms.types.js';

interface GymsRoutesOptions {
  appConfig: Pick<AppConfig, 'nodeEnv' | 'baseUrl' | 'mobileAppUrl' | 'adminWebUrl'>;
  authConfig: Pick<
    AuthConfig,
    'refreshTokenSecret' | 'refreshTokenExpiresIn' | 'passwordResetTokenExpiresInMinutes'
  >;
  emailConfig: EmailConfig;
  authService?: AuthServiceContract;
  gymsService?: GymsServiceContract;
  mailService?: MailServiceContract;
  usersService?: AuthUsersServiceContract;
}

export const gymsRoutes: FastifyPluginAsync<GymsRoutesOptions> = async (app, options) => {
  const usersService = options.usersService ?? new UsersService(app.prisma);
  const gymsService = options.gymsService ?? new GymsService(app.prisma);
  const mailService =
    options.mailService ??
    new MailService({
      emailConfig: options.emailConfig,
      nodeEnv: options.appConfig.nodeEnv,
      logger: app.log,
    });
  const authService =
    options.authService ??
    new AuthService(
      usersService,
      gymsService,
      {
        signAccessToken: (payload) => app.jwt.sign(payload),
        signRefreshToken: (payload) =>
          app.jwt.sign(payload, {
            key: options.authConfig.refreshTokenSecret,
            expiresIn: options.authConfig.refreshTokenExpiresIn,
          }),
        verifyRefreshToken: (token) =>
          app.jwt.verify(token, {
            key: options.authConfig.refreshTokenSecret,
          }),
      },
      mailService,
      {
        tokenExpiresInMinutes: options.authConfig.passwordResetTokenExpiresInMinutes,
        ...(options.appConfig.baseUrl ? { baseUrl: options.appConfig.baseUrl } : {}),
        ...(options.appConfig.mobileAppUrl ? { mobileAppUrl: options.appConfig.mobileAppUrl } : {}),
        ...(options.appConfig.adminWebUrl ? { adminWebUrl: options.appConfig.adminWebUrl } : {}),
      },
    );
  const authenticate = createJwtAuthGuard(authService);
  const requireAdmin = createRolesGuard([PrismaUserRole.ADMIN]);

  app.get('/public/gym-units/qr/:token', async (request) => {
    const token = parseRouteParam(request.params, 'token');

    return gymsService.validateGymUnitQrCodeToken(token);
  });

  app.post('/admin/gyms', { preHandler: [authenticate, requireAdmin] }, async (request, reply) => {
    const input = parseCreateGymInput(request.body);
    const gym = await gymsService.createGym(input);

    return reply.status(201).send(gym);
  });

  app.get('/admin/gyms', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const query = parseListGymsQuery(request.query);

    return gymsService.listGyms(query);
  });

  app.get('/admin/gyms/:id', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const gymId = parseRouteParam(request.params, 'id');

    return gymsService.getGymById(gymId);
  });

  app.patch('/admin/gyms/:id', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const gymId = parseRouteParam(request.params, 'id');
    const input = parseUpdateGymInput(request.body);

    return gymsService.updateGym(gymId, input);
  });

  app.patch(
    '/admin/gyms/:id/activate',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const gymId = parseRouteParam(request.params, 'id');

      return gymsService.activateGym(gymId);
    },
  );

  app.patch(
    '/admin/gyms/:id/deactivate',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const gymId = parseRouteParam(request.params, 'id');

      return gymsService.deactivateGym(gymId);
    },
  );

  app.post(
    '/admin/gym-units',
    { preHandler: [authenticate, requireAdmin] },
    async (request, reply) => {
      const input = parseCreateGymUnitInput(request.body);
      const gymUnit = await gymsService.createGymUnit(input);

      return reply.status(201).send(gymUnit);
    },
  );

  app.get('/admin/gym-units', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const query = parseListGymUnitsQuery(request.query);

    return gymsService.listGymUnits(query);
  });

  app.get('/admin/gym-units/:id', { preHandler: [authenticate, requireAdmin] }, async (request) => {
    const gymUnitId = parseRouteParam(request.params, 'id');

    return gymsService.getGymUnitById(gymUnitId);
  });

  app.patch(
    '/admin/gym-units/:id',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const gymUnitId = parseRouteParam(request.params, 'id');
      const input = parseUpdateGymUnitInput(request.body);

      return gymsService.updateGymUnit(gymUnitId, input);
    },
  );

  app.patch(
    '/admin/gym-units/:id/activate',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const gymUnitId = parseRouteParam(request.params, 'id');

      return gymsService.activateGymUnit(gymUnitId);
    },
  );

  app.patch(
    '/admin/gym-units/:id/deactivate',
    { preHandler: [authenticate, requireAdmin] },
    async (request) => {
      const gymUnitId = parseRouteParam(request.params, 'id');

      return gymsService.deactivateGymUnit(gymUnitId);
    },
  );
};

function parseRouteParam(payload: unknown, field: string): string {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Route params must be a JSON object.');
  }

  const value = payload[field];

  if (typeof value !== 'string' || value.trim().length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return value.trim();
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
