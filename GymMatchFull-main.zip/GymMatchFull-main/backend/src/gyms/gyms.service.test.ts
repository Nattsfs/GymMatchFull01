import { Prisma } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';
import { GymStatus as PrismaGymStatus, GymUnitStatus as PrismaGymUnitStatus } from '@prisma/client';
import { describe, expect, it } from 'vitest';

import { GymsRepository } from './gyms.repository.js';
import { GymsService } from './gyms.service.js';
import {
  type CreateGymInput,
  type CreateGymUnitInput,
  GymConflictError,
  GymNotFoundError,
  GymUnitNotFoundError,
  type GymRecord,
  type GymUnitRecord,
  type GymUnitWithGymSummaryRecord,
  type ListGymUnitsQueryInput,
  type UpdateGymUnitInput,
} from './gyms.types.js';

class InMemoryGymsRepository {
  private readonly gyms: GymRecord[] = [];
  private readonly gymUnits: GymUnitRecord[] = [];
  private nextGymId = 1;
  private nextGymUnitId = 1;

  async createGym(input: CreateGymInput): Promise<GymRecord> {
    if (input.document && this.gyms.some((gym) => gym.document === input.document)) {
      throw new GymConflictError('document');
    }

    const now = new Date();
    const gym: GymRecord = {
      id: `gym_${this.nextGymId++}`,
      name: input.name,
      legalName: input.legalName ?? null,
      document: input.document ?? null,
      email: input.email ?? null,
      phone: input.phone ?? null,
      status: input.status ?? PrismaGymStatus.ACTIVE,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.gyms.push(gym);

    return cloneGym(gym);
  }

  async findGymById(id: string): Promise<GymRecord | null> {
    const gym = this.gyms.find((storedGym) => storedGym.id === id && storedGym.deletedAt === null);

    return gym ? cloneGym(gym) : null;
  }

  async createGymUnit(input: CreateGymUnitInput): Promise<GymUnitWithGymSummaryRecord> {
    if (
      this.gymUnits.some((gymUnit) => gymUnit.gymId === input.gymId && gymUnit.name === input.name)
    ) {
      throw new GymConflictError('unitName');
    }

    const qrCodeToken = input.qrCodeToken ?? `seed_qr_token_${this.nextGymUnitId}`;

    if (this.gymUnits.some((gymUnit) => gymUnit.qrCodeToken === qrCodeToken)) {
      throw new GymConflictError('qrCodeToken');
    }

    const gymSummary = this.getGymSummaryById(input.gymId);

    if (!gymSummary) {
      throw new GymNotFoundError();
    }

    const now = new Date();
    const gymUnit: GymUnitRecord = {
      id: `gym_unit_${this.nextGymUnitId++}`,
      gymId: input.gymId,
      qrCodeToken,
      name: input.name,
      addressLine: input.addressLine ?? null,
      number: input.number ?? null,
      complement: input.complement ?? null,
      neighborhood: input.neighborhood ?? null,
      city: input.city ?? null,
      state: input.state ?? null,
      zipCode: input.zipCode ?? null,
      latitude: input.latitude !== undefined ? new Prisma.Decimal(input.latitude) : null,
      longitude: input.longitude !== undefined ? new Prisma.Decimal(input.longitude) : null,
      status: input.status ?? PrismaGymUnitStatus.ACTIVE,
      createdAt: now,
      updatedAt: now,
      deletedAt: input.deletedAt ?? null,
    };

    this.gymUnits.push(gymUnit);

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  async findGymUnitById(id: string): Promise<GymUnitRecord | null> {
    const gymUnit = this.gymUnits.find(
      (storedGymUnit) => storedGymUnit.id === id && storedGymUnit.deletedAt === null,
    );

    if (!gymUnit) {
      return null;
    }

    return this.getGymSummaryById(gymUnit.gymId) ? cloneGymUnit(gymUnit) : null;
  }

  async findGymUnitByIdWithGym(id: string): Promise<GymUnitWithGymSummaryRecord | null> {
    const gymUnit = this.gymUnits.find(
      (storedGymUnit) => storedGymUnit.id === id && storedGymUnit.deletedAt === null,
    );

    if (!gymUnit) {
      return null;
    }

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    return gymSummary ? cloneGymUnitWithGymSummary(gymUnit, gymSummary) : null;
  }

  async findActiveGymUnitByQrCodeToken(token: string): Promise<GymUnitWithGymSummaryRecord | null> {
    const gymUnit = this.gymUnits.find(
      (storedGymUnit) =>
        storedGymUnit.qrCodeToken === token &&
        storedGymUnit.status === PrismaGymUnitStatus.ACTIVE &&
        storedGymUnit.deletedAt === null,
    );

    if (!gymUnit) {
      return null;
    }

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    if (!gymSummary || gymSummary.status !== PrismaGymStatus.ACTIVE) {
      return null;
    }

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  async listGymUnits(
    input: ListGymUnitsQueryInput,
  ): Promise<{ data: GymUnitWithGymSummaryRecord[]; total: number }> {
    let data = this.gymUnits.filter((gymUnit) => {
      if (gymUnit.deletedAt !== null) {
        return false;
      }

      return this.getGymSummaryById(gymUnit.gymId) !== null;
    });

    if (input.gymId) {
      data = data.filter((gymUnit) => gymUnit.gymId === input.gymId);
    }

    if (input.status) {
      data = data.filter((gymUnit) => gymUnit.status === input.status);
    }

    if (input.search) {
      const normalizedSearch = input.search.toLowerCase();

      data = data.filter((gymUnit) => gymUnit.name.toLowerCase().includes(normalizedSearch));
    }

    if (input.city) {
      const normalizedCity = input.city.toLowerCase();

      data = data.filter((gymUnit) => (gymUnit.city?.toLowerCase() ?? '') === normalizedCity);
    }

    if (input.state) {
      const normalizedState = input.state.toUpperCase();

      data = data.filter((gymUnit) => (gymUnit.state?.toUpperCase() ?? '') === normalizedState);
    }

    data.sort((left, right) => right.createdAt.getTime() - left.createdAt.getTime());

    return {
      data: data
        .slice((input.page - 1) * input.limit, (input.page - 1) * input.limit + input.limit)
        .map((gymUnit) => {
          const gymSummary = this.getGymSummaryById(gymUnit.gymId);

          if (!gymSummary) {
            throw new GymNotFoundError();
          }

          return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
        }),
      total: data.length,
    };
  }

  async listUnitsByGymId(gymId: string): Promise<GymUnitRecord[]> {
    return this.gymUnits
      .filter(
        (gymUnit) =>
          gymUnit.gymId === gymId &&
          gymUnit.deletedAt === null &&
          this.getGymSummaryById(gymUnit.gymId) !== null,
      )
      .sort((left, right) => left.createdAt.getTime() - right.createdAt.getTime())
      .map(cloneGymUnit);
  }

  async updateGymUnit(id: string, input: UpdateGymUnitInput): Promise<GymUnitWithGymSummaryRecord> {
    const gymUnit = this.gymUnits.find((storedGymUnit) => storedGymUnit.id === id);

    if (!gymUnit) {
      throw new GymUnitNotFoundError();
    }

    if (
      'name' in input &&
      input.name &&
      this.gymUnits.some(
        (storedGymUnit) =>
          storedGymUnit.id !== id &&
          storedGymUnit.gymId === gymUnit.gymId &&
          storedGymUnit.name === input.name,
      )
    ) {
      throw new GymConflictError('unitName');
    }

    if ('name' in input && input.name !== undefined) {
      gymUnit.name = input.name;
    }

    if ('addressLine' in input) {
      gymUnit.addressLine = input.addressLine ?? null;
    }

    if ('number' in input) {
      gymUnit.number = input.number ?? null;
    }

    if ('complement' in input) {
      gymUnit.complement = input.complement ?? null;
    }

    if ('neighborhood' in input) {
      gymUnit.neighborhood = input.neighborhood ?? null;
    }

    if ('city' in input) {
      gymUnit.city = input.city ?? null;
    }

    if ('state' in input) {
      gymUnit.state = input.state ?? null;
    }

    if ('zipCode' in input) {
      gymUnit.zipCode = input.zipCode ?? null;
    }

    if ('latitude' in input) {
      gymUnit.latitude = input.latitude === null ? null : new Prisma.Decimal(input.latitude);
    }

    if ('longitude' in input) {
      gymUnit.longitude = input.longitude === null ? null : new Prisma.Decimal(input.longitude);
    }

    gymUnit.updatedAt = new Date();

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    if (!gymSummary) {
      throw new GymNotFoundError();
    }

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  async updateGymStatus(id: string, status: PrismaGymStatus): Promise<GymRecord> {
    const gym = this.gyms.find((storedGym) => storedGym.id === id);

    if (!gym) {
      throw new GymNotFoundError();
    }

    gym.status = status;
    gym.updatedAt = new Date();

    return cloneGym(gym);
  }

  async updateGymUnitStatus(
    id: string,
    status: PrismaGymUnitStatus,
  ): Promise<GymUnitWithGymSummaryRecord> {
    const gymUnit = this.gymUnits.find((storedGymUnit) => storedGymUnit.id === id);

    if (!gymUnit) {
      throw new GymUnitNotFoundError();
    }

    gymUnit.status = status;
    gymUnit.updatedAt = new Date();

    const gymSummary = this.getGymSummaryById(gymUnit.gymId);

    if (!gymSummary) {
      throw new GymNotFoundError();
    }

    return cloneGymUnitWithGymSummary(gymUnit, gymSummary);
  }

  softDeleteGym(id: string, deletedAt: Date): void {
    const gym = this.gyms.find((storedGym) => storedGym.id === id);

    if (gym) {
      gym.deletedAt = deletedAt;
      gym.updatedAt = deletedAt;
    }
  }

  softDeleteGymUnit(id: string, deletedAt: Date): void {
    const gymUnit = this.gymUnits.find((storedGymUnit) => storedGymUnit.id === id);

    if (gymUnit) {
      gymUnit.deletedAt = deletedAt;
      gymUnit.updatedAt = deletedAt;
    }
  }

  private getGymSummaryById(gymId: string): Pick<GymRecord, 'id' | 'name' | 'status'> | null {
    const gym = this.gyms.find(
      (storedGym) => storedGym.id === gymId && storedGym.deletedAt === null,
    );

    if (!gym) {
      return null;
    }

    return {
      id: gym.id,
      name: gym.name,
      status: gym.status,
    };
  }
}

function cloneGym(gym: GymRecord): GymRecord {
  return {
    ...gym,
  };
}

function cloneGymUnit(gymUnit: GymUnitRecord): GymUnitRecord {
  return {
    ...gymUnit,
  };
}

function cloneGymUnitWithGymSummary(
  gymUnit: GymUnitRecord,
  gym: Pick<GymRecord, 'id' | 'name' | 'status'>,
): GymUnitWithGymSummaryRecord {
  return {
    ...cloneGymUnit(gymUnit),
    gym: {
      ...gym,
    },
  };
}

function makeCreateGymInput(overrides: Partial<CreateGymInput> = {}): CreateGymInput {
  return {
    name: 'GymMatch Moema',
    legalName: 'GymMatch Moema LTDA',
    document: '12345678000199',
    email: 'contato@gymmatchmoema.com',
    phone: '1130004000',
    ...overrides,
  };
}

function makeCreateGymUnitInput(overrides: Partial<CreateGymUnitInput> = {}): CreateGymUnitInput {
  return {
    gymId: 'gym_1',
    name: 'Moema I',
    addressLine: 'Avenida Ibirapuera',
    number: '1000',
    neighborhood: 'Moema',
    city: 'Sao Paulo',
    state: 'SP',
    zipCode: '04028-003',
    ...overrides,
  };
}

function createGymsService(): GymsService {
  const repository = new InMemoryGymsRepository();

  return new GymsService({} as PrismaClient, repository as unknown as GymsRepository);
}

function createGymsServiceWithRepository(): {
  service: GymsService;
  repository: InMemoryGymsRepository;
} {
  const repository = new InMemoryGymsRepository();
  const service = new GymsService({} as PrismaClient, repository as unknown as GymsRepository);

  return {
    service,
    repository,
  };
}

describe('GymsService', () => {
  it('creates a valid gym', async () => {
    const service = createGymsService();

    const gym = await service.createGym(makeCreateGymInput());

    expect(gym.name).toBe('GymMatch Moema');
    expect(gym.document).toBe('12345678000199');
    expect(gym.status).toBe(PrismaGymStatus.ACTIVE);
    expect(gym.deletedAt).toBeNull();
  });

  it('finds a gym by id', async () => {
    const service = createGymsService();
    const createdGym = await service.createGym(makeCreateGymInput());

    const gym = await service.findGymById(createdGym.id);

    expect(gym).toEqual(createdGym);
  });

  it('creates a valid gym unit linked to an existing gym', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());

    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    expect(gymUnit.gymId).toBe(gym.id);
    expect(gymUnit.name).toBe('Moema I');
    expect(gymUnit.status).toBe(PrismaGymUnitStatus.ACTIVE);
    expect(gymUnit.qrCodeToken).toMatch(/^[0-9a-f]{48}$/);
  });

  it('generates unique qrCodeToken values for different gym units', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());

    const firstGymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
        name: 'Moema I',
      }),
    );
    const secondGymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
        name: 'Moema II',
      }),
    );

    expect(firstGymUnit.qrCodeToken).toMatch(/^[0-9a-f]{48}$/);
    expect(secondGymUnit.qrCodeToken).toMatch(/^[0-9a-f]{48}$/);
    expect(firstGymUnit.qrCodeToken).not.toBe(secondGymUnit.qrCodeToken);
  });

  it('prevents creating a gym unit without an existing gym', async () => {
    const service = createGymsService();

    await expect(
      service.createGymUnit(
        makeCreateGymUnitInput({
          gymId: 'gym_missing',
        }),
      ),
    ).rejects.toMatchObject({
      name: 'HttpError',
      statusCode: 404,
      message: 'Gym not found.',
    });
  });

  it('finds a gym unit by id', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const createdGymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    const gymUnit = await service.findGymUnitById(createdGymUnit.id);

    expect(gymUnit).toMatchObject({
      id: createdGymUnit.id,
      gymId: gym.id,
      name: createdGymUnit.name,
      status: createdGymUnit.status,
    });
    expect(gymUnit).not.toHaveProperty('gym');
  });

  it('gets a gym unit by id with gym summary', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const createdGymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    const gymUnit = await service.getGymUnitById(createdGymUnit.id);

    expect(gymUnit).toMatchObject({
      id: createdGymUnit.id,
      gymId: gym.id,
      name: 'Moema I',
      qrCodeToken: createdGymUnit.qrCodeToken,
      gym: {
        id: gym.id,
        name: gym.name,
        status: gym.status,
      },
    });
  });

  it('lists units for the correct gym only', async () => {
    const service = createGymsService();
    const gymA = await service.createGym(makeCreateGymInput());
    const gymB = await service.createGym(
      makeCreateGymInput({
        name: 'GymMatch Vila Mariana',
        legalName: 'GymMatch Vila Mariana LTDA',
        document: '10987654000188',
        email: 'contato-vm@gymmatch.com',
      }),
    );

    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymA.id,
        name: 'Moema I',
      }),
    );
    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymA.id,
        name: 'Moema II',
      }),
    );
    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymB.id,
        name: 'Vila Mariana I',
      }),
    );

    const gymAUnits = await service.listUnitsByGymId(gymA.id);

    expect(gymAUnits).toHaveLength(2);
    expect(gymAUnits.every((gymUnit) => gymUnit.gymId === gymA.id)).toBe(true);
    expect(gymAUnits.map((gymUnit) => gymUnit.name)).toEqual(['Moema I', 'Moema II']);
  });

  it('lists gym units with pagination and filters', async () => {
    const service = createGymsService();
    const gymA = await service.createGym(makeCreateGymInput());
    const gymB = await service.createGym(
      makeCreateGymInput({
        name: 'GymMatch Centro',
        legalName: 'GymMatch Centro LTDA',
        document: '10987654000188',
        email: 'centro@gymmatch.com',
      }),
    );

    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymA.id,
        name: 'Centro Prime',
        city: 'Sao Paulo',
        state: 'SP',
      }),
    );
    const inactiveGymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymA.id,
        name: 'Centro Inativo',
        city: 'Sao Paulo',
        state: 'SP',
      }),
    );
    await service.deactivateGymUnit(inactiveGymUnit.id);
    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymB.id,
        name: 'Centro Prime',
        city: 'Campinas',
        state: 'SP',
      }),
    );

    const result = await service.listGymUnits({
      page: 1,
      limit: 10,
      gymId: gymA.id,
      status: PrismaGymUnitStatus.ACTIVE,
      city: 'sao paulo',
      state: 'SP',
      search: 'prime',
    });

    expect(result.pagination).toMatchObject({
      page: 1,
      limit: 10,
      total: 1,
      totalPages: 1,
    });
    expect(result.data).toHaveLength(1);
    expect(result.data[0]).toMatchObject({
      gymId: gymA.id,
      name: 'Centro Prime',
      status: PrismaGymUnitStatus.ACTIVE,
      gym: {
        id: gymA.id,
        name: gymA.name,
      },
    });
    expect(result.data[0]).not.toHaveProperty('qrCodeToken');
  });

  it('updates a gym unit while keeping the same gymId', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
        latitude: -23.5,
        longitude: -46.6,
      }),
    );

    const updatedGymUnit = await service.updateGymUnit(gymUnit.id, {
      name: 'Moema Atualizada',
      addressLine: null,
      state: 'RJ',
      zipCode: '20040020',
      latitude: null,
    });

    expect(updatedGymUnit).toMatchObject({
      id: gymUnit.id,
      gymId: gym.id,
      qrCodeToken: gymUnit.qrCodeToken,
      name: 'Moema Atualizada',
      addressLine: null,
      state: 'RJ',
      zipCode: '20040020',
      latitude: null,
      longitude: -46.6,
      gym: {
        id: gym.id,
        name: gym.name,
      },
    });
  });

  it('deactivates and activates a gym without propagating to its units', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    const deactivatedGym = await service.deactivateGym(gym.id);
    const reactivatedGym = await service.activateGym(gym.id);
    const storedGymUnit = await service.findGymUnitById(gymUnit.id);

    expect(deactivatedGym.status).toBe(PrismaGymStatus.INACTIVE);
    expect(reactivatedGym.status).toBe(PrismaGymStatus.ACTIVE);
    expect(storedGymUnit?.status).toBe(PrismaGymUnitStatus.ACTIVE);
  });

  it('deactivates and activates a gym unit', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    const deactivatedGymUnit = await service.deactivateGymUnit(gymUnit.id);
    const reactivatedGymUnit = await service.activateGymUnit(gymUnit.id);

    expect(deactivatedGymUnit.status).toBe(PrismaGymUnitStatus.INACTIVE);
    expect(reactivatedGymUnit.status).toBe(PrismaGymUnitStatus.ACTIVE);
    expect(deactivatedGymUnit.qrCodeToken).toBe(gymUnit.qrCodeToken);
    expect(reactivatedGymUnit.qrCodeToken).toBe(gymUnit.qrCodeToken);
  });

  it('validates a qrCodeToken and returns only public gym and unit data', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
        city: 'Sao Paulo',
        state: 'SP',
      }),
    );

    const result = await service.validateGymUnitQrCodeToken(gymUnit.qrCodeToken);

    expect(result).toEqual({
      valid: true,
      gym: {
        id: gym.id,
        name: gym.name,
      },
      unit: {
        id: gymUnit.id,
        name: gymUnit.name,
        city: 'Sao Paulo',
        state: 'SP',
      },
    });
    expect(result).not.toHaveProperty('qrCodeToken');
    expect(result).not.toHaveProperty('status');
    if (!result.valid) {
      throw new Error('Expected QR validation to succeed in this test.');
    }
    expect(result.gym).not.toHaveProperty('document');
    expect(result.gym).not.toHaveProperty('email');
    expect(result.gym).not.toHaveProperty('phone');
  });

  it('returns valid false for an invalid qrCodeToken', async () => {
    const service = createGymsService();

    const result = await service.validateGymUnitQrCodeToken('invalid-token');

    expect(result).toEqual({
      valid: false,
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('does not validate qrCodeToken for an inactive unit', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    await service.deactivateGymUnit(gymUnit.id);

    const result = await service.validateGymUnitQrCodeToken(gymUnit.qrCodeToken);

    expect(result).toEqual({
      valid: false,
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('does not validate qrCodeToken for an inactive gym', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    await service.deactivateGym(gym.id);

    const result = await service.validateGymUnitQrCodeToken(gymUnit.qrCodeToken);

    expect(result).toEqual({
      valid: false,
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('does not validate qrCodeToken for a soft deleted unit', async () => {
    const { service, repository } = createGymsServiceWithRepository();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    repository.softDeleteGymUnit(gymUnit.id, new Date('2026-05-09T00:00:00.000Z'));

    const result = await service.validateGymUnitQrCodeToken(gymUnit.qrCodeToken);

    expect(result).toEqual({
      valid: false,
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('does not validate qrCodeToken for a soft deleted gym', async () => {
    const { service, repository } = createGymsServiceWithRepository();
    const gym = await service.createGym(
      makeCreateGymInput({
        name: 'GymMatch Arquivada',
        document: '55544433000122',
      }),
    );
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    repository.softDeleteGym(gym.id, new Date('2026-05-09T00:00:00.000Z'));

    const result = await service.validateGymUnitQrCodeToken(gymUnit.qrCodeToken);

    expect(result).toEqual({
      valid: false,
      message: 'QR Code invalido ou indisponivel.',
    });
  });

  it('prevents creating a gym unit for an inactive gym', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    await service.deactivateGym(gym.id);

    await expect(
      service.createGymUnit(
        makeCreateGymUnitInput({
          gymId: gym.id,
        }),
      ),
    ).rejects.toMatchObject({
      name: 'HttpError',
      statusCode: 409,
      message: 'Gym must be active to create or activate units.',
    });
  });

  it('prevents activating a gym unit when the parent gym is inactive', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());
    const gymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
      }),
    );

    await service.deactivateGym(gym.id);
    await service.deactivateGymUnit(gymUnit.id);

    await expect(service.activateGymUnit(gymUnit.id)).rejects.toMatchObject({
      name: 'HttpError',
      statusCode: 409,
      message: 'Gym must be active to create or activate units.',
    });
  });

  it('prevents duplicate gym documents', async () => {
    const service = createGymsService();

    await service.createGym(makeCreateGymInput());

    await expect(
      service.createGym(
        makeCreateGymInput({
          name: 'Outra GymMatch',
          email: 'outra@gymmatch.com',
        }),
      ),
    ).rejects.toMatchObject({
      name: 'HttpError',
      statusCode: 409,
      message: 'A record with the same gym document already exists.',
    });
  });

  it('prevents duplicate unit names inside the same gym', async () => {
    const service = createGymsService();
    const gym = await service.createGym(makeCreateGymInput());

    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gym.id,
        name: 'Moema I',
      }),
    );

    await expect(
      service.createGymUnit(
        makeCreateGymUnitInput({
          gymId: gym.id,
          name: 'Moema I',
          zipCode: '04546-042',
        }),
      ),
    ).rejects.toMatchObject({
      name: 'HttpError',
      statusCode: 409,
      message: 'A record with the same gym unit name within the same gym already exists.',
    });
  });

  it('allows the same unit name in different gyms', async () => {
    const service = createGymsService();
    const gymA = await service.createGym(makeCreateGymInput());
    const gymB = await service.createGym(
      makeCreateGymInput({
        name: 'GymMatch Pinheiros',
        legalName: 'GymMatch Pinheiros LTDA',
        document: '99887766000155',
        email: 'pinheiros@gymmatch.com',
      }),
    );

    const gymAUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymA.id,
        name: 'Unidade Central',
      }),
    );
    const gymBUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: gymB.id,
        name: 'Unidade Central',
      }),
    );

    expect(gymAUnit.gymId).toBe(gymA.id);
    expect(gymBUnit.gymId).toBe(gymB.id);
    expect(gymAUnit.name).toBe(gymBUnit.name);
  });

  it('hides soft deleted gyms and units from standard queries', async () => {
    const service = createGymsService();
    const deletedGym = await service.createGym(
      makeCreateGymInput({
        name: 'GymMatch Arquivada',
        document: '55544433000122',
        deletedAt: new Date('2026-05-09T00:00:00.000Z'),
      }),
    );
    const activeGym = await service.createGym(
      makeCreateGymInput({
        name: 'GymMatch Ativa',
        document: '22233344000111',
      }),
    );

    const deletedGymUnit = await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: activeGym.id,
        name: 'Unidade Oculta',
        deletedAt: new Date('2026-05-09T00:00:00.000Z'),
      }),
    );
    await service.createGymUnit(
      makeCreateGymUnitInput({
        gymId: activeGym.id,
        name: 'Unidade Visivel',
      }),
    );

    const foundDeletedGym = await service.findGymById(deletedGym.id);
    const foundDeletedGymUnit = await service.findGymUnitById(deletedGymUnit.id);
    const listedUnits = await service.listUnitsByGymId(activeGym.id);

    expect(foundDeletedGym).toBeNull();
    expect(foundDeletedGymUnit).toBeNull();
    expect(listedUnits).toHaveLength(1);
    expect(listedUnits[0]?.name).toBe('Unidade Visivel');
  });
});
