import type { FastifyInstance } from 'fastify';

async function start(): Promise<void> {
  let app: FastifyInstance | undefined;

  try {
    const [{ buildApp }, { config }] = await Promise.all([
      import('./app.js'),
      import('./config/index.js'),
    ]);

    app = buildApp({ config });

    const address = await app.listen({
      host: '0.0.0.0',
      port: config.app.port,
    });

    console.info(`${config.app.name} is running on ${address} in ${config.app.nodeEnv} mode.`);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown startup error.';

    console.error(`Failed to start GymMatch API.\n${message}`);

    if (app) {
      await app.close().catch(() => undefined);
    }

    process.exitCode = 1;
  }
}

void start();
