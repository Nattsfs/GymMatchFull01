import multipart from '@fastify/multipart';
import websocket from '@fastify/websocket';
import jwt from '@fastify/jwt';
import sensible from '@fastify/sensible';
import Fastify, { type FastifyInstance, type FastifyServerOptions } from 'fastify';

import { adminMetricsRoutes } from './admin-metrics/admin-metrics.route.js';
import type { AdminMetricsServiceContract } from './admin-metrics/admin-metrics.types.js';
import { adminUsersRoutes } from './users/admin-users.route.js';
import type { AuthServiceContract, AuthUsersServiceContract } from './auth/auth.types.js';
import { authRoutes } from './auth/auth.route.js';
import { blocksRoutes } from './blocks/blocks.route.js';
import type { BlocksServiceContract } from './blocks/blocks.types.js';
import { ChatRealtimeGateway, chatGatewayRoutes } from './chat/chat.gateway.js';
import type { ChatRealtimeGatewayContract } from './chat/chat.gateway.js';
import { chatRoutes } from './chat/chat.route.js';
import type { ChatServiceContract } from './chat/chat.types.js';
import type { Config } from './config/index.js';
import { registerErrorHandler } from './common/errors/error-handler.js';
import { registerNotFoundHandler } from './common/not-found/not-found-handler.js';
import { registerDatabase } from './database/index.js';
import { discoveryRoutes } from './discovery/discovery.route.js';
import type { DiscoveryServiceContract } from './discovery/discovery.types.js';
import { gymsRoutes } from './gyms/gyms.route.js';
import { healthRoutes } from './health/health.route.js';
import { likesRoutes } from './likes/likes.route.js';
import { matchesRoutes } from './matches/matches.route.js';
import type { MatchesServiceContract } from './matches/matches.types.js';
import type { MailServiceContract } from './mail/mail.service.js';
import type { GymsServiceContract } from './gyms/gyms.types.js';
import type { LikesServiceContract } from './likes/likes.types.js';
import { profilesRoutes } from './profiles/profiles.route.js';
import type { ProfilesServiceContract } from './profiles/profiles.types.js';
import { reportsRoutes } from './reports/reports.route.js';
import type { ReportsServiceContract } from './reports/reports.types.js';
import { rejectionsRoutes } from './rejections/rejections.route.js';
import type { RejectionsServiceContract } from './rejections/rejections.types.js';
import type { AdminUsersServiceContract } from './users/users.types.js';

export interface BuildAppOptions {
  config: Config;
  logger?: FastifyServerOptions['logger'];
  services?: {
    adminMetricsService?: AdminMetricsServiceContract;
    adminUsersService?: AdminUsersServiceContract;
    authService?: AuthServiceContract;
    blocksService?: BlocksServiceContract;
    chatRealtimeGateway?: ChatRealtimeGatewayContract;
    chatService?: ChatServiceContract;
    discoveryService?: DiscoveryServiceContract;
    gymsService?: GymsServiceContract;
    likesService?: LikesServiceContract;
    mailService?: MailServiceContract;
    matchesService?: MatchesServiceContract;
    profilesService?: ProfilesServiceContract;
    reportsService?: ReportsServiceContract;
    rejectionsService?: RejectionsServiceContract;
    usersService?: AuthUsersServiceContract;
  };
}

type LoggerConfig = Exclude<FastifyServerOptions['logger'], undefined>;

function resolveLogger(options: BuildAppOptions): LoggerConfig {
  if (options.logger !== undefined) {
    return options.logger;
  }

  if (options.config.app.nodeEnv === 'test') {
    return false;
  }

  return {
    level: options.config.logs.level,
  };
}

export function buildApp(options: BuildAppOptions): FastifyInstance {
  const logger = resolveLogger(options);
  const app = Fastify({
    logger,
  });

  registerDatabase(app, options.config);
  app.register(sensible);
  app.register(multipart);
  app.register(jwt, {
    secret: options.config.auth.jwtSecret,
    sign: {
      expiresIn: options.config.auth.jwtExpiresIn,
    },
  });
  app.register(websocket);
  registerErrorHandler(app, options.config.app.nodeEnv);
  registerNotFoundHandler(app);
  const chatRealtimeGateway =
    options.services?.chatRealtimeGateway ?? new ChatRealtimeGateway();
  app.register(healthRoutes, {
    appConfig: {
      name: options.config.app.name,
      nodeEnv: options.config.app.nodeEnv,
    },
  });
  app.register(authRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(adminMetricsRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.adminMetricsService
      ? { adminMetricsService: options.services.adminMetricsService }
      : {}),
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(adminUsersRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.adminUsersService
      ? { adminUsersService: options.services.adminUsersService }
      : {}),
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(chatGatewayRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    chatRealtimeGateway,
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(chatRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.chatService ? { chatService: options.services.chatService } : {}),
    messageEventPublisher: chatRealtimeGateway,
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(blocksRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.blocksService ? { blocksService: options.services.blocksService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(gymsRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(profilesRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.profilesService
      ? { profilesService: options.services.profilesService }
      : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(discoveryRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.discoveryService
      ? { discoveryService: options.services.discoveryService }
      : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(likesRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.likesService ? { likesService: options.services.likesService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(matchesRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.matchesService
      ? { matchesService: options.services.matchesService }
      : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(rejectionsRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.rejectionsService
      ? { rejectionsService: options.services.rejectionsService }
      : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });
  app.register(reportsRoutes, {
    appConfig: {
      nodeEnv: options.config.app.nodeEnv,
      ...(options.config.app.baseUrl ? { baseUrl: options.config.app.baseUrl } : {}),
      ...(options.config.app.mobileAppUrl ? { mobileAppUrl: options.config.app.mobileAppUrl } : {}),
      ...(options.config.app.adminWebUrl ? { adminWebUrl: options.config.app.adminWebUrl } : {}),
    },
    authConfig: {
      refreshTokenSecret: options.config.auth.refreshTokenSecret,
      refreshTokenExpiresIn: options.config.auth.refreshTokenExpiresIn,
      passwordResetTokenExpiresInMinutes: options.config.auth.passwordResetTokenExpiresInMinutes,
    },
    emailConfig: options.config.email,
    ...(options.services?.authService ? { authService: options.services.authService } : {}),
    ...(options.services?.gymsService ? { gymsService: options.services.gymsService } : {}),
    ...(options.services?.mailService ? { mailService: options.services.mailService } : {}),
    ...(options.services?.reportsService ? { reportsService: options.services.reportsService } : {}),
    ...(options.services?.usersService ? { usersService: options.services.usersService } : {}),
  });

  return app;
}
