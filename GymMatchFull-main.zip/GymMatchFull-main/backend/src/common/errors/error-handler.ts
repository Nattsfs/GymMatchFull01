import type { FastifyInstance, RawServerBase } from 'fastify';

import type { NodeEnv } from '../../config/index.js';
import { createErrorResponse } from './error-response.js';

function getStatusCode(error: unknown): number {
  if (
    typeof error === 'object' &&
    error !== null &&
    'statusCode' in error &&
    typeof error.statusCode === 'number' &&
    error.statusCode >= 400 &&
    error.statusCode < 600
  ) {
    return error.statusCode;
  }

  return 500;
}

function getMessage(error: unknown, statusCode: number, nodeEnv: NodeEnv): string {
  if (statusCode >= 500) {
    if (nodeEnv !== 'production' && error instanceof Error && error.message) {
      return error.message;
    }

    return 'Internal server error.';
  }

  if (error instanceof Error && error.message) {
    return error.message;
  }

  return 'Request failed.';
}

export function registerErrorHandler<TServer extends RawServerBase>(
  app: FastifyInstance<TServer>,
  nodeEnv: NodeEnv,
): void {
  app.setErrorHandler((error, request, reply) => {
    const statusCode = getStatusCode(error);

    if (statusCode >= 500) {
      request.log.error({ err: error }, 'Unhandled request error');
    }

    return reply
      .status(statusCode)
      .send(createErrorResponse(statusCode, getMessage(error, statusCode, nodeEnv)));
  });
}
