import { STATUS_CODES } from 'node:http';

export interface ErrorResponse {
  statusCode: number;
  error: string;
  message: string;
}

export function createErrorResponse(statusCode: number, message: string): ErrorResponse {
  return {
    statusCode,
    error: STATUS_CODES[statusCode] ?? 'Error',
    message,
  };
}
