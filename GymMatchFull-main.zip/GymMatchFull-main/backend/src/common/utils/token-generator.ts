import { randomBytes } from 'node:crypto';

const GYM_UNIT_QR_CODE_TOKEN_BYTES = 24;

export function generateGymUnitQrCodeToken(): string {
  return randomBytes(GYM_UNIT_QR_CODE_TOKEN_BYTES).toString('hex');
}
