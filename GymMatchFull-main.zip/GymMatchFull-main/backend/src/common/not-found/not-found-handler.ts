import type { FastifyInstance, RawServerBase } from 'fastify';

import { createErrorResponse } from '../errors/error-response.js';

export function registerNotFoundHandler<TServer extends RawServerBase>(
  app: FastifyInstance<TServer>,
): void {
  app.setNotFoundHandler((request, reply) => {
    return reply
      .status(404)
      .send(createErrorResponse(404, `Route ${request.method} ${request.url} not found.`));
  });
}
