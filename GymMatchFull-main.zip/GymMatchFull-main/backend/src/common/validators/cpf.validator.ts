const invalidRepeatedDigitsPattern = /^(\d)\1{10}$/;

export function normalizeCpf(value: string): string {
  return value.replace(/\D/g, '');
}

export function isValidCpf(value: string): boolean {
  const normalizedCpf = normalizeCpf(value);

  if (normalizedCpf.length !== 11 || invalidRepeatedDigitsPattern.test(normalizedCpf)) {
    return false;
  }

  const digits = normalizedCpf.split('').map(Number);
  const firstCheckDigit = calculateCpfCheckDigit(digits.slice(0, 9), 10);
  const secondCheckDigit = calculateCpfCheckDigit(digits.slice(0, 10), 11);

  return digits[9] === firstCheckDigit && digits[10] === secondCheckDigit;
}

function calculateCpfCheckDigit(digits: number[], initialWeight: number): number {
  const sum = digits.reduce((accumulator, digit, index) => {
    return accumulator + digit * (initialWeight - index);
  }, 0);
  const remainder = (sum * 10) % 11;

  return remainder === 10 ? 0 : remainder;
}
