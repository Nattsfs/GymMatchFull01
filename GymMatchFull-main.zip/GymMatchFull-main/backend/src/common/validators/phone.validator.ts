export function normalizePhone(value: string): string {
  return value.replace(/\D/g, '');
}

export function isValidPhone(value: string): boolean {
  const normalizedPhone = normalizePhone(value);

  return normalizedPhone.length >= 10 && normalizedPhone.length <= 15;
}
