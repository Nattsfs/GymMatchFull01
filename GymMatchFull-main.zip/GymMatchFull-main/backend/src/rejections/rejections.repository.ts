import { Prisma } from '@prisma/client';
import type { PrismaClient } from '@prisma/client';

import type { CreateRejectionInput, RejectionRecord } from './rejections.types.js';
import { RejectionConflictError, RejectionSelfRejectionError } from './rejections.types.js';

const REJECTION_ORDER_BY: Prisma.RejectionOrderByWithRelationInput[] = [
  { createdAt: 'desc' },
  { id: 'asc' },
];

function getConflictField(
  error: Prisma.PrismaClientKnownRequestError,
): RejectionConflictError['field'] {
  const target = Array.isArray(error.meta?.target)
    ? error.meta.target
    : typeof error.meta?.target === 'string'
      ? [error.meta.target]
      : [];

  if (target.includes('rejectedByUserId') && target.includes('rejectedUserId')) {
    return 'userPair';
  }

  return 'unknown';
}

function isSelfRejectionConstraintError(error: Prisma.PrismaClientKnownRequestError): boolean {
  if (error.code !== 'P2004') {
    return false;
  }

  return String(error.meta?.database_error ?? '').includes(
    'Rejection_rejectedByUserId_rejectedUserId_check',
  );
}

export class RejectionsRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async createRejection(input: CreateRejectionInput): Promise<RejectionRecord> {
    if (input.rejectedByUserId === input.rejectedUserId) {
      throw new RejectionSelfRejectionError();
    }

    const data: Prisma.RejectionCreateInput = {
      rejectedByUser: {
        connect: {
          id: input.rejectedByUserId,
        },
      },
      rejectedUser: {
        connect: {
          id: input.rejectedUserId,
        },
      },
    };

    if (input.deletedAt !== undefined) {
      data.deletedAt = input.deletedAt;
    }

    try {
      return await this.prisma.rejection.create({
        data,
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new RejectionConflictError(getConflictField(error));
      }

      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        isSelfRejectionConstraintError(error)
      ) {
        throw new RejectionSelfRejectionError();
      }

      throw error;
    }
  }

  findActiveRejectionBetweenUsers(
    rejectedByUserId: string,
    rejectedUserId: string,
  ): Promise<RejectionRecord | null> {
    return this.prisma.rejection.findFirst({
      where: {
        rejectedByUserId,
        rejectedUserId,
        deletedAt: null,
      },
    });
  }

  findActiveRejectionsSentByUser(rejectedByUserId: string): Promise<RejectionRecord[]> {
    return this.prisma.rejection.findMany({
      where: {
        rejectedByUserId,
        deletedAt: null,
      },
      orderBy: REJECTION_ORDER_BY,
    });
  }

  findActiveRejectionsReceivedByUser(rejectedUserId: string): Promise<RejectionRecord[]> {
    return this.prisma.rejection.findMany({
      where: {
        rejectedUserId,
        deletedAt: null,
      },
      orderBy: REJECTION_ORDER_BY,
    });
  }
}
