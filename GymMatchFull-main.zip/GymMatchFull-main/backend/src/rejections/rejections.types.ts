import type { Rejection } from '@prisma/client';

import type { CurrentUserContext } from '../auth/current-user.js';

export interface CreateRejectionInput {
  rejectedByUserId: string;
  rejectedUserId: string;
  deletedAt?: Date;
}

export interface CreateRejectionForCurrentUserInput {
  rejectedUserId: string;
}

export type RejectionRecord = Rejection;
export type SafeRejection = RejectionRecord;

export interface RejectionsServiceContract {
  createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateRejectionForCurrentUserInput,
  ): Promise<SafeRejection>;
  createRejection(input: CreateRejectionInput): Promise<SafeRejection>;
  findRejectionBetweenUsers(
    rejectedByUserId: string,
    rejectedUserId: string,
  ): Promise<SafeRejection | null>;
  findRejectionsSentByUser(rejectedByUserId: string): Promise<SafeRejection[]>;
  findRejectionsReceivedByUser(rejectedUserId: string): Promise<SafeRejection[]>;
}

export class RejectionConflictError extends Error {
  readonly field: 'userPair' | 'unknown';

  constructor(field: 'userPair' | 'unknown') {
    const fieldLabel = field === 'userPair' ? 'user rejection pair' : 'unique rejection field';

    super(`A record with the same ${fieldLabel} already exists.`);
    this.name = 'RejectionConflictError';
    this.field = field;
  }
}

export class RejectionSelfRejectionError extends Error {
  constructor() {
    super('A user cannot reject themselves.');
    this.name = 'RejectionSelfRejectionError';
  }
}
