import type { PrismaClient } from '@prisma/client';
import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { afterEach, describe, expect, it } from 'vitest';

import { buildApp } from '../app.js';
import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import { buildConfig } from '../config/env.js';
import type { SafeUser } from '../users/users.types.js';
import { RejectionsRepository } from './rejections.repository.js';
import { RejectionsService } from './rejections.service.js';
import type { CreateRejectionInput, RejectionRecord } from './rejections.types.js';
import { RejectionConflictError, RejectionSelfRejectionError } from './rejections.types.js';

const FIXED_NOW = new Date('2026-05-10T18:30:00.000Z');
const config = buildConfig({
  NODE_ENV: 'test',
  APP_NAME: 'GymMatch API',
  API_PORT: '3000',
  DATABASE_URL: 'postgresql://USER:PASSWORD@HOST:5432/DATABASE',
  JWT_SECRET: 'jwt-secret',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'refresh-secret',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  PASSWORD_RESET_TOKEN_EXPIRES_IN_MINUTES: '30',
  MOBILE_APP_URL: 'https://mobile.gymmatch.local',
  CORS_ORIGIN: 'http://localhost:3001',
});

const appsToClose: Array<ReturnType<typeof buildApp>> = [];

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryRejectionsRepository {
  private readonly rejections: RejectionRecord[] = [];
  private nextId = 1;

  async createRejection(input: CreateRejectionInput): Promise<RejectionRecord> {
    if (input.rejectedByUserId === input.rejectedUserId) {
      throw new RejectionSelfRejectionError();
    }

    const existingRejection = this.rejections.find(
      (rejection) =>
        rejection.rejectedByUserId === input.rejectedByUserId &&
        rejection.rejectedUserId === input.rejectedUserId &&
        rejection.deletedAt === null,
    );

    if (existingRejection) {
      throw new RejectionConflictError('userPair');
    }

    const rejection: RejectionRecord = {
      id: `rejection_${this.nextId++}`,
      rejectedByUserId: input.rejectedByUserId,
      rejectedUserId: input.rejectedUserId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.rejections.push(rejection);

    return rejection;
  }

  async findActiveRejectionBetweenUsers(
    rejectedByUserId: string,
    rejectedUserId: string,
  ): Promise<RejectionRecord | null> {
    return (
      this.rejections.find(
        (rejection) =>
          rejection.rejectedByUserId === rejectedByUserId &&
          rejection.rejectedUserId === rejectedUserId &&
          rejection.deletedAt === null,
      ) ?? null
    );
  }

  async findActiveRejectionsSentByUser(rejectedByUserId: string): Promise<RejectionRecord[]> {
    return this.rejections.filter(
      (rejection) =>
        rejection.rejectedByUserId === rejectedByUserId && rejection.deletedAt === null,
    );
  }

  async findActiveRejectionsReceivedByUser(rejectedUserId: string): Promise<RejectionRecord[]> {
    return this.rejections.filter(
      (rejection) => rejection.rejectedUserId === rejectedUserId && rejection.deletedAt === null,
    );
  }

  seedRejection(input: CreateRejectionInput): RejectionRecord {
    const rejection: RejectionRecord = {
      id: `rejection_${this.nextId++}`,
      rejectedByUserId: input.rejectedByUserId,
      rejectedUserId: input.rejectedUserId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.rejections.push(rejection);

    return rejection;
  }
}

function createTestApp() {
  const usersService = new InMemoryUsersService();
  const rejectionsRepository = new InMemoryRejectionsRepository();
  const rejectionsService = new RejectionsService({} as PrismaClient, {
    rejectionsRepository: rejectionsRepository as unknown as RejectionsRepository,
    usersService: usersService as unknown as AuthUsersServiceContract,
  });
  const app = buildApp({
    config,
    services: {
      rejectionsService,
      usersService: usersService as unknown as AuthUsersServiceContract,
    },
  });

  appsToClose.push(app);

  return {
    app,
    rejectionsRepository,
    usersService,
  };
}

function signAccessToken(
  app: ReturnType<typeof buildApp>,
  user: Pick<SafeUser, 'id' | 'role' | 'status'>,
): string {
  return app.jwt.sign({
    sub: user.id,
    role: user.role,
    status: user.status,
  });
}

afterEach(async () => {
  while (appsToClose.length > 0) {
    const app = appsToClose.pop();

    if (app) {
      await app.close();
    }
  }
});

describe('POST /rejections', () => {
  it('creates a rejection for an authenticated student', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/rejections',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        rejectedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(201);
    expect(response.json()).toMatchObject({
      rejectedByUserId: sender.id,
      rejectedUserId: target.id,
      deletedAt: null,
    });
  });

  it('rejects requests without an access token', async () => {
    const { app } = createTestApp();

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/rejections',
      payload: {
        rejectedUserId: 'student_2',
      },
    });

    expect(response.statusCode).toBe(401);
    expect(response.json()).toEqual({
      statusCode: 401,
      error: 'Unauthorized',
      message: 'Invalid or missing access token.',
    });
  });

  it('blocks admin users from rejecting profiles', async () => {
    const { app, usersService } = createTestApp();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/rejections',
      headers: {
        authorization: `Bearer ${signAccessToken(app, admin)}`,
      },
      payload: {
        rejectedUserId: 'student_2',
      },
    });

    expect(response.statusCode).toBe(403);
    expect(response.json()).toEqual({
      statusCode: 403,
      error: 'Forbidden',
      message: 'Insufficient permissions.',
    });
  });

  it('prevents rejecting yourself', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/rejections',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        rejectedUserId: sender.id,
      },
    });

    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({
      statusCode: 400,
      error: 'Bad Request',
      message: 'Users cannot reject themselves.',
    });
  });

  it('prevents duplicate rejections', async () => {
    const { app, rejectionsRepository, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    rejectionsRepository.seedRejection({
      rejectedByUserId: sender.id,
      rejectedUserId: target.id,
    });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/rejections',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        rejectedUserId: target.id,
      },
    });

    expect(response.statusCode).toBe(409);
    expect(response.json()).toEqual({
      statusCode: 409,
      error: 'Conflict',
      message: 'Rejection already exists between these users.',
    });
  });

  it('returns not found when the rejected user does not exist', async () => {
    const { app, usersService } = createTestApp();
    const sender = usersService.seedUser({ id: 'student_1' });

    await app.ready();

    const response = await app.inject({
      method: 'POST',
      url: '/rejections',
      headers: {
        authorization: `Bearer ${signAccessToken(app, sender)}`,
      },
      payload: {
        rejectedUserId: 'missing_user',
      },
    });

    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({
      statusCode: 404,
      error: 'Not Found',
      message: 'Rejected user not found.',
    });
  });
});
