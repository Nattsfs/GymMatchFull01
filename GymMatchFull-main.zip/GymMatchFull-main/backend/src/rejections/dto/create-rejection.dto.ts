import { HttpError } from '../../common/errors/http-error.js';
import type { CreateRejectionForCurrentUserInput } from '../rejections.types.js';

interface CreateRejectionRequestBody {
  rejectedUserId?: unknown;
}

export function parseCreateRejectionInput(payload: unknown): CreateRejectionForCurrentUserInput {
  if (!isObject(payload)) {
    throw new HttpError(400, 'Request body must be a JSON object.');
  }

  const body = payload as CreateRejectionRequestBody;
  const rejectedUserId = parseRequiredString(body.rejectedUserId, 'rejectedUserId');

  return {
    rejectedUserId,
  };
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseRequiredString(value: unknown, field: string): string {
  if (typeof value !== 'string') {
    throw new HttpError(400, `${field} is required and must be a string.`);
  }

  const normalizedValue = value.trim();

  if (normalizedValue.length === 0) {
    throw new HttpError(400, `${field} is required and must be a non-empty string.`);
  }

  return normalizedValue;
}
