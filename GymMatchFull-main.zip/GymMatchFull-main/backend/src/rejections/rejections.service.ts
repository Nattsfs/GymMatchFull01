import { UserRole as PrismaUserRole, type PrismaClient } from '@prisma/client';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { CurrentUserContext } from '../auth/current-user.js';
import { HttpError } from '../common/errors/http-error.js';
import { UsersService } from '../users/users.service.js';
import { RejectionsRepository } from './rejections.repository.js';
import type {
  CreateRejectionForCurrentUserInput,
  CreateRejectionInput,
  RejectionsServiceContract,
  SafeRejection,
} from './rejections.types.js';
import { RejectionConflictError, RejectionSelfRejectionError } from './rejections.types.js';

const DUPLICATE_REJECTION_MESSAGE = 'Rejection already exists between these users.';
const SELF_REJECTION_MESSAGE = 'Users cannot reject themselves.';
const REJECTIONS_STUDENT_ONLY_MESSAGE = 'Only STUDENT users can reject profiles.';
const REJECTION_TARGET_NOT_FOUND_MESSAGE = 'Rejected user not found.';
const INVALID_ACCESS_TOKEN_MESSAGE = 'Invalid access token.';

type RejectionsUsersReader = Pick<AuthUsersServiceContract, 'findUserById'>;

interface RejectionsServiceDependencies {
  rejectionsRepository?: RejectionsRepository;
  usersService?: RejectionsUsersReader;
}

export class RejectionsService implements RejectionsServiceContract {
  private readonly rejectionsRepository: RejectionsRepository;
  private readonly usersService: RejectionsUsersReader;

  constructor(prisma: PrismaClient, dependencies: RejectionsServiceDependencies = {}) {
    this.rejectionsRepository =
      dependencies.rejectionsRepository ?? new RejectionsRepository(prisma);
    this.usersService = dependencies.usersService ?? new UsersService(prisma);
  }

  async createForCurrentUser(
    currentUser: CurrentUserContext,
    input: CreateRejectionForCurrentUserInput,
  ): Promise<SafeRejection> {
    if (currentUser.role !== PrismaUserRole.STUDENT) {
      throw new HttpError(403, REJECTIONS_STUDENT_ONLY_MESSAGE);
    }

    if (currentUser.id === input.rejectedUserId) {
      throw new HttpError(400, SELF_REJECTION_MESSAGE);
    }

    const rejectedByUser = await this.usersService.findUserById(currentUser.id);

    if (!rejectedByUser) {
      throw new HttpError(401, INVALID_ACCESS_TOKEN_MESSAGE);
    }

    const rejectedUser = await this.usersService.findUserById(input.rejectedUserId);

    if (!rejectedUser) {
      throw new HttpError(404, REJECTION_TARGET_NOT_FOUND_MESSAGE);
    }

    return this.createRejection({
      rejectedByUserId: currentUser.id,
      rejectedUserId: input.rejectedUserId,
    });
  }

  async createRejection(input: CreateRejectionInput): Promise<SafeRejection> {
    if (input.rejectedByUserId === input.rejectedUserId) {
      throw new HttpError(400, SELF_REJECTION_MESSAGE);
    }

    try {
      return await this.rejectionsRepository.createRejection(input);
    } catch (error) {
      if (error instanceof RejectionSelfRejectionError) {
        throw new HttpError(400, SELF_REJECTION_MESSAGE);
      }

      if (error instanceof RejectionConflictError && error.field === 'userPair') {
        throw new HttpError(409, DUPLICATE_REJECTION_MESSAGE);
      }

      throw error;
    }
  }

  findRejectionBetweenUsers(
    rejectedByUserId: string,
    rejectedUserId: string,
  ): Promise<SafeRejection | null> {
    return this.rejectionsRepository.findActiveRejectionBetweenUsers(
      rejectedByUserId,
      rejectedUserId,
    );
  }

  findRejectionsSentByUser(rejectedByUserId: string): Promise<SafeRejection[]> {
    return this.rejectionsRepository.findActiveRejectionsSentByUser(rejectedByUserId);
  }

  findRejectionsReceivedByUser(rejectedUserId: string): Promise<SafeRejection[]> {
    return this.rejectionsRepository.findActiveRejectionsReceivedByUser(rejectedUserId);
  }
}
