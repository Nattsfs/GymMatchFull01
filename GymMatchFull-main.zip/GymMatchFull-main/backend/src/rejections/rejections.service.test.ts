import type { PrismaClient } from '@prisma/client';
import { UserRole as PrismaUserRole, UserStatus as PrismaUserStatus } from '@prisma/client';
import { describe, expect, it } from 'vitest';

import type { AuthUsersServiceContract } from '../auth/auth.types.js';
import type { SafeUser } from '../users/users.types.js';
import { RejectionsRepository } from './rejections.repository.js';
import { RejectionsService } from './rejections.service.js';
import type { CreateRejectionInput, RejectionRecord } from './rejections.types.js';
import { RejectionConflictError, RejectionSelfRejectionError } from './rejections.types.js';

const FIXED_NOW = new Date('2026-05-10T18:30:00.000Z');

interface SeedUserInput {
  deletedAt?: Date | null;
  gymId?: string | null;
  gymUnitId?: string | null;
  id?: string;
  role?: PrismaUserRole;
  status?: PrismaUserStatus;
}

class InMemoryUsersService {
  private readonly users: SafeUser[] = [];

  seedUser(input: SeedUserInput = {}): SafeUser {
    const index = this.users.length + 1;
    const user: SafeUser = {
      id: input.id ?? `user_${index}`,
      name: `Aluno ${index}`,
      email: `aluno_${index}@example.com`,
      phone: `1199999999${index}`,
      cpf: `1234567890${index}`,
      gymId: input.gymId ?? 'gym_1',
      gymUnitId: input.gymUnitId ?? 'unit_1',
      role: input.role ?? PrismaUserRole.STUDENT,
      status: input.status ?? PrismaUserStatus.ACTIVE,
      emailVerifiedAt: null,
      phoneVerifiedAt: null,
      termsAcceptedAt: null,
      lastLoginAt: null,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.users.push(user);

    return user;
  }

  async findUserById(id: string): Promise<SafeUser | null> {
    return this.users.find((user) => user.id === id) ?? null;
  }
}

class InMemoryRejectionsRepository {
  private readonly rejections: RejectionRecord[] = [];
  private nextId = 1;

  async createRejection(input: CreateRejectionInput): Promise<RejectionRecord> {
    if (input.rejectedByUserId === input.rejectedUserId) {
      throw new RejectionSelfRejectionError();
    }

    const existingRejection = this.rejections.find(
      (rejection) =>
        rejection.rejectedByUserId === input.rejectedByUserId &&
        rejection.rejectedUserId === input.rejectedUserId &&
        rejection.deletedAt === null,
    );

    if (existingRejection) {
      throw new RejectionConflictError('userPair');
    }

    const rejection: RejectionRecord = {
      id: `rejection_${this.nextId++}`,
      rejectedByUserId: input.rejectedByUserId,
      rejectedUserId: input.rejectedUserId,
      createdAt: FIXED_NOW,
      updatedAt: FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.rejections.push(rejection);

    return rejection;
  }

  async findActiveRejectionBetweenUsers(
    rejectedByUserId: string,
    rejectedUserId: string,
  ): Promise<RejectionRecord | null> {
    return (
      this.rejections.find(
        (rejection) =>
          rejection.rejectedByUserId === rejectedByUserId &&
          rejection.rejectedUserId === rejectedUserId &&
          rejection.deletedAt === null,
      ) ?? null
    );
  }

  async findActiveRejectionsSentByUser(rejectedByUserId: string): Promise<RejectionRecord[]> {
    return this.rejections.filter(
      (rejection) =>
        rejection.rejectedByUserId === rejectedByUserId && rejection.deletedAt === null,
    );
  }

  async findActiveRejectionsReceivedByUser(rejectedUserId: string): Promise<RejectionRecord[]> {
    return this.rejections.filter(
      (rejection) => rejection.rejectedUserId === rejectedUserId && rejection.deletedAt === null,
    );
  }

  seedRejection(
    input: CreateRejectionInput & { createdAt?: Date; updatedAt?: Date },
  ): RejectionRecord {
    const rejection: RejectionRecord = {
      id: `rejection_${this.nextId++}`,
      rejectedByUserId: input.rejectedByUserId,
      rejectedUserId: input.rejectedUserId,
      createdAt: input.createdAt ?? FIXED_NOW,
      updatedAt: input.updatedAt ?? input.createdAt ?? FIXED_NOW,
      deletedAt: input.deletedAt ?? null,
    };

    this.rejections.push(rejection);

    return rejection;
  }
}

function createRejectionsService(
  options: {
    rejectionsRepository?: InMemoryRejectionsRepository;
    usersService?: InMemoryUsersService;
  } = {},
): RejectionsService {
  return new RejectionsService({} as PrismaClient, {
    rejectionsRepository: (options.rejectionsRepository ??
      new InMemoryRejectionsRepository()) as unknown as RejectionsRepository,
    usersService: (options.usersService ??
      new InMemoryUsersService()) as unknown as AuthUsersServiceContract,
  });
}

function toCurrentUser(user: Pick<SafeUser, 'id' | 'role' | 'status'>) {
  return {
    id: user.id,
    role: user.role,
    status: user.status,
  };
}

describe('RejectionsService', () => {
  it('creates a rejection between two distinct users', async () => {
    const rejectionsRepository = new InMemoryRejectionsRepository();
    const service = createRejectionsService({ rejectionsRepository });

    const rejection = await service.createRejection({
      rejectedByUserId: 'user_1',
      rejectedUserId: 'user_2',
    });

    expect(rejection).toMatchObject({
      rejectedByUserId: 'user_1',
      rejectedUserId: 'user_2',
      deletedAt: null,
    });
    await expect(service.findRejectionBetweenUsers('user_1', 'user_2')).resolves.toEqual(rejection);
  });

  it('creates a rejection for an authenticated student target', async () => {
    const usersService = new InMemoryUsersService();
    const sender = usersService.seedUser({ id: 'student_1' });
    const target = usersService.seedUser({ id: 'student_2' });
    const service = createRejectionsService({ usersService });

    const rejection = await service.createForCurrentUser(toCurrentUser(sender), {
      rejectedUserId: target.id,
    });

    expect(rejection.rejectedByUserId).toBe(sender.id);
    expect(rejection.rejectedUserId).toBe(target.id);
  });

  it('rejects duplicate rejections for the same user pair', async () => {
    const rejectionsRepository = new InMemoryRejectionsRepository();
    rejectionsRepository.seedRejection({
      rejectedByUserId: 'user_1',
      rejectedUserId: 'user_2',
    });
    const service = createRejectionsService({ rejectionsRepository });

    await expect(
      service.createRejection({
        rejectedByUserId: 'user_1',
        rejectedUserId: 'user_2',
      }),
    ).rejects.toMatchObject({
      statusCode: 409,
      message: 'Rejection already exists between these users.',
    });
  });

  it('rejects self rejection attempts', async () => {
    const service = createRejectionsService();

    await expect(
      service.createRejection({
        rejectedByUserId: 'user_1',
        rejectedUserId: 'user_1',
      }),
    ).rejects.toMatchObject({
      statusCode: 400,
      message: 'Users cannot reject themselves.',
    });
  });

  it('blocks non-student senders', async () => {
    const usersService = new InMemoryUsersService();
    const admin = usersService.seedUser({
      id: 'admin_1',
      role: PrismaUserRole.ADMIN,
      gymId: null,
      gymUnitId: null,
    });
    const target = usersService.seedUser({ id: 'student_2' });
    const service = createRejectionsService({ usersService });

    await expect(
      service.createForCurrentUser(toCurrentUser(admin), {
        rejectedUserId: target.id,
      }),
    ).rejects.toMatchObject({
      statusCode: 403,
      message: 'Only STUDENT users can reject profiles.',
    });
  });

  it('rejects unknown target users', async () => {
    const usersService = new InMemoryUsersService();
    const sender = usersService.seedUser({ id: 'student_1' });
    const service = createRejectionsService({ usersService });

    await expect(
      service.createForCurrentUser(toCurrentUser(sender), {
        rejectedUserId: 'missing_user',
      }),
    ).rejects.toMatchObject({
      statusCode: 404,
      message: 'Rejected user not found.',
    });
  });

  it('lists only active rejections sent and received by a user', async () => {
    const rejectionsRepository = new InMemoryRejectionsRepository();
    rejectionsRepository.seedRejection({
      rejectedByUserId: 'user_1',
      rejectedUserId: 'user_2',
    });
    rejectionsRepository.seedRejection({
      rejectedByUserId: 'user_1',
      rejectedUserId: 'user_3',
      deletedAt: FIXED_NOW,
    });
    rejectionsRepository.seedRejection({
      rejectedByUserId: 'user_4',
      rejectedUserId: 'user_1',
    });
    const service = createRejectionsService({ rejectionsRepository });

    await expect(service.findRejectionsSentByUser('user_1')).resolves.toHaveLength(1);
    await expect(service.findRejectionsReceivedByUser('user_1')).resolves.toHaveLength(1);
  });
});
