export { MailService } from './mail.service.js';
export type { MailServiceContract, PasswordResetMailInput } from './mail.service.js';
