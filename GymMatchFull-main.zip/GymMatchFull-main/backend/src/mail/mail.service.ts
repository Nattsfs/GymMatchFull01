import type { FastifyBaseLogger } from 'fastify';

import type { EmailConfig, NodeEnv } from '../config/index.js';

export interface PasswordResetMailInput {
  to: string;
  name: string;
  token: string;
  resetUrl: string;
  expiresInMinutes: number;
}

export interface MailServiceContract {
  sendPasswordResetEmail(input: PasswordResetMailInput): Promise<void>;
}

interface MailServiceOptions {
  emailConfig: EmailConfig;
  nodeEnv: NodeEnv;
  logger: Pick<FastifyBaseLogger, 'info' | 'warn'>;
}

export class MailService implements MailServiceContract {
  constructor(private readonly options: MailServiceOptions) {}

  async sendPasswordResetEmail(input: PasswordResetMailInput): Promise<void> {
    const provider = this.options.emailConfig.provider?.trim().toLowerCase() ?? 'mock';
    const safePayload = {
      event: 'auth.password-reset-email',
      provider,
      recipient: maskEmailAddress(input.to),
    };

    if (provider !== 'mock') {
      this.options.logger.warn(
        {
          provider,
        },
        'Email provider integration is not implemented yet. Falling back to simulated delivery.',
      );
    }

    if (this.options.nodeEnv === 'production') {
      this.options.logger.info(safePayload, 'Password reset email queued.');
      return;
    }

    this.options.logger.info(
      {
        ...safePayload,
        subject: 'GymMatch password reset',
        previewUrl: input.resetUrl,
        previewToken: input.token,
        expiresInMinutes: input.expiresInMinutes,
      },
      'Password reset email queued.',
    );
  }
}

function maskEmailAddress(email: string): string {
  const [localPart = '', domain = ''] = email.split('@');

  if (localPart.length <= 2) {
    return `${localPart[0] ?? '*'}***@${domain}`;
  }

  return `${localPart.slice(0, 2)}***@${domain}`;
}
