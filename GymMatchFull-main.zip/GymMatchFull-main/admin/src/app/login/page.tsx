import { redirect } from 'next/navigation';

import { BrandMark } from '@/components/brand-mark';
import { LoginForm } from '@/components/login-form';
import { getAdminSessionState } from '@/lib/auth';
import { ADMIN_HOME_PATH, getLoginPageNoticeMessage } from '@/lib/auth.shared';

interface LoginPageProps {
  searchParams?:
    | Promise<Record<string, string | string[] | undefined>>
    | Record<string, string | string[] | undefined>;
}

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const sessionState = await getAdminSessionState();

  if (sessionState.status === 'authenticated') {
    redirect(ADMIN_HOME_PATH);
  }

  const resolvedSearchParams = (await searchParams) ?? {};
  const searchReason = resolvedSearchParams.reason;
  const reason = sessionState.status === 'invalid'
    ? 'session-invalid'
    : Array.isArray(searchReason)
      ? searchReason[0]
      : searchReason;
  const noticeMessage = getLoginPageNoticeMessage(reason);

  return (
    <main className="auth-page">
      <section className="auth-hero">
        <div className="auth-hero__content">
          <BrandMark />
          <span className="eyebrow">Painel administrativo</span>
          <h1>Painel ADMIN conectado a API com sessao protegida no servidor.</h1>
          <p>
            Entre com uma conta administrativa para acessar o shell interno do GymMatch com
            validacao de role, sessao em cookie HttpOnly e bloqueio de acessos fora do painel.
          </p>
          <ul className="auth-hero__highlights">
            <li>Login real no backend com JWT</li>
            <li>Bloqueio explicito para contas STUDENT</li>
            <li>Protecao do grupo interno e logout administrativo</li>
          </ul>
        </div>
      </section>

      <section className="auth-panel">
        <div className="auth-card">
          <div className="auth-card__header">
            <span className="eyebrow">Acesso interno</span>
            <h2>Entrar no GymMatch Admin</h2>
            <p>Use apenas credenciais com role ADMIN para acessar o painel.</p>
          </div>

          <LoginForm noticeMessage={noticeMessage} />

          <div className="auth-card__footer">
            <span>A autenticacao do painel depende da URL da API configurada no ambiente.</span>
          </div>
        </div>
      </section>
    </main>
  );
}
