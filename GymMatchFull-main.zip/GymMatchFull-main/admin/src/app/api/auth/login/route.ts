import { NextResponse } from 'next/server';

import { AdminAuthError, startAdminSession } from '@/lib/auth';
import { ADMIN_HOME_PATH } from '@/lib/auth.shared';
import { validateLoginForm } from '@/lib/validators/login-form';

function getFieldValue(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

export async function POST(request: Request) {
  let payload: unknown;

  try {
    payload = await request.json();
  } catch {
    return NextResponse.json(
      {
        message: 'Dados de login invalidos.',
      },
      {
        status: 400,
      },
    );
  }

  const body = payload && typeof payload === 'object' ? (payload as Record<string, unknown>) : {};
  const email = getFieldValue(body.email);
  const password = getFieldValue(body.password);
  const validationErrors = validateLoginForm({ email, password });

  if (Object.keys(validationErrors).length > 0) {
    return NextResponse.json(
      {
        message:
          validationErrors.email ??
          validationErrors.password ??
          'Revise os dados informados e tente novamente.',
      },
      {
        status: 400,
      },
    );
  }

  try {
    const user = await startAdminSession({
      email: email.trim(),
      password,
    });

    return NextResponse.json({
      redirectTo: ADMIN_HOME_PATH,
      user,
    });
  } catch (error) {
    if (error instanceof AdminAuthError) {
      return NextResponse.json(
        {
          message: error.message,
        },
        {
          status: error.status,
        },
      );
    }

    return NextResponse.json(
      {
        message: 'Nao foi possivel entrar no painel agora. Tente novamente em instantes.',
      },
      {
        status: 500,
      },
    );
  }
}
