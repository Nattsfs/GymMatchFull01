import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import { Barlow_Condensed, Manrope } from 'next/font/google';

import './globals.css';

const headingFont = Barlow_Condensed({
  subsets: ['latin'],
  weight: ['600', '700'],
  variable: '--font-heading',
});

const bodyFont = Manrope({
  subsets: ['latin'],
  variable: '--font-body',
});

export const metadata: Metadata = {
  title: {
    default: 'GymMatch Admin',
    template: '%s | GymMatch Admin',
  },
  description: 'Painel administrativo web do GymMatch.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className={`${headingFont.variable} ${bodyFont.variable}`}>{children}</body>
    </html>
  );
}
