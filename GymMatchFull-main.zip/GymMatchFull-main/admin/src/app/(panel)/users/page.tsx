import Link from 'next/link';
import { cookies } from 'next/headers';

import { UserFiltersForm } from '@/components/users/user-filters-form';
import { UsersTable } from '@/components/users/users-table';
import {
  buildAdminUsersListPath,
  fetchAdminUserFilterOptions,
  fetchAdminUsers,
  getAdminUsersErrorMessage,
  normalizeAdminUsersSearchParams,
} from '@/lib/admin-users';
import { ADMIN_SESSION_COOKIE_NAME } from '@/lib/auth.shared';
import type {
  AdminGymFilterOption,
  AdminGymUnitFilterOption,
  AdminUsersListResponse,
} from '@/types/users';

interface UsersPageProps {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

export default async function UsersPage({ searchParams }: UsersPageProps) {
  const resolvedSearchParams = await searchParams;
  const filters = normalizeAdminUsersSearchParams(resolvedSearchParams);
  const cookieStore = await cookies();
  const accessToken = cookieStore.get(ADMIN_SESSION_COOKIE_NAME)?.value;
  let errorMessage: string | null = null;
  let filtersErrorMessage: string | null = null;
  let usersResponse: AdminUsersListResponse | null = null;
  let gymOptions: AdminGymFilterOption[] = [];
  let gymUnitOptions: AdminGymUnitFilterOption[] = [];

  if (!accessToken) {
    errorMessage = 'Sessao administrativa indisponivel. Entre novamente.';
  } else {
    try {
      usersResponse = await fetchAdminUsers(accessToken, filters);
    } catch (error) {
      errorMessage = getAdminUsersErrorMessage(error);
    }

    try {
      const filterOptions = await fetchAdminUserFilterOptions(accessToken, {
        ...(filters.gymId ? { gymId: filters.gymId } : {}),
      });

      gymOptions = filterOptions.gyms;
      gymUnitOptions = filterOptions.gymUnits;
    } catch {
      filtersErrorMessage =
        'Academias e unidades nao puderam ser carregadas agora. A busca textual e o status continuam disponiveis.';
    }
  }

  const pagination = usersResponse?.pagination ?? {
    page: filters.page,
    limit: filters.limit,
    total: 0,
    totalPages: 1,
  };
  const previousPagePath =
    pagination.page > 1
      ? buildAdminUsersListPath({
          ...filters,
          page: pagination.page - 1,
          limit: pagination.limit,
        })
      : null;
  const nextPagePath =
    pagination.page < pagination.totalPages
      ? buildAdminUsersListPath({
          ...filters,
          page: pagination.page + 1,
          limit: pagination.limit,
        })
      : null;
  const returnTo = buildAdminUsersListPath({
    ...filters,
    page: pagination.page,
    limit: pagination.limit,
  });

  return (
    <div className="users-page">
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Operacao</span>
          <h1>Usuarios do GymMatch.</h1>
          <p>
            A tela administrativa lista contas com paginação e filtros basicos sem expor dados
            sensiveis desnecessarios.
          </p>
        </div>

        <div className="dashboard-hero__status">
          <span className="dashboard-hero__label">Status da consulta</span>
          <strong>{errorMessage ? 'Falha ao carregar' : `${pagination.total} usuarios encontrados`}</strong>
          <span>
            {errorMessage
              ? errorMessage
              : 'Listagem protegida por JWT e role ADMIN, com leitura paginada do backend.'}
          </span>
        </div>
      </section>

      <div className="users-layout">
        <UserFiltersForm
          filters={filters}
          filtersErrorMessage={filtersErrorMessage}
          gymOptions={gymOptions}
          gymUnitOptions={gymUnitOptions}
        />

        <section className="dashboard-card users-results">
          <div className="users-results__header">
            <div>
              <span className="dashboard-card__title">Listagem</span>
              <h2>Usuarios cadastrados</h2>
              <p className="dashboard-card__copy">
                Pagina {pagination.page} de {pagination.totalPages} com {pagination.total} resultado(s).
              </p>
            </div>
          </div>

          {errorMessage ? (
            <div className="users-empty">
              <strong>Erro ao consultar a API administrativa.</strong>
              <p>{errorMessage}</p>
            </div>
          ) : usersResponse && usersResponse.data.length > 0 ? (
            <>
              <UsersTable returnTo={returnTo} users={usersResponse.data} />

              <div className="users-pagination">
                <span className="users-pagination__summary">
                  Pagina {pagination.page} de {pagination.totalPages}
                </span>

                <div className="users-pagination__actions">
                  {previousPagePath ? (
                    <Link className="button-secondary" href={previousPagePath}>
                      Anterior
                    </Link>
                  ) : (
                    <span aria-disabled="true" className="button-secondary">
                      Anterior
                    </span>
                  )}

                  {nextPagePath ? (
                    <Link className="button-secondary" href={nextPagePath}>
                      Proxima
                    </Link>
                  ) : (
                    <span aria-disabled="true" className="button-secondary">
                      Proxima
                    </span>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="users-empty">
              <strong>Nenhum usuario encontrado.</strong>
              <p>Revise os filtros aplicados ou cadastre novas contas para aparecerem aqui.</p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
