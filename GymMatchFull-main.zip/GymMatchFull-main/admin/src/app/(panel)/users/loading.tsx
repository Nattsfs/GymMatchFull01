export default function UsersLoadingPage() {
  return (
    <div className="users-page">
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Operacao</span>
          <h1>Usuarios do GymMatch.</h1>
          <p>Carregando listagem administrativa protegida por role ADMIN.</p>
        </div>

        <div className="dashboard-hero__status">
          <span className="dashboard-hero__label">Status da consulta</span>
          <strong>Carregando</strong>
          <span>Buscando usuarios, academias e unidades.</span>
        </div>
      </section>

      <div className="users-layout">
        <section className="dashboard-card users-filters">
          <div>
            <span className="dashboard-card__title">Filtros</span>
          </div>

          <article className="metric-card metric-card--loading">
            <span className="metric-card__placeholder metric-card__placeholder--label" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
          </article>
        </section>

        <section className="dashboard-card">
          <article className="metric-card metric-card--loading">
            <span className="metric-card__placeholder metric-card__placeholder--label" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
          </article>
        </section>
      </div>
    </div>
  );
}
