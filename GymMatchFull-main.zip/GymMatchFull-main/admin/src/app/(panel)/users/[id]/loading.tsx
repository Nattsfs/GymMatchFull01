export default function UserDetailLoadingPage() {
  return (
    <div className="user-detail-page">
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Detalhe do usuario</span>
          <h1>Carregando usuario...</h1>
          <p>Consultando os dados administrativos basicos da conta.</p>
        </div>

        <div className="dashboard-hero__status">
          <span className="dashboard-hero__label">Situacao da conta</span>
          <strong>Carregando</strong>
          <span>Aguarde enquanto a API responde.</span>
        </div>
      </section>

      <section className="user-detail-grid">
        {Array.from({ length: 3 }).map((_, index) => (
          <article className="dashboard-card metric-card metric-card--loading" key={index}>
            <span className="metric-card__placeholder metric-card__placeholder--label" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
          </article>
        ))}
      </section>
    </div>
  );
}
