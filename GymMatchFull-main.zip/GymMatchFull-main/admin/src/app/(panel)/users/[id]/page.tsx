import { cookies } from 'next/headers';

import { UserDetailCard } from '@/components/users/user-detail-card';
import {
  fetchAdminUserDetail,
  getAdminUsersErrorMessage,
  resolveAdminUsersReturnToPath,
} from '@/lib/admin-users';
import { ADMIN_SESSION_COOKIE_NAME } from '@/lib/auth.shared';
import type { AdminUserDetail } from '@/types/users';

interface UserDetailPageProps {
  params: Promise<{
    id: string;
  }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}

export default async function UserDetailPage({
  params,
  searchParams,
}: UserDetailPageProps) {
  const [{ id }, resolvedSearchParams] = await Promise.all([params, searchParams]);
  const returnTo = resolveAdminUsersReturnToPath(resolvedSearchParams.returnTo);
  const cookieStore = await cookies();
  const accessToken = cookieStore.get(ADMIN_SESSION_COOKIE_NAME)?.value;
  let errorMessage: string | null = null;
  let user: AdminUserDetail | null = null;

  if (!accessToken) {
    errorMessage = 'Sessao administrativa indisponivel. Entre novamente.';
  } else {
    try {
      user = await fetchAdminUserDetail(accessToken, id);
    } catch (error) {
      errorMessage = getAdminUsersErrorMessage(error);
    }
  }

  return (
    <div className="user-detail-page">
      {errorMessage || !user ? (
        <section className="dashboard-card dashboard-card--error">
          <span className="dashboard-card__title">Erro ao carregar usuario</span>
          <p className="dashboard-card__copy">
            {errorMessage ?? 'O usuario solicitado nao esta disponivel para consulta.'}
          </p>
          <div className="user-detail-page__actions">
            <a className="button-secondary" href={returnTo}>
              Voltar para usuarios
            </a>
          </div>
        </section>
      ) : (
        <UserDetailCard returnTo={returnTo} user={user} />
      )}
    </div>
  );
}
