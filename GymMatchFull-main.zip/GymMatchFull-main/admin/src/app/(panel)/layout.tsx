import type { ReactNode } from 'react';
import { redirect } from 'next/navigation';

import { AdminShell } from '@/components/admin-shell';
import { getAdminSessionState } from '@/lib/auth';
import { ADMIN_LOGIN_PATH, getAdminSessionRedirectReason } from '@/lib/auth.shared';

export default async function PanelLayout({ children }: { children: ReactNode }) {
  const sessionState = await getAdminSessionState();

  if (sessionState.status !== 'authenticated') {
    redirect(`${ADMIN_LOGIN_PATH}?reason=${getAdminSessionRedirectReason(sessionState.status)}`);
  }

  return <AdminShell user={sessionState.user}>{children}</AdminShell>;
}
