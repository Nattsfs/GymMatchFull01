const loadingCards = Array.from({ length: 5 }, (_, index) => `metric-loading-${index}`);

export default function DashboardLoading() {
  return (
    <div className="dashboard-page">
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Visao geral</span>
          <h1>Indicadores principais do GymMatch.</h1>
          <p>Consultando a API administrativa para carregar as metricas reais do painel.</p>
        </div>

        <div className="dashboard-hero__status">
          <span className="dashboard-hero__label">Status do dashboard</span>
          <strong>Carregando metricas</strong>
          <span>Os cards abaixo serao preenchidos assim que a API responder.</span>
        </div>
      </section>

      <section className="dashboard-metrics">
        {loadingCards.map((cardId) => (
          <article className="dashboard-card metric-card metric-card--loading" key={cardId}>
            <span className="metric-card__placeholder metric-card__placeholder--label" />
            <span className="metric-card__placeholder metric-card__placeholder--value" />
            <span className="metric-card__placeholder metric-card__placeholder--copy" />
          </article>
        ))}
      </section>
    </div>
  );
}
