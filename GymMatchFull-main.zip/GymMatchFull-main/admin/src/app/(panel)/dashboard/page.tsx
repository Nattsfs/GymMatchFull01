import { cookies } from 'next/headers';

import { ADMIN_SESSION_COOKIE_NAME } from '@/lib/auth.shared';
import {
  buildDashboardMetricCards,
  fetchAdminDashboardMetrics,
  getDashboardMetricsErrorMessage,
} from '@/lib/dashboard-metrics';

const dashboardNotes = [
  'A leitura usa a API administrativa real protegida por JWT e role ADMIN.',
  'Usuarios ativos consideram apenas contas ACTIVE sem soft delete.',
  'Assinaturas premium ficam em zero ate o modulo de planos existir no backend.',
];

export default async function DashboardPage() {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get(ADMIN_SESSION_COOKIE_NAME)?.value;
  let errorMessage: string | null = null;
  let metricCards = [] as ReturnType<typeof buildDashboardMetricCards>;

  if (!accessToken) {
    errorMessage = 'Sessao administrativa indisponivel. Entre novamente.';
  } else {
    try {
      const metrics = await fetchAdminDashboardMetrics(accessToken);

      metricCards = buildDashboardMetricCards(metrics);
    } catch (error) {
      errorMessage = getDashboardMetricsErrorMessage(error);
    }
  }

  return (
    <div className="dashboard-page">
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Visao geral</span>
          <h1>Indicadores principais do GymMatch.</h1>
          <p>
            O dashboard administrativo agora consome metricas reais da API para dar visibilidade
            imediata sobre usuarios, matches e moderacao do MVP.
          </p>
        </div>

        <div className="dashboard-hero__status">
          <span className="dashboard-hero__label">Status do dashboard</span>
          <strong>{errorMessage ? 'Falha ao carregar' : `${metricCards.length} indicadores online`}</strong>
          <span>
            {errorMessage
              ? errorMessage
              : 'Dados protegidos por acesso administrativo e atualizados a partir do backend.'}
          </span>
        </div>
      </section>

      {errorMessage ? (
        <section className="dashboard-grid">
          <article className="dashboard-card dashboard-card--error">
            <span className="dashboard-card__title">Erro ao consultar a API</span>
            <p className="dashboard-card__copy">{errorMessage}</p>
          </article>

          <article className="dashboard-card">
            <span className="dashboard-card__title">Leitura esperada</span>
            <ul className="dashboard-list">
              {dashboardNotes.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        </section>
      ) : (
        <section className="dashboard-metrics">
          {metricCards.map((card) => (
            <article className="dashboard-card metric-card" key={card.id}>
              <span className="metric-card__label">{card.label}</span>
              <strong className="metric-card__value">{card.value}</strong>
              <p className="metric-card__copy">{card.description}</p>
            </article>
          ))}
        </section>
      )}

      <section className="dashboard-grid">
        <article className="dashboard-card">
          <span className="dashboard-card__title">Leituras desta tela</span>
          <ul className="dashboard-list">
            {dashboardNotes.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </article>

        <article className="dashboard-card">
          <span className="dashboard-card__title">Proximos passos naturais</span>
          <ul className="dashboard-list">
            <li>Conectar a listagem administrativa de usuarios.</li>
            <li>Exibir fila de denuncias com acesso de moderacao.</li>
            <li>Adicionar filtros e recortes quando o painel crescer.</li>
          </ul>
        </article>
      </section>
    </div>
  );
}
