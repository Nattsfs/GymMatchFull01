export interface AdminDashboardMetrics {
  totalUsers: number;
  activeUsers: number;
  totalMatches: number;
  totalReports: number;
  premiumSubscriptions: number;
}
