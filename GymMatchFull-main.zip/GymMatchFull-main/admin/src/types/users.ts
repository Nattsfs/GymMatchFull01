export type AdminUserRole = 'STUDENT' | 'ADMIN';

export type AdminUserStatus = 'ACTIVE' | 'PENDING' | 'SUSPENDED' | 'BANNED' | 'DELETED';

export type AdminGymStatus = 'ACTIVE' | 'INACTIVE' | 'DELETED';

export type AdminGymUnitStatus = 'ACTIVE' | 'INACTIVE' | 'DELETED';

export interface PaginationResult {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface AdminUserGymSummary {
  id: string;
  name: string;
  status: AdminGymStatus;
}

export interface AdminUserGymUnitSummary {
  id: string;
  name: string;
  status: AdminGymUnitStatus;
}

export interface AdminUserListItem {
  id: string;
  name: string;
  email: string;
  role: AdminUserRole;
  status: AdminUserStatus;
  createdAt: string;
  gym: AdminUserGymSummary | null;
  gymUnit: AdminUserGymUnitSummary | null;
}

export interface AdminUserDetail extends AdminUserListItem {
  lastLoginAt: string | null;
  deletedAt: string | null;
}

export interface AdminUsersQueryInput {
  page: number;
  limit: number;
  search?: string;
  gymId?: string;
  gymUnitId?: string;
  status?: AdminUserStatus;
}

export interface AdminUsersListResponse {
  data: AdminUserListItem[];
  pagination: PaginationResult;
}

export interface AdminGymFilterOption {
  id: string;
  name: string;
  status: AdminGymStatus;
}

export interface AdminGymListResponse {
  data: AdminGymFilterOption[];
  pagination: PaginationResult;
}

export interface AdminGymUnitFilterOption {
  id: string;
  name: string;
  status: AdminGymUnitStatus;
  gym: AdminGymFilterOption;
}

export interface AdminGymUnitListResponse {
  data: AdminGymUnitFilterOption[];
  pagination: PaginationResult;
}
