import { describe, expect, it } from 'vitest';

import { ApiClientError } from './api-client';
import {
  buildAdminUserDetailPath,
  buildAdminUsersListPath,
  buildAdminUsersQueryString,
  getAdminUsersErrorMessage,
  normalizeAdminUsersSearchParams,
  resolveAdminUsersReturnToPath,
} from './admin-users';

describe('admin-users', () => {
  it('normalizes search params with defaults and valid filters', () => {
    expect(
      normalizeAdminUsersSearchParams({
        page: '2',
        limit: '20',
        search: '  pedro  ',
        gymId: 'gym_1',
        gymUnitId: 'unit_9',
        status: 'active',
      }),
    ).toEqual({
      page: 2,
      limit: 20,
      search: 'pedro',
      gymId: 'gym_1',
      gymUnitId: 'unit_9',
      status: 'ACTIVE',
    });
  });

  it('falls back to safe defaults when the search params are invalid', () => {
    expect(
      normalizeAdminUsersSearchParams({
        page: 'zero',
        limit: '1000',
        status: 'unknown',
      }),
    ).toEqual({
      page: 1,
      limit: 50,
    });
  });

  it('builds list and detail paths preserving the current filters', () => {
    const query = buildAdminUsersQueryString({
      page: 3,
      limit: 20,
      search: 'ana',
      gymId: 'gym_2',
      status: 'PENDING',
    });

    expect(query).toBe('page=3&limit=20&search=ana&gymId=gym_2&status=PENDING');
    expect(buildAdminUsersListPath({ page: 3, search: 'ana' })).toBe('/users?page=3&search=ana');
    expect(buildAdminUserDetailPath('user_1', '/users?page=3&search=ana')).toBe(
      '/users/user_1?returnTo=%2Fusers%3Fpage%3D3%26search%3Dana',
    );
  });

  it('accepts only internal return paths for the users area', () => {
    expect(resolveAdminUsersReturnToPath('/users?page=2')).toBe('/users?page=2');
    expect(resolveAdminUsersReturnToPath('/dashboard')).toBe('/users');
  });

  it('maps authorization failures to a session-oriented users message', () => {
    const error = new ApiClientError('Forbidden', 403);

    expect(getAdminUsersErrorMessage(error)).toBe(
      'Sua sessao administrativa nao conseguiu acessar os usuarios. Entre novamente.',
    );
  });
});
