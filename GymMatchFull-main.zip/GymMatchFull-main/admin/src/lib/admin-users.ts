import { ApiClientError, apiClient } from './api-client';
import type {
  AdminGymFilterOption,
  AdminGymListResponse,
  AdminGymUnitFilterOption,
  AdminGymUnitListResponse,
  AdminUserDetail,
  AdminUsersListResponse,
  AdminUsersQueryInput,
  AdminUserStatus,
} from '@/types/users';

const DEFAULT_USERS_PAGE = 1;
const DEFAULT_USERS_LIMIT = 10;
const MAX_USERS_LIMIT = 50;

export const ADMIN_USER_STATUS_OPTIONS: Array<{ value: AdminUserStatus; label: string }> = [
  { value: 'ACTIVE', label: 'Ativo' },
  { value: 'PENDING', label: 'Pendente' },
  { value: 'SUSPENDED', label: 'Suspenso' },
  { value: 'BANNED', label: 'Banido' },
  { value: 'DELETED', label: 'Removido' },
];

export const ADMIN_USER_PAGE_SIZE_OPTIONS = [10, 20, 50] as const;

const adminUserStatuses = new Set<AdminUserStatus>(
  ADMIN_USER_STATUS_OPTIONS.map((option) => option.value),
);

const adminDateTimeFormatter = new Intl.DateTimeFormat('pt-BR', {
  dateStyle: 'short',
  timeStyle: 'short',
});

export async function fetchAdminUsers(
  token: string,
  query: AdminUsersQueryInput,
): Promise<AdminUsersListResponse> {
  const queryString = buildAdminUsersQueryString(query);

  return apiClient<AdminUsersListResponse>(`/admin/users${queryString ? `?${queryString}` : ''}`, {
    token,
  });
}

export async function fetchAdminUserDetail(token: string, userId: string): Promise<AdminUserDetail> {
  return apiClient<AdminUserDetail>(`/admin/users/${userId}`, {
    token,
  });
}

export async function fetchAdminUserFilterOptions(
  token: string,
  input: { gymId?: string },
): Promise<{
  gyms: AdminGymFilterOption[];
  gymUnits: AdminGymUnitFilterOption[];
}> {
  const gymUnitsQuery = new URLSearchParams();

  gymUnitsQuery.set('limit', String(MAX_USERS_LIMIT));

  if (input.gymId) {
    gymUnitsQuery.set('gymId', input.gymId);
  }

  const [gymsResponse, gymUnitsResponse] = await Promise.all([
    apiClient<AdminGymListResponse>(`/admin/gyms?limit=${MAX_USERS_LIMIT}`, {
      token,
    }),
    apiClient<AdminGymUnitListResponse>(`/admin/gym-units?${gymUnitsQuery.toString()}`, {
      token,
    }),
  ]);

  return {
    gyms: gymsResponse.data,
    gymUnits: gymUnitsResponse.data,
  };
}

export function normalizeAdminUsersSearchParams(
  searchParams: Record<string, string | string[] | undefined>,
): AdminUsersQueryInput {
  const page = parsePositiveInteger(searchParams.page, DEFAULT_USERS_PAGE);
  const limit = parsePositiveInteger(searchParams.limit, DEFAULT_USERS_LIMIT, MAX_USERS_LIMIT);
  const search = normalizeOptionalString(searchParams.search);
  const gymId = normalizeOptionalString(searchParams.gymId);
  const gymUnitId = normalizeOptionalString(searchParams.gymUnitId);
  const status = normalizeOptionalStatus(searchParams.status);

  return {
    page,
    limit,
    ...(search ? { search } : {}),
    ...(gymId ? { gymId } : {}),
    ...(gymUnitId ? { gymUnitId } : {}),
    ...(status ? { status } : {}),
  };
}

export function buildAdminUsersQueryString(query: Partial<AdminUsersQueryInput>): string {
  const params = new URLSearchParams();

  if (query.page && query.page > 1) {
    params.set('page', String(query.page));
  }

  if (query.limit && query.limit !== DEFAULT_USERS_LIMIT) {
    params.set('limit', String(query.limit));
  }

  if (query.search) {
    params.set('search', query.search);
  }

  if (query.gymId) {
    params.set('gymId', query.gymId);
  }

  if (query.gymUnitId) {
    params.set('gymUnitId', query.gymUnitId);
  }

  if (query.status) {
    params.set('status', query.status);
  }

  return params.toString();
}

export function buildAdminUsersListPath(query: Partial<AdminUsersQueryInput>): string {
  const queryString = buildAdminUsersQueryString(query);

  return queryString.length > 0 ? `/users?${queryString}` : '/users';
}

export function buildAdminUserDetailPath(userId: string, returnTo: string): string {
  const params = new URLSearchParams({
    returnTo,
  });

  return `/users/${userId}?${params.toString()}`;
}

export function resolveAdminUsersReturnToPath(value: string | string[] | undefined): string {
  const normalizedValue = getFirstValue(value);

  if (normalizedValue && normalizedValue.startsWith('/users')) {
    return normalizedValue;
  }

  return '/users';
}

export function formatAdminDateTime(value: string | null): string {
  if (!value) {
    return 'Nao informado';
  }

  const parsedDate = new Date(value);

  if (Number.isNaN(parsedDate.getTime())) {
    return 'Nao informado';
  }

  return adminDateTimeFormatter.format(parsedDate);
}

export function formatAdminRole(role: string): string {
  return role === 'ADMIN' ? 'Administrador' : 'Aluno';
}

export function formatAdminUserStatus(status: AdminUserStatus): string {
  switch (status) {
    case 'ACTIVE':
      return 'Ativo';
    case 'PENDING':
      return 'Pendente';
    case 'SUSPENDED':
      return 'Suspenso';
    case 'BANNED':
      return 'Banido';
    case 'DELETED':
      return 'Removido';
    default:
      return status;
  }
}

export function getAdminUsersErrorMessage(error: unknown): string {
  if (error instanceof ApiClientError) {
    if (error.status === 401 || error.status === 403) {
      return 'Sua sessao administrativa nao conseguiu acessar os usuarios. Entre novamente.';
    }

    if (error.status >= 500) {
      return 'A API administrativa nao conseguiu responder agora. Tente novamente em instantes.';
    }

    return error.message;
  }

  return 'Nao foi possivel carregar os usuarios administrativos.';
}

function parsePositiveInteger(
  value: string | string[] | undefined,
  fallback: number,
  max?: number,
): number {
  const normalizedValue = getFirstValue(value);

  if (!normalizedValue || !/^[1-9]\d*$/.test(normalizedValue)) {
    return fallback;
  }

  const parsedValue = Number.parseInt(normalizedValue, 10);

  if (max !== undefined && parsedValue > max) {
    return max;
  }

  return parsedValue;
}

function normalizeOptionalString(value: string | string[] | undefined): string | undefined {
  const normalizedValue = getFirstValue(value)?.trim();

  return normalizedValue ? normalizedValue : undefined;
}

function normalizeOptionalStatus(value: string | string[] | undefined): AdminUserStatus | undefined {
  const normalizedValue = getFirstValue(value)?.trim().toUpperCase();

  if (!normalizedValue || !adminUserStatuses.has(normalizedValue as AdminUserStatus)) {
    return undefined;
  }

  return normalizedValue as AdminUserStatus;
}

function getFirstValue(value: string | string[] | undefined): string | undefined {
  if (Array.isArray(value)) {
    return value[0];
  }

  return typeof value === 'string' ? value : undefined;
}
