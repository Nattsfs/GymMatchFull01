import 'server-only';

import { cookies } from 'next/headers';

import { ApiClientError, apiClient } from '@/lib/api-client';

import {
  ADMIN_SESSION_COOKIE_NAME,
  type AdminCheckResponse,
  type AuthenticatedAdminUser,
  type AuthLoginResponse,
  getFriendlyAdminLoginErrorMessage,
  isAdminRole,
} from './auth.shared';

const sessionCookieOptions = {
  httpOnly: true,
  sameSite: 'lax' as const,
  secure: process.env.NODE_ENV === 'production',
  path: '/',
};

export class AdminAuthError extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = 'AdminAuthError';
    this.status = status;
  }
}

export type AdminSessionState =
  | { status: 'anonymous' }
  | { status: 'invalid' }
  | { status: 'authenticated'; user: AuthenticatedAdminUser };

function mapAdminUser(
  user: AuthLoginResponse['user'] | AdminCheckResponse['user'],
): AuthenticatedAdminUser {
  if (!isAdminRole(user.role)) {
    throw new AdminAuthError(403, getFriendlyAdminLoginErrorMessage({ status: 403 }));
  }

  return {
    ...user,
    role: 'ADMIN',
  };
}

async function revokeBackendSession(token: string): Promise<void> {
  try {
    await apiClient('/auth/logout', {
      method: 'POST',
      token,
    });
  } catch {
    // Keep logout best-effort. The local session cookie still needs to be cleared.
  }
}

export async function startAdminSession(input: {
  email: string;
  password: string;
}): Promise<AuthenticatedAdminUser> {
  try {
    const response = await apiClient<AuthLoginResponse>('/auth/login', {
      method: 'POST',
      body: input,
    });

    if (!isAdminRole(response.user.role)) {
      await revokeBackendSession(response.accessToken);

      throw new AdminAuthError(403, getFriendlyAdminLoginErrorMessage({ status: 403 }));
    }

    const user: AuthenticatedAdminUser = {
      ...response.user,
      role: 'ADMIN',
    };
    const cookieStore = await cookies();

    cookieStore.set(ADMIN_SESSION_COOKIE_NAME, response.accessToken, sessionCookieOptions);

    return user;
  } catch (error) {
    if (error instanceof AdminAuthError) {
      throw error;
    }

    if (error instanceof ApiClientError) {
      throw new AdminAuthError(
        error.status,
        getFriendlyAdminLoginErrorMessage({
          status: error.status,
          message: error.message,
        }),
      );
    }

    throw new AdminAuthError(500, getFriendlyAdminLoginErrorMessage({}));
  }
}

export async function endAdminSession(): Promise<void> {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_SESSION_COOKIE_NAME)?.value;

  if (token) {
    await revokeBackendSession(token);
  }

  cookieStore.delete(ADMIN_SESSION_COOKIE_NAME);
}

export async function getAdminSessionState(): Promise<AdminSessionState> {
  const cookieStore = await cookies();
  const token = cookieStore.get(ADMIN_SESSION_COOKIE_NAME)?.value;

  if (!token) {
    return {
      status: 'anonymous',
    };
  }

  try {
    const response = await apiClient<AdminCheckResponse>('/auth/admin-check', {
      token,
    });

    return {
      status: 'authenticated',
      user: mapAdminUser(response.user),
    };
  } catch {
    return {
      status: 'invalid',
    };
  }
}
