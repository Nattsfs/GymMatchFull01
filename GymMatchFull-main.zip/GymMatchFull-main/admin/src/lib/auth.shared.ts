export const ADMIN_HOME_PATH = '/dashboard';
export const ADMIN_LOGIN_PATH = '/login';
export const ADMIN_SESSION_COOKIE_NAME = 'gymmatch_admin_session';

export type AdminSessionReason = 'logged-out' | 'session-invalid' | 'session-required';

export interface AuthenticatedApiUser {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
}

export interface AuthenticatedAdminUser {
  id: string;
  name: string;
  email: string;
  role: 'ADMIN';
  status: string;
}

export interface AuthLoginResponse {
  accessToken: string;
  refreshToken: string;
  user: AuthenticatedApiUser;
}

export interface AdminCheckResponse {
  status: string;
  message: string;
  user: AuthenticatedApiUser;
}

const accountStatusMessages = new Map<string, string>([
  ['This account has been deleted.', 'Esta conta foi removida e nao pode acessar o painel.'],
  ['This account is suspended.', 'Esta conta esta suspensa e nao pode acessar o painel.'],
  ['This account is banned.', 'Esta conta foi banida e nao pode acessar o painel.'],
  [
    'This account is pending activation.',
    'Esta conta ainda nao esta liberada para acessar o painel.',
  ],
  [
    'This account is not allowed to log in.',
    'Esta conta nao esta autorizada a acessar o painel.',
  ],
]);

export function isAdminRole(role: string): role is AuthenticatedAdminUser['role'] {
  return role === 'ADMIN';
}

export function getFriendlyAdminLoginErrorMessage(input: {
  status?: number;
  message?: string;
}): string {
  if (input.status === 401) {
    return 'E-mail ou senha incorretos.';
  }

  if (input.status === 403) {
    if (input.message && accountStatusMessages.has(input.message)) {
      return accountStatusMessages.get(input.message) ?? 'Acesso administrativo negado.';
    }

    return 'Esta conta nao tem permissao para acessar o painel administrativo.';
  }

  if (input.status === 400) {
    return 'Revise os dados informados e tente novamente.';
  }

  return 'Nao foi possivel entrar no painel agora. Tente novamente em instantes.';
}

export function getAdminSessionRedirectReason(status: 'anonymous' | 'invalid'): AdminSessionReason {
  return status === 'invalid' ? 'session-invalid' : 'session-required';
}

export function getLoginPageNoticeMessage(reason?: string | null): string | null {
  switch (reason) {
    case 'logged-out':
      return 'Sua sessao administrativa foi encerrada.';
    case 'session-invalid':
      return 'Sua sessao administrativa expirou ou nao e valida. Entre novamente.';
    case 'session-required':
      return 'Faca login com uma conta ADMIN para continuar.';
    default:
      return null;
  }
}
