import { describe, expect, it } from 'vitest';

import { validateLoginForm } from './login-form';

describe('validateLoginForm', () => {
  it('returns required errors when fields are empty', () => {
    expect(validateLoginForm({ email: '', password: '' })).toEqual({
      email: 'Informe o e-mail.',
      password: 'Informe a senha.',
    });
  });

  it('returns an email format error when email is invalid', () => {
    expect(validateLoginForm({ email: 'admin-gymmatch.com', password: '123456' })).toEqual({
      email: 'Informe um e-mail valido.',
    });
  });

  it('returns no errors when the form is valid', () => {
    expect(
      validateLoginForm({
        email: 'admin@gymmatch.com',
        password: '123456',
      }),
    ).toEqual({});
  });
});
