export interface LoginFormValues {
  email: string;
  password: string;
}

export type LoginFormErrors = Partial<Record<keyof LoginFormValues, string>>;

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateLoginForm(values: LoginFormValues): LoginFormErrors {
  const errors: LoginFormErrors = {};
  const normalizedEmail = values.email.trim();
  const normalizedPassword = values.password.trim();

  if (normalizedEmail.length === 0) {
    errors.email = 'Informe o e-mail.';
  } else if (!emailPattern.test(normalizedEmail)) {
    errors.email = 'Informe um e-mail valido.';
  }

  if (normalizedPassword.length === 0) {
    errors.password = 'Informe a senha.';
  }

  return errors;
}
