import { describe, expect, it } from 'vitest';

import {
  getAdminSessionRedirectReason,
  getFriendlyAdminLoginErrorMessage,
  getLoginPageNoticeMessage,
  isAdminRole,
} from './auth.shared';

describe('auth.shared', () => {
  it('maps invalid credentials to a friendly login message', () => {
    expect(getFriendlyAdminLoginErrorMessage({ status: 401 })).toBe(
      'E-mail ou senha incorretos.',
    );
  });

  it('maps backend account status errors to friendly admin messages', () => {
    expect(
      getFriendlyAdminLoginErrorMessage({
        status: 403,
        message: 'This account is suspended.',
      }),
    ).toBe('Esta conta esta suspensa e nao pode acessar o painel.');
  });

  it('blocks non-admin roles', () => {
    expect(isAdminRole('ADMIN')).toBe(true);
    expect(isAdminRole('STUDENT')).toBe(false);
  });

  it('returns the proper redirect reason for session states', () => {
    expect(getAdminSessionRedirectReason('anonymous')).toBe('session-required');
    expect(getAdminSessionRedirectReason('invalid')).toBe('session-invalid');
  });

  it('returns contextual notices for the login page', () => {
    expect(getLoginPageNoticeMessage('logged-out')).toBe(
      'Sua sessao administrativa foi encerrada.',
    );
    expect(getLoginPageNoticeMessage('session-invalid')).toBe(
      'Sua sessao administrativa expirou ou nao e valida. Entre novamente.',
    );
    expect(getLoginPageNoticeMessage('session-required')).toBe(
      'Faca login com uma conta ADMIN para continuar.',
    );
    expect(getLoginPageNoticeMessage()).toBeNull();
  });
});
