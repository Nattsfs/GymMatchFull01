import type { AdminDashboardMetrics } from '../types/metrics';
import { ApiClientError, apiClient } from './api-client';

export interface DashboardMetricCard {
  description: string;
  id: string;
  label: string;
  value: string;
}

const numberFormatter = new Intl.NumberFormat('pt-BR');

export async function fetchAdminDashboardMetrics(token: string): Promise<AdminDashboardMetrics> {
  return apiClient<AdminDashboardMetrics>('/admin/metrics', {
    token,
  });
}

export function formatMetricValue(value: number): string {
  return numberFormatter.format(value);
}

export function buildDashboardMetricCards(
  metrics: AdminDashboardMetrics,
): DashboardMetricCard[] {
  return [
    {
      id: 'total-users',
      label: 'Usuarios totais',
      value: formatMetricValue(metrics.totalUsers),
      description: 'Contas nao removidas por soft delete no ambiente atual.',
    },
    {
      id: 'active-users',
      label: 'Usuarios ativos',
      value: formatMetricValue(metrics.activeUsers),
      description: 'Contas com status ACTIVE liberadas para uso da plataforma.',
    },
    {
      id: 'total-matches',
      label: 'Matches',
      value: formatMetricValue(metrics.totalMatches),
      description: 'Volume total de registros de match ainda presentes no banco.',
    },
    {
      id: 'total-reports',
      label: 'Denuncias',
      value: formatMetricValue(metrics.totalReports),
      description: 'Ocorrencias administrativas disponiveis para moderacao.',
    },
    {
      id: 'premium-subscriptions',
      label: 'Assinaturas premium',
      value: formatMetricValue(metrics.premiumSubscriptions),
      description: 'Mantido em zero enquanto o modulo de assinaturas nao existe.',
    },
  ];
}

export function getDashboardMetricsErrorMessage(error: unknown): string {
  if (error instanceof ApiClientError) {
    if (error.status === 401 || error.status === 403) {
      return 'Sua sessao administrativa nao conseguiu acessar as metricas. Entre novamente.';
    }

    if (error.status >= 500) {
      return 'A API administrativa nao conseguiu responder agora. Tente novamente em instantes.';
    }

    return error.message;
  }

  return 'Nao foi possivel carregar as metricas do dashboard.';
}
