const DEFAULT_API_BASE_URL = 'http://localhost:3000';

export const adminApiConfig = {
  baseUrl: (process.env.NEXT_PUBLIC_API_BASE_URL ?? DEFAULT_API_BASE_URL).replace(/\/+$/, ''),
};

export type ApiMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export interface ApiRequestOptions {
  method?: ApiMethod;
  body?: FormData | unknown;
  headers?: HeadersInit;
  token?: string;
  cache?: RequestCache;
}

export class ApiClientError extends Error {
  readonly status: number;
  readonly details: unknown | undefined;

  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.details = details;
  }
}

function buildUrl(path: string) {
  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }

  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return `${adminApiConfig.baseUrl}${normalizedPath}`;
}

function parseResponseBody(body: string) {
  if (body.length === 0) {
    return null;
  }

  try {
    return JSON.parse(body) as unknown;
  } catch {
    return body;
  }
}

function getErrorMessage(payload: unknown, fallbackMessage: string) {
  if (payload && typeof payload === 'object' && 'message' in payload) {
    const possibleMessage = payload.message;

    if (typeof possibleMessage === 'string' && possibleMessage.length > 0) {
      return possibleMessage;
    }
  }

  return fallbackMessage;
}

export async function apiClient<TResponse>(
  path: string,
  options: ApiRequestOptions = {},
): Promise<TResponse> {
  const headers = new Headers(options.headers);
  const hasBody = options.body !== undefined;
  const formDataBody = options.body instanceof FormData ? options.body : null;
  const requestBody: BodyInit | undefined = hasBody
    ? (formDataBody ?? JSON.stringify(options.body))
    : undefined;

  if (options.token) {
    headers.set('Authorization', `Bearer ${options.token}`);
  }

  if (hasBody && !formDataBody && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const requestInit: RequestInit = {
    method: options.method ?? 'GET',
    headers,
    cache: options.cache ?? 'no-store',
  };

  if (requestBody !== undefined) {
    requestInit.body = requestBody;
  }

  const response = await fetch(buildUrl(path), requestInit);

  const rawBody = await response.text();
  const parsedBody = parseResponseBody(rawBody);

  if (!response.ok) {
    throw new ApiClientError(
      getErrorMessage(parsedBody, 'Nao foi possivel concluir a requisicao.'),
      response.status,
      parsedBody,
    );
  }

  return parsedBody as TResponse;
}
