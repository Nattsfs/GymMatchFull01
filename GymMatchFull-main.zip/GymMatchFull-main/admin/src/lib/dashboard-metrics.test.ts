import { describe, expect, it } from 'vitest';

import { ApiClientError } from './api-client';
import {
  buildDashboardMetricCards,
  formatMetricValue,
  getDashboardMetricsErrorMessage,
} from './dashboard-metrics';

describe('dashboard-metrics', () => {
  it('formats metric values using pt-BR separators', () => {
    expect(formatMetricValue(12345)).toBe('12.345');
  });

  it('builds the five dashboard cards from the API payload', () => {
    const cards = buildDashboardMetricCards({
      totalUsers: 120,
      activeUsers: 98,
      totalMatches: 44,
      totalReports: 6,
      premiumSubscriptions: 0,
    });

    expect(cards).toEqual([
      expect.objectContaining({
        id: 'total-users',
        label: 'Usuarios totais',
        value: '120',
      }),
      expect.objectContaining({
        id: 'active-users',
        label: 'Usuarios ativos',
        value: '98',
      }),
      expect.objectContaining({
        id: 'total-matches',
        label: 'Matches',
        value: '44',
      }),
      expect.objectContaining({
        id: 'total-reports',
        label: 'Denuncias',
        value: '6',
      }),
      expect.objectContaining({
        id: 'premium-subscriptions',
        label: 'Assinaturas premium',
        value: '0',
      }),
    ]);
  });

  it('maps authorization failures to a session-oriented dashboard message', () => {
    const error = new ApiClientError('Forbidden', 403);

    expect(getDashboardMetricsErrorMessage(error)).toBe(
      'Sua sessao administrativa nao conseguiu acessar as metricas. Entre novamente.',
    );
  });
});
