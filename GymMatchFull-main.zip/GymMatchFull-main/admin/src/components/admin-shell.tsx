import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';

import { AdminNavLink } from '@/components/admin-nav-link';
import { BrandMark } from '@/components/brand-mark';
import { endAdminSession } from '@/lib/auth';
import type { AuthenticatedAdminUser } from '@/lib/auth.shared';

const navigationItems = [
  {
    href: '/dashboard',
    label: 'Dashboard',
    description: 'Visao geral com metricas reais do sistema.',
  },
  {
    href: '/users',
    label: 'Usuarios',
    description: 'Consulta administrativa com filtros, paginação e detalhe basico.',
  },
];

const placeholderItems = [
  {
    label: 'Academias e unidades',
    description: 'Cadastro e filtros seguem como proxima etapa do painel.',
  },
  {
    label: 'Denuncias e relatorios',
    description: 'Area reservada para moderacao e exportacoes futuras.',
  },
];

interface AdminShellProps {
  children: ReactNode;
  user: AuthenticatedAdminUser;
}

export function AdminShell({ children, user }: AdminShellProps) {
  async function logoutAction() {
    'use server';

    await endAdminSession();
    redirect('/login?reason=logged-out');
  }

  return (
    <div className="admin-shell">
      <aside className="admin-shell__sidebar">
        <BrandMark />

        <nav aria-label="Navegacao principal" className="admin-shell__nav">
          {navigationItems.map((item) => (
            <AdminNavLink
              description={item.description}
              href={item.href}
              key={item.href}
              label={item.label}
            />
          ))}

          {placeholderItems.map((item) => (
            <div className="admin-shell__nav-placeholder" key={item.label}>
              <strong>{item.label}</strong>
              <span>{item.description}</span>
            </div>
          ))}
        </nav>
      </aside>

      <div className="admin-shell__content">
        <header className="admin-shell__header">
          <div>
            <span className="eyebrow">GymMatch web</span>
            <h1 className="admin-shell__title">Painel administrativo</h1>
            <p>Autenticacao validada no servidor com acesso restrito a contas ADMIN.</p>
          </div>

          <div className="admin-shell__header-actions">
            <div className="admin-shell__session">
              <strong>{user.name}</strong>
              <span className="admin-shell__session-email">{user.email}</span>
            </div>

            <form action={logoutAction}>
              <button className="button-secondary" type="submit">
                Sair
              </button>
            </form>
          </div>
        </header>

        <main className="admin-shell__main">{children}</main>
      </div>
    </div>
  );
}
