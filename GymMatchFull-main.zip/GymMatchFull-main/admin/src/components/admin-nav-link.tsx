'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

interface AdminNavLinkProps {
  href: string;
  label: string;
  description: string;
}

export function AdminNavLink({ href, label, description }: AdminNavLinkProps) {
  const pathname = usePathname();
  const isCurrent = pathname === href || pathname.startsWith(`${href}/`);

  return (
    <Link
      aria-current={isCurrent ? 'page' : undefined}
      className="admin-shell__nav-item"
      href={href}
    >
      <strong>{label}</strong>
      <span>{description}</span>
    </Link>
  );
}
