export function BrandMark() {
  return (
    <div className="brand-mark">
      <span aria-hidden="true" className="brand-mark__badge">
        GM
      </span>

      <div className="brand-mark__copy">
        <strong className="brand-mark__title">GymMatch Admin</strong>
        <span className="brand-mark__subtitle">Controle web do MVP administrativo</span>
      </div>
    </div>
  );
}
