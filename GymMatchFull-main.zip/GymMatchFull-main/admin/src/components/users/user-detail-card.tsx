import Link from 'next/link';

import {
  formatAdminDateTime,
  formatAdminRole,
  formatAdminUserStatus,
} from '@/lib/admin-users';
import type { AdminUserDetail } from '@/types/users';

interface UserDetailCardProps {
  returnTo: string;
  user: AdminUserDetail;
}

export function UserDetailCard({ returnTo, user }: UserDetailCardProps) {
  return (
    <>
      <section className="dashboard-hero">
        <div>
          <span className="eyebrow">Detalhe do usuario</span>
          <h1>{user.name}</h1>
          <p>
            Consulta administrativa somente leitura para operacao e moderacao basica do MVP.
          </p>
        </div>

        <div className="dashboard-hero__status">
          <span className="dashboard-hero__label">Situacao da conta</span>
          <strong>{formatAdminUserStatus(user.status)}</strong>
          <span>{formatAdminRole(user.role)}</span>
        </div>
      </section>

      <div className="user-detail-page__actions">
        <Link className="button-secondary" href={returnTo}>
          Voltar para usuarios
        </Link>
      </div>

      <section className="user-detail-grid">
        <article className="dashboard-card">
          <span className="dashboard-card__title">Identificacao</span>
          <dl className="detail-list">
            <div>
              <dt>Nome</dt>
              <dd>{user.name}</dd>
            </div>
            <div>
              <dt>E-mail</dt>
              <dd>{user.email}</dd>
            </div>
            <div>
              <dt>Role</dt>
              <dd>{formatAdminRole(user.role)}</dd>
            </div>
            <div>
              <dt>Status</dt>
              <dd>
                <span className="status-pill" data-status={user.status}>
                  {formatAdminUserStatus(user.status)}
                </span>
              </dd>
            </div>
          </dl>
        </article>

        <article className="dashboard-card">
          <span className="dashboard-card__title">Vinculo</span>
          <dl className="detail-list">
            <div>
              <dt>Academia</dt>
              <dd>{user.gym?.name ?? 'Nao vinculada'}</dd>
            </div>
            <div>
              <dt>Unidade</dt>
              <dd>{user.gymUnit?.name ?? 'Nao vinculada'}</dd>
            </div>
            <div>
              <dt>Criado em</dt>
              <dd>{formatAdminDateTime(user.createdAt)}</dd>
            </div>
          </dl>
        </article>

        <article className="dashboard-card">
          <span className="dashboard-card__title">Sessao</span>
          <dl className="detail-list">
            <div>
              <dt>Ultimo login</dt>
              <dd>{formatAdminDateTime(user.lastLoginAt)}</dd>
            </div>
            <div>
              <dt>Soft delete</dt>
              <dd>{formatAdminDateTime(user.deletedAt)}</dd>
            </div>
          </dl>
        </article>
      </section>
    </>
  );
}
