import Link from 'next/link';

import {
  ADMIN_USER_PAGE_SIZE_OPTIONS,
  ADMIN_USER_STATUS_OPTIONS,
} from '@/lib/admin-users';
import type {
  AdminGymFilterOption,
  AdminGymUnitFilterOption,
  AdminUsersQueryInput,
} from '@/types/users';

interface UserFiltersFormProps {
  filters: AdminUsersQueryInput;
  filtersErrorMessage?: string | null;
  gymOptions: AdminGymFilterOption[];
  gymUnitOptions: AdminGymUnitFilterOption[];
}

export function UserFiltersForm({
  filters,
  filtersErrorMessage,
  gymOptions,
  gymUnitOptions,
}: UserFiltersFormProps) {
  return (
    <section className="dashboard-card users-filters">
      <div>
        <span className="dashboard-card__title">Filtros</span>
        <p className="dashboard-card__copy">
          Consulte usuarios por status, academia, unidade e busca textual.
        </p>
      </div>

      {filtersErrorMessage ? (
        <div className="form-status" data-tone="error">
          {filtersErrorMessage}
        </div>
      ) : null}

      <form action="/users" className="users-filters__form" method="GET">
        <input name="page" type="hidden" value="1" />

        <div className="form-field">
          <label htmlFor="search">Busca por nome ou e-mail</label>
          <input
            defaultValue={filters.search ?? ''}
            id="search"
            name="search"
            placeholder="Ex.: Pedro ou admin@gymmatch.com"
            type="search"
          />
        </div>

        <div className="form-field">
          <label htmlFor="status">Status</label>
          <select defaultValue={filters.status ?? ''} id="status" name="status">
            <option value="">Todos</option>
            {ADMIN_USER_STATUS_OPTIONS.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label htmlFor="gymId">Academia</label>
          <select defaultValue={filters.gymId ?? ''} id="gymId" name="gymId">
            <option value="">Todas</option>
            {gymOptions.map((gym) => (
              <option key={gym.id} value={gym.id}>
                {gym.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label htmlFor="gymUnitId">Unidade</label>
          <select defaultValue={filters.gymUnitId ?? ''} id="gymUnitId" name="gymUnitId">
            <option value="">
              {filters.gymId ? 'Todas as unidades da academia' : 'Todas as unidades'}
            </option>
            {gymUnitOptions.map((gymUnit) => (
              <option key={gymUnit.id} value={gymUnit.id}>
                {gymUnit.gym.name} - {gymUnit.name}
              </option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label htmlFor="limit">Itens por pagina</label>
          <select defaultValue={String(filters.limit)} id="limit" name="limit">
            {ADMIN_USER_PAGE_SIZE_OPTIONS.map((limit) => (
              <option key={limit} value={limit}>
                {limit}
              </option>
            ))}
          </select>
        </div>

        <div className="users-filters__actions">
          <button className="button-primary" type="submit">
            Aplicar filtros
          </button>

          <Link className="button-secondary" href="/users">
            Limpar
          </Link>
        </div>
      </form>
    </section>
  );
}
