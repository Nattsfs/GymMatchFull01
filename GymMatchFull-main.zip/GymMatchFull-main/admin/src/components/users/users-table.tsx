import Link from 'next/link';

import {
  buildAdminUserDetailPath,
  formatAdminDateTime,
  formatAdminRole,
  formatAdminUserStatus,
} from '@/lib/admin-users';
import type { AdminUserListItem } from '@/types/users';

interface UsersTableProps {
  returnTo: string;
  users: AdminUserListItem[];
}

export function UsersTable({ returnTo, users }: UsersTableProps) {
  return (
    <div className="users-table__wrapper">
      <table className="users-table">
        <thead>
          <tr>
            <th scope="col">Nome</th>
            <th scope="col">E-mail</th>
            <th scope="col">Role</th>
            <th scope="col">Status</th>
            <th scope="col">Academia / unidade</th>
            <th scope="col">Criado em</th>
            <th scope="col" />
          </tr>
        </thead>

        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>
                <strong>{user.name}</strong>
              </td>
              <td>{user.email}</td>
              <td>{formatAdminRole(user.role)}</td>
              <td>
                <span className="status-pill" data-status={user.status}>
                  {formatAdminUserStatus(user.status)}
                </span>
              </td>
              <td>
                <strong>{user.gym?.name ?? 'Sem academia vinculada'}</strong>
                <div className="users-table__meta">{user.gymUnit?.name ?? 'Sem unidade vinculada'}</div>
              </td>
              <td>{formatAdminDateTime(user.createdAt)}</td>
              <td>
                <Link className="button-secondary users-table__action" href={buildAdminUserDetailPath(user.id, returnTo)}>
                  Abrir
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
