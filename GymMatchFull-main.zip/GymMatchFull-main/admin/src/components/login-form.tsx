'use client';

import type { ChangeEvent, FormEvent } from 'react';
import { useState } from 'react';

import {
  type LoginFormErrors,
  type LoginFormValues,
  validateLoginForm,
} from '@/lib/validators/login-form';

const initialValues: LoginFormValues = {
  email: '',
  password: '',
};

type FormStatusTone = 'error' | 'neutral';

interface LoginFormProps {
  noticeMessage?: string | null;
}

function readResponseMessage(payload: unknown) {
  if (payload && typeof payload === 'object' && 'message' in payload) {
    const message = payload.message;

    if (typeof message === 'string' && message.length > 0) {
      return message;
    }
  }

  return null;
}

export function LoginForm({ noticeMessage = null }: LoginFormProps) {
  const [values, setValues] = useState<LoginFormValues>(initialValues);
  const [errors, setErrors] = useState<LoginFormErrors>({});
  const [statusMessage, setStatusMessage] = useState<string | null>(noticeMessage);
  const [statusTone, setStatusTone] = useState<FormStatusTone>('neutral');
  const [isSubmitting, setIsSubmitting] = useState(false);

  function updateField(field: keyof LoginFormValues, value: string) {
    setValues((currentValues) => ({
      ...currentValues,
      [field]: value,
    }));

    setErrors((currentErrors) => {
      if (!currentErrors[field]) {
        return currentErrors;
      }

      const nextErrors = { ...currentErrors };
      delete nextErrors[field];
      return nextErrors;
    });

    setStatusMessage(null);
    setStatusTone('neutral');
  }

  function handleChange(field: keyof LoginFormValues) {
    return (event: ChangeEvent<HTMLInputElement>) => {
      updateField(field, event.target.value);
    };
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const nextErrors = validateLoginForm(values);

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      setStatusMessage(null);
      setStatusTone('neutral');
      return;
    }

    setErrors({});
    setStatusMessage(null);
    setStatusTone('neutral');
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: values.email.trim(),
          password: values.password,
        }),
      });
      const payload = (await response.json().catch(() => null)) as unknown;

      if (!response.ok) {
        setStatusTone('error');
        setStatusMessage(
          readResponseMessage(payload) ??
            'Nao foi possivel entrar no painel agora. Tente novamente em instantes.',
        );
        return;
      }

      const redirectTo =
        payload &&
        typeof payload === 'object' &&
        'redirectTo' in payload &&
        typeof payload.redirectTo === 'string'
          ? payload.redirectTo
          : '/dashboard';

      window.location.assign(redirectTo);
    } catch {
      setStatusTone('error');
      setStatusMessage('Nao foi possivel entrar no painel agora. Tente novamente em instantes.');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <form aria-busy={isSubmitting} className="login-form" noValidate onSubmit={handleSubmit}>
      <div className="form-field">
        <label htmlFor="email">E-mail</label>
        <input
          autoComplete="email"
          disabled={isSubmitting}
          id="email"
          name="email"
          onChange={handleChange('email')}
          placeholder="admin@gymmatch.com"
          required
          type="email"
          value={values.email}
          aria-invalid={Boolean(errors.email)}
          aria-describedby={errors.email ? 'email-error' : undefined}
        />
        {errors.email ? (
          <span className="form-field__error" id="email-error">
            {errors.email}
          </span>
        ) : null}
      </div>

      <div className="form-field">
        <label htmlFor="password">Senha</label>
        <input
          autoComplete="current-password"
          disabled={isSubmitting}
          id="password"
          name="password"
          onChange={handleChange('password')}
          placeholder="Digite sua senha"
          required
          type="password"
          value={values.password}
          aria-invalid={Boolean(errors.password)}
          aria-describedby={errors.password ? 'password-error' : undefined}
        />
        {errors.password ? (
          <span className="form-field__error" id="password-error">
            {errors.password}
          </span>
        ) : null}
      </div>

      {statusMessage ? (
        <div className="form-status" data-tone={statusTone}>
          {statusMessage}
        </div>
      ) : null}

      <button className="button-primary" disabled={isSubmitting} type="submit">
        {isSubmitting ? 'Entrando...' : 'Continuar'}
      </button>
    </form>
  );
}
