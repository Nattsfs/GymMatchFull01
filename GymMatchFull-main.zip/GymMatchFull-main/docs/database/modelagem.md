# Modelagem Inicial do Banco

## User

O modelo `User` representa a base de autenticacao e identificacao de contas do sistema. Nesta fase ele existe apenas como estrutura de persistencia e suporte interno para tarefas futuras.

Campos principais:

- `id`
- `name`
- `email`
- `phone`
- `cpf`
- `passwordHash`
- `role`
- `status`
- `gymId`
- `gymUnitId`
- `emailVerifiedAt`
- `phoneVerifiedAt`
- `termsAcceptedAt`
- `lastLoginAt`
- `createdAt`
- `updatedAt`
- `deletedAt`

## Roles

- `STUDENT`
- `ADMIN`

## Status

- `ACTIVE`
- `PENDING`
- `SUSPENDED`
- `BANNED`
- `DELETED`

## Soft delete

O campo `deletedAt` foi adicionado para suportar soft delete. Nesta fase, as constraints de unicidade continuam simples em `email`, `cpf` e `phone`, inclusive para registros com `deletedAt` preenchido.

Impacto da decisao atual:

- uma conta soft deleted ainda reserva `email`, `cpf` e `phone`;
- a regra pode ser refinada em tarefa futura se o produto exigir reativacao ou recriacao controlada de contas.
- novos alunos `STUDENT` devem ser criados com `gymId` e `gymUnitId` preenchidos a partir do QR Code valido da unidade.

## Gym

O modelo `Gym` representa uma academia ou rede de academias dentro do MVP.

Campos principais:

- `id`
- `name`
- `legalName`
- `document`
- `email`
- `phone`
- `status`
- `createdAt`
- `updatedAt`
- `deletedAt`

## GymUnit

O modelo `GymUnit` representa uma unidade fisica vinculada a uma `Gym`.

Campos principais:

- `id`
- `gymId`
- `qrCodeToken`
- `name`
- `addressLine`
- `number`
- `complement`
- `neighborhood`
- `city`
- `state`
- `zipCode`
- `latitude`
- `longitude`
- `status`
- `createdAt`
- `updatedAt`
- `deletedAt`

## Relacionamento entre Gym e GymUnit

- uma `Gym` pode possuir varias `GymUnit`;
- uma `GymUnit` pertence obrigatoriamente a uma `Gym`;
- o banco protege essa regra com chave estrangeira em `gymId`;
- existe unicidade de `GymUnit` por `gymId + name`.

## Vinculacao entre User, Gym e GymUnit

- `User.gymId` referencia a academia do aluno;
- `User.gymUnitId` referencia a unidade do aluno;
- o cadastro publico do aluno deriva ambos apenas do `qrCodeToken` da `GymUnit`;
- o banco possui FKs para `Gym` e `GymUnit`, indices por `gymId`, `gymUnitId` e `role + gymUnitId`;
- uma constraint impede novos `STUDENT` sem academia/unidade;
- uma FK composta em `gymUnitId + gymId` protege a consistencia entre a unidade e a academia vinculadas.

## Status de academias e unidades

`Gym` e `GymUnit` usam enums dedicados com os valores:

- `ACTIVE`
- `INACTIVE`
- `DELETED`

Nesta fase:

- `ACTIVE` representa registro disponivel para uso;
- `INACTIVE` representa registro desativado sem exclusao logica;
- `DELETED` fica reservado para fluxos futuros que precisem marcar o status alem de `deletedAt`.

## Soft delete de Gym e GymUnit

`Gym` e `GymUnit` tambem possuem `deletedAt` para suportar soft delete.

Decisao atual:

- buscas padrao do modulo `gyms` ocultam registros com `deletedAt` preenchido;
- a modelagem mantem o registro no banco para auditoria e restauracao futura;
- `document` de `Gym` continua unico mesmo se um registro estiver soft deleted.

## Decisao atual sobre desativacao

Na fase atual, desativar uma `Gym` altera apenas o `status` da propria academia.

- `Gym` pode ser marcada como `INACTIVE`;
- `GymUnit` vinculadas mantem seu proprio `status`;
- nenhuma propagacao automatica de status para unidades foi implementada nesta etapa;
- criar ou ativar `GymUnit` exige que a `Gym` vinculada esteja `ACTIVE`.

## Indices e constraints principais

- `Gym`: indices em `status`, `deletedAt` e `createdAt`
- `Gym`: unicidade em `document`
- `GymUnit`: indices em `gymId`, `status`, `deletedAt` e `city + state`
- `GymUnit`: unicidade em `qrCodeToken`
- `GymUnit`: unicidade composta em `gymId + name`
- `User`: indices em `gymId`, `gymUnitId` e `role + gymUnitId`

## Observacao desta fase

As entidades `Gym` e `GymUnit` foram criadas apenas para preparar o cadastro por academia/unidade.

Ja fazem parte desta fase:

- token publico de QR Code por `GymUnit`;
- validacao publica do token;
- vinculacao de `User` a `Gym` e `GymUnit` no cadastro de aluno.

Ainda nao fazem parte desta fase:

- leitura mobile do QR Code por camera;
- validacao real de matricula;
- integracao com sistemas reais de academia.

Ja existem endpoints administrativos para `Gym` e `GymUnit`, protegidos por JWT e role `ADMIN`.
