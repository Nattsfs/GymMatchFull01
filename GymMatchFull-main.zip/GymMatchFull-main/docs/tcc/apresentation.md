# GymMatch - guia para apresentacao

Este documento foi escrito para ajudar quem for apresentar o projeto sem ter participado de toda a implementacao. O objetivo aqui nao e vender um produto pronto; e explicar com clareza o que existe de fato, o que esta parcial e como conduzir uma apresentacao honesta e segura.

## 1. Resumo executivo

O GymMatch foi pensado como um MVP academico de uma plataforma para conectar alunos da mesma academia ou unidade. A ideia central e combinar:

- descoberta de perfis
- curtidas e matches
- chat entre usuarios com match
- mecanismos basicos de moderacao
- um painel admin inicial para acompanhar o sistema

O estado atual do repositorio esta concentrado em:

- backend/API bem avancado
- painel admin web inicial, mas funcional
- modelagem de banco em Prisma
- boa cobertura de testes no backend

O que nao foi entregue:

- app mobile
- integracoes reais de SMS, e-mail, storage e pagamentos
- seed automatica para ambiente de demo
- painel admin completo para todos os modulos existentes na API

## 2. Arquitetura entregue

### Monorepo

O repositorio esta dividido em workspaces:

- `backend/`
- `admin/`
- `mobile/`

### Backend

Stack principal:

- Fastify
- Prisma
- PostgreSQL
- JWT
- Vitest

O backend concentra praticamente todas as regras de negocio ja implementadas.

### Painel admin

Stack principal:

- Next.js App Router
- React
- TypeScript

O painel admin:

- faz login real no backend
- grava sessao em cookie HttpOnly
- valida a sessao via `GET /auth/admin-check`
- exibe dashboard com metricas reais
- lista usuarios com filtros e paginacao
- mostra detalhe individual de usuario

### Mobile

O workspace `mobile/` existe apenas como reserva de estrutura. Nao ha telas, navegacao ou integracao iniciadas ali.

## 3. O que foi criado ate aqui

### 3.1 Base do projeto

Ja foram estruturados:

- monorepo com `pnpm`
- TypeScript em toda a base
- ESLint e Prettier
- scripts de build, test e typecheck
- configuracao centralizada de ambiente
- migrations versionadas com Prisma

### 3.2 Banco de dados e modelagem

Entidades que ja aparecem no schema:

- `User`
- `Gym`
- `GymUnit`
- `Profile`
- `Like`
- `Rejection`
- `Match`
- `Conversation`
- `Message`
- `Block`
- `Report`
- `AppMetadata`

Enums relevantes que ja existem:

- roles de usuario: `STUDENT`, `ADMIN`
- status de usuario: `ACTIVE`, `PENDING`, `SUSPENDED`, `BANNED`, `DELETED`
- status de match: `ACTIVE`, `EXPIRED`, `UNMATCHED`, `BLOCKED`
- tipos de mensagem: `TEXT`, `AUDIO`, `IMAGE`
- tipos e status de denuncia

Observacao importante:

- varias entidades ja tem `deletedAt`, entao a base ja foi preparada para soft delete
- ainda nao existe uma entidade de auditoria persistida

### 3.3 Autenticacao e cadastro

Fluxos implementados:

- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/refresh`
- `POST /auth/logout`
- `GET /auth/me`
- `POST /auth/forgot-password`
- `POST /auth/reset-password`
- `GET /auth/admin-check`

Comportamento atual:

- o cadastro publico so cria usuarios `STUDENT`
- cadastro de `ADMIN` por endpoint publico e bloqueado
- login devolve access token e refresh token
- refresh token usa hash salvo no banco
- recuperacao de senha existe, mas o envio de e-mail e simulado por log

O que vale dizer na apresentacao:

- a base de autenticacao esta funcional
- seguranca minima ja existe
- os providers reais de e-mail e SMS ainda nao foram plugados

### 3.4 Academias e unidades

Fluxos implementados:

- `GET /public/gym-units/qr/:token`
- `POST /admin/gyms`
- `GET /admin/gyms`
- `GET /admin/gyms/:id`
- `PATCH /admin/gyms/:id`
- `PATCH /admin/gyms/:id/activate`
- `PATCH /admin/gyms/:id/deactivate`
- `POST /admin/gym-units`
- `GET /admin/gym-units`
- `GET /admin/gym-units/:id`
- `PATCH /admin/gym-units/:id`
- `PATCH /admin/gym-units/:id/activate`
- `PATCH /admin/gym-units/:id/deactivate`

Pontos importantes:

- `GymUnit` possui `qrCodeToken`
- o cadastro do aluno depende de um token valido da unidade
- `Gym` e `GymUnit` ja possuem `status` e `deletedAt`
- o CRUD existe na API, mas ainda nao tem telas equivalentes no painel admin

### 3.5 Perfil de aluno

Fluxos implementados:

- `POST /profiles/me`
- `PATCH /profiles/me`
- `POST /profiles/me/photo`

Campos e regras que ja pesam no comportamento:

- idade minima de 18 anos
- genero
- orientacao sexual
- objetivo no app
- nivel de treino
- periodos disponiveis
- modalidades preferidas
- divisao de treino
- bio opcional
- flags de visibilidade
- foto de perfil

Regra central ja implementada:

- um perfil so fica `isComplete = true` quando os dados obrigatorios existem e a foto esta presente

Observacao importante para a demo:

- sem foto e sem perfil completo, o aluno nao entra em descoberta

### 3.6 Descoberta

Fluxo implementado:

- `GET /discovery/profiles`

O que a descoberta ja filtra:

- o proprio usuario
- usuarios fora da mesma academia/unidade
- usuarios nao ativos
- usuarios soft deleted
- perfis incompletos
- perfis sem foto
- usuarios bloqueados
- usuarios que bloquearam o usuario atual
- usuarios ja recusados pelo usuario atual

O que a descoberta ja faz alem do filtro:

- se o usuario atual ja tiver perfil, a lista prioriza primeiro pessoas com o mesmo `appGoal`

O que ainda nao faz:

- algoritmo sofisticado de recomendacao
- ordenacao por compatibilidade avancada

### 3.7 Curtidas, recusas e matches

Fluxos implementados:

- `POST /likes`
- `POST /rejections`
- `GET /matches/me`

Regras ja implementadas:

- curtida mutua gera match automaticamente
- match so acontece entre alunos ativos e elegiveis
- like na propria conta e bloqueado
- like entre usuarios com bloqueio tambem e bloqueado
- plano gratis tem limite diario de 10 likes
- plano gratis tem limite de 5 matches ativos
- quando o match e criado, a conversa interna e criada junto

O que vale frisar:

- ja existe o nucleo de regra social do produto
- o app mobile nao foi construido, mas o dominio principal ja esta modelado e testado

### 3.8 Chat

Fluxos HTTP implementados:

- `GET /chat/conversations/:conversationId/messages`
- `POST /chat/conversations/:conversationId/messages`
- `POST /chat/conversations/:conversationId/audio`
- `POST /chat/conversations/:conversationId/image`
- `DELETE /chat/messages/:messageId`

Fluxo WebSocket implementado:

- `GET /chat/ws`

Capacidades atuais:

- mensagem de texto
- upload de audio
- listagem paginada de mensagens
- delecao logica de mensagem pelo proprio remetente
- evento `message.created` por WebSocket

Limites atuais:

- upload de imagem exige premium, mas o stub de premium retorna `false` para todos
- os arquivos sao salvos localmente em `tmp/storage`
- a URL `/storage/...` ainda nao foi exposta publicamente pela API

Como explicar isso:

- o chat ja tem boa parte da estrutura tecnica
- a experiencia final de produto ainda nao foi concluida

### 3.9 Bloqueios e denuncias

Fluxos implementados:

- `POST /blocks`
- `POST /reports/users`
- `POST /reports/messages`
- `GET /admin/reports`
- `GET /admin/reports/:id`
- `PATCH /admin/reports/:id/status`
- `PATCH /admin/reports/:id/urgency`
- `POST /admin/reports/:id/suspend-reported-user`
- `POST /admin/reports/:id/ban-reported-user`

Comportamentos atuais:

- bloquear um usuario impacta o match entre eles
- denunciar um usuario ou mensagem cria o registro de moderacao
- a denuncia automatiza um bloqueio entre os envolvidos
- o admin ja pode listar, detalhar, marcar urgencia e aplicar suspensao/banimento

Ponto honesto para a banca:

- a moderacao basica existe
- ainda nao ha um modulo completo de auditoria persistida

### 3.10 Painel administrativo

Telas entregues:

- `/login`
- `/dashboard`
- `/users`
- `/users/:id`

O que cada uma demonstra:

- `login`: autenticacao real com role `ADMIN`
- `dashboard`: metricas reais do backend
- `users`: listagem paginada com filtros basicos
- `users/:id`: detalhamento de cadastro e estado do usuario

Metricas atualmente expostas no dashboard:

- total de usuarios
- usuarios ativos
- total de matches
- total de denuncias
- assinaturas premium em zero

Importante:

- o painel ainda nao tem telas para gerenciar gyms, gym units e reports
- essas operacoes estao prontas na API, mas nao na interface web

### 3.11 Testes

Cobertura ja existente no backend:

- health
- auth
- gyms
- profiles
- discovery
- likes
- rejections
- matches
- chat
- blocks
- reports
- admin metrics
- users
- storage local
- validacao de ambiente

Cobertura existente no admin:

- validacao do login
- mapeamento de metricas
- utilitarios de usuarios
- autenticacao compartilhada

Como usar isso na fala:

- mesmo sem o produto final completo, ha preocupacao com confiabilidade e regressao

## 4. O que esta parcial, simulado ou pendente

Estas sao as limitacoes que vale declarar abertamente:

- o app mobile ainda nao foi iniciado
- nao existe seed automatica para ambiente de demo
- conta `ADMIN` precisa ser criada manualmente
- e-mail de recuperacao e simulado por log
- SMS nao foi integrado
- pagamentos nao foram implementados
- premium existe apenas como stub tecnico
- storage local existe, mas a entrega publica dos arquivos nao
- painel admin ainda cobre so uma parte dos modulos do backend
- nao existe integracao real com academia, catraca ou matricula
- nao existe algoritmo avancado de recomendacao
- nao existe exportacao de relatorios em Excel

## 5. O que vale demonstrar

Se houver pouco tempo, foque no que realmente esta forte:

1. monorepo organizado com backend, admin e banco modelado
2. autenticacao funcional
3. cadastro do aluno ligado a uma unidade
4. perfis com regra de completude
5. descoberta + curtida mutua + match
6. chat basico
7. denuncia e bloqueio
8. painel admin com metricas e consulta de usuarios

## 6. Roteiro sugerido de apresentacao

### Roteiro curto, 5 a 8 minutos

1. Explique a proposta do produto.
2. Mostre a estrutura do repositorio.
3. Mostre a API rodando em `/health`.
4. Mostre o login administrativo em `http://localhost:3001/login`.
5. Entre no dashboard e explique as metricas reais.
6. Abra a listagem de usuarios e o detalhe de um usuario.
7. Encerre explicando que o backend do MVP esta avancado, enquanto mobile e integracoes ficaram para a proxima fase.

### Roteiro medio, 10 a 15 minutos

1. Contextualize o problema e o publico do app.
2. Mostre o monorepo e a stack.
3. Explique que o backend concentra a maior parte do progresso.
4. Suba a API e o painel admin.
5. Demonstre login administrativo.
6. Mostre dashboard e usuarios.
7. Abra um cliente HTTP e mostre:
   - validacao publica de `qrCodeToken`
   - cadastro de aluno
   - criacao de perfil
   - descoberta
   - curtida mutua gerando match
   - envio de mensagem
   - denuncia de usuario ou mensagem
8. Volte ao admin e explique que o backend ja expoe moderacao e metricas.
9. Feche com as limitacoes atuais e os proximos passos naturais.

## 7. Frases seguras para usar na banca

Quando precisar ser direto e honesto:

- "A parte mais madura do trabalho hoje esta no backend e no modelo de dados."
- "O painel admin ja consome a API real, com autenticacao e validacao de role."
- "O fluxo mobile nao foi iniciado, mas as regras centrais do dominio ja foram implementadas e testadas."
- "Integracoes reais de e-mail, SMS, premium e storage ficaram preparadas em abstracao, mas nao plugadas nesta etapa."
- "Para a apresentacao, o mais demonstravel e o funcionamento do backend, da moderacao e do painel administrativo."

## 8. Perguntas que podem aparecer

### "Por que o admin precisa ser criado manualmente?"

Porque o sistema ja protege o cadastro publico para nao permitir criacao aberta de contas administrativas. Como ainda nao existe um bootstrap/seed pronto, a conta admin precisa ser inserida manualmente no banco para fins de demo.

### "Por que o app mobile nao esta aqui?"

Porque o desenvolvimento foi priorizado em infraestrutura, banco, autenticacao, regras de negocio e painel admin inicial. O mobile ficou para a proxima etapa.

### "O chat esta pronto?"

Parcialmente. Texto e audio existem, o fluxo de conversa existe, o evento WebSocket existe, mas imagem premium ainda esta bloqueada e o serving publico de arquivos ainda nao esta fechado.

### "O que seria a proxima fase natural?"

- iniciar o app mobile
- concluir telas administrativas que faltam
- plugar providers reais de e-mail, SMS e storage
- adicionar seed/demo data
- finalizar premium e pagamentos

## 9. Fechamento recomendado

Uma forma segura de encerrar a apresentacao:

"Mesmo sem todas as frentes concluidas, o projeto conseguiu entregar uma base tecnica consistente para o MVP: autenticacao, modelagem relacional, regras centrais de descoberta e interacao, moderacao e um painel admin inicial. O proximo passo seria transformar essa base em uma experiencia completa de app."
