## Visão geral do projeto

Este repositório contém o desenvolvimento de um TCC de ADS: uma plataforma estilo “Tinder de academia”, voltada para alunos de academia que desejam conhecer outras pessoas da mesma academia/unidade, interagir, dar match e conversar.

O projeto terá:

- Aplicativo mobile para alunos.
- Painel administrativo web para administradores.
- Backend/API.
- Banco de dados PostgreSQL.
- Funcionalidades de cadastro, autenticação, perfil, descoberta de usuários, curtidas, matches, chat, denúncias, bloqueios, planos premium, relatórios e moderação.

O objetivo principal do sistema é social, permitindo que alunos encontrem:

- Parceiros de treino.
- Amizades.
- Pessoas com objetivos parecidos.
- Possíveis interesses amorosos.

O projeto deve ser desenvolvido com foco em MVP funcional para apresentação acadêmica, evitando complexidade desnecessária.

---

## Objetivo deste arquivo

Este arquivo define as regras de trabalho que o Codex deve seguir ao executar qualquer tarefa neste projeto.

Antes de modificar arquivos, o Codex deve ler este documento e respeitar as instruções aqui descritas.

---

## Princípios gerais de trabalho

Ao executar uma tarefa, o Codex deve:

1. Entender o contexto da tarefa antes de alterar arquivos.
2. Verificar a estrutura atual do projeto.
3. Respeitar a arquitetura existente.
4. Fazer alterações pequenas, coesas e bem delimitadas.
5. Evitar misturar funcionalidades não relacionadas na mesma alteração.
6. Priorizar o MVP do TCC.
7. Evitar overengineering.
8. Criar código simples, legível e fácil de explicar em banca.
9. Sempre considerar segurança, privacidade e LGPD.
10. Atualizar testes e documentação quando necessário.

---

## Como o Codex deve iniciar cada tarefa

Antes de codar, o Codex deve:

1. Ler a tarefa solicitada.
2. Identificar quais módulos serão afetados.
3. Inspecionar os arquivos relevantes do projeto.
4. Entender padrões já existentes.
5. Criar um plano breve de execução quando a tarefa for média ou complexa.
6. Só então implementar.

Para tarefas simples, o Codex pode implementar diretamente, mas ainda deve respeitar os padrões do projeto.

---

## Como o Codex deve finalizar cada tarefa

Ao terminar uma tarefa, o Codex deve informar:

1. O que foi alterado.
2. Quais arquivos foram criados ou modificados.
3. Quais testes foram criados ou atualizados.
4. Quais comandos foram executados.
5. Se os testes passaram ou falharam.
6. Riscos ou pendências.
7. Próximos passos sugeridos, se existirem.

O Codex não deve omitir falhas de build, lint ou testes.

---

## Escopo do MVP

O MVP deve priorizar:

- Cadastro de aluno via QR Code da academia/unidade.
- Verificação de telefone por SMS.
- Verificação de e-mail.
- Login e logout.
- Recuperação de senha.
- Criação e edição de perfil.
- Upload de foto.
- Listagem de perfis da mesma academia/unidade.
- Curtir perfil.
- Recusar perfil.
- Criação de match por curtida mútua.
- Chat após match.
- Denúncia de usuário ou mensagem.
- Bloqueio entre usuários.
- Painel administrativo web.
- Gestão de usuários.
- Gestão de academias e unidades.
- Visualização de denúncias.
- Suspensão e banimento de usuários.
- Métricas administrativas.
- Exportação de relatórios.
- Soft delete.
- Logs de auditoria básicos.
- Controle de acesso por role.
- Testes principais.
- Deploy inicial.

---

## Funcionalidades fora do MVP ou futuras

As seguintes funcionalidades devem ser tratadas como melhorias futuras, salvo solicitação explícita:

- Algoritmo avançado de recomendação.
- Integração real com sistema da academia.
- Integração real com catraca.
- Validação real de matrícula.
- Gamificação.
- Ranking.
- Favoritos.
- Filtro automático avançado de mensagens ofensivas.
- Moderação com IA.
- Backup avançado.
- Múltiplos níveis administrativos.
- Analytics avançado.
- Sistema complexo de permissões.
- Integração com sistemas financeiros da academia.

---

## Usuários do sistema

O sistema terá inicialmente dois tipos de usuário:

### Aluno

Usuário principal do app mobile.

Pode:

- Criar conta.
- Fazer login.
- Editar perfil.
- Visualizar perfis.
- Curtir perfis.
- Recusar perfis.
- Dar match.
- Conversar após match.
- Denunciar usuários/mensagens.
- Bloquear usuários.
- Pausar ou excluir conta com soft delete.
- Usar recursos premium, se assinante.

### Administrador

Usuário do painel web.

Pode:

- Acessar painel administrativo.
- Visualizar usuários.
- Filtrar usuários por academia/unidade.
- Criar contas manualmente.
- Editar dados de alunos.
- Suspender usuários.
- Banir usuários.
- Gerenciar denúncias.
- Visualizar conversas denunciadas.
- Cadastrar academias.
- Cadastrar unidades.
- Ver métricas.
- Exportar relatórios.
- Enviar comunicados.
- Acessar logs relevantes.

---

## Dados sensíveis

Este projeto lida com dados sensíveis e pessoais, incluindo:

- CPF.
- Telefone.
- E-mail.
- Data de nascimento.
- Idade.
- Gênero.
- Orientação sexual.
- Fotos.
- Mensagens.
- Áudios.
- Imagens enviadas no chat.
- Denúncias.
- Histórico de bloqueios.
- Dados de assinatura.

O Codex deve tratar esses dados com cuidado.

---

## Regras de privacidade e LGPD

O Codex deve seguir estes princípios:

1. Coletar apenas dados necessários.
2. Proteger dados sensíveis.
3. Nunca expor CPF, telefone ou dados privados sem necessidade.
4. Não retornar dados sensíveis em endpoints públicos.
5. Usar controle de acesso em todas as rotas protegidas.
6. Aplicar soft delete em contas.
7. Manter logs de auditoria para ações administrativas importantes.
8. Permitir que o usuário solicite exclusão/desativação da conta.
9. Separar dados públicos de dados privados do perfil.
10. Respeitar visibilidade configurável para orientação sexual e horários disponíveis.

---

## Regras de segurança

O Codex deve:

1. Nunca salvar senhas em texto puro.
2. Usar hash seguro para senhas.
3. Usar variáveis de ambiente para segredos.
4. Nunca commitar tokens, secrets, senhas ou chaves.
5. Validar dados de entrada no backend.
6. Sanitizar campos livres quando necessário.
7. Proteger rotas por autenticação.
8. Proteger rotas administrativas por role.
9. Implementar rate limiting quando aplicável.
10. Evitar vazamento de stack trace em produção.
11. Criar mensagens de erro seguras e compreensíveis.
12. Validar permissões no backend, não apenas no frontend.
13. Registrar ações críticas em logs de auditoria.
14. Evitar dependências desnecessárias.
15. Justificar qualquer nova dependência adicionada.

---

## Regras de autenticação

O sistema deve suportar:

- Cadastro.
- Login.
- Logout.
- Refresh token ou estratégia equivalente.
- Recuperação de senha por e-mail.
- Verificação de telefone por SMS.
- Verificação de e-mail.
- Controle de sessão.
- Controle de role: `STUDENT` e `ADMIN`.

O Codex deve garantir que:

1. Usuários não autenticados não acessem rotas protegidas.
2. Alunos não acessem rotas administrativas.
3. Administradores não usem endpoints de aluno de forma indevida, salvo quando a regra permitir.
4. Tokens sejam tratados de forma segura.
5. Fluxos sensíveis tenham validação adequada.

---

## Regras de cadastro

O fluxo de cadastro do aluno deve seguir a lógica:

1. Usuário escaneia QR Code da academia/unidade.
2. Sistema identifica academia/unidade.
3. Usuário informa telefone.
4. Sistema verifica telefone por SMS.
5. Usuário informa e-mail.
6. Sistema verifica e-mail.
7. Usuário preenche perfil.
8. Usuário aceita termos de uso e política de privacidade.
9. Sistema cria a conta.
10. Conta fica ativa automaticamente, sem aprovação manual de administrador.

O sistema deve impedir duplicidade por:

- CPF.
- E-mail.
- Telefone.

O sistema deve validar:

- CPF.
- E-mail.
- Telefone.
- Data de nascimento.
- Idade mínima de 18 anos.

---

## Regras de perfil

O perfil do aluno deve conter:

- Nome.
- E-mail.
- Telefone.
- Data de nascimento.
- Idade calculada.
- Foto.
- Gênero.
- CPF.
- Orientação sexual.
- Interesses.
- Objetivo com o app.
- Nível de treino.
- Horários disponíveis.
- Academia.
- Unidade.
- Modalidades preferidas.
- Divisão de treinos.

O usuário poderá ocultar:

- Orientação sexual.
- Horários disponíveis.

O usuário poderá alterar seus dados, exceto:

- CPF.
- E-mail, salvo fluxo seguro específico.
- Telefone, salvo fluxo seguro específico.
- Data de nascimento/idade, salvo regra administrativa.

Perfis incompletos não devem aparecer na descoberta.

Perfis sem foto não podem dar match.

---

## Regras de descoberta de perfis

A descoberta deve respeitar:

1. Mostrar apenas usuários da mesma academia/unidade, conforme regra atual do produto.
2. Não mostrar o próprio usuário.
3. Não mostrar usuários bloqueados.
4. Não mostrar usuários que bloquearam o usuário atual.
5. Não mostrar usuários já recusados.
6. Não mostrar usuários já curtidos, salvo regra específica.
7. Não mostrar usuários inativos.
8. Não mostrar usuários com perfil incompleto.
9. Não mostrar usuários soft deleted.
10. Considerar objetivo de uso do app como critério de compatibilidade.

Inicialmente, a listagem pode ser aleatória ou simples.

Algoritmos avançados devem ser tratados como melhoria futura.

---

## Regras de curtida e recusa

O usuário poderá:

- Curtir perfil.
- Recusar perfil.

Regras:

1. Curtida mútua gera match.
2. Usuário recusado não deve aparecer novamente para quem recusou.
3. Usuário bloqueado não pode ser curtido.
4. Usuário inativo não pode ser curtido.
5. Usuário com perfil incompleto não deve participar de matches.
6. Plano grátis possui limite diário de curtidas.
7. Desfazer curtida é recurso premium.
8. Desfazer match é recurso premium.

---

## Regras de match

O match ocorre quando dois usuários se curtem mutuamente.

Regras:

1. Chat só é liberado após match.
2. Usuários bloqueados não podem manter match ativo.
3. Se houver bloqueio, o match deve ser encerrado ou tornado inacessível.
4. No plano grátis, o usuário pode ter até 5 matches ativos.
5. Match pode expirar após determinado tempo sem conversa.
6. Mesmo com expiração do match, o histórico do chat pode permanecer salvo.
7. Administradores só podem visualizar dados de match dentro de critérios de moderação, segurança ou auditoria.

---

## Regras de chat

O chat deve ser interno.

Regras:

1. Chat só existe após match.
2. Usuário pode enviar texto.
3. Usuário pode enviar áudio.
4. Usuário premium pode enviar imagem.
5. Histórico da conversa deve ser salvo.
6. Usuário pode apagar mensagem para si ou conforme regra definida.
7. Mensagens apagadas devem permanecer disponíveis para moderação administrativa quando necessário.
8. Usuário pode denunciar mensagem.
9. Usuário pode bloquear outro usuário.
10. Administrador pode acessar conversas denunciadas.
11. Novas mensagens devem gerar notificação.

O chat em tempo real deve ser implementado com WebSocket ou tecnologia equivalente quando essa fase for solicitada.

---

## Regras de denúncia

O usuário pode denunciar:

- Perfil.
- Mensagem.
- Conversa.

Motivos possíveis:

- Assédio.
- Perfil falso.
- Linguagem ofensiva.
- Spam.
- Comportamento inadequado.
- Racismo.
- Outro.

Regras:

1. Denúncia deve notificar administradores.
2. Denúncia urgente deve aparecer destacada.
3. Usuário denunciado deve ser bloqueado automaticamente para quem denunciou.
4. Usuário não deve conseguir denunciar a mesma pessoa repetidamente pelo mesmo contexto.
5. Administrador pode analisar denúncia.
6. Administrador pode suspender ou banir usuário.
7. Administrador pode visualizar contexto necessário para moderação.
8. Toda ação administrativa em denúncia deve gerar log de auditoria.

---

## Regras de bloqueio

Regras:

1. Usuário pode bloquear outro usuário.
2. Usuário bloqueado não aparece mais na descoberta.
3. Usuário bloqueado não pode enviar mensagem.
4. Usuário bloqueado não pode manter interação ativa com quem bloqueou.
5. Bloqueio deve afetar match existente.
6. Bloqueio deve ser reversível apenas se essa funcionalidade for explicitamente implementada.
7. Bloqueios devem ser registrados no banco.

---

## Regras do painel administrativo

O painel administrativo deve permitir:

- Login administrativo.
- Visualização de usuários.
- Filtro por academia.
- Filtro por unidade.
- Edição de dados de aluno.
- Suspensão de conta.
- Banimento de conta.
- Soft delete.
- Visualização de denúncias.
- Tratamento de denúncias.
- Visualização de conversas denunciadas.
- Cadastro de academias.
- Cadastro de unidades.
- Métricas.
- Exportação de relatórios em Excel.
- Envio de comunicados.

O Codex deve garantir que todo endpoint administrativo valide role de administrador.

---

## Regras de planos premium

O sistema deve prever plano gratuito e plano premium/pro.

Plano grátis:

- Limite diário de curtidas.
- Até 5 matches ativos.
- Sem envio de imagem no chat.
- Sem desfazer curtida.
- Sem desfazer match.

Plano premium/pro:

- Maior limite de curtidas ou curtidas ilimitadas.
- Mais matches ativos ou matches ilimitados.
- Envio de imagem no chat.
- Desfazer curtida.
- Desfazer match.

Pagamento real pode ser implementado com Stripe em fase específica.

Não implementar pagamentos antes da base do produto estar funcional, salvo solicitação explícita.

---

## Regras de banco de dados

O banco principal será PostgreSQL.

O Codex deve:

1. Usar migrations.
2. Evitar alterações manuais diretas no banco.
3. Criar constraints adequadas.
4. Criar índices para campos de busca e relacionamento.
5. Usar soft delete em entidades importantes.
6. Usar campos de auditoria.
7. Preservar integridade referencial.
8. Evitar duplicidade de dados sensíveis.
9. Usar enums quando fizer sentido.
10. Documentar decisões relevantes de modelagem.

Entidades esperadas:

- User.
- Profile.
- Gym.
- GymUnit.
- Like.
- Rejection.
- Match.
- Message.
- Report.
- Block.
- Plan.
- Subscription.
- Notification.
- AuditLog.
- Announcement.
- SupportTicket.
- MediaFile.

A modelagem pode ser ajustada conforme a arquitetura escolhida, mas deve preservar as regras de negócio.

---

## Campos de auditoria recomendados

Sempre que fizer sentido, entidades devem conter:

- `id`
- `createdAt`
- `updatedAt`
- `deletedAt`
- `createdBy`
- `updatedBy`
- `deletedBy`
- `status`

---

## Regras de API

A API deve:

1. Usar rotas organizadas por módulo.
2. Validar entrada com DTOs/schemas.
3. Retornar erros padronizados.
4. Usar autenticação em rotas protegidas.
5. Usar autorização por role.
6. Evitar retornar dados sensíveis.
7. Usar paginação em listagens.
8. Usar filtros quando necessário.
9. Registrar ações críticas.
10. Ter documentação mínima de endpoints, se solicitado.

Endpoints administrativos devem ficar separados ou claramente protegidos.

---

## Regras para frontend mobile

O app mobile dos alunos deve ser:

- Mobile-first.
- Simples.
- Responsivo aos tamanhos comuns de tela.
- Fácil de usar.
- Focado nos fluxos principais.

Fluxos principais:

- Tela inicial.
- Login.
- Cadastro via QR Code.
- Verificação de telefone.
- Verificação de e-mail.
- Boas-vindas.
- Criação de perfil.
- Edição de perfil.
- Descoberta de perfis.
- Curtir/recusar.
- Lista de matches.
- Chat.
- Denúncia.
- Bloqueio.
- Configurações.
- Plano premium.

O Codex deve evitar criar telas sem integração ou sem propósito no MVP.

---

## Regras para painel web administrativo

O painel web deve ser:

- Responsivo.
- Protegido por autenticação.
- Acessível apenas para administradores.
- Organizado por seções.

Seções recomendadas:

- Dashboard.
- Usuários.
- Academias.
- Unidades.
- Denúncias.
- Matches/conversas denunciadas.
- Relatórios.
- Comunicados.
- Logs.
- Configurações.

O Codex deve priorizar funcionalidades úteis para demonstração do TCC.

---

## Regras de armazenamento de mídia

O sistema pode armazenar:

- Fotos de perfil.
- Imagens de chat premium.
- Áudios de chat.

O Codex deve:

1. Validar tipo de arquivo.
2. Validar tamanho.
3. Evitar arquivos executáveis.
4. Usar storage externo ou abstração para storage.
5. Nunca salvar arquivos sensíveis diretamente no repositório.
6. Usar URLs ou chaves de storage no banco.
7. Preparar estrutura para trocar provider depois.

---

## Regras de notificações

O sistema deve prever notificações para:

- Novo match.
- Nova mensagem.
- Denúncia recebida.
- Conta suspensa.
- Comunicados importantes.
- Recuperação de senha.
- Verificação de e-mail.
- Verificação de telefone.

Notificações por e-mail devem ser usadas apenas para eventos importantes.

Notificações internas podem ser implementadas em fase própria.

---

## Regras de relatórios

O painel administrativo deve permitir relatórios sobre:

- Número de usuários.
- Usuários ativos.
- Métrica de idade.
- Matches realizados.
- Denúncias.
- Horários mais procurados.
- Assinaturas premium.
- Usuários por academia/unidade.

Exportação em Excel deve ser implementada em fase própria.

---

## Testes

O Codex deve criar ou atualizar testes quando implementar regras relevantes.

Tipos de teste recomendados:

- Testes unitários.
- Testes de integração.
- Testes e2e para fluxos principais.
- Testes de validação de regras de negócio.
- Testes de autorização.
- Testes de endpoints críticos.

Fluxos prioritários para e2e:

1. Cadastro.
2. Login.
3. Criação de perfil.
4. Descoberta de perfis.
5. Curtida mútua gerando match.
6. Chat após match.
7. Denúncia.
8. Bloqueio.
9. Suspensão administrativa.
10. Exportação de relatório.

---

## Comandos do projeto

Os comandos devem ser ajustados conforme a stack definida.

Quando existirem, o Codex deve usar comandos como:

```bash
npm install
npm run dev
npm run lint
npm run test
npm run test:e2e
npm run build
```

Ou equivalentes:

```bash
pnpm install
pnpm dev
pnpm lint
pnpm test
pnpm test:e2e
pnpm build
```

Se o projeto usar monorepo, comandos devem indicar o app/package correto.

Exemplo:

```bash
pnpm --filter api test
pnpm --filter mobile lint
pnpm --filter admin build
```

O Codex deve verificar o `package.json` antes de assumir comandos.

---

## Estrutura sugerida do repositório

Caso o projeto ainda não tenha estrutura definida, usar algo semelhante a:

```txt
/
├── apps/
│   ├── mobile/
│   └── admin/
├── packages/
│   ├── api/
│   ├── database/
│   ├── shared/
│   └── config/
├── docs/
│   ├── requirements/
│   ├── architecture/
│   ├── database/
│   └── tcc/
├── .env.example
├── AGENTS.md
├── README.md
└── package.json
```

Ou, se o backend for separado:

```txt
/
├── backend/
├── mobile/
├── admin/
├── docs/
├── .env.example
├── AGENTS.md
└── README.md
```

O Codex deve respeitar a estrutura existente se ela já tiver sido criada.

---

## Padrões de código

O Codex deve:

1. Usar nomes claros.
2. Evitar abreviações confusas.
3. Separar responsabilidades.
4. Evitar arquivos muito grandes.
5. Evitar funções muito longas.
6. Evitar duplicação de lógica.
7. Criar helpers/services quando fizer sentido.
8. Usar tipagem forte sempre que possível.
9. Tratar erros explicitamente.
10. Manter consistência com o padrão existente.

---

## Padrões de commits e PRs

Quando solicitado a sugerir commit, usar mensagens claras.

Formato sugerido:

```txt
feat(auth): add student login flow
fix(match): prevent blocked users from matching
test(chat): add message permission tests
docs(project): update setup instructions
```

Tipos recomendados:

- `feat`
- `fix`
- `refactor`
- `test`
- `docs`
- `chore`
- `build`
- `ci`

---

## Definition of Done

Uma tarefa só deve ser considerada pronta quando:

1. O escopo solicitado foi implementado.
2. O código segue os padrões do projeto.
3. Não há alterações não relacionadas.
4. Dados sensíveis estão protegidos.
5. Entradas são validadas.
6. Permissões são verificadas.
7. Testes foram criados ou atualizados, quando aplicável.
8. Lint foi executado, quando disponível.
9. Build foi executado, quando disponível.
10. Erros encontrados foram documentados.
11. Arquivos alterados foram listados.
12. Pendências foram informadas.

---

## Como lidar com ambiguidades

Se uma decisão for bloqueante, o Codex deve pedir esclarecimento.

Exemplos de decisões bloqueantes:

- Stack ainda não definida.
- Banco ainda não configurado.
- Regra de negócio contraditória.
- Fluxo de pagamento real sem credenciais ou ambiente.
- Provider de SMS não definido.
- Provider de storage não definido.

Se a ambiguidade não bloquear a tarefa, o Codex deve:

1. Tomar uma decisão razoável.
2. Documentar a decisão.
3. Seguir com a implementação.

Exemplo:

```txt
Decisão tomada: como o provider de storage ainda não foi definido, criei uma interface StorageService e uma implementação local/mock para desenvolvimento.
```

---

## O que o Codex não deve fazer

O Codex não deve:

1. Implementar funcionalidades fora do escopo pedido.
2. Reescrever o projeto inteiro sem necessidade.
3. Remover código existente sem justificar.
4. Ignorar testes quebrando.
5. Ignorar erros de lint.
6. Criar dependências novas sem necessidade.
7. Comitar secrets.
8. Expor dados sensíveis em logs.
9. Expor CPF, telefone ou e-mail em endpoints públicos.
10. Misturar backend, mobile e admin na mesma tarefa sem necessidade.
11. Criar arquitetura complexa demais para o TCC.
12. Implementar pagamentos antes da fase adequada.
13. Implementar integração real com academia/catraca.
14. Tratar soft delete como exclusão física.
15. Permitir acesso administrativo sem role.
16. Permitir chat sem match.
17. Permitir match com usuário bloqueado.
18. Permitir menor de idade.
19. Permitir perfil incompleto na descoberta.
20. Criar código difícil de explicar academicamente.

---

## Ordem recomendada de desenvolvimento

O Codex deve respeitar, sempre que possível, esta ordem:

1. Preparação do repositório.
2. Configuração da stack.
3. Banco de dados e ORM.
4. Autenticação base.
5. Roles e permissões.
6. Academias e unidades.
7. Cadastro via QR Code.
8. Perfil do aluno.
9. Upload de foto.
10. Descoberta de perfis.
11. Curtidas e recusas.
12. Match.
13. Chat.
14. Denúncias.
15. Bloqueios.
16. Painel administrativo.
17. Métricas.
18. Relatórios.
19. Planos premium.
20. Notificações.
21. Observabilidade.
22. Testes e2e.
23. Deploy.
24. Documentação final do TCC.

---

## Fases recomendadas

### Fase 0 — Setup e arquitetura

Objetivo:

- Criar estrutura inicial.
- Configurar ferramentas.
- Criar documentação básica.
- Preparar ambiente.

### Fase 1 — Banco e autenticação

Objetivo:

- Criar banco.
- Criar usuários.
- Criar roles.
- Criar login/logout.
- Criar recuperação de senha.

### Fase 2 — Academias, unidades e QR Code

Objetivo:

- Criar entidades de academia e unidade.
- Criar fluxo de cadastro via QR Code.
- Associar aluno à unidade.

### Fase 3 — Perfil do aluno

Objetivo:

- Criar perfil.
- Editar perfil.
- Validar dados.
- Controlar visibilidade.
- Upload de foto.

### Fase 4 — Descoberta

Objetivo:

- Listar perfis elegíveis.
- Aplicar regras de filtro.
- Impedir perfis inválidos.

### Fase 5 — Curtidas, recusas e matches

Objetivo:

- Implementar curtidas.
- Implementar recusas.
- Criar match por curtida mútua.
- Aplicar limites do plano grátis.

### Fase 6 — Chat

Objetivo:

- Criar conversas por match.
- Enviar mensagens.
- Salvar histórico.
- Preparar envio de áudio e imagem premium.

### Fase 7 — Denúncias e bloqueios

Objetivo:

- Denunciar usuários/mensagens.
- Bloquear usuários.
- Notificar administradores.
- Criar fluxo de moderação.

### Fase 8 — Admin web

Objetivo:

- Criar dashboard.
- Gerenciar usuários.
- Gerenciar academias/unidades.
- Gerenciar denúncias.
- Visualizar métricas.

### Fase 9 — Premium e pagamentos

Objetivo:

- Criar planos.
- Aplicar limites.
- Integrar Stripe em ambiente de teste, se solicitado.

### Fase 10 — Relatórios, observabilidade e deploy

Objetivo:

- Exportar Excel.
- Criar logs.
- Preparar deploy.
- Documentar execução.

---

## Prompts para tarefas do Codex

Cada tarefa enviada ao Codex deve seguir este formato:

```txt
Contexto:
[Explique o que já existe e qual fase estamos desenvolvendo.]

Objetivo:
[Explique exatamente o que deve ser implementado.]

Escopo:
[Liste o que deve ser feito.]

Fora de escopo:
[Liste o que não deve ser feito.]

Regras de negócio:
[Liste as regras que se aplicam.]

Critérios de aceite:
[Liste como saberemos que a tarefa está pronta.]

Testes esperados:
[Liste os testes que devem ser criados ou atualizados.]

Observações:
[Inclua detalhes técnicos, se houver.]
```

---

## Tamanho ideal das tarefas

As tarefas devem ser médias.

Uma tarefa boa para o Codex deve:

- Ter começo, meio e fim.
- Afetar poucos módulos.
- Ser testável.
- Ter critérios de aceite claros.
- Não exigir decisões gigantes.
- Não implementar muitas features de uma vez.

Exemplo de tarefa boa:

```txt
Implementar endpoint de curtida de perfil, verificando se o usuário curtido existe, se pertence à mesma academia, se não está bloqueado e se uma curtida mútua deve gerar match.
```

Exemplo de tarefa grande demais:

```txt
Implementar todo o sistema de match, chat, denúncia e admin.
```

Exemplo de tarefa pequena demais:

```txt
Criar botão de curtir.
```

---

## Checklist antes de terminar uma tarefa

Antes de finalizar, o Codex deve verificar:

- [ ] A tarefa foi implementada dentro do escopo.
- [ ] Não foram feitas alterações não solicitadas.
- [ ] O código compila.
- [ ] O lint foi executado, se existir.
- [ ] Os testes foram executados, se existirem.
- [ ] Testes novos foram adicionados, se necessário.
- [ ] Dados sensíveis não foram expostos.
- [ ] Rotas protegidas exigem autenticação.
- [ ] Rotas administrativas exigem role de admin.
- [ ] Soft delete foi respeitado.
- [ ] Erros foram tratados.
- [ ] Documentação foi atualizada, se necessário.
- [ ] Arquivos alterados foram listados.
- [ ] Pendências foram informadas.

---

## Observações finais

Este projeto é um TCC, portanto o código deve equilibrar:

- Boa arquitetura.
- Simplicidade.
- Segurança.
- Clareza.
- Demonstrabilidade.
- Escopo realista.

Sempre que houver conflito entre uma solução muito complexa e uma solução simples suficiente para o MVP, priorizar a solução simples, desde que ela não comprometa segurança, privacidade ou regras centrais do sistema.